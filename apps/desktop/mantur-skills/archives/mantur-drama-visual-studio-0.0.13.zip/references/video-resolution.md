# 视频分辨率设置与中途修改

Seedance 2.0 与 WAN 3.0 共用项目分辨率 `project.json.video.resolution`。新项目必须明确选择 `480p / 720p / 1080p`，旧项目缺失时才兼容读取为 `480p`；`2k` 及其他超限值直接拒绝，不自动转换，历史产物保留。实际远端请求仍须通过当前合同校验和报价。

视频生成的既有例外仅限 `seedance / seedance-fast / seedance-mini` 的 `1080p` 请求：在实时输入 Schema 的本地副本中补充 resolution 枚举，保留其他字段约束、原始 Schema 及收据，1080p 原值进入报价与提交；本地通过不等于远端支持。Seedance 的其他档位和 WAN 的所有档位均按原始实时 Schema 校验。不得为 WAN 补充分辨率／模型枚举，不扩展到 2k 或其他档位，也不恢复算子指纹白名单。

## 初始化及分镜准备

开局配置汇总中把分辨率与模型、比例和风格一起提供选项，不询问制作范围。新项目未明确分辨率不得完成初始化；模型初始化后固定，分辨率可通过下述本地动作修改。

`prepare-clip-compilation` 自动读取项目分辨率并在私有 candidate.compilation_parameters 固化。描述文件可省略 parameters.resolution；显式值与项目已配置值不同返回 `CLIP_PROJECT_RESOLUTION_CONFLICT`，不静默改用旧参数。旧项目缺字段时允许描述文件显式值，否则补 480p。WAN 同时保持 5–15 秒和 9:16 默认值。

已准备的分镜操作继续使用固化参数；更改项目默认值不重写已准备、报价、获批或提交的分镜操作。恢复用原 operation_id；同一 generation_intent 不得偷换新分辨率。需要改变尚未提交的分镜编译请求时另建 generation_intent 并重新报价批准。旧操作缺固化字段时恢复原归档描述文件的行为。

原操作尚待生产清单确认时，使用 `resume-clip-compilation --operation-id <原ID> --manifest-review <原绑定的确认文件>` 继续；不为恢复原参数重新 prepare。视频报价、提交和胶囊始终采用各 Clip `请求体模板JSON.metadata.resolution`，不在提交时用项目默认值覆盖模板。WAN 原始 size 在导入时转换；不修改平台原始 JSON/XLSX/Job。

## 修改范围与命令

用户说“后续改 720p”但范围不清时，澄清是否同时修改已编译的未提交 Clip；用户已明确范围不重复确认。两种范围：

- 仅后续新准备的分镜：更新项目默认值，传空 clip_ids。
- 同时修改指定未提交 Clip：更新项目默认值并列明 clip_ids；只改这些基础模板，不扩展为整集或全项目。

先进行本地预览：

```text
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" inspect-video-resolution-change --resolution 720p
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" inspect-video-resolution-change --resolution 720p --clips CLIP-EP01-001,CLIP-EP01-002
```

取返回的 confirmation_binding，依据用户明确的修改指令增加 `user_confirmed:true`，存入项目内描述文件（Schema: `schemas/video-resolution-change.schema.json`）。这不是费用批准，也不需要用户重复授权同一范围。

```text
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" apply-video-resolution-change --input input/resolution-change.json --no-write
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" apply-video-resolution-change --input input/resolution-change.json
```

动作不联网、上传、报价或生成。目标 Clip 存在提交、未知提交、历史 Run/视频或已采用记录时拒绝该范围；用户若要重新生成已提交/已完成 Clip，须单独安排新生成流程，不通过此动作覆盖历史。future_only 仍可执行，既有任务照原请求恢复。

## 持久化与兼容

修改前保存描述文件、项目和受影响报告原件到 `runtime/video-resolution-changes/<描述文件摘要>/`。新工作报告写入 `results/clip-active/resolution-<摘要>.json`，在生产共用发布锁内复核来源和提交状态，以一次原子 project.json 写入同时发布默认分辨率和报告指针。v1/v2 原报告不重写，素材、模型、真实尾帧、Run、操作、批准文件及交付记录不修改。

选中 Clip 更新模板 resolution，校验回到待校验、用户批准状态回到未报价；明确驳回保持驳回。旧实际请求仅作历史，下一次必须重新物化和报价，使用新生成意图/批次并获费用批准。新模板摘要会使旧操作/批次批准失效；同一批次含修改项时整批需重新准备，不能继续套用旧总价。

第一次修改保存项目私有 `video_resolution_binding={resolution:<原值或null>,video_present:<原video对象是否存在>}`。它只保留旧请求/Run 摘要中的默认分辨率基线，不是新的生产配置；实际分辨率仍绑定模板。其他视频策略和模型变化仍参与校验。后续修改不改基线，因此仅改默认值不会使未改 Clip 的原批准、真实尾帧或交付失效。不得手工编辑此兼容字段或批量重算历史摘要。

`workflow_state.video_resolution_changes` 保存已应用描述文件摘要及范围。重复执行仅重试快照刷新，不再次修改。快照失败报告“配置已保存，快照刷新失败”；恢复刷新并回读同 revision 的 Manifest、Clip 参数胶囊后报告完成。页面保持只读。
