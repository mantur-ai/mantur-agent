# 视频创作风格合同

新项目初始化必须在“水果剧”“AI 仿真人剧”“自定义”中明确选择一种视频创作风格。预设在项目中只保存稳定 ID 和版本：`fruit-drama-3d` 对应“水果剧”，`ai-photoreal-live-action` 对应“AI 仿真人剧”；完整提示词属于 Runtime 私有 v1 文案，不向用户、Manifest、只读快照、HTTP API 或看板回显。自定义风格保存用户文本，整段只去除首尾空白、保留内部格式，不能为空且最长 12,000 字符。

`project.json.creative_style` 是结构化选择，不由 `production_brief` 替代。新项目初始 revision 为 1，并保存私有选择收据与不可变 revision 收据。旧项目缺少该字段时继续按未指定风格运行，不迁移、不阻断、不主动补问；只有用户主动设置后，新操作才绑定风格。

Runtime 使用唯一解析器取得用户标签、内部提示词、revision 与提示词 SHA-256，传播规则固定如下：

- 资产提取：追加到算子 `projectStyle`；`visualNegative` 仍只承载明确禁止内容。
- 平台生图和 Agent 内置生图：最终 `generation_prompt` 按“资产主体提示词 → 参考素材强制约束 → 私有风格后缀”组成。操作或审核私有记录保存风格 binding；恢复原操作不重复追加。
- Seedance/WAN 分镜：项目分辨率写入 `resolution`，项目比例写入 `ratio`，风格提示词写入 `visualStyle`；`visualNegative` 与 `hardConstraints` 继续保持各自语义。
- 视频生成：只消费已编译请求模板，不再追加风格，避免重复提示词。

`production_brief` 仍可补充节奏、画面细节、台词、声音、素材使用和禁止内容；普通视觉细节可以叠加，但不得静默替换结构化风格。与风格冲突且无法确定优先级时，在准备受影响的新操作前询问。

## 初始化结构

预设示例：

```json
{"creative_style":{"schema_version":1,"mode":"preset","preset_id":"fruit-drama-3d","preset_version":1,"revision":1}}
```

自定义示例：

```json
{"creative_style":{"schema_version":1,"mode":"custom","custom_text":"低饱和手持纪实风格\n保留自然环境光","revision":1}}
```

不要把预设完整文案写进用户可见配置，也不要让用户填写 `preset_version`、`revision` 或提示词摘要；这些由 Runtime 固化。

## 修改流程

风格变更必须先预览再应用，不直接编辑 `project.json`：

1. 保存只含 `schema_version` 和 `creative_style` 的描述文件，执行 `inspect-creative-style-change --input <文件>`。
2. 向用户展示旧／新标签、待失效的未提交资产提取／生图／分镜操作，以及已完成资产可能产生视觉不一致但不会被删除或自动重做。
3. 用户确认后，把返回的 `confirmation_binding` 与 `user_confirmed:true` 保存为应用文件，执行 `apply-creative-style-change --input <文件>`；可先加 `--no-write` 复核。

预设变更描述：

```json
{"schema_version":1,"creative_style":{"mode":"preset","preset_id":"ai-photoreal-live-action"}}
```

自定义变更描述：

```json
{"schema_version":1,"creative_style":{"mode":"custom","custom_text":"电影化黑色幽默，低饱和冷暖对比"}}
```

应用时 Runtime 原子更新项目、递增 revision，并保存不可变变更收据。风格变化不改历史资产、分镜、批准、已提交任务或视频；旧风格下已准备／已报价但未提交的资产提取、生图和分镜操作返回 `PROJECT_CREATIVE_STYLE_CHANGED`，必须按新风格重新准备并重新报价。已提交操作继续使用原请求恢复，不能改写或重新追加风格。
