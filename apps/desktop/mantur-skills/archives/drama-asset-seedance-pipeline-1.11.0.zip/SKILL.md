---
name: drama-asset-seedance-pipeline
title: 全自动漫剧生产线
description: 全自动漫剧生产线：跟随当前ManturHub的.ai或.cn环境并锁定单站运行；接收完整剧本、任意数量风格参考图及可选既有图片/音色，调用剧本资产提取与剧本分镜提示词生成算子，Agent有原生生图能力时使用该能力、没有时使用当前站图片生成算子，缺少用户音色时从永久公开预制音色库做可审计匹配，通过飞书 CLI 建立和增量回填多维表格，默认通过当前站ManturHub按集→场次→Clip生成Seedance视频，同场串行引用真实尾帧、异场默认五路并行，最后按集导出视频片段ZIP，并可选生成剪映专业版便携草稿ZIP。用户说“全自动漫剧生产线、跑新剧、拆资产、生资产图、配音色、建多维表格、拆分镜、生成整部剧视频、导出每集片段、交付剪映草稿”时使用。
category: 漫剧制作
version: 1.11.0
triggers:
  - 全自动漫剧生产线
  - 跑新剧
  - 批量跑剧
  - 拆剧本资产
  - 生成资产图
  - 匹配角色音色
  - 建剧本多维表格
  - 生成分镜提示词
  - 生成整部剧视频
  - 导出每集片段
  - 交付剪映草稿
uses_operators:
  - op.drama.asset-extract
  - op.drama.clip-seedance-compile
  - op.image.generate
  - op.video.understand-v2
  - op.voice.design
  - op.audio.generate
  - op.video.generate
---

# 全自动漫剧生产线

两个算子是事实编译器；本 Skill 负责资产文件、视觉判断、生图、飞书、付费确认、视频执行、尾帧承接和本地交付。本期没有服务端调度层；剪映草稿是可选的本地确定性 action，不是新算子。Skill 安装在用户本地，业务算子运行在 ManturHub；Agent 必须把状态持久化到项目目录，不能依赖一个长连接或聊天上下文记忆。

本 Skill 支持 `https://hub.mantur.ai` 与 `https://hub.mantur.cn`，但一次项目运行只能使用一个站点。环境解析顺序固定为：显式 `MANTURHUB_BASE` → 当前 Skill 安装记录的 `base_url` → CLI 配置 `baseUrl` → 默认 `.ai`。预检输出选中的 `manturhub_base` 和来源后，把它持久化到项目状态；后续上传、算子查询、报价、提交、轮询、Skill安装和状态查询全部显式使用同一基址。当前环境与项目已锁定环境不一致、安装记录同时指向两站、任务或poll URL来自另一站时必须阻断，不得自动跨站。

资产提取和分镜编译都是长时异步任务。使用 `manturhub run <算子ID> --json-file <参数文件> --no-wait` 提交，拿到 `task_id/poll_url` 后立即持久化，再按 [异步等待与轮询合同](references/async-wait-policy.md) 查询状态；不要让一次终端或 Agent 工具调用一直占着连接。**等待60秒没有终态是正常运行，不是错误。** 只有任务状态明确进入 `failed/error/cancelled` 才能把任务判为失败；单次查询超时或网络错误只表示本次状态读取失败，不得重新提交、换幂等键或宣布算子失败。

把当前项目根目录的绝对路径记为 `PROJECT_DIR`。Agent 启动或恢复工作流时，先运行 `manturhub skill run drama-asset-seedance-pipeline --project "$PROJECT_DIR" -- --stage <当前阶段> --deliverable <episode-clips|jianying-drafts>`；可重复 `--deliverable` 同时选择两种交付。用户只选择交付类型，不直接接触内部 action。该命令验证可信安装和当前阶段依赖并返回下一步，不会另起后台调度器。只需单独诊断时使用下述 `skill doctor`。

版本绑定以包内 `VERSION_LINK.json` 为机器可读来源；同时阅读 [references/version-compatibility.md](references/version-compatibility.md)。

## 0. 硬预检与输入

先完整阅读：

- [references/input-preparation.md](references/input-preparation.md)
- [references/reference-routing.md](references/reference-routing.md)
- [references/visual-matching.md](references/visual-matching.md)
- [references/base-schema.md](references/base-schema.md)
- [references/preset-voice-library.md](references/preset-voice-library.md)
- [references/runtime-and-export.md](references/runtime-and-export.md)
- [references/async-wait-policy.md](references/async-wait-policy.md)
- [references/video-concurrency-policy.md](references/video-concurrency-policy.md)
- [references/jianying-draft-delivery.md](references/jianying-draft-delivery.md)
- [references/third-party-audit.md](references/third-party-audit.md)

本 Skill 要求 ManturHub CLI `>=0.10.0`、已完成 `manturhub login`，并要求 Agent 对一个可持久化的项目目录具有读写权限；所有本地确定性动作都由 CLI 的受控 Skill runtime 执行，不要求用户安装额外解释器。项目需要创建或更新飞书 Base 时，另须安装 `lark-cli` 并完成授权；缺少它属于飞书依赖问题，不是 Agent 客户端问题。按本次阶段运行 `manturhub skill doctor drama-asset-seedance-pipeline --project "$PROJECT_DIR" -- --stage extraction|asset-production|clips|video`。Agent 确实提供可调用的原生生图能力时，资产补全阶段加 `--native-imagegen`；没有时不加，预检会在启动阶段选择当前站点的 ManturHub `op.image.generate`。Agent 同时具有原生图片和视频理解能力时可声明 `--native-image --native-video`；否则预检选择当前站 `op.video.understand-v2`。旧 CLI 必须先明确升级，不能改走其他入口或静默降级。只有该阶段需要的算子离线才阻断；视频算子离线不能阻断纯资产提取。读取预检结果中的 `manturhub_base`，每次调用前以 `MANTURHUB_BASE="$PROJECT_MANTURHUB_BASE" manturhub describe` 获取当前站 live schema，以同一基址运行 `manturhub quote/run/status/upload`。真实密钥不得进入 Skill、命令历史、Base 或日志；一个站点的Key不能拿到另一个站点使用。

预检结束时把 `image_provider` 和 `video_provider` 写入 `<project>/.pipeline-state/project.json`。图片供应路径只按“Agent 原生能力是否存在”选择一次：声明了 `--native-imagegen` 为 `native_agent_imagegen`，否则为 `manturhub:op.image.generate`；视频默认固定为 `manturhub:op.video.generate`。这不是运行失败后的自动 fallback。供应路径选定后若调用失败，必须返回真实错误并停止对应资产或场次链，不得静默换 provider、换模型或生成替代数据。

恢复旧项目时，`codex_imagegen` 只作为 `native_agent_imagegen` 的历史别名识别。预检会明确报告迁移要求，不能静默改成另一家 provider。当前 Agent 仍有原生生图能力时，内部执行 `migrate-image-provider --to native_agent_imagegen --confirm-native-imagegen`，只规范名称并写入 `provider_migrations` 审计；若当前 Agent 没有原生生图能力，改用当前站 ManturHub 属于实际 provider 变更，必须以 `--to manturhub:op.image.generate --confirm-provider-change` 明确确认并留下审计。新项目只写规范值。

确认并持久化 `<project>/.pipeline-state/project.json`：剧名、`manturhub_base`、环境来源、剧本本地路径与公网URL、制作集数、交付截止阶段、参考图目录、既有资产目录、是否生图、是否生视频、Base URL、画幅、视频模型/分辨率、视频场次链并发数、Clip数量软目标、每集时长强下限目标与软上界、单Clip硬范围、对白语言、15秒对白词数、缺音色策略、预制音色是否允许自动绑定、同项目音色是否允许复用、世界观和硬限制。恢复旧任务时先核对 `manturhub_base`；不同站点的task_id、poll_url、quote_id和余额记录不可复用。默认仅在用户未指定时使用：视频并发5条场次链；4–6个Clip、目标5；每集60秒强下限目标/90秒软上界；Clip 5–15秒；英文约15秒40词；9:16；Seedance 2.0标准版480p；缺音色按“用户音色→预制音色库→显式AI直出”决策。最后一步只在项目策略预先允许时使用，不是运行失败后的fallback。

风格参考图是开放目录，可以是任意数量和任意用途，不固定四张，不固定男女。给每张图建立 `REF-001...`，保存原附件、checksum、公网原图URL、用户说明与视觉事实。每个资产绑定必须使用 `reference-routing-v3` 为每张所选参考显式标注 `style/palette/material/rendering/layout/identity/wardrobe/structure` 用途；用途不清就阻断生图。资产提取时传全部参考图；生图时只传当前资产相关子集。`style/palette/material/rendering/layout` 只允许影响美术语言与版式，严禁复制参考图主体、人物身份、服装、背景、道具、文字、Logo或剧情动作。任何用途都禁止把参考图作为画中画、相框、屏幕、海报、卡片、缩略图、拼贴面板、贴花或纹理直接放进新图。

## 1. 资产提取

调用 `op.drama.asset-extract` v2.4.3 或兼容的更高版本。传 `script_url` 或 `script_text`、项目风格、负面要求和 `reference_images`；Worker会把完整剧本统一固化为文件，通过 Responses API 的 `input_file` 单次调用，并以严格 JSON Schema 返回资产结构。使用稳定幂等键和 `--no-wait` 只提交一次；先保存 `task_id/poll_url`，再按当前 `.ai/.cn` 的 `extraction` 等待策略异步轮询并按变化回填进度。60秒无终态不得报错，也不得重提。不得把剧本切批或改走 Chat Completions。

验收四张表：`项目美术规范 / 角色资产 / 场景资产 / 道具资产`。群众并入角色资产，不建关系表和群众表。每条资产必须有：稳定资产ID、基础资产ID、变体、适用集数/场景、证据、提示词、负面提示词、生成策略和 `变体规则JSON`；角色另有音色策略。V01 的基础资产ID为自身，V02+ 指向同实体V01。`变体规则JSON` 是唯一新增的机器决策列，固定保存 state_tags/applicable_scenes/forbidden_tags/transitions/persistence；旧自然语言列继续给人审阅，不能拿备注替代机器规则。V02+ 没有任何可判断正向规则时资产阶段不得通过。提取阶段只产出文本，媒体字段必须为空。

`reference_required` 表示进入分镜前必须匹配或生成参考图；`defer_to_video` 只允许一次使用、非变体、非关键、无需跨镜头连续性的资产，后续不创建 `@Image`，由视频模型按文字随机生成。V02+ 一律 `reference_required`。

## 2. 资产补全与飞书 Base

通过 `lark-cli` 新建或增量更新同一个 Base。必须保留旧版四表结构，并按 [base-schema.md](references/base-schema.md) 增加附件、纯文本URL、参考绑定、生成来源、执行ID和验收状态；后续再添加 `Clip总表`、`Seedance2.0请求体`。建表或写记录前先运行 `manturhub skill exec drama-asset-seedance-pipeline base-media-contract --project "$PROJECT_DIR"` 和 `manturhub skill exec drama-asset-seedance-pipeline storyboard-status-contract --project "$PROJECT_DIR"`：按前者补齐附件字段，按后者把所有状态列创建为固定中文单选字段。任何状态写入必须使用合同枚举；旧英文状态先通过 `normalize-storyboard-statuses` 的字段级映射迁移，未知值直接阻断，不能让Agent临时创建新选项。不得删除用户列。URL与JSON必须是纯文本，不能写Markdown链接。

### 2.1 匹配用户资产

库存记录本地路径、checksum、媒体类型和文件名；看实际图片/视频内容，不能只凭文件名。用用户声明→剧本名称/别名/证据→视觉内容→文件名/目录的证据顺序匹配。唯一匹配才回填 `user_uploaded`；多解或冲突标 `unresolved` 并等待用户确认。音频需核实说话人和可用时长，再转公网URL和附件。

### 2.2 生成缺失资产

用户要求生资产时，先按 `reference-manifest.json` 运行 `manturhub skill exec drama-asset-seedance-pipeline validate-references --project "$PROJECT_DIR" -- "$PROJECT_DIR/reference-manifest.json"`。只有 `reference-routing-v3` 且每张参考用途完整时才能继续；把返回的每个资产 `generation_guards.mandatory_prompt_constraints` 原样并入该资产生图提示词。提示词必须结合资产行提示词、项目风格和所选参考图的可见特征，并明确“参考图仅作为外部条件，不得作为图中内容出现”；调用时同时传入这些原图。角色V02+以已验收V01图为第一身份参考，只继承身份与明确变体，再加相关风格图。先生成少量角色/场景测试图，用户确认且视觉验收没有参考图直嵌或无授权内容复制后才批量并发。

每个资产必须在生成前确定唯一的 `primary_layout_source`。有参考图时，主参考图决定输出画布方向和宽高比；其他参考图只提供身份、材质、服装或美术风格，不能改变画幅。目标宽高比与主参考图偏差不得超过1%。角色V02+默认以已验收V01/基础资产作为第一张参考并继承其画幅；用户若明确指定另一画幅，先更新绑定记录再生成。多张参考图横竖方向混合且没有明确主参考时必须阻断，不能随机选择。没有任何参考图时才使用资产模板默认画幅。资产图画幅与最终视频画幅是两个独立概念，不能因为视频为9:16就把横版角色设定板或四宫格场景改成竖版。

- `image_provider=native_agent_imagegen`：每张图调用当前 Agent 的原生生图能力，把当前资产的真实本地参考图作为参考输入；全新文生图不传参考路径。
- `image_provider=manturhub:op.image.generate`：先用 `manturhub upload` 把当前资产的参考原图转成匿名可读URL；实时 `describe/quote`，用户确认本次费用后调用 `op.image.generate`。无参考图用 `mode=generate`；有参考图用 `mode=edit` 和 `images[]`。默认 `n=1`，尺寸按主参考图宽高比选 live schema 中最接近值，画质和引擎由用户要求决定。

Agent 没有原生生图能力时使用 ManturHub 是启动阶段的能力选择；Agent 原生能力调用失败后不得自动改投 ManturHub，ManturHub 调用失败后也不得伪装成本地成功。

提示词必须明确写出主参考图的横版/竖版/方形方向和目标宽高比或尺寸。每张图是一个原子事务：生成→本地规范命名→运行 `manturhub skill exec drama-asset-seedance-pipeline validate-aspect-ratio --project "$PROJECT_DIR" -- <主参考图> <生成图>`→视觉验收→上传公网对象→验证图片Content-Type→Base附件/URL/来源/执行ID/状态回填→读回确认。画幅校验失败的图不得上传、不得写为已完成、不得发群；如需重新付费生成，必须重新报价并获批，不能静默重试。失败保持明确，不借用其他身份图片。`defer_to_video` 可以保持空图，但必须显式写“可延后”，不能与遗漏混淆。

### 2.3 音色

严格按以下优先级处理，每一步都记录来源和理由：

1. 用户明确提供并唯一匹配的音色最高优先。上传原附件、转公网URL、验证可播放后回填；不得被预制音色覆盖。
2. 缺少用户音色且项目允许预制匹配时，使用包内 `assets/voice-library/catalog.json`，通过 `manturhub skill exec drama-asset-seedance-pipeline match-voice --project "$PROJECT_DIR" -- <角色声线JSON>` 执行确定性匹配。先把角色资产中的 `gender/age_range/role/personality/voice_description` 规范化成声线呈现、年龄感、音域、核心音色、表达倾向和角色标签，再确定性打分。只允许 `matched` 自动绑定；`review_required/unresolved/no_candidate` 必须保持未绑定或让用户试听选择，不能强行取第一名。
3. 同一 canonical character 的V01及外观变体默认锁定同一 `preset_voice_id`；只有剧本文字明确出现童年/老年、机械化、变声或其他声音状态切换时，才能新增音色变体并保存证据。不同主要角色默认不得复用同一预制音色；群众/一次性角色只有项目明确允许时可复用。
   可以并行计算各 canonical character 的候选分数，但最终绑定必须先按角色重要度做一次全局冲突消解，再把已占用ID传给后续匹配；不能让并发竞态把同一嗓音分给两个主要角色。
4. 库中 `待试听确认` 的条目永不自动绑定。每次实际引用前检查 catalog 条目 `active=true`、稳定URL无query、HTTP可播放、MIME为音频，并记录 catalog/match-policy 版本和checksum。匹配结果必须保留 `voice_id/asset_id/public_url/sha256`，不能只记录一个音色名称。
5. 用户音色、预制音色和定制生成音色一旦绑定，都要把可播放音频下载到项目缓存并校验MIME、时长和checksum，再通过 `lark-cli` 上传到角色资产行的“音色原文件/voice attachment”附件字段；“音色URL/voice URL”继续保存真正用于模型请求的匿名公网纯文本URL。预制音色的永久catalog URL不能被飞书附件下载地址替换。
6. 用户要求定制生成音色时，实时 `describe/quote` `op.voice.design` 与 `op.audio.generate`，确认费用后生成可用参考音频并回填；不要把仅有的 `voice_id` 当成 Seedance 的音频URL。
7. 只有项目事先允许AI直出且没有安全匹配时，才把该角色写为 `ai_direct`；不写 `@Audio/reference_audio`，视频请求保持 `generate_audio=true`。预制匹配或上传失败不能静默改成AI直出。

角色音色匹配的完整合同见 [preset-voice-library.md](references/preset-voice-library.md)。

如果用户只要资产，到这里结束。

## 3. 分镜与请求体模板

资产验收后调用 `op.drama.clip-seedance-compile` v2.4.0 或兼容更高版本。传完整剧本、已补全资产JSON、制作集数、Clip软目标、每集时长强下限目标与软上界、单Clip硬范围、对白语言与语速、画幅、分辨率、视频模型、缺音色策略、美术正负要求和其他硬限制。使用稳定幂等键和 `--no-wait` 只提交一次；持久化 `task_id/poll_url` 后按当前 `.ai/.cn` 的 `clips` 等待策略轮询，60秒无终态只表示仍在处理。Worker必须把完整剧本作为 `complete-script.md`、完整资产清单作为 `complete-assets.json`，通过 Responses API 的两个 `input_file.file_data` 加制作要求进行一次模型调用；不得把剧本或资产清单正文压缩进普通提示词，也不得把对象存储 `file_url` 交给上游下载。模型以严格且禁止空集/空Clip的 JSON Schema 返回紧凑分镜；不得按集拆调或改走 Chat Completions。资产媒体URL尚未补齐时也必须完整输出语义分镜，缺失资产门禁由确定性编译器生成，不得返回空episodes。幂等重放必须返回 `idempotent_replay=true` 且 `usage.billable_units=0`，不得重复扣费。

层级固定为 `集 → 场次组 → Clip`，一条Clip就是一个视频，不再增加Cut。模型决定剧情拆分、资产选择和台词翻译；代码确定 `Clip ID`、引用编号和请求体。每集Clip数是软目标；每集时长采用“下限强引导、上限宽容”：默认60–90秒时同一次模型输出优先规划到70–85秒安全区，不能为了90秒上界删剧情，内容过长允许超出。模型只调用一次；若结果仍偏短，编译器只能在现有Clip的单Clip上限内向上分配秒数，不得缩短、删剧情、增加虚构剧情或触发第二次模型调用。单Clip模型时长范围仍是硬限制。提示词必须覆盖场景、人物、动作、运镜、英文对白、音效和世界观，并精确以 `不要背景音乐，不要字幕。` 结尾。

分镜结果中的 `quality_report.duration_planning` 是时长审计事实源。回填Base时必须保存每个Clip的模型原始时长、补足秒数，以及每集模型原始总时长、最终总时长和时长状态。最终仍低于用户最低目标时标记“低于最低目标·需审核”，但不自动重调模型；超过软上界时标记“超过软上界·保留完整剧情”，不自动压缩。

每个已绑定用户/预制/定制音色的说话角色，都必须在对白处以 `@ImageN @AudioM 角色名`（无角色图片时至少 `@AudioM 角色名`）出现；同一请求的 `metadata.content` 必须包含对应的 `{"type":"audio_url","audio_url":{"url":"<voice URL>"},"role":"reference_audio"}`。`@Audio1...N` 的编号严格按 `metadata.content` 中 `audio_url` 项的出现顺序生成，URL必须等于角色资产行的公网 `voice URL`。已匹配预制音色不得继续出现在 `missing_voice_assets`，也不得标为 `ai_direct_voices`。

写回两个Sheet，Clip ID一一对应：

- `Clip总表`：含场次组、连续性模式、前序Clip、`变体决策JSON`、连续性冲突、缺失/延后资产和最终提示词。`变体决策JSON` 是唯一新增的分镜机器决策列；不要为变体再创建多套状态列。
- `Seedance2.0请求体`：`请求体模板JSON` 是编译产物；`实际请求体JSON` 只能在视频提交前写。模板必须在 `metadata` 内包含 `return_last_frame: true`，并包含 `metadata.content/resolution/ratio/generate_audio/seed`。同场后续Clip只记录 `pending_previous_tail`，此时不得伪造尾帧URL。

如果 `missing_assets` 或 `missing_voice_assets` 非空，禁止进入视频；`deferred_assets` 和 `ai_direct_voices` 是允许的显式策略。任何Clip的 `校验状态` 不是“校验通过”、`连续性冲突` 非空，或缺少 `变体决策JSON` 时，也必须阻断视频队列；复用现有“校验状态/连续性冲突”，不得创建新的变体状态枚举。

## 4. 视频生成（Agent 编排，无服务端调度）

用户批准视频费用后才执行。生成 `scene-chain-plan.json`：

```bash
manturhub skill exec drama-asset-seedance-pipeline plan-scenes --project "$PROJECT_DIR" -- clip-rows.json --requested-concurrency "$REQUESTED_VIDEO_CONCURRENCY" --concurrency "$EFFECTIVE_VIDEO_CONCURRENCY" --output scene-chain-plan.json
```

### 4.1 并发设置合同

`video_concurrency` 的单位是**场次链**，不是Clip、剧集或模型线程。默认值为5，表示整个项目同时最多有5条 `(episode, scene_group)` 场次链处于视频生成/轮询中；同一条链一次只能提交1个Clip，必须拿到真实尾帧后才提交下一个。不同场次链互不依赖，可以并行。

用户可把并发配置为1–20；Agent在视频阶段通过 `--video-concurrency <N>` 把请求值写入预检与项目状态，并把按live schema、QPM、余额和用户限制收敛后的有效值传给 `plan-scenes --concurrency <N>`。不得把“并发5”解释成同一场景同时提交5个Clip，也不得在多个Agent进程各开5路造成全局超限。超过有效并发的场次链按 `episode → scene_group` 稳定排队；任一链完成或失败释放槽位后，队首进入。单链失败只阻断该链，其他活动链和队列继续。完整合同见 [video-concurrency-policy.md](references/video-concurrency-policy.md)。

每个Clip提交前：

1. 场次首Clip从模板直接物化；同场后续Clip必须先等前序完成并取得真实 `last_frame_url`。
2. 运行 `manturhub skill exec drama-asset-seedance-pipeline materialize-video --project "$PROJECT_DIR" -- <模板JSON> [--needs-previous-tail --previous-tail-url <真实尾帧URL>] --output <实际请求JSON>`，把上一条尾帧作为最后一个 `metadata.content` 图片引用，并在固定结尾前加入连续性指令；动作会确认 `metadata.return_last_frame=true`。
3. 重新校验 `@Image/@Audio` 顺序、URL、模型媒体上限和时长，再对**实际请求**报价。请求变化或报价过期必须重报。
4. 运行 `manturhub skill exec drama-asset-seedance-pipeline materialize-video-params --project "$PROJECT_DIR" -- <实际请求JSON> --output <算子参数JSON>`，把实际 Seedance 请求确定性映射为 live `op.video.generate` 参数；默认只调用 ManturHub，不直连 SumOne。映射结果必须包含 `return_last_frame=true`，并保持图片、音频、时长、画幅、分辨率、随机种子和音频策略一致。
5. 只提交一次，先确认返回的 `poll_url` 与项目 `manturhub_base` 同源，再持久化 ManturHub `task_id/poll_url`；网络不明或轮询暂时失败不得新建任务。终态后保存完整响应，要求官方 `video_url` 与 `last_frame_url`。把两个公网文件下载到本地并校验MIME后，用 `lark-cli base +record-upload-attachment` 分别上传到“成片附件”和“尾帧附件”；同时把原始公网URL以纯文本写入“成片URL”和“尾帧URL”。四个字段读回均非空后，才能把生成状态写为完成；不得把URL或本地路径直接写进附件字段。

如果上游确实未返回尾帧，只有 live 视频算子明确声明“本地提取尾帧”并在结果里标 provenance 时才可使用；Skill 本身不得伪造成功尾帧。场次链前序失败只阻断本链，其他场继续。

飞书只做查看、审核和审计，不直接承担动态JSON、轮询或视频调度。

## 5. 按集导出

### 5.1 视频片段 ZIP

全部视频终验后，将下载完成的本地文件写成 manifest（`clip_id/episode/order/video_path/status=completed`），运行：

```bash
manturhub skill exec drama-asset-seedance-pipeline export-episodes --project "$PROJECT_DIR" -- completed-clips.json --output-dir exports
```

每集输出一个按Clip顺序命名的ZIP。上传ZIP并写入交付索引或Base。

### 5.2 可选剪映草稿 ZIP

仅当用户通过 `skill run` 选择 `--deliverable jianying-drafts` 时执行。完整合同见 [references/jianying-draft-delivery.md](references/jianying-draft-delivery.md)。输入必须列出每集全部目标 Clip 和完成结果；内部 action 按 `episode_number → scene_index → clip_index` 排序，不采用表格行顺序。每集全部 Clip 完成、素材 SHA-256 一致且纯 JS 解析出实际时长后，才生成一个便携 ZIP。

第一版仅支持明确 profile `jianying-macos-5.9`。剪映 6.0+ 的加密/新版草稿及其他未知版本一律失败关闭。默认只生成 ZIP，不写用户剪映目录。目标机器导入时必须检测本机剪映专业版 5.9.x、复制包内素材、重写本机绝对路径，并由用户明确确认 `--confirm-write` 后才能写入 `com.lveditor.draft`；不得覆盖已有草稿。

草稿固定为单主视频轨、按顺序硬切，保留每个 Clip 边界和视频自带音轨；不加字幕、BGM、自动转场、花字、贴纸或模板。ZIP 内含草稿目录、`assets/video/` 全部本地视频、`manifest.json`、`validation-report.json` 和 `IMPORT.md`，不得长期依赖签名 URL。生成后把每集交付写回现有“项目文件”表，不新建 Sheet。

## 完成门禁

只有以下全部满足才可报相应阶段完成：

- 资产：四表可读、ID/基础ID/变体/策略/证据完整；required资产图片已匹配或验收，参考用途为v3显式绑定，生成图未包含参考图直嵌或style-only参考的主体/背景/道具/文字/Logo复制，画幅已通过主参考图一致性校验；每个说话角色具有用户音色、可审计预制匹配、明确待确认或显式AI直出中的一种状态，已绑定音色同时具有Base附件和公网URL，主要角色无意外音色冲突；Base读回一致。
- 分镜：两表一一对应、制作范围完整、台词说话人正确、请求模板URL纯文本、`metadata.return_last_frame=true`、缺失门禁为零；每条多变体资产选择都能在 `变体决策JSON` 中追溯，`连续性冲突` 为空且 `校验状态=校验通过`；时长审计字段已回填，低于最低目标的集有明确人工审核状态且未触发第二次模型调用。
- 视频：每个已提交任务终态且幂等；“成片附件、成片URL、尾帧附件、尾帧URL”四项均已读回非空，实际请求和计费已回填；同场连续性来源正确。
- 导出：每集视频ZIP内Clip数量与完成表一致，不含未完成或重复文件；若选择剪映交付，每集便携ZIP的目标Clip、素材哈希、实际时长、单轨顺序和连续时间线校验全部通过，目标版本明确，未把“生成ZIP”冒充为“本机剪映已打开”。

任何硬门禁失败都返回真实错误与待处理记录；不得切模型、换provider、借用其他资产或用旧缓存假装成功。
