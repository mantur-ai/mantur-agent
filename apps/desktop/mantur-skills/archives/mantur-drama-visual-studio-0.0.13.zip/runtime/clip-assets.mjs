import { existsSync, lstatSync } from 'node:fs';
import { resolve } from 'node:path';
import { assertProjectWritePath, parseOptions, plainObject, projectRoot, readJson } from './common.mjs';

const text = value => typeof value === 'string' ? value.trim() : '';
const safeId = value => /^[\p{L}\p{N}_.-]+$/u.test(text(value)) ? text(value) : null;
const boundStatuses = new Set(['matched', 'matched_locked_identity']);
const boundSources = new Set(['user_uploaded', 'preset', 'custom_generated', 'generated']);

function httpsUrl(value) {
  if (typeof value !== 'string' || !/^https:\/\//i.test(value) || /[\s\\]/.test(value)) return false;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !!url.hostname && !url.username && !url.password;
  } catch { return false; }
}

// Read only project files; do not forward parser errors containing private input bytes.
function projectJson(path) {
  const file = assertProjectWritePath(resolve(projectRoot(), path));
  if (!lstatSync(file).isFile()) throw new Error('Invalid input file');
  return readJson(file, { object: true });
}

export function validateClipAssets(tokens) {
  const issues = [];
  let assetCount = 0;
  const add = (id, field, reason) => issues.push({ asset_id: safeId(id), field, reason });
  const result = () => ({
    ok: issues.length === 0,
    ...(issues.length ? { error: { code: 'CLIP_ASSETS_NOT_READY', message: '资产清单未通过校验，请根据 issues 补齐绑定。' } } : {}),
    counts: {
      assets: assetCount, issues: issues.length,
      missing_image_urls: issues.filter(x => x.reason === 'missing_image_url').length,
      missing_voice_urls: issues.filter(x => x.reason === 'missing_voice_url').length,
    },
    issues,
  });
  let manifest, project, matching;
  try {
    const { positionals } = parseOptions(tokens, { positionals: 1 });
    manifest = projectJson(positionals[0]);
  } catch { add(null, 'manifest', 'invalid_manifest_file'); return result(); }
  try { project = projectJson('.pipeline-state/project.json'); }
  catch { add(null, 'project', 'invalid_project_file'); return result(); }
  try {
    const pointer = project.workflow_state?.asset_matching_report;
    if (pointer !== undefined && !text(pointer)) throw new Error('Invalid pointer');
    let selected = pointer;
    if (selected === undefined && existsSync(resolve(projectRoot(), '.pipeline-state/manifest.json'))) {
      selected = projectJson('.pipeline-state/manifest.json').authoritative_files?.asset_matching?.path;
      if (selected !== undefined && !text(selected)) throw new Error('Invalid pointer');
    }
    matching = projectJson(selected ?? '.pipeline-state/results/asset-matching-report.json');
    if (!Array.isArray(matching.voices) || matching.voices.some(row => !plainObject(row))) throw new Error('Invalid voices');
  } catch { add(null, 'asset_matching_report', 'invalid_matching_report'); return result(); }

  const byId = new Map();
  const characters = [];
  for (const group of ['角色资产', '场景资产', '道具资产']) {
    if (!Array.isArray(manifest[group])) { add(null, group, 'invalid_asset_array'); continue; }
    for (const row of manifest[group]) {
      assetCount++;
      if (!plainObject(row)) { add(null, group, 'invalid_asset_record'); continue; }
      const id = text(row.资产ID);
      if (!id) add(null, '资产ID', 'missing_asset_id');
      else if (byId.has(id)) add(id, '资产ID', 'duplicate_asset_id');
      else byId.set(id, row);
      const policy = row.生成策略 === undefined ? 'reference_required' : text(row.生成策略);
      if (!['reference_required', 'defer_to_video'].includes(policy)) add(id, '生成策略', 'unknown_generation_policy');
      if (policy === 'reference_required' && !text(row.图片URL)) add(id, '图片URL', 'missing_image_url');
      else if (row.图片URL !== undefined && row.图片URL !== '' && !httpsUrl(row.图片URL)) add(id, '图片URL', 'invalid_image_url');
      if (group === '角色资产') characters.push(row);
    }
  }
  if (!assetCount) add(null, 'manifest', 'empty_asset_manifest');

  const characterIds = new Set(characters.map(row => text(row.资产ID)));
  const familyById = new Map();
  for (const row of characters) {
    const id = text(row.资产ID);
    let current = id;
    const seen = new Set();
    while (current && !seen.has(current)) {
      seen.add(current);
      const base = text(byId.get(current)?.基础资产ID);
      if (!base || base === current) break;
      if (!characterIds.has(base)) { add(id, '基础资产ID', 'unknown_base_character'); break; }
      current = base;
    }
    if (text(byId.get(current)?.基础资产ID) !== current && seen.has(text(byId.get(current)?.基础资产ID))) {
      add(id, '基础资产ID', 'cyclic_base_character');
    }
    familyById.set(id, current);
  }
  const familiesByName = new Map();
  for (const row of characters) {
    const name = text(row.角色名);
    if (!name) continue;
    if (!familiesByName.has(name)) familiesByName.set(name, new Set());
    familiesByName.get(name).add(familyById.get(text(row.资产ID)));
  }
  const voicesByFamily = new Map();
  for (const voice of matching.voices) {
    const ids = [voice.asset_id, voice.base_asset_id].map(text).filter(Boolean);
    const families = new Set();
    for (const id of ids) {
      if (!familyById.has(id)) add(id, '音色绑定', 'unknown_voice_character');
      else families.add(familyById.get(id));
    }
    // Stable identity wins over a legacy display name. Name-only records must be unique.
    if (!ids.length) {
      for (const family of familiesByName.get(text(voice.character)) ?? []) families.add(family);
    }
    if (families.size !== 1) { add(ids[0], '音色绑定', families.size ? 'ambiguous_voice_character' : 'unknown_voice_character'); continue; }
    const family = [...families][0];
    if (!voicesByFamily.has(family)) voicesByFamily.set(family, []);
    voicesByFamily.get(family).push(voice);
  }
  const allowDirect = project.voice_policy?.allow_ai_direct === true || project.allow_ai_direct === true ||
    project.missing_asset_policy?.voices === 'user_voice_then_explicit_ai_direct';
  for (const row of characters) {
    const id = text(row.资产ID);
    const voices = voicesByFamily.get(familyById.get(id)) ?? [];
    const modes = voices.map(voice => ({
      status: boundStatuses.has(text(voice.status)) ? 'matched' : text(voice.status), source: text(voice.source), url: text(voice.public_url ?? voice.audio_url ?? voice.音色URL),
      local: text(voice.local_audio ?? voice.local_file ?? voice.local_files?.[0]), voiceId: text(voice.voice_id),
    }));
    const distinct = new Set(modes.map(mode => JSON.stringify(mode)));
    if (distinct.size > 1) { add(id, '音色绑定', 'ambiguous_voice_binding'); continue; }
    const mode = modes[0];
    const status = mode?.status ?? text(row.音色策略);
    if (boundStatuses.has(status)) {
      if (mode && !boundSources.has(mode.source)) add(id, '音色绑定', 'unknown_voice_source');
      if (!text(row.音色URL)) add(id, '音色URL', 'missing_voice_url');
      else if (!httpsUrl(row.音色URL)) add(id, '音色URL', 'invalid_voice_url');
      else if (mode?.url && row.音色URL !== mode.url) add(id, '音色URL', 'voice_url_mismatch');
    } else if (status === 'ai_direct' || status === 'not_required') {
      if (status === 'ai_direct' && !allowDirect) add(id, '音色策略', 'ai_direct_not_allowed');
      if (text(row.音色URL)) add(id, '音色URL', 'voice_policy_conflict');
    } else {
      add(id, '音色绑定', 'unresolved_voice_binding');
      if (text(row.音色URL) && !httpsUrl(row.音色URL)) add(id, '音色URL', 'invalid_voice_url');
    }
  }
  return result();
}
