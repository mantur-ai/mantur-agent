# 各阶段 JSON 结构

每个引擎输出严格 camelCase JSON。下面给字段树 + 关键约束。**结构固定、字段名别改**——后端和下游阶段按字段名取值。

## 目录
- [analysis（拉片分析，Step 2）](#analysis拉片分析)
- [element（元素提取，Step 3）](#element元素提取)
- [mapping（替换映射，Step 4）](#mapping替换映射)
- [script（文案改写，Step 5）](#script文案改写)

---

## analysis（拉片分析）

每段一个文件 `analysis_partN.json`。核心是 `segments[]`，每段固定 **12 个 sourceGrid.cells + 12 个 segment.cells**，靠 `cellIndex` 1~12 对齐。

```jsonc
{
  "summary": { "mainProduct":"", "contentTheme":"", "visualStyle":"", "rhythm":"", "emotion":"", "audioStyle":"" },
  "styleSkeleton": { "camera":"", "style":"", "rhythm":"" },
  "segments": [{
    "segmentIndex": 1, "startMs": 0, "endMs": 15000, "keyframeMs": 0,
    "sourceGrid": { "cells": [
      { "cellIndex":1, "timeMs":0, "visualDescription":"", "visibleText":"", "mainSubject":"",
        "scene":"", "shotSize":"", "composition":"", "cameraMovement":"", "personRatio":0, "hasFace":false }
      /* …固定 12 个，timeMs 严格递增 */
    ]},
    "cells": [
      { "cellIndex":1, "startMs":0, "endMs":1000, "title":"", "tags":[], "shotSize":"", "composition":"",
        "cameraMovement":"", "lighting":"", "colorStyle":"", "visualDescription":"", "action":"",
        "mainSubject":"", "productPosition":"", "hasProduct":false, "scene":"", "visibleText":"", "props":[],
        "sourceElementIds":[], "speakerElementId":"", "voiceElementId":"", "faceBlurRequired":false,
        "personRatio":0, "hasFace":false }
      /* …固定 12 个，与 sourceGrid.cells 的 cellIndex 对齐 */
    ]
  }],
  "elementsPreview": [
    { "elementType":"PRODUCT", "elementSubType":"", "sourceElementKey":"", "relatedSourceElementKey":"",
      "name":"", "description":"", "attributes":{}, "sourceOccurrences":[] }
    /* 覆盖 PRODUCT/CHARACTER/SCENE/PROP/BRAND/SELLING_POINT/VOICE */
  ],
  "originalScript": { "source":"SUBTITLE|VISUAL_ONLY", "text":"", "lines":[ {"startMs":0,"endMs":0,"text":""} ] },
  "warnings": []
}
```
- `hasFace` / `personRatio`：后续定"哪几格出完整人物、哪几格仅手部"的依据（用于 Step 6 新宫格）。
- `sourceElementKey` 是元素主键（如 `product_juice`/`character_host`），贯穿 mapping 与 script 的 `elementRefs`。

---

## element（元素提取）

每个要替换的元素一份（产品最关键）。`productLock` 8 维是产品视觉一致性的锚。

```jsonc
{
  "displayName": "", "sourceDescription": "",
  "editableData": {
    "productLock": { "name":"", "category":"", "shape":"", "color":"", "material":"", "pattern":"", "details":"", "packaging":"" },
    "sellingPoints": [], "usageScenes": [], "replacementNotes": "", "negativePrompt": ""
  },
  "warnings": []
}
```

---

## mapping（替换映射）

一份 `element_mapping.json` 覆盖所有段。逐元素标 `action: REPLACE | KEEP`。

```jsonc
{
  "appliesTo": ["part1","part2"],
  "voicePolicy": "音色不替换：保留原片音色；已抽 3s 样本供后续 TTS/克隆保持一致。",
  "mappings": [
    { "sourceElementKey":"product_x", "elementType":"PRODUCT", "action":"REPLACE",
      "original": { "name":"原产品名", "brandKey":"" },
      "replacement": { "name":"新产品名", "referenceImages":[], "productLock":{ /* 8 维 */ },
        "sellingPoints":[], "usageScenes":[], "negativePrompt":"" },
      "notes":"" },
    { "sourceElementKey":"voice_host", "elementType":"VOICE", "action":"KEEP", "replacement":null,
      "voiceSample": { "audioFiles":[], "extractedRange":{"startMs":0,"endMs":0,"durationMs":5000},
        "spec":"44100Hz/单声道/WAV（op.audio.extract 抽取，至少 5s，已自动 AI 分离人声）", "transcriptApprox":"" } },
    { "sourceElementKey":"scene_x", "elementType":"SCENE", "action":"KEEP", "replacement":null, "notes":"无替换素材，保留原片" }
  ],
  "globalNotes": [ "口播里出现的原品类词（如原产品名/原水果）需在 Step 5 文案改写时一并平移" ],
  "warnings": []
}
```
- **没有替换素材的元素一律 KEEP**（场景、器皿等），保留原片。
- 音色 KEEP 但**必带 voiceSample**——出片阶段要喂它做 `ref_audios`。

---

## script（文案改写）

每段一份 `script_partN.json`。`shots` 逐镜对位原片 12 个 cell，只平移产品/元素指向。

```jsonc
{
  "rewriteDirection": "", "scriptSummary": "",
  "copyGroups": [ { "beatGroupId":"", "label":"", "timeRange":"0-3755ms", "cellIndexes":[1,2,3] } ],
  "subtitlePolicy": {}, "voiceoverPolicy": { "voiceElementId":"voice_host", "useOriginalVoice":true, "replaceVoice":false, "tone":"" },
  "shots": [
    { "cellId":"seg1_cell1", "segmentIndex":1, "cellIndex":1, "newCopy":"", "copyType":"VOICEOVER",
      "speakerType":"ON_CAMERA_HOST", "voiceElementId":"voice_host", "elementRefs":[], "sellingPointRefs":[],
      "sceneRefs":[], "status":"AI_REWRITTEN", "versionLabel":"v1" }
    /* …12 个，对位原片 12 cell */
  ],
  "warnings": []
}
```
- `newCopy` 是**该镜配音文案**——这些拼起来就是该段连续口播，**衔接处去重复词**（见 engines.md §4 提醒）。
- `voiceoverPolicy.tone` 会被 Step 7 当作 `[声音风格]` 填进视频提示词。
