# 算子调用要点 & 踩坑速查

平台接入（认证、异步 invoke+poll、自动退费）由平台注入，这里只讲**每个算子的入参字段**和**亲历的坑**。字段名拼错会被静默忽略、结果不对，务必精确。

## 目录
- [§1 op.video.understand-v2（拉片，含回退）](#1-opvideounderstand-v2拉片含回退)
- [§2 op.video.grid（宫格）](#2-opvideogrid宫格)
- [§2b op.video.compose（切分 / 拼接）](#2b-opvideocompose切分--拼接)
- [§3 op.image.generate（新宫格）](#3-op.image.generate新宫格)
- [§4 op.video.generate（出片，最关键）](#4-opvideogenerate出片最关键)
- [§4b op.audio.extract（抽音色）](#4b-opaudioextract抽音色)
- [§6 踩坑速查](#6-踩坑速查)

---

## §1 op.video.understand-v2（拉片，含回退）

**优先用它做拉片**（所有能力优先走中台算子）。字段：
- `video_url`（必填）：分段视频公网 URL。
- `model`：`doubao`（默认/国内快）| `gemini` | `gpt`。
- `prompt`（必填）：引擎①拉片提示词（见 engines.md §1）。

**回退判断**：understand-v2 是**同步算子**，喂引擎①这种超长 prompt（~4000 字）+ 要 12+12 格大输出，**常 502/UPSTREAM 或 504 网关超时**。
- 先试 `model:doubao`，超时换 `gemini`/`gpt` 各试一次。
- 仍超时 → **回退**：① 外部长上下文多模态模型（如 Gemini 3.5 Flash）直接读视频+宫格出 JSON；② 或本地视觉——用 ffmpeg 把关键帧抽出来拼成宫格图，看图逐格写 JSON。
- **无论哪条路，输出 JSON 结构必须和 schemas.md → analysis 完全一致。**

---

## §2 op.video.grid（宫格）

- `src`（必填）：视频 URL。
- `grid`：`"4x3"` = **4 行 3 列 = 12 格**（爆款复刻固定用 4x3）。枚举 `2x2|3x3|3x4|4x3|4x4`。
- `storyboards`：`[{start,end}]` 多分镜，每段出一张图（按 15s 分段填）。
- `label_timestamps`：是否每格标时间戳（拉片对齐时可开）。
- 输出：`grids[].url`（TOS，24h 有效，尽快下载）。

---

## §2b op.video.compose（切分 / 拼接）

视频剪辑/合成算子，**切分（Step 0）和拼接（Step 9）默认走它**。异步算子。核心字段 `tracks`（轨道二维数组，每段含 `type`/`src`/`target_time`/`extra`）。

**切分**：单视频取某时间段，用 `extra` 里的 `trim`。例：取 0-15s 为一段——
```json
{"tracks":[[{"type":"video","src":"<原视频URL>","target_time":{"start":0,"end":15},"extra":[{"type":"trim","start":0,"end":15}]}]]}
```
按 15s 逐段各调一次（trim 0-15、15-30…），分别得到各分段视频。

**拼接**：同一 track 里按顺序排各段、用 `target_time` 接续——
```json
{"tracks":[[
  {"type":"video","src":"<part1>","target_time":{"start":0,"end":15}},
  {"type":"video","src":"<part2>","target_time":{"start":15,"end":30}}
]]}
```
compose 输出统一规格，省去本地 scale。`output` 可配 `{format:"mp4",fps,crf}`。

⚠️ **只输出 mp4、不出纯音频**——"抽音色样本"（Step 4）改用 `op.audio.extract`（见 §4b）。

---

## §3 op.image.generate（新宫格）

- `mode`：`edit`（图生图，多图融合，新宫格用这个）| `generate`（文生图）。
- `prompt`（必填）：新宫格重绘 prompt（见 engines.md §6）。
- `images`：URL 数组，顺序对应 prompt 里的 `[图1][图2]…`（老宫格/产品/人物/道具）。
- `size`：`1024x1792`（竖屏 9:16）。`tier`：`standard`(50 馒头)|`hd`(70)|`ultra`(100)。
- **⚠️ 返回 base64，不是 URL**：图在 `result.value`（或 `result_b64_json`），`result.type=base64`。**用 `scripts/save_image_b64.py` 解码存盘**，别用 URL 正则去抠。
- **也用于「多角度拼图」**：出片 `images` 名额紧张（会超 9 张）或某类素材图太多时，用 `mode=edit` 输入多张同类图（如多角度产品图），prompt 要求"把这些图**无改动地**平铺成一张 2×2 / 2×3 网格拼图、各角度清晰、不改变原物外观与配色"，输出当**单张**参考图喂出片。

---

## §4 op.video.generate（出片，最关键）

multimodal 模式，一次喂提示词+多图+音频出带声视频。**这步坑最多，逐条照做：**

字段：
- `prompt`（必填）：最终视频提示词（engines.md §5 产出）。多图用 `@Image1/@Image2` 按序点名。
- `model`：**`seedance`**（多图+音频必须 seedance；happyhorse 仅文/图）。
- `resolution`：`720p`（默认推荐，最省可行）｜`1080p`（计费翻倍、慢 12-18min）。
- `ratio`：`9:16`。`duration`：`15`（seedance 最低 5s）。
- `images`：`[宫格URL, 产品URL, 人物URL, 道具URL]`（**≤9 张，算子硬上限**）。⚠️ 某类图过多先合成：**产品图 >4 张 → 用 op.image.generate 合成一张多角度拼图当单张产品图**（人物/道具同理），避免超 9 张、@Image 点名被拆乱。
- `image_roles`：`["reference_image","reference_image","reference_image","reference_image"]`（全 reference_image）。
- `ref_audios`：`[音色样本URL]`（≤3 段，单段 ≤15s）——驱动口型/音色。
- **`generate_audio`: `true`** ← **必传！默认 false，且文档没列这个字段。不传成片没有声音**（`ref_audios` 只驱动口型，不出音轨；两个一起才有声）。
- `seed`：固定正整数（如 `2026`），让人物跨段更一致。

输出：成功后 `result.result_url`（mp4，24h 有效）。`mode` 会显示 `multimodal`。

**出片标准 payload（720p 带声）：**
```jsonc
{ "prompt":"<最终提示词>", "model":"seedance", "resolution":"720p", "ratio":"9:16", "duration":15,
  "images":["<宫格>","<产品>","<人物>","<道具>"],
  "image_roles":["reference_image","reference_image","reference_image","reference_image"],
  "ref_audios":["<音色>"], "generate_audio":true, "seed":2026 }
```

---

## §4b op.audio.extract（抽音色）

从视频/音频按时间段裁出一段音频，**默认自动 AI 分离人声、去 BGM** 得纯净人声样本。Step 4 抽音色用它。字段：
- `src`（必填）：原视频/音频公网 URL（视频自动抽音轨）。
- `start`（默认 0）/ `end` 或 `duration`：裁剪区间。**音色样本至少 5 秒**（5-10s）；都不传默认抽 5s。
- `format`：`wav`（默认，克隆/驱动推荐）| `mp3` | `m4a`。`sample_rate` 默认 44100，`channels` 默认 1（单声道）。
- `denoise` / `normalize`：可选降噪 / 响度归一。
- `skip_separation`：默认 `false`=自动分离人声；设 `true` 仅裁剪不分离（更快、保留原混音）。
- 输出 `result_url`（音频文件），直接喂 `op.video.generate` 的 `ref_audios`。

```json
{"src":"<原视频URL>","start":0.8,"duration":5,"format":"wav","channels":1}
```

---

## §5 踩坑速查

| 症状 / 场景 | 真因 & 解法 |
|---|---|
| **成片没声音** | 漏传 `generate_audio:true`（默认 false、文档没列）。`ref_audios` 只驱动口型不出音轨，必须配 `generate_audio:true`。 |
| **`UPSTREAM_TASK_FAILED` + `resource download failed`** | 参考图 URL 在**上游侧拉取失败**。TOS 签名 URL 虽标 7 天、本地还能下，但上传几小时后上游就拉不动。**解法：出片前重新上传所有素材换全新 URL。** 别误判成上游抽风/分辨率/审核。 |
| **`UPSTREAM_TASK_FAILED`（无 download failed）反复** | 先用「刚上传的新 URL + 已知能成的配置」跑对照，确认是不是上游时段故障；是就挂间隔重试等恢复（失败自动退馒头）。 |
| **480p 出片被拒** | 480p 在 multimodal（多图+音频）下常不支持。用 **720p**（最省可行）或 1080p。 |
| **拉片算子超时（502/504）** | understand-v2 喂超长 prompt 会超时；换 model 再试，仍不行回退外部模型/本地视觉（见 §1）。 |
| **op.image.generate 拿不到图** | 它返回 **base64**（`result.value`）不是 URL，要解码存盘（`scripts/save_image_b64.py`）。 |
| **切分后时间轴对不齐** | ffmpeg 切段必须**重编码**，别用 `-c copy`（会跳到关键帧）。用 `scripts/split_video.sh`。 |
| **配音把同一句念两遍** | 原片字幕分镜切分有**词重叠**，连续配音文案要去掉衔接处重复字（engines.md §4）。 |
| **拼接错位/失败** | 各段分辨率/帧率不一致。先 scale 到统一尺寸+统一 fps 再 concat（`scripts/concat_videos.sh`）。 |
| **宫格行列搞反** | `op.video.grid` 的 `grid="4x3"`=4 行 3 列；ffmpeg 本地拼是 `tile=3x4`（3 列×4 行）。两者写法相反。 |
| **新宫格到处冒人脸** | 没按拉片 `hasFace` 区分人物格/手部格。产品/道具特写格要写"仅手部、不露脸"。 |
