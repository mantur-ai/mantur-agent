# 批量视频提前报价与一次费用授权

本合同优先于视频旧指引中的逐操作费用询问；仅适用于当前 OpenAPI 视频批次。素材、分镜、legacy 以及已保存逐操作批准继续遵守各自合同。看板只读，不增加常驻付费调度器。

## Agent 执行顺序

1. 用户可选择单个、多个或全部 Clip，可跨集、可不连续；未明确选择时先询问想生成哪些分镜的视频，已明确指定则不重复询问。仅把选中的 Clip 写入计划，其他分镜保持待生成，全集编译不等于授权生成全部视频。自动校验分镜结构、素材和生成参数；生成后的分镜无需用户确认，素材有效确认不重复询问。使用 plan-video-batch 保存稳定意图和范围。计划完成后用创作者能理解的语言说明最终生成范围、Clip 数量、同场连续关系及哪些片段要等待前序结果；没有待决选择时说明下一步会自动询价，无需逐 Clip 回复。
2. 范围外前序仅一个合规候选自动冻结；多个候选按页面结果编号集中询问并 select-video-results。零候选时集中询问“补生成前序 / 暂不生成受影响链”，并分别说明前者会扩大本批生成范围、重新形成报价，后者会暂时移除该 Clip 及依赖它的后续链。补生成递归检查依赖，用户确认后以新 plan_key 重建范围；暂不生成则移除受影响链。不得取消分镜承接要求。范围内待生成前序不是缺失参考，不向用户索取尾帧。
3. prepare-video-batch --input <同一批次描述文件>：先对全部 Clip 的当前模板构建独立计价请求并逐项实时 precharge，再准备可生成项；不 invoke。平台计价不受真实尾帧注入影响，计价副本不注入虚构尾帧，保留普通引用和模型、时长、分辨率、比例、音频等参数；缺失的 @ImageLastFrame 仅从计价副本移除，不改模板。计价请求绝不保存为生产 operation/request.json。全部成功返回每项 pricing_parameters 报价和 total_exact_points；一项失败则 approval_ready=false、总价不可用，不从首段价格推算。外部前序决策仍先集中处理；内部前序等待只影响 generation_ready，不影响报价。
4. 按 quote-and-balance 查询余额，一次展示站点/上传目的地、最终范围、模型、比例、分辨率、逐项价格、整批总价、余额与查询时间、按总价预计余量。让用户确认该总价，不要求用户猜费用上限；同时说明批准后同场连续链会按真实前序自动推进，不再逐 Clip 索要回复。批准金额限制本批次提交报价累计值，不冒充最终扣费。余额不足先处理。
5. 保存真实用户批准证据，调用 approve-video-batch 一次，正常省略 max_points，由 Runtime 取当前 proposal 的 quoted_total_points。批次授权涵盖列明 Clip 各一次生成及既定尾帧注入，不涵盖自动付费重跑。不要替每段制作 user_confirmed 或新的人工批准文件。
6. 读取 video-batch-status 的 actionable；已完成及终止项不会列入推进队列，对可推进项按 prepare-video-generation 准备实际请求，再 submit-video-generation --operation-id <id> --batch-authorization <authorization_id>。参数与范围未变、报价处于剩余额度内时自动提交；报价规则/金额变化在上限内也由 Runtime 复核，无需逐段询问。正常 prepare 返回 awaiting_approval 只是兼容操作状态，不表示已有有效批次授权仍需人类批准。若存在 waiting，按各项 next_check_seconds 分段等待后重新读取批次状态；actionable 为空不能据此结束批次。未提交操作的排队、限流、临时网络及服务故障以本批次指引为准，不因单操作 polling=blocked 永久放弃。
7. 按 async-wait-policy 持续恢复原任务至下载、技术校验和快照回读成功。范围内后续只使用本次新结果尾帧，重新生成也不回退旧采用结果。同场串行、跨场受控并发；失败阻断其依赖链，其他独立链继续。不得每段停下来要求用户说“继续”或确认成片。
8. 正常运行仅在首个合规结果和重要状态变化时提供必要进展，后续正常结果可合并反馈，不要求回复。整批进入终态后统一汇报已完成、失败、阻塞、未生成及费用占用，并按[批次完成后的下一步选择](video-result-selection.md#批次完成后的下一步选择)暂停等待用户重新选择；此前的 ZIP、剪映或其他交付目标不触发自动导出。超上限或实质范围/参数变化先停止新提交，集中说明；轮询已受理任务仍继续。业务批准不替代宿主权限审核。

## 关键节点沟通边界

批次沟通表达必须包含与当前节点有关的“结果、意义、下一步、可选项、是否需要回复”，但不规定逐字模板。真实尾帧连续性在首次影响范围或顺序时解释一次；后续只报告变化。首个合规视频按视频合同主动展示，并告诉用户其余已批准片段会继续。临时等待、原任务恢复和独立链继续不制造新的批准；只有候选决策、费用或范围发生实质变化时才停下来要求选择。

## 本地接口

通过 scripts/studio.mjs --project <项目> 调用，全部记录为项目私有数据，不进入 HTTP/看板。

- prepare-video-batch --input：输入与 plan-video-batch 相同，不支持 --no-write；明确允许准备阶段网络和本地写入，但不生成。
- approve-video-batch --input [--no-write]：离线保存或只读校验批准，不查询余额、上传、报价或 invoke。
- video-batch-status --batch-id：本地只读，返回 operations、actionable、waiting、ready、pending、authorization_id、max_points、occupied_points、remaining_points；不写、不联网。operations 增加 retryable、retry_not_before、next_check_seconds；waiting 列出尚在等待的可恢复未提交项及原操作标识。
- submit-video-generation --operation-id --batch-authorization：批次授权路径，与 --approval 互斥。旧 --approval 仍绑定精确请求；resume 不接收新费用授权，只恢复原操作。

批准描述文件：
```json
{"schema_version":1,"batch_id":"<plan_id>","proposal_sha256":"<prepare返回值>","approved":true,"approved_at":"<ISO时间>","evidence":"input/batch-fee-consent.json","evidence_sha256":"<该文件字节SHA256>","expected_authorization_id":null}
```

max_points 为兼容旧预算授权保留的可选字段；新流程省略时使用已保存整批总价，旧 proposal 缺少完整逐项报价时不能推断金额。

evidence 来自用户实际批准文字或观察记录，不可复制合成测试证据。首次 expected_authorization_id=null；用户明确提高/调整同批预算时填写刚读取的旧 authorization_id，新授权保留全部既有占用。不通过更换 plan_key 或 generation_intent 绕开超限、未知提交或原操作恢复。费用支持至多六位小数，按百万分之一 point 的整数单位累计，避免浮点超限；面向用户仍以原小数值显示为“馒头”。

## 持久化与一致性

.pipeline-state/runtime/video-budgets/<batch_id>/ 保存不可变 proposal、authorization、原批准证据副本、逐操作 allocation receipt 和原子 ledger.json。新 proposal 与 allocation receipt 都绑定 `credential_scheme + credential_sha256`；旧证据缺 scheme 按 `legacy-key-v1` 解释。新 proposal 另包含 pricing_policy=tail_independent_v1、各 Clip 的计价请求/响应/规则摘要与 quoted_total_points，整体不可变摘要绑定批准。批准绑定计划版本、项目/站点、认证身份摘要、参数、模板/素材审核摘要、生成意图和外部选择；只允许声明的本批次尾帧和经过校验的上传引用在执行时具体化。Key 与 CLI 身份摘要不得互相推断等价，切换认证方式不改写批准、Job 或既有分配。

提交在项目锁内复核并预占预算，保存带 authorization_kind=batch 的派生批准，再标记 submission_unknown 后 invoke。派生记录不是逐段人工同意。恢复保留原幂等键、请求和分配；未知受理不释放占用。明确未提交可释放；已受理失败和取消仍占用本次额度，不猜退款或平台结算，不自动付费重试。

Ledger、原操作、批准证据和分配摘要交叉校验；删占用不能制造新余额。技术校验、候选、真实尾帧和导出共用批次授权验证。旧证据无需迁移，不把旧批准变成批次预算。快照失败只恢复发布，未提交请求的来源变更阻断，不改已提交历史。

实际生成前仍等待并验证真实前序，构建完整请求后复核报价。除已声明的连续性提示词、真实尾帧及同源上传引用外，实际计费参数必须与逐项计价凭据一致。尾帧与普通引用媒体始终按生产合同校验，不能将报价成功当作可提交。超出已批准总额停止新提交，旧未知受理恢复不重新占用额度或付费。

## 临时等待与原操作继续

仅对白名单临时错误恢复推进：VIDEO_CHAIN_QUEUED / VIDEO_CHAIN_BUSY、已知超时和网络中断、MANTURHUB_SERVICE_UNAVAILABLE / MANTURHUB_RATE_LIMITED、ONLINE_LOCK_UNAVAILABLE / PROJECT_BUSY / PROJECT_UPDATE_IN_PROGRESS。排队/同链忙默认等待 15 秒，其他临时错误至少 30 秒，同时遵守保存的 Retry-After 和 retry_not_before 中较晚的期限；重复读取状态不会延后期限。旧操作缺少时间证据时允许一次受控重查，不迁移记录。

等待到期且依赖就绪后，原项重新进入 actionable。仍按原 operation_id、意图和批准推进，Runtime 再次检查并发槽位、来源、请求、身份、最新报价与剩余额度；排队未解除就再次等待。Agent 按统一异步策略对连续网络错误增加退避，其他独立链继续。临时错误不授权新增 attempt，不把明确失败/取消改成可重试，也不释放未知受理的预算；已提交或受理未知仍只 resume 原操作。身份、授权、请求/素材变化、未知错误及超预算继续阻断（预算经用户批准补足后的既有恢复规则保留）。
