# Open visual reference routing

## Principle

Reference images preserve visual information that prose loses: proportions, facial language, palette, material response, spatial layout, camera angle, and presentation design. Therefore the extraction model should see the full catalog, while each image-generation call should receive the smallest relevant original subset.

Do not define fixed slots such as female, male, scene 1, or four mandatory images. The user may supply any number of references with arbitrary semantic roles.

## Catalog schema

```json
{
  "version": "reference-routing-v3",
  "references": [
    {
      "reference_id": "REF-001",
      "label": "user-defined meaning",
      "note": "what to borrow or avoid",
      "local_path": "/absolute/source/path.png",
      "public_url": "https://raw-public-image-url",
      "checksum": "sha256",
      "width": 1672,
      "height": 941,
      "visible_style_facts": ["observable fact"],
      "scope": "global"
    }
  ],
  "bindings": [
    {
      "asset_id": "CHAR-001-V01",
      "selected_reference_ids": ["REF-001", "REF-004"],
      "reference_uses": [
        {
          "reference_id": "REF-001",
          "roles": ["style", "palette", "rendering", "layout"],
          "literal_embedding": "forbidden",
          "rationale": "borrow the presentation system and lighting only"
        },
        {
          "reference_id": "REF-004",
          "roles": ["identity"],
          "literal_embedding": "forbidden",
          "rationale": "preserve the approved character identity only"
        }
      ],
      "base_asset_id": null,
      "primary_layout_source": {"type": "source_reference", "reference_id": "REF-001"},
      "aspect_ratio_policy": "match_primary_reference",
      "target_width": 1672,
      "target_height": 941,
      "rationale": "why each selected reference is relevant",
      "status": "ready"
    }
  ]
}
```

## Routing rules

- Preserve user labels and notes, but verify them against pixels.
- Pass every catalog image to asset extraction in stable order.
- Route references per asset based on semantic relevance, not array position.
- Every selected reference must have exactly one `reference_uses` entry. Allowed roles are `style / palette / material / rendering / layout / identity / wardrobe / structure`; unlabelled references block generation.
- `style / palette / material / rendering / layout` are non-content roles. They may influence visual language and presentation only; they must not transfer the source subject, character identity, clothing, props, setting, readable text, logo or narrative action.
- `identity / wardrobe / structure` permit only the named feature class. They still do not permit copying source pose, framing, background, unrelated objects, text or logos.
- Every reference use must set `literal_embedding=forbidden`. Never render a reference as a framed image, screen, poster, card, thumbnail, inset panel, split-screen source, collage element, decal or texture inside the new asset.
- Use no reference when none is relevant; do not force a match.
- Use multiple references when they contribute compatible dimensions, such as character proportions plus wardrobe material plus sheet layout.
- Exactly one `primary_layout_source` controls the generated canvas. A source reference uses `type=source_reference`; a character variant normally uses the approved V01/base image with `type=base_asset`; no-reference generation uses `type=asset_template`.
- The output aspect ratio must match the primary layout source within 1%. Secondary references may influence identity, palette, material and detail, but cannot change canvas orientation or ratio.
- If selected references mix landscape and portrait layouts, explicitly choose the primary source from user intent. If no priority can be established, set the binding unresolved and stop generation.
- Block and ask when references conflict on a defining trait and the user did not state priority.
- Character variants include the approved base-character image as first continuity input and inherit its aspect ratio by default; this generated base is not added to the immutable source-reference catalog.
- Mixed or unspecified crowds may be generated as a group when the prompt clearly defines composition. Split by gender or another trait only when the user's references or story require it; never impose a universal gender split.

## Generation gate

Before bulk generation, verify:

1. every selected reference ID exists and has a reachable raw image URL;
2. every local path exists and checksum matches the catalog;
3. the prompt names the relevant visible traits instead of merely saying “same style”;
4. every selected reference has an explicit role and the prompt contains the guard clauses returned by `validate-references`; style-only references are described as non-content conditioning, not as objects to reproduce;
5. every reference records verified source dimensions; every binding records primary layout source, target dimensions and ratio policy;
6. the imagegen call includes the selected original files with the primary layout source first;
7. the prompt explicitly states canvas orientation and ratio/dimensions;
8. visual review confirms the result does not contain a literal copy, thumbnail, frame, screen, poster, text or logo from any reference;
9. generated output passes the allowlisted `validate-aspect-ratio` Skill action before upload or Base completion;
10. representative test images have explicit user approval.
