# 视频并发与排队合同

## 并发单位

视频连续性的最小调度单位是场次链 `(episode, scene_group)`。一条链包含同一场次内按顺序排列的Clip：

- 不同链可以并行，因为它们不共享尾帧。
- 同一链严格串行，一次只能有一个已提交且未终态的Clip。
- 同链后续Clip必须等待上一Clip成功并取得真实 `last_frame_url`；不能为了提高并发跳过尾帧依赖。
- `video_concurrency=5` 表示全项目最多5条活动场次链，不是每集5条、每场5个Clip或每个Agent进程5条。

## 默认值与配置

- 默认：5条活动场次链。
- 用户可配置：1–20。
- Agent在工作流预检使用 `--video-concurrency <N>`，并把请求值持久化为 `requested_video_concurrency`。
- 提交前实时读取视频算子的schema/QPM/并发限制，并结合余额和用户限制计算 `effective_video_concurrency`。有效值只能小于等于请求值；不能因为机器空闲擅自放大。
- 把有效值传给 `plan-scenes --concurrency <N>`。若live限制无法确认，停止视频阶段并报告缺失信息，不猜测一个更高值。

## 队列规则

`plan-scenes` 按 `episode → scene_group` 生成稳定链顺序：

1. 前 `effective_video_concurrency` 条链进入初始活动集合。
2. 其余链进入FIFO队列。
3. 活动链中的当前Clip终态成功后，同链下一Clip占用原槽位；整条链完成后才释放槽位。
4. 活动链失败时只阻断该链并释放槽位，下一条排队链进入；其他链不停止。
5. 提交响应不明确时，该链进入 `submission_unknown` 并继续占用槽位，直到通过原状态查询确认；不得释放槽位后重复提交。

并发数统计的是已分配的活动场次链。每条活动链最多有一个 `submitted/processing/submission_unknown` Clip，因此同时在途视频任务数不会超过有效并发。

## 状态与恢复

把以下字段写入项目状态和场次链计划：

- `requested_video_concurrency`
- `effective_video_concurrency`
- `scheduling_unit=scene_chain`
- `scope=project_global`
- `same_chain_serial=true`
- `different_chains_parallel=true`
- `queue_policy=fifo_episode_scene`
- `active_chain_ids`
- `queued_chain_ids`

恢复工作流时先读取已有场次链和Clip任务ID。已提交或状态不明的Clip仍占槽位；不得因为Agent重启就清零并发计数或重新提交。只有明确终态才更新槽位。

## 示例

一集有3个场次，共12个Clip，配置并发2：

- 场次1的Clip按1→2→3串行；场次2的Clip也串行，两条场次链可同时运行。
- 场次3先排队；场次1或场次2整条链结束/失败后，场次3进入释放的槽位。
- 不允许同时提交场次1的Clip1和Clip2，即使全局还有空闲额度。
