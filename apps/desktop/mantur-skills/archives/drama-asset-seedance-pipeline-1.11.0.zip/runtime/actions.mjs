import {
  accessSync,
  constants,
  existsSync,
  lstatSync,
  mkdirSync,
} from "node:fs";
import { homedir } from "node:os";
import { extname, resolve } from "node:path";
import {
  assertProjectWritePath,
  httpUrl,
  outputPath,
  parseOptions,
  plainObject,
  projectRoot,
  readJson,
  runCli,
  runExternal,
  writeJson,
} from "./common.mjs";
import { imageDimensions, ratioMatches, sha256 } from "./images.mjs";
import {
  exportJianyingDrafts,
  importJianyingDraft,
  inspectJianyingApp,
} from "./jianying.mjs";
import { createZip } from "./zip.mjs";

const SKILL_SLUG = "drama-asset-seedance-pipeline";
const ALLOWED_BASES = new Set(["https://hub.mantur.ai", "https://hub.mantur.cn"]);
const DEFAULT_BASE = "https://hub.mantur.ai";
const SKILL_VERSION = "1.11.0";
const HARD_ENDING = "不要背景音乐，不要字幕。";
const NATIVE_IMAGE_PROVIDER = "native_agent_imagegen";
const LEGACY_NATIVE_IMAGE_PROVIDER = "codex_imagegen";
const MANTURHUB_IMAGE_PROVIDER = "manturhub:op.image.generate";
const IMAGE_PROVIDERS = new Set([NATIVE_IMAGE_PROVIDER, MANTURHUB_IMAGE_PROVIDER]);
const STAGE_OPERATORS = {
  extraction: ["op.drama.asset-extract"],
  "asset-production": ["op.drama.asset-extract"],
  clips: ["op.drama.clip-seedance-compile"],
  video: ["op.drama.clip-seedance-compile", "op.video.generate"],
};
const MINIMUM_OPERATOR_VERSIONS = {
  "op.drama.asset-extract": [2, 4, 3],
  "op.drama.clip-seedance-compile": [2, 4, 0],
};
const VERSION_KEYS = ["active_version", "version", "version_tag", "active_version_tag"];
const REQUIRED_LARK_BASE_COMMANDS = [
  "+base-create",
  "+table-create",
  "+field-create",
  "+field-list",
  "+record-get",
  "+record-batch-create",
  "+record-batch-update",
  "+record-upload-attachment",
];
const ACTIVE_STATES = new Set(["created", "queued", "running", "pending", "processing", "in_progress"]);
const SUCCESS_STATES = new Set(["succeeded", "success", "completed", "done"]);
const FAILED_STATES = new Set(["failed", "error", "cancelled", "canceled"]);
const ASYNC_WAIT_POLICY_BY_ENVIRONMENT = Object.freeze({
  ai: Object.freeze({
    extraction: Object.freeze({ expected_min_seconds: 300, expected_max_seconds: 900 }),
    clips: Object.freeze({ expected_min_seconds: 300, expected_max_seconds: 900 }),
  }),
  cn: Object.freeze({
    extraction: Object.freeze({ expected_min_seconds: 300, expected_max_seconds: 900 }),
    clips: Object.freeze({ expected_min_seconds: 300, expected_max_seconds: 900 }),
  }),
});
const ASYNC_WAIT_POLICY_COMMON = Object.freeze({
  initial_poll_period_seconds: 120,
  initial_poll_interval_seconds: 15,
  steady_poll_interval_seconds: 30,
  long_running_after_seconds: 1200,
  minimum_observation_seconds: 1800,
  sixty_seconds_without_terminal_is_failure: false,
  active_after_minimum_observation_is_failure: false,
});
const ASYNC_WAIT_STAGES = new Set(["extraction", "clips"]);
const DEFAULT_VIDEO_CONCURRENCY = 5;
const MAX_VIDEO_CONCURRENCY = 20;
const MODEL_MAP = {
  "doubao-seedance-2-0-260128": "seedance",
  "doubao-seedance-2-0-mini-260615": "seedance-mini",
  seedance: "seedance",
  "seedance-fast": "seedance-fast",
  "seedance-mini": "seedance-mini",
};
const IMAGE_ROLES = new Set(["reference_image", "first_frame", "last_frame"]);
const REFERENCE_USE_ROLES = new Set(["style", "palette", "material", "rendering", "layout", "identity", "wardrobe", "structure"]);
const CONTENT_REFERENCE_ROLES = new Set(["identity", "wardrobe", "structure"]);

function localPath(value) {
  const text = String(value || "");
  return resolve(text === "~" ? homedir() : text.startsWith("~/") ? `${homedir()}/${text.slice(2)}` : text);
}

function addCheck(checks, name, ok, detail, repair) {
  const row = { name, ok: Boolean(ok), detail };
  if (!row.ok && repair) row.repair = repair;
  checks.push(row);
}

function checkProjectDirectory() {
  try {
    const root = projectRoot();
    accessSync(root, constants.R_OK | constants.W_OK);
    return [true, "persistent project directory is readable and writable"];
  } catch (error) {
    return [false, error.message];
  }
}

function projectStatePath() {
  return assertProjectWritePath(resolve(projectRoot(), ".pipeline-state", "project.json"));
}

function inspectProjectImageProvider(selectedProvider, stage) {
  const path = projectStatePath();
  if (!existsSync(path)) return { status: "not_initialized", stored_image_provider: null };
  let state;
  try {
    state = readJson(path, { object: true });
  } catch (error) {
    return { status: "invalid", stored_image_provider: null, detail: error.message };
  }
  const stored = state.image_provider;
  if (!stored) return { status: "not_recorded", stored_image_provider: null };
  if (stored === LEGACY_NATIVE_IMAGE_PROVIDER) {
    const providerChange = selectedProvider === MANTURHUB_IMAGE_PROVIDER;
    return {
      status: stage === "asset-production" ? "migration_required" : "legacy_alias_recognized",
      stored_image_provider: stored,
      canonical_image_provider: NATIVE_IMAGE_PROVIDER,
      selected_image_provider: selectedProvider,
      actual_provider_change_requires_confirmation: providerChange,
    };
  }
  if (!IMAGE_PROVIDERS.has(stored)) {
    return { status: "invalid", stored_image_provider: stored, detail: "unknown image_provider in project state" };
  }
  if (stage === "asset-production" && selectedProvider && stored !== selectedProvider) {
    return {
      status: "provider_change_required",
      stored_image_provider: stored,
      selected_image_provider: selectedProvider,
      actual_provider_change_requires_confirmation: true,
    };
  }
  return { status: "current", stored_image_provider: stored, selected_image_provider: selectedProvider };
}

export function normalizeManturhubBase(value) {
  let url;
  try {
    url = new URL(String(value || ""));
  } catch {
    throw new Error("ManturHub base must be a valid HTTPS origin");
  }
  if (url.protocol !== "https:" || url.username || url.password || url.pathname !== "/" || url.search || url.hash) {
    throw new Error("ManturHub base must be an HTTPS origin without path, credentials, query or fragment");
  }
  const normalized = url.origin;
  if (!ALLOWED_BASES.has(normalized)) throw new Error(`unsupported ManturHub base: ${normalized}`);
  return normalized;
}

export function resolveManturhubBase(environ = process.env, home = homedir()) {
  if (environ.MANTURHUB_BASE) return [normalizeManturhubBase(environ.MANTURHUB_BASE), "environment"];
  let installed = {};
  const installedPath = resolve(home, ".manturhub", "installed-skills.json");
  if (existsSync(installedPath)) installed = readJson(installedPath, { object: true }).skills || {};
  const bases = new Set();
  if (plainObject(installed)) {
    for (const row of Object.values(installed)) {
      if (plainObject(row) && row.slug === SKILL_SLUG && row.base_url) bases.add(normalizeManturhubBase(row.base_url));
    }
  }
  if (bases.size === 1) return [[...bases][0], "installed_skill"];
  if (bases.size > 1) throw new Error("installed Skill records point to multiple ManturHub environments; set MANTURHUB_BASE explicitly");
  let config = {};
  const configPath = resolve(home, ".manturhub", "config.json");
  if (existsSync(configPath)) config = readJson(configPath, { object: true });
  if (config.baseUrl) return [normalizeManturhubBase(config.baseUrl), "cli_config"];
  return [DEFAULT_BASE, "cli_default"];
}

export function asyncWaitPolicy(base, stage) {
  const normalizedBase = normalizeManturhubBase(base);
  const normalizedStage = stage === "asset-production" ? "extraction" : stage;
  if (!ASYNC_WAIT_STAGES.has(normalizedStage)) return null;
  const environment = normalizedBase.endsWith(".cn") ? "cn" : "ai";
  return {
    environment,
    manturhub_base: normalizedBase,
    stage: normalizedStage,
    ...ASYNC_WAIT_POLICY_BY_ENVIRONMENT[environment][normalizedStage],
    ...ASYNC_WAIT_POLICY_COMMON,
  };
}

export function videoParallelismPolicy(requested = DEFAULT_VIDEO_CONCURRENCY, effective = null) {
  const requestedConcurrency = Number(requested);
  if (!Number.isInteger(requestedConcurrency) || requestedConcurrency < 1 || requestedConcurrency > MAX_VIDEO_CONCURRENCY) {
    throw new Error(`video concurrency must be 1-${MAX_VIDEO_CONCURRENCY}`);
  }
  const effectiveConcurrency = effective === null || effective === undefined ? null : Number(effective);
  if (effectiveConcurrency !== null) {
    if (!Number.isInteger(effectiveConcurrency) || effectiveConcurrency < 1 || effectiveConcurrency > MAX_VIDEO_CONCURRENCY) {
      throw new Error(`effective video concurrency must be 1-${MAX_VIDEO_CONCURRENCY}`);
    }
    if (effectiveConcurrency > requestedConcurrency) {
      throw new Error("effective video concurrency cannot exceed requested video concurrency");
    }
  }
  return {
    requested_video_concurrency: requestedConcurrency,
    effective_video_concurrency: effectiveConcurrency,
    default_video_concurrency: DEFAULT_VIDEO_CONCURRENCY,
    maximum_configurable_video_concurrency: MAX_VIDEO_CONCURRENCY,
    scheduling_unit: "scene_chain",
    scope: "project_global",
    same_chain_serial: true,
    different_chains_parallel: true,
    queue_policy: "fifo_episode_scene",
    live_limit_check_required: effectiveConcurrency === null,
  };
}

function versionTuple(value) {
  const match = String(value || "").trim().match(/^v?(\d+)\.(\d+)\.(\d+)/);
  return match ? match.slice(1, 4).map(Number) : null;
}

function versionAtLeast(actual, minimum) {
  if (!actual) return false;
  for (let index = 0; index < 3; index++) {
    if (actual[index] !== minimum[index]) return actual[index] > minimum[index];
  }
  return true;
}

function liveVersion(payload) {
  for (const key of VERSION_KEYS) if (payload[key]) return payload[key];
  if (plainObject(payload.active)) {
    for (const key of ["tag", "version", "version_tag"]) if (payload.active[key]) return payload.active[key];
  }
  if (Array.isArray(payload.versions)) {
    const activeRows = payload.versions.filter((row) => plainObject(row) && (row.active === true || Number(row.weight) > 0));
    if (activeRows.length === 1) return activeRows[0].tag || activeRows[0].version;
  }
  return null;
}

function describeOperator(operatorId) {
  try {
    const { payload } = runCli(["describe", operatorId, "--json"]);
    const ok = payload.id === operatorId && payload.status === "online";
    return { ok, detail: payload.id === operatorId ? `status=${payload.status}` : "unexpected operator id", payload };
  } catch {
    return { ok: false, detail: "describe failed", payload: null };
  }
}

function checkVoiceCatalog() {
  const skillDir = process.env.MANTURHUB_SKILL_DIR;
  if (!skillDir) return [false, "Skill directory is unavailable"];
  try {
    const payload = readJson(resolve(skillDir, "assets", "voice-library", "catalog.json"), { object: true });
    const voices = payload.voices;
    if (!Array.isArray(voices) || !voices.length) return [false, "catalog contains no voices"];
    if (payload.voice_count !== voices.length) return [false, "voice_count does not match catalog rows"];
    const ids = voices.map((row) => row?.voice_id);
    const hashes = voices.map((row) => row?.sha256);
    if (new Set(ids).size !== voices.length || ids.some((id) => !id)) return [false, "voice_id values are missing or duplicated"];
    if (new Set(hashes).size !== voices.length || hashes.some((hash) => typeof hash !== "string" || hash.length !== 64)) {
      return [false, "voice checksums are missing or duplicated"];
    }
    for (const voice of voices) {
      if (!voice.active || !voice.asset_id) return [false, `inactive preset voice: ${voice.voice_id}`];
      httpUrl(voice.public_url, `voice ${voice.voice_id}`, { httpsOnly: true, noQuery: true });
      if (voice.mime_type !== "audio/mpeg" || Number(voice.file_duration_seconds) < 2) {
        return [false, `invalid audio metadata: ${voice.voice_id}`];
      }
    }
    return [true, `${voices.length} immutable preset voices ready`];
  } catch (error) {
    return [false, `catalog invalid: ${error.message}`];
  }
}

export function baseMediaContract() {
  const skillDir = process.env.MANTURHUB_SKILL_DIR;
  if (!skillDir) throw new Error("Skill directory is unavailable");
  const manifest = "assets/feishu-base-media-contract.json";
  const payload = readJson(resolve(skillDir, manifest), { object: true });
  if (payload.schema_version !== 1 || payload.table !== "Seedance2.0请求体") {
    throw new Error("invalid Feishu Base media contract identity");
  }
  const fields = payload.required_media_fields;
  if (!Array.isArray(fields)) throw new Error("required_media_fields must be an array");
  const byName = new Map(fields.map((field) => [field?.name, field]));
  const expected = new Map([
    ["成片附件", "attachment"],
    ["成片URL", "text"],
    ["尾帧附件", "attachment"],
    ["尾帧URL", "text"],
  ]);
  for (const [name, type] of expected) {
    if (byName.get(name)?.type !== type) throw new Error(`${name} must be a Feishu ${type} field`);
  }
  const required = payload.completion_gate?.required_non_empty;
  if (!Array.isArray(required) || required.length !== expected.size || [...expected.keys()].some((name) => !required.includes(name))) {
    throw new Error("video completion gate must require all four media fields");
  }
  return {
    ok: true,
    manifest,
    ...payload,
  };
}

function loadStoryboardStatusContract() {
  const skillDir = process.env.MANTURHUB_SKILL_DIR;
  if (!skillDir) throw new Error("Skill directory is unavailable");
  const manifest = "assets/storyboard-status-contract.json";
  const payload = readJson(resolve(skillDir, manifest), { object: true });
  if (payload.schema_version !== 1 || payload.contract_version !== "storyboard-status-cn-v1") {
    throw new Error("invalid storyboard status contract identity");
  }
  for (const table of ["Clip总表", "Seedance2.0请求体"]) {
    const fields = payload.tables?.[table];
    if (!plainObject(fields)) throw new Error(`status contract is missing ${table}`);
    for (const [field, spec] of Object.entries(fields)) {
      if (spec?.type !== "select" || spec.multiple !== false || !Array.isArray(spec.values) || !spec.values.length) {
        throw new Error(`${table}.${field} must be a non-empty Feishu single-select contract`);
      }
      if (new Set(spec.values).size !== spec.values.length || spec.values.some((value) => typeof value !== "string" || !value.trim())) {
        throw new Error(`${table}.${field} contains invalid or duplicate values`);
      }
      if (spec.default_value && (!Array.isArray(spec.default_value) || spec.default_value.length !== 1 || !spec.values.includes(spec.default_value[0]))) {
        throw new Error(`${table}.${field} has an invalid default_value`);
      }
      for (const [alias, canonical] of Object.entries(spec.legacy_aliases || {})) {
        if (!alias || !spec.values.includes(canonical)) throw new Error(`${table}.${field} has an invalid legacy alias`);
      }
    }
  }
  return { manifest, payload };
}

export function storyboardStatusContract() {
  const { manifest, payload } = loadStoryboardStatusContract();
  const fieldDefinitions = {};
  for (const [table, fields] of Object.entries(payload.tables)) {
    fieldDefinitions[table] = Object.entries(fields).map(([name, spec]) => ({
      type: "select",
      name,
      multiple: false,
      ...(spec.default_value ? { default_value: spec.default_value } : {}),
      options: spec.values.map((value) => ({ name: value })),
    }));
  }
  return { ok: true, manifest, ...payload, feishu_field_definitions: fieldDefinitions };
}

export function normalizeStoryboardStatuses(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["output"] });
  const input = readJson(localPath(positionals[0]), { object: true });
  const { payload: contract } = loadStoryboardStatusContract();
  const normalized = structuredClone(input);
  let mapped = 0;
  let checked = 0;
  for (const [table, fields] of Object.entries(contract.tables)) {
    const rows = normalized[table];
    if (!Array.isArray(rows)) throw new Error(`input is missing ${table}`);
    rows.forEach((row, rowIndex) => {
      for (const [field, spec] of Object.entries(fields)) {
        const raw = row?.[field];
        if (raw === undefined || raw === null || String(raw).trim() === "") {
          if (Array.isArray(spec.default_value) && spec.default_value.length === 1) {
            row[field] = spec.default_value[0];
            checked += 1;
            mapped += 1;
            continue;
          }
          throw new Error(`${table} row ${rowIndex + 1} is missing required status field ${field}`);
        }
        const value = String(raw).trim();
        checked += 1;
        if (spec.values.includes(value)) continue;
        const canonical = spec.legacy_aliases?.[value];
        if (!canonical) throw new Error(`${table} row ${rowIndex + 1} contains unknown ${field}: ${value}`);
        row[field] = canonical;
        mapped += 1;
      }
    });
  }
  const target = outputPath(options.output, "--output");
  writeJson(target, normalized);
  return { ok: true, contract_version: contract.contract_version, checked_status_cells: checked, migrated_legacy_cells: mapped, output: target };
}

function parseDoctorArgs(tokens) {
  const { options } = parseOptions(tokens, {
    positionals: 0,
    values: ["stage", "video-concurrency"],
    repeated: ["deliverable"],
    booleans: ["native-image", "native-video", "native-imagegen", "reference-images"],
  });
  const stage = options.stage || "video";
  if (!Object.hasOwn(STAGE_OPERATORS, stage)) throw new Error(`invalid stage: ${stage}`);
  const deliverables = options.deliverable.length ? options.deliverable : ["episode-clips"];
  const allowed = new Set(["episode-clips", "jianying-drafts"]);
  for (const deliverable of deliverables) {
    if (!allowed.has(deliverable)) throw new Error(`invalid deliverable: ${deliverable}`);
  }
  if (new Set(deliverables).size !== deliverables.length) throw new Error("deliverable cannot be repeated");
  const videoParallelism = videoParallelismPolicy(options["video-concurrency"] ?? DEFAULT_VIDEO_CONCURRENCY);
  return { ...options, stage, deliverables, videoParallelism };
}

export function doctor(tokens) {
  const options = parseDoctorArgs(tokens);
  const checks = [];
  let mediaContract = null;
  try {
    mediaContract = baseMediaContract();
    addCheck(checks, "feishu_base_media_contract", true, "video and tail-frame attachment+URL fields are machine-readable");
  } catch (error) {
    addCheck(checks, "feishu_base_media_contract", false, error.message, "Restore assets/feishu-base-media-contract.json from the published Skill bundle");
  }
  let statusContract = null;
  try {
    statusContract = storyboardStatusContract();
    addCheck(checks, "storyboard_status_contract", true, "storyboard status fields use fixed Chinese single-select enums");
  } catch (error) {
    addCheck(checks, "storyboard_status_contract", false, error.message, "Restore assets/storyboard-status-contract.json from the published Skill bundle");
  }
  const [projectReady, projectDetail] = checkProjectDirectory();
  addCheck(
    checks,
    "project_directory",
    projectReady,
    projectDetail,
    "Choose a persistent project directory and grant the Agent read/write permission"
  );
  let base = null;
  let source = "invalid";
  try {
    [base, source] = resolveManturhubBase();
    addCheck(checks, "manturhub_environment", true, `base=${base}; source=${source}`);
  } catch (error) {
    addCheck(checks, "manturhub_environment", false, error.message, "Set MANTURHUB_BASE to https://hub.mantur.ai or https://hub.mantur.cn");
  }
  const cliReady = Boolean(process.env.MANTURHUB_CLI_ENTRY && existsSync(process.env.MANTURHUB_CLI_ENTRY));
  addCheck(checks, "manturhub_cli", cliReady, cliReady ? "CLI-managed runtime ready" : "missing", "Install the ManturHub CLI");
  const descriptions = {};
  if (cliReady && base) {
    try {
      const { payload } = runCli(["balance", "--json"]);
      addCheck(checks, "manturhub_auth", Boolean(payload.email), payload.email ? "CLI-managed authentication ready" : "authenticated account identity is missing", "Run: manturhub login");
    } catch {
      addCheck(checks, "manturhub_auth", false, "CLI authentication failed", "Run: manturhub login");
    }
    for (const operatorId of STAGE_OPERATORS[options.stage]) {
      const described = describeOperator(operatorId);
      descriptions[operatorId] = described.payload;
      addCheck(checks, `operator:${operatorId}`, described.ok, described.detail, `Publish or restore ${operatorId} on ${base}`);
      const minimum = MINIMUM_OPERATOR_VERSIONS[operatorId];
      if (described.payload && minimum) {
        const candidate = liveVersion(described.payload);
        const ok = versionAtLeast(versionTuple(candidate), minimum);
        const required = minimum.join(".");
        addCheck(checks, `operator_version:${operatorId}`, ok, `live=${candidate}, required>=v${required}`, `Publish ${operatorId} v${required} or a compatible newer version`);
      }
    }
    if (options["reference-images"]) {
      const hasField = JSON.stringify(descriptions["op.drama.asset-extract"] || {}).includes('"reference_images"');
      addCheck(checks, "asset_reference_images_schema", hasField, hasField ? "reference_images present" : "reference_images missing from live schema", "Publish an asset-extract version whose live params_schema contains reference_images");
    }
  }

  let visualRoute = "not_required";
  if (["asset-production", "video"].includes(options.stage)) {
    const nativeVision = options["native-image"] && (options["native-video"] || options.stage === "asset-production");
    if (nativeVision) {
      visualRoute = "native_agent";
      addCheck(checks, "visual_route", true, "native_agent_visual_understanding");
    } else if (cliReady && base) {
      const described = describeOperator("op.video.understand-v2");
      addCheck(checks, "operator:op.video.understand-v2", described.ok, described.detail, `Publish or restore op.video.understand-v2 on ${base}`);
      addCheck(checks, "visual_route", described.ok, described.ok ? "manturhub_visual_operator" : "no usable visual route");
      visualRoute = described.ok ? "op.video.understand-v2" : null;
    } else {
      visualRoute = null;
      addCheck(checks, "visual_route", false, "no native vision and no ManturHub CLI", "Provide native vision or install ManturHub CLI");
    }
  } else addCheck(checks, "visual_route", true, "not required for this stage");

  let imageProvider = "not_required";
  if (options.stage === "asset-production") {
    if (options["native-imagegen"]) {
      imageProvider = NATIVE_IMAGE_PROVIDER;
      addCheck(checks, "image_provider", true, imageProvider);
    } else if (cliReady && base) {
      const described = describeOperator("op.image.generate");
      imageProvider = described.ok ? MANTURHUB_IMAGE_PROVIDER : null;
      addCheck(checks, "operator:op.image.generate", described.ok, described.detail, `Publish or restore op.image.generate on ${base}`);
      addCheck(checks, "image_provider", described.ok, imageProvider || "no usable image generation route");
    } else {
      imageProvider = null;
      addCheck(
        checks,
        "image_provider",
        false,
        "no Agent-native image generation and no ManturHub CLI",
        "Declare Agent-native image generation with --native-imagegen, or install and authenticate ManturHub CLI"
      );
    }
  }
  const videoProvider = options.stage === "video" ? "manturhub:op.video.generate" : "not_required";
  if (["asset-production", "clips", "video"].includes(options.stage)) {
    const [ok, detail] = checkVoiceCatalog();
    addCheck(checks, "preset_voice_catalog", ok, detail, "Publish the bundled preset voice catalog to permanent public ManturHub storage");
  }

  const larkDoctor = runExternal("lark-cli", ["doctor"]);
  addCheck(checks, "lark_cli", larkDoctor.found, larkDoctor.found ? "lark-cli found" : "missing", "Install lark-cli");
  if (larkDoctor.found) {
    let payload = null;
    try { payload = JSON.parse(larkDoctor.stdout); } catch { /* handled below */ }
    const authOk = larkDoctor.status === 0 && payload?.ok === true;
    addCheck(checks, "lark_auth", authOk, authOk ? "authorized identity ready" : "lark-cli doctor failed", "Run lark-cli config init or scoped lark-cli auth login");
    const help = runExternal("lark-cli", ["base", "--help"]);
    const missing = REQUIRED_LARK_BASE_COMMANDS.filter((name) => !help.stdout.includes(name));
    addCheck(checks, "lark_base_commands", help.status === 0 && !missing.length, missing.length ? `missing: ${missing.join(", ")}` : "all required commands present", "Run: lark-cli update");
  }
  let projectProviderState = { status: "unavailable", stored_image_provider: null };
  if (projectReady) {
    projectProviderState = inspectProjectImageProvider(imageProvider, options.stage);
    if (projectProviderState.status === "invalid") {
      addCheck(
        checks,
        "project_image_provider",
        false,
        projectProviderState.detail,
        "Repair .pipeline-state/project.json with an explicitly confirmed supported image provider"
      );
    } else if (projectProviderState.status === "migration_required") {
      const target = projectProviderState.selected_image_provider;
      const confirmation = target === MANTURHUB_IMAGE_PROVIDER
        ? "--confirm-provider-change"
        : "--confirm-native-imagegen";
      addCheck(
        checks,
        "project_image_provider",
        false,
        `${LEGACY_NATIVE_IMAGE_PROVIDER} is a recognized legacy alias; explicit migration to ${target} is required`,
        `Run the allowlisted migrate-image-provider action with --to ${target} ${confirmation}`
      );
    } else if (projectProviderState.status === "provider_change_required") {
      addCheck(
        checks,
        "project_image_provider",
        false,
        `stored=${projectProviderState.stored_image_provider}; selected=${projectProviderState.selected_image_provider}`,
        `Confirm the provider change through migrate-image-provider --to ${projectProviderState.selected_image_provider} --confirm-provider-change`
      );
    } else {
      addCheck(checks, "project_image_provider", true, projectProviderState.status);
    }
  }
  const ok = checks.every((row) => row.ok);
  return {
    ok,
    manturhub_base: base,
    manturhub_base_source: source,
    stage: options.stage,
    deliverables: options.deliverables,
    visual_route: visualRoute,
    image_provider: imageProvider,
    video_provider: videoProvider,
    project_provider_state: projectProviderState,
    async_wait_policy: base ? asyncWaitPolicy(base, options.stage) : null,
    video_parallelism_policy: options.videoParallelism,
    feishu_base_media_contract: mediaContract,
    storyboard_status_contract: statusContract,
    runtime_requirements: {
      minimum_cli_version: "0.10.0",
      manturhub_login_required: true,
      persistent_project_directory: "read_write",
      lark_cli: "required_when_feishu_base_is_used",
    },
    checks,
  };
}

export function runWorkflow(tokens) {
  const report = doctor(tokens);
  let localJianying = { detected: false, reason: "not requested" };
  if (report.deliverables.includes("jianying-drafts")) {
    try {
      localJianying = { detected: true, ...inspectJianyingApp() };
    } catch (error) {
      localJianying = { detected: false, reason: error.message };
    }
  }
  return {
    ...report,
    project: projectRoot(),
    orchestration: "agent",
    next_action: report.ok ? "continue_with_skill_workflow" : "repair_failed_checks",
    delivery_plan: report.deliverables.map((deliverable) => deliverable === "jianying-drafts"
      ? {
          deliverable,
          internal_action: "export-jianying-drafts",
          target_profile: "jianying-macos-5.9",
          default_output: "portable_zip_only",
          local_app: localJianying,
          import_requires_explicit_confirmation: true,
        }
      : { deliverable, internal_action: "export-episodes" }),
  };
}

export function migrateImageProvider(tokens) {
  const { options } = parseOptions(tokens, {
    positionals: 0,
    values: ["to"],
    booleans: ["confirm-native-imagegen", "confirm-provider-change"],
  });
  const target = options.to;
  if (!IMAGE_PROVIDERS.has(target)) throw new Error(`unsupported image provider: ${target || "(empty)"}`);
  const path = projectStatePath();
  if (!existsSync(path)) throw new Error("project state does not exist: .pipeline-state/project.json");
  const state = readJson(path, { object: true });
  const current = state.image_provider;
  if (current === target) {
    return { ok: true, changed: false, image_provider: target, audit: "already_current" };
  }
  if (current !== LEGACY_NATIVE_IMAGE_PROVIDER && !IMAGE_PROVIDERS.has(current)) {
    throw new Error(`unsupported stored image provider: ${current || "(empty)"}`);
  }
  const aliasOnly = current === LEGACY_NATIVE_IMAGE_PROVIDER && target === NATIVE_IMAGE_PROVIDER;
  if (target === NATIVE_IMAGE_PROVIDER && !options["confirm-native-imagegen"]) {
    throw new Error("--confirm-native-imagegen is required to confirm the current Agent exposes native image generation");
  }
  if (!aliasOnly && !options["confirm-provider-change"]) {
    throw new Error("--confirm-provider-change is required because this changes the actual image provider");
  }
  if (target === MANTURHUB_IMAGE_PROVIDER) {
    const described = describeOperator("op.image.generate");
    if (!described.ok) throw new Error("current-site ManturHub op.image.generate is unavailable");
  }
  const migrations = Array.isArray(state.provider_migrations) ? state.provider_migrations : [];
  const audit = {
    sequence: migrations.length + 1,
    from: current,
    to: target,
    actual_provider_changed: !aliasOnly,
    reason: aliasOnly ? "legacy_alias_normalization" : "explicit_provider_reroute",
    migrated_by: `${SKILL_SLUG}@${SKILL_VERSION}`,
  };
  writeJson(path, {
    ...state,
    image_provider: target,
    provider_migrations: [...migrations, audit],
  });
  return { ok: true, changed: true, image_provider: target, audit };
}

export function validateReferences(tokens) {
  const { positionals } = parseOptions(tokens, { positionals: 1 });
  const payload = readJson(localPath(positionals[0]), { object: true });
  const errors = [];
  const generationGuards = [];
  let references = payload.references;
  let bindings = payload.bindings;
  if (payload.version !== "reference-routing-v3") errors.push("version must be reference-routing-v3; migrate ambiguous v2 bindings before generation");
  if (!Array.isArray(references) || !Array.isArray(bindings)) {
    errors.push("references and bindings must be arrays");
    references = Array.isArray(references) ? references : [];
    bindings = Array.isArray(bindings) ? bindings : [];
  }
  const byId = new Map();
  references.forEach((item, index) => {
    if (!plainObject(item)) {
      errors.push(`references[${index}] must be an object`);
      return;
    }
    const id = String(item.reference_id || "").trim();
    if (!id || byId.has(id)) {
      errors.push(`references[${index}] has missing or duplicate reference_id`);
      return;
    }
    byId.set(id, item);
    const path = localPath(item.local_path);
    if (!existsSync(path) || !lstatSync(path).isFile()) errors.push(`${id} local_path is not a file`);
    else {
      if (!item.checksum || sha256(path) !== String(item.checksum).toLowerCase()) errors.push(`${id} checksum mismatch`);
      try {
        const [width, height] = imageDimensions(path);
        if (item.width !== width || item.height !== height) errors.push(`${id} recorded dimensions do not match source image`);
      } catch (error) { errors.push(`${id} ${error.message}`); }
    }
    try { httpUrl(item.public_url, `${id} public_url`); } catch { errors.push(`${id} public_url must be raw HTTP/HTTPS`); }
    if (!String(item.label || "").trim()) errors.push(`${id} label is required`);
  });
  const assetIds = new Set();
  bindings.forEach((binding, index) => {
    if (!plainObject(binding)) {
      errors.push(`bindings[${index}] must be an object`);
      return;
    }
    const assetId = String(binding.asset_id || "").trim();
    const label = assetId || index;
    if (!assetId || assetIds.has(assetId)) errors.push(`bindings[${index}] has missing or duplicate asset_id`);
    assetIds.add(assetId);
    const selected = binding.selected_reference_ids;
    if (!Array.isArray(selected)) {
      errors.push(`${label} selected_reference_ids must be an array`);
      return;
    }
    const missing = selected.filter((id) => !byId.has(id));
    if (missing.length) errors.push(`${label} references missing IDs: ${missing.join(", ")}`);
    if (selected.length && !String(binding.rationale || "").trim()) errors.push(`${label} rationale is required when references are selected`);
    const uses = binding.reference_uses;
    const useMap = new Map();
    if (!Array.isArray(uses)) errors.push(`${label} reference_uses must be an array`);
    else {
      uses.forEach((use, useIndex) => {
        if (!plainObject(use)) {
          errors.push(`${label} reference_uses[${useIndex}] must be an object`);
          return;
        }
        const referenceId = String(use.reference_id || "").trim();
        if (!referenceId || useMap.has(referenceId)) {
          errors.push(`${label} reference_uses has missing or duplicate reference_id`);
          return;
        }
        useMap.set(referenceId, use);
        if (!selected.includes(referenceId)) errors.push(`${label} reference_uses includes unselected reference ${referenceId}`);
        const roles = use.roles;
        if (!Array.isArray(roles) || !roles.length || roles.some((role) => !REFERENCE_USE_ROLES.has(role))) {
          errors.push(`${label} ${referenceId} roles must use the allowlisted reference roles`);
        }
        if (use.literal_embedding !== "forbidden") errors.push(`${label} ${referenceId} literal_embedding must be forbidden`);
        if (!String(use.rationale || "").trim()) errors.push(`${label} ${referenceId} reference-use rationale is required`);
      });
      for (const referenceId of selected) if (!useMap.has(referenceId)) errors.push(`${label} selected reference ${referenceId} has no explicit use`);
    }
    const styleOnlyIds = selected.filter((referenceId) => {
      const roles = useMap.get(referenceId)?.roles;
      return Array.isArray(roles) && !roles.some((role) => CONTENT_REFERENCE_ROLES.has(role));
    });
    const contentUses = selected.flatMap((referenceId) => {
      const roles = useMap.get(referenceId)?.roles;
      const allowed = Array.isArray(roles) ? roles.filter((role) => CONTENT_REFERENCE_ROLES.has(role)) : [];
      return allowed.length ? [{ reference_id: referenceId, allowed_roles: allowed }] : [];
    });
    const mandatoryPromptConstraints = [
      "所有参考图仅作为生成模型的外部条件输入；严禁把任何参考图本身绘制为画中画、相框、屏幕、海报、卡片、缩略图、拼贴面板、贴花或纹理。",
      "输出只包含当前目标资产及目标模板要求的视图；不得展示参考图、参考缩略图、参考说明、来源文字或Logo。",
    ];
    if (styleOnlyIds.length) {
      mandatoryPromptConstraints.push(`${styleOnlyIds.join("、")} 仅参考风格、色调、材质、渲染或版式；不得复制其中的主体、人物身份、服装、背景、道具、文字、Logo或剧情动作。`);
    }
    if (contentUses.length) {
      mandatoryPromptConstraints.push(`${contentUses.map((use) => `${use.reference_id}仅允许继承${use.allowed_roles.join("/")}`).join("；")}；除此之外不得复制原图姿势、构图、背景、无关物体、文字或Logo。`);
    }
    generationGuards.push({
      asset_id: assetId,
      style_only_reference_ids: styleOnlyIds,
      controlled_content_references: contentUses,
      mandatory_prompt_constraints: mandatoryPromptConstraints,
    });
    const width = binding.target_width;
    const height = binding.target_height;
    if (!Number.isInteger(width) || width <= 0 || !Number.isInteger(height) || height <= 0) {
      errors.push(`${label} target_width/target_height must be positive integers`);
      return;
    }
    const primary = binding.primary_layout_source;
    if (!plainObject(primary)) {
      errors.push(`${label} primary_layout_source is required`);
      return;
    }
    let primaryDimensions = null;
    if (primary.type === "source_reference") {
      if (!selected.includes(primary.reference_id) || !byId.has(primary.reference_id)) errors.push(`${label} primary source reference must be selected`);
      else primaryDimensions = [byId.get(primary.reference_id).width, byId.get(primary.reference_id).height];
      if (binding.aspect_ratio_policy !== "match_primary_reference") errors.push(`${label} source reference must use match_primary_reference`);
    } else if (primary.type === "base_asset") {
      const path = localPath(primary.local_path);
      if (!String(primary.asset_id || "").trim() || !existsSync(path) || !lstatSync(path).isFile()) errors.push(`${label} base asset primary source is incomplete`);
      else {
        if (!primary.checksum || sha256(path) !== String(primary.checksum).toLowerCase()) errors.push(`${label} base asset checksum mismatch`);
        try {
          const actual = imageDimensions(path);
          if (primary.width !== actual[0] || primary.height !== actual[1]) errors.push(`${label} base asset dimensions mismatch`);
          primaryDimensions = actual;
        } catch (error) { errors.push(`${label} ${error.message}`); }
      }
      if (binding.aspect_ratio_policy !== "match_primary_reference") errors.push(`${label} base asset must use match_primary_reference`);
    } else if (primary.type === "asset_template") {
      if (selected.length) errors.push(`${label} selected references require an explicit primary layout reference`);
      if (binding.aspect_ratio_policy !== "asset_template_default") errors.push(`${label} asset template must use asset_template_default`);
      primaryDimensions = [width, height];
    } else errors.push(`${label} primary_layout_source.type is invalid`);
    if (primaryDimensions && !ratioMatches(...primaryDimensions, width, height)) errors.push(`${label} target aspect ratio does not match primary reference`);
  });
  return { ok: !errors.length, reference_count: byId.size, binding_count: bindings.length, generation_guards: generationGuards, errors };
}

export function validateAspectRatio(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 2, values: ["tolerance"] });
  const tolerance = options.tolerance === undefined ? 0.01 : Number(options.tolerance);
  if (!Number.isFinite(tolerance) || tolerance < 0) throw new Error("tolerance must be a non-negative number");
  const reference = imageDimensions(localPath(positionals[0]));
  const output = imageDimensions(localPath(positionals[1]));
  return {
    ok: ratioMatches(...reference, ...output, tolerance),
    reference: { width: reference[0], height: reference[1] },
    output: { width: output[0], height: output[1] },
    reference_aspect_ratio: Number((reference[0] / reference[1]).toFixed(6)),
    output_aspect_ratio: Number((output[0] / output[1]).toFixed(6)),
    tolerance,
  };
}

const AGE_COMPATIBILITY = {
  "童年感": { "童年感": 30, "少年感": 10 },
  "少年感": { "少年感": 30, "青年感": 14, "童年感": 10 },
  "青年感": { "青年感": 30, "少年感": 14, "成熟感": 12 },
  "成熟感": { "成熟感": 30, "青年感": 12, "长者感": 10 },
  "长者感": { "长者感": 30, "成熟感": 12 },
};
const AGE_RANGE_TO_FEEL = { child: "童年感", teen: "少年感", "young-adult": "青年感", adult: "青年感", "middle-aged": "成熟感", senior: "长者感" };
const GENDER_TO_PRESENTATION = { male: "男声", female: "女声", "non-binary": "中性声" };

function normalizedList(value) {
  if (Array.isArray(value)) return value.map((item) => String(item).trim()).filter(Boolean);
  if (typeof value === "string") return value.replaceAll("/", "·").split("·").map((item) => item.trim()).filter(Boolean);
  return [];
}

function desiredAgeFeel(profile) {
  const explicit = String(profile.age_feel || "").trim();
  return Object.hasOwn(AGE_COMPATIBILITY, explicit) ? explicit : AGE_RANGE_TO_FEEL[String(profile.age_range || "").trim()] || null;
}

function presentation(profile) {
  const explicit = String(profile.voice_presentation || "").trim();
  if (["男声", "女声", "童声", "中性声"].includes(explicit)) return explicit;
  if (desiredAgeFeel(profile) === "童年感") return "童声";
  return GENDER_TO_PRESENTATION[String(profile.gender || "").trim()] || null;
}

function scoreVoice(profile, voice, wantedAge) {
  let score = 40;
  const reasons = [`声线呈现=${voice.voice_presentation}`];
  const ageScore = AGE_COMPATIBILITY[wantedAge]?.[voice.age_feel] || 0;
  score += ageScore;
  if (ageScore) reasons.push(`年龄感=${voice.age_feel}(${ageScore})`);
  const pitch = String(profile.pitch_band || "").trim();
  if (pitch && pitch === voice.pitch_band) { score += 8; reasons.push(`音域=${pitch}`); }
  const roles = normalizedList(profile.role_tags).length ? normalizedList(profile.role_tags) : normalizedList(profile.role);
  const roleHits = [...new Set(roles.filter((role) => (voice.role_tags || []).includes(role)))].sort();
  if (roleHits.length) { const amount = Math.min(24, roleHits.length * 8); score += amount; reasons.push(`角色标签=${roleHits.join("/")}`); }
  const freeText = ["voice_description", "personality", "role"].map((key) => String(profile[key] || "")).join(" ");
  const timbres = normalizedList(profile.timbre_tags);
  const expressions = normalizedList(profile.expression_tags);
  if (freeText.includes(voice.core_timbre)) timbres.push(voice.core_timbre);
  if (freeText.includes(voice.expression_tendency)) expressions.push(voice.expression_tendency);
  if (timbres.includes(voice.core_timbre)) { score += 16; reasons.push(`核心音色=${voice.core_timbre}`); }
  if (expressions.includes(voice.expression_tendency)) { score += 12; reasons.push(`表达倾向=${voice.expression_tendency}`); }
  if (voice.confidence === "较高") { score += 5; reasons.push("标签置信度=较高"); }
  return [score, reasons];
}

export function matchVoice(tokens) {
  const { options, positionals } = parseOptions(tokens, {
    positionals: 1,
    values: ["catalog", "output", "existing-voice-id", "max-candidates"],
    repeated: ["reserved-voice-id"],
    booleans: ["allow-reuse"],
  });
  const profile = readJson(localPath(positionals[0]), { object: true });
  const catalogPath = options.catalog
    ? localPath(options.catalog)
    : resolve(process.env.MANTURHUB_SKILL_DIR, "assets", "voice-library", "catalog.json");
  const catalog = readJson(catalogPath, { object: true });
  if (!Array.isArray(catalog.voices)) throw new Error("voice catalog must contain voices[]");
  let result;
  if (options["existing-voice-id"]) {
    const selected = catalog.voices.find((voice) => voice.voice_id === options["existing-voice-id"] && voice.active);
    result = selected
      ? { status: "matched_locked_identity", reason: "same_canonical_character_keeps_existing_voice", selected, candidates: [] }
      : { status: "unresolved", reason: "existing_voice_id_not_active_in_catalog", selected: null, candidates: [] };
  } else {
    const wantedPresentation = presentation(profile);
    const wantedAge = desiredAgeFeel(profile);
    if (!wantedPresentation || !wantedAge) result = { status: "unresolved", reason: "voice_presentation_or_age_feel_missing", selected: null, candidates: [] };
    else {
      const reserved = new Set(options["reserved-voice-id"] || []);
      const eligible = catalog.voices.filter((voice) => voice.active && voice.confidence !== "待试听确认" && voice.voice_presentation === wantedPresentation && (options["allow-reuse"] || !reserved.has(voice.voice_id)));
      const ranked = eligible.map((voice) => {
        const [score, reasons] = scoreVoice(profile, voice, wantedAge);
        return { voice_id: voice.voice_id, score, confidence: voice.confidence, reasons, public_url: voice.public_url, asset_id: voice.asset_id };
      }).sort((left, right) => right.score - left.score || left.voice_id.localeCompare(right.voice_id));
      const maxCandidates = options["max-candidates"] === undefined ? 3 : Number(options["max-candidates"]);
      if (!Number.isInteger(maxCandidates) || maxCandidates < 1) throw new Error("max-candidates must be a positive integer");
      const candidates = ranked.slice(0, maxCandidates);
      const top = candidates[0] || null;
      const margin = top ? (candidates.length > 1 ? top.score - candidates[1].score : 999) : null;
      const safe = Boolean(top && top.confidence === "较高" && top.score >= 75 && margin >= 6);
      result = {
        status: safe ? "matched" : top ? "review_required" : "no_candidate",
        reason: safe ? "unique_high_confidence_match" : "manual_review_required",
        selected: safe ? catalog.voices.find((voice) => voice.voice_id === top.voice_id) : null,
        candidates,
        score_margin: margin,
      };
    }
  }
  Object.assign(result, {
    character_id: profile.asset_id || profile.character_id,
    canonical_name: profile.canonical_name,
    catalog_id: catalog.catalog_id,
    catalog_version: catalog.catalog_version,
    match_policy_version: "1.0.0",
  });
  if (options.output) writeJson(options.output, result);
  return result;
}

function rowValue(row, ...keys) {
  for (const key of keys) if (Object.hasOwn(row, key) && row[key] !== null && row[key] !== "") return row[key];
  return null;
}

export function planScenes(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["concurrency", "requested-concurrency", "output"] });
  const concurrency = options.concurrency === undefined ? DEFAULT_VIDEO_CONCURRENCY : Number(options.concurrency);
  const requested = options["requested-concurrency"] === undefined ? concurrency : Number(options["requested-concurrency"]);
  const parallelism = videoParallelismPolicy(requested, concurrency);
  const rows = readJson(localPath(positionals[0]));
  if (!Array.isArray(rows)) throw new Error("clip rows must be a JSON array");
  const errors = [];
  const ids = new Set();
  for (const row of rows) {
    const id = String(rowValue(row, "Clip ID", "clip_id") || "").trim();
    if (!id || ids.has(id)) errors.push(`missing or duplicate Clip ID: ${JSON.stringify(id)}`);
    ids.add(id);
    const validation = String(rowValue(row, "校验状态", "lint_status") || "").trim();
    if (validation !== "校验通过") errors.push(`${id || "<unknown>"} 校验状态必须为“校验通过”，当前为 ${JSON.stringify(validation || "空")}`);
    if (!Object.hasOwn(row, "变体决策JSON") && !Object.hasOwn(row, "variant_decisions")) errors.push(`${id || "<unknown>"} 缺少变体决策JSON`);
    const rawConflicts = rowValue(row, "连续性冲突", "continuity_conflicts");
    let conflicts = rawConflicts;
    if (typeof rawConflicts === "string" && rawConflicts.trim()) {
      try { conflicts = JSON.parse(rawConflicts); }
      catch { conflicts = [rawConflicts]; }
    }
    if ((Array.isArray(conflicts) && conflicts.length) || (!Array.isArray(conflicts) && String(conflicts || "").trim())) {
      errors.push(`${id || "<unknown>"} 存在连续性冲突，禁止进入视频队列`);
    }
  }
  const chains = new Map();
  for (const row of rows) {
    const episode = Number(rowValue(row, "集数", "episode") || 0);
    const scene = String(rowValue(row, "场次组", "scene_group") || "").trim();
    const order = Number(rowValue(row, "集内序号", "order") || 0);
    const clipId = String(rowValue(row, "Clip ID", "clip_id") || "").trim();
    const previous = String(rowValue(row, "前序Clip ID", "连续性来源Clip ID", "previous_clip_id") || "").trim();
    if (!Number.isInteger(episode) || episode < 1 || !scene || !Number.isInteger(order) || order < 1) errors.push(`${clipId || "<unknown>"} lacks episode/scene_group/order`);
    const key = `${String(episode).padStart(8, "0")}\0${scene}`;
    if (!chains.has(key)) chains.set(key, { episode, scene, clips: [] });
    chains.get(key).clips.push({ clip_id: clipId, episode, scene_group: scene, order, previous_clip_id: previous });
  }
  const outputChains = [...chains.values()].sort((a, b) => a.episode - b.episode || (a.scene < b.scene ? -1 : a.scene > b.scene ? 1 : 0)).map(({ episode, scene, clips }) => {
    clips.sort((a, b) => a.order - b.order);
    clips.forEach((clip, index) => {
      const expected = index ? clips[index - 1].clip_id : "";
      if (clip.previous_clip_id !== expected) errors.push(`${clip.clip_id} previous_clip_id must be ${JSON.stringify(expected)}`);
    });
    return { chain_id: `EP${String(episode).padStart(2, "0")}-${scene}`, episode, scene_group: scene, clips };
  });
  if (errors.length) throw new Error(errors.join("; "));
  const activeChainIds = outputChains.slice(0, concurrency).map((chain) => chain.chain_id);
  const queuedChainIds = outputChains.slice(concurrency).map((chain) => chain.chain_id);
  const payload = {
    version: "scene-chain-plan-v1",
    max_parallel_chains: concurrency,
    ...parallelism,
    active_chain_ids: activeChainIds,
    queued_chain_ids: queuedChainIds,
    chains: outputChains,
  };
  const target = outputPath(options.output, "--output");
  writeJson(target, payload);
  return {
    ok: true,
    chain_count: outputChains.length,
    active_chain_count: activeChainIds.length,
    queued_chain_count: queuedChainIds.length,
    effective_video_concurrency: concurrency,
    output: target,
  };
}

export function materializeVideo(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["previous-tail-url", "output"], booleans: ["needs-previous-tail"] });
  const request = structuredClone(readJson(localPath(positionals[0]), { object: true }));
  if (!plainObject(request.metadata)) throw new Error("metadata must be an object");
  if (request.metadata.return_last_frame !== true) throw new Error("metadata.return_last_frame must be true");
  if (!Array.isArray(request.metadata.content)) throw new Error("metadata.content must be an array");
  const prompt = String(request.prompt || "").trim();
  if (!prompt.endsWith(HARD_ENDING)) throw new Error(`prompt must end exactly with ${HARD_ENDING}`);
  const previous = options["previous-tail-url"] || "";
  if (options["needs-previous-tail"]) {
    const url = httpUrl(previous, "previous tail URL");
    const count = request.metadata.content.filter((item) => plainObject(item) && item.type === "image_url").length;
    const token = `@Image${count + 1}`;
    request.metadata.content.push({ type: "image_url", image_url: { url }, role: "reference_image" });
    const body = prompt.slice(0, -HARD_ENDING.length).trimEnd();
    request.prompt = `${body}\n\n连续性首帧：${token} 是同一场次上一Clip的真实尾帧；从该画面自然继续，不得跳变人物位置、服装、光线或空间关系。\n\n${HARD_ENDING}`;
  } else if (previous) throw new Error("scene-start request must not receive a previous tail URL");
  const target = outputPath(options.output, "--output");
  writeJson(target, request);
  return {
    ok: true,
    output: target,
    request_stage: "实际请求体",
    tail_injection_status: options["needs-previous-tail"] ? "已注入前序尾帧" : "无需注入",
    generation_status: "待提交",
  };
}

export function materializeVideoParams(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["output"] });
  const request = readJson(localPath(positionals[0]), { object: true });
  const metadata = request.metadata;
  if (!plainObject(metadata)) throw new Error("metadata must be an object");
  if (metadata.return_last_frame !== true) throw new Error("metadata.return_last_frame must be true");
  const model = MODEL_MAP[String(request.model || "")];
  if (!model) throw new Error(`unsupported video model: ${JSON.stringify(request.model)}`);
  const prompt = String(request.prompt || "").trim();
  if (!prompt) throw new Error("prompt is required");
  if (!Number.isInteger(request.duration) || request.duration < 5 || request.duration > 15) throw new Error("duration must be an integer between 5 and 15");
  if (!Array.isArray(metadata.content)) throw new Error("metadata.content must be an array");
  const images = [];
  const imageRoles = [];
  const audios = [];
  metadata.content.forEach((item, index) => {
    if (!plainObject(item)) throw new Error(`metadata.content[${index}] must be an object`);
    if (item.type === "image_url") {
      if (!plainObject(item.image_url)) throw new Error(`metadata.content[${index}].image_url must be an object`);
      images.push(httpUrl(item.image_url.url, `metadata.content[${index}].image_url.url`));
      const role = String(item.role || "reference_image");
      if (!IMAGE_ROLES.has(role)) throw new Error(`unsupported image role: ${role}`);
      imageRoles.push(role);
    } else if (item.type === "audio_url") {
      if (!plainObject(item.audio_url)) throw new Error(`metadata.content[${index}].audio_url must be an object`);
      audios.push(httpUrl(item.audio_url.url, `metadata.content[${index}].audio_url.url`));
    } else throw new Error(`unsupported metadata content type: ${JSON.stringify(item.type)}`);
  });
  if (images.length > 9) throw new Error("op.video.generate accepts at most 9 reference images");
  if (audios.length > 3) throw new Error("op.video.generate accepts at most 3 reference audios");
  const params = {
    prompt,
    model,
    resolution: String(metadata.resolution || "480p"),
    duration: request.duration,
    ratio: String(metadata.ratio || "9:16"),
    generate_audio: metadata.generate_audio !== false,
    seed: metadata.seed ?? -1,
    return_last_frame: true,
  };
  if (images.length) { params.images = images; params.image_roles = imageRoles; }
  if (audios.length) params.ref_audios = audios;
  const target = outputPath(options.output, "--output");
  writeJson(target, params);
  return { ok: true, output: target };
}

function classifyStatus(value) {
  const status = String(value || "").trim().toLowerCase();
  if (!status) throw new Error("ManturHub status response is missing status");
  if (ACTIVE_STATES.has(status)) return { status, terminal: false, failed: false };
  if (SUCCESS_STATES.has(status)) return { status, terminal: true, failed: false };
  if (FAILED_STATES.has(status)) return { status, terminal: true, failed: true };
  throw new Error(`ManturHub status response contains unknown status: ${value}`);
}

function redactStatusText(value) {
  if (value === undefined || value === null) return value;
  return String(value)
    .replace(/\bsk-[A-Za-z0-9_-]+\b/g, "[REDACTED_KEY]")
    .replace(/https:\/\/[^\s"'<>?]+\?[^\s"'<>]+/g, (match) => {
      try {
        const url = new URL(match);
        return `${url.origin}${url.pathname}?[REDACTED_QUERY]`;
      } catch {
        return "[REDACTED_URL]";
      }
    });
}

export async function pollCheckpoint(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["state-file", "output-dir", "stage"] });
  if (!options["state-file"] || !options["output-dir"]) throw new Error("--state-file and --output-dir are required");
  const statePath = assertProjectWritePath(options["state-file"]);
  const outputDir = assertProjectWritePath(options["output-dir"]);
  const state = existsSync(statePath) ? readJson(statePath, { object: true }) : {};
  const { payload: status } = runCli(["status", positionals[0]], { allowNonZeroJson: true });
  const classification = classifyStatus(status.status);
  if (!status.task_id) throw new Error("ManturHub status returned an invalid task payload");
  const taskId = String(status.task_id);
  if (state.task_id && state.task_id !== taskId) throw new Error(`state belongs to task ${state.task_id}, not ${taskId}`);
  const checkpoint = Number(status.checkpoint_seq || 0);
  const previous = Number(state.last_checkpoint_seq || 0);
  if (!Number.isInteger(checkpoint) || checkpoint < 0) throw new Error("checkpoint_seq must be a non-negative integer");
  if (checkpoint < previous) throw new Error(`checkpoint regressed from ${previous} to ${checkpoint}`);
  const changed = checkpoint > previous || classification.status !== String(state.status || "").toLowerCase();
  const observedAt = new Date().toISOString();
  const firstObservedAt = state.submitted_at || state.first_observed_at || observedAt;
  const firstObservedMs = Date.parse(firstObservedAt);
  if (!Number.isFinite(firstObservedMs)) throw new Error("state submitted_at/first_observed_at must be a valid timestamp");
  const elapsedSeconds = Math.max(0, Math.floor((Date.parse(observedAt) - firstObservedMs) / 1000));
  const [base] = resolveManturhubBase();
  const waitPolicy = options.stage ? asyncWaitPolicy(base, options.stage) : null;
  if (options.stage && !waitPolicy) throw new Error("--stage must be extraction or clips when an async wait policy is requested");
  const nextPollAfterSeconds = waitPolicy && !classification.terminal
    ? (elapsedSeconds < waitPolicy.initial_poll_period_seconds
        ? waitPolicy.initial_poll_interval_seconds
        : waitPolicy.steady_poll_interval_seconds)
    : null;
  let partialPath = null;
  if (checkpoint > previous && plainObject(status.partial_result) && status.partial_result.result_url) {
    const url = httpUrl(status.partial_result.result_url, "partial result URL", { httpsOnly: true });
    const response = await fetch(url, {
      headers: { "User-Agent": "drama-pipeline-skill/1" },
      signal: AbortSignal.timeout(45000),
    });
    if (!response.ok) throw new Error(`partial checkpoint download failed (HTTP ${response.status})`);
    const partial = await response.json();
    partialPath = resolve(outputDir, `checkpoint-${String(checkpoint).padStart(6, "0")}.json`);
    writeJson(partialPath, partial);
  }
  writeJson(statePath, {
    task_id: taskId,
    poll_url: positionals[0],
    stage: waitPolicy?.stage || state.stage,
    status: classification.status,
    submitted_at: state.submitted_at,
    first_observed_at: firstObservedAt,
    last_observed_at: observedAt,
    elapsed_seconds: elapsedSeconds,
    last_checkpoint_seq: Math.max(previous, checkpoint),
    updated_at: status.updated_at,
    partial_path: partialPath || state.partial_path,
    result_url: status.result_url,
    report_url: status.report_url,
  });
  return {
    task_id: taskId,
    status: classification.status,
    terminal: classification.terminal,
    failed: classification.failed,
    job_interpretation: classification.terminal
      ? (classification.failed ? "terminal_failure" : "terminal_success")
      : "running_not_failed",
    changed,
    checkpoint_seq: checkpoint,
    partial_path: partialPath,
    progress: status.progress,
    partial_result_available: Boolean(status.partial_result),
    result_available: Boolean(status.result_url),
    report_available: Boolean(status.report_url),
    error: redactStatusText(status.error),
    message: redactStatusText(status.message),
    retryable: status.retryable,
    wait_policy: waitPolicy,
    elapsed_seconds: elapsedSeconds,
    next_poll_after_seconds: nextPollAfterSeconds,
    long_running: Boolean(waitPolicy && !classification.terminal && elapsedSeconds >= waitPolicy.long_running_after_seconds),
    beyond_minimum_observation: Boolean(waitPolicy && !classification.terminal && elapsedSeconds >= waitPolicy.minimum_observation_seconds),
  };
}

function safeName(value) {
  return String(value).replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^_+|_+$/g, "") || "clip";
}

export function exportEpisodes(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["output-dir"] });
  const rows = readJson(localPath(positionals[0]));
  if (!Array.isArray(rows)) throw new Error("manifest must be a JSON array");
  const grouped = new Map();
  for (const row of rows) {
    const clipId = String(row?.clip_id || "").trim();
    const episode = Number(row?.episode || 0);
    const order = Number(row?.order || 0);
    const path = localPath(row?.video_path);
    if (!clipId || !Number.isInteger(episode) || episode < 1 || !Number.isInteger(order) || order < 1 || String(row?.status || "").toLowerCase() !== "completed" || !existsSync(path) || !lstatSync(path).isFile()) {
      throw new Error(`incomplete export row: ${clipId || "<unknown>"}`);
    }
    if (!grouped.has(episode)) grouped.set(episode, []);
    grouped.get(episode).push({ clipId, order, path });
  }
  const outputDir = outputPath(options["output-dir"], "--output-dir");
  mkdirSync(outputDir, { recursive: true });
  const episodes = [];
  for (const episode of [...grouped.keys()].sort((a, b) => a - b)) {
    const clips = grouped.get(episode).sort((a, b) => a.order - b.order);
    const target = assertProjectWritePath(resolve(outputDir, `EP${String(episode).padStart(2, "0")}-clips.zip`));
    createZip(target, clips.map((clip) => ({
      path: clip.path,
      name: `${String(clip.order).padStart(3, "0")}-${safeName(clip.clipId)}${extname(clip.path).toLowerCase()}`,
    })));
    episodes.push({ episode, clip_count: clips.length, zip: target });
  }
  return { ok: true, episodes };
}

export const ACTIONS = {
  doctor,
  run: runWorkflow,
  "migrate-image-provider": migrateImageProvider,
  "validate-references": validateReferences,
  "validate-aspect-ratio": validateAspectRatio,
  "match-voice": matchVoice,
  "base-media-contract": baseMediaContract,
  "storyboard-status-contract": storyboardStatusContract,
  "normalize-storyboard-statuses": normalizeStoryboardStatuses,
  "plan-scenes": planScenes,
  "materialize-video": materializeVideo,
  "materialize-video-params": materializeVideoParams,
  "poll-checkpoint": pollCheckpoint,
  "export-episodes": exportEpisodes,
  "export-jianying-drafts": exportJianyingDrafts,
  "import-jianying-draft": importJianyingDraft,
};
