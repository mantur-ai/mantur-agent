// Private Runtime adapter. Never expose task identities or result URLs in UI snapshots.
function fail(code) {
  throw Object.assign(new Error(code), { code });
}
function object(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

export function videoTaskIdentity(record, source) {
  const ids = ['task_id', 'job_id'].filter(key => Object.hasOwn(record, key));
  if (!ids.length) fail(`VIDEO_${source}_IDENTITY_MISSING`);
  for (const key of ids) {
    if (typeof record[key] !== 'string' || !record[key].trim()) fail(`VIDEO_${source}_IDENTITY_INVALID`);
  }
  if (ids.length === 2 && record.task_id !== record.job_id) fail(`VIDEO_${source}_IDENTITY_CONFLICT`);
  return record[ids[0]];
}

function pollTarget(value) {
  try {
    if (typeof value !== 'string' || !value.trim()) throw new Error();
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.hash) throw new Error();
    return url.href;
  } catch { fail('VIDEO_POLL_TARGET_INVALID'); }
}

export function validateVideoCheckpoint(state, requestedUrl) {
  const identity = videoTaskIdentity(state, 'CHECKPOINT');
  const requested = pollTarget(requestedUrl);
  if (Object.hasOwn(state, 'poll_url') && pollTarget(state.poll_url) !== requested) fail('VIDEO_POLL_TARGET_MISMATCH');
  return identity;
}

export function normalizeVideoResponse(response, expectedIdentity) {
  if (!object(response)) fail('VIDEO_RESPONSE_INVALID');
  const identity = videoTaskIdentity(response, 'RESPONSE');
  if (identity !== expectedIdentity) fail('VIDEO_TASK_IDENTITY_MISMATCH');
  const result = object(response.result?.value) ? response.result.value
    : object(response.result) ? response.result : {};
  const present = value => value !== undefined && value !== null && value !== '';
  const choose = (...values) => values.find(present);
  const invalid = [];
  function mediaUrl(value, field) {
    if (!present(value)) return undefined;
    try {
      if (typeof value !== 'string') throw new Error();
      const url = new URL(value);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error();
      return url.href;
    } catch { invalid.push(field); return undefined; }
  }
  const video = mediaUrl(choose(result.video_url, result.result_url, response.video_url, response.result_url), 'video_url');
  const tail = mediaUrl(choose(result.last_frame_url, response.last_frame_url), 'last_frame_url');
  return {
    task_id: identity,
    video_url: video,
    result_url: video,
    last_frame_url: tail,
    invalid_fields: invalid,
  };
}

export function videoResultDiagnostic(result, classification) {
  const missing = ['video_url', 'last_frame_url'].filter(key => !result[key]);
  if (result.invalid_fields.length) return {
    code: 'VIDEO_RESULT_URL_INVALID', invalid_fields: result.invalid_fields,
    message: 'Result contains invalid media URLs; preserve the original task and query it again. Never resubmit.',
  };
  if (classification.terminal && !classification.failed && missing.length) return {
    code: 'VIDEO_RESULT_INCOMPLETE', missing_fields: missing,
    message: 'Remote task succeeded but media references are incomplete. Query the original task; never resubmit.',
  };
  return undefined;
}
