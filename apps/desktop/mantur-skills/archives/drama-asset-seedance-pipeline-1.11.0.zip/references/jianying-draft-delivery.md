# Optional JianYing draft delivery

This is a local deterministic delivery action owned by the Skill. It is not an operator, a server-side scheduler, or a JianYing GUI export API.

## User entry and profile gate

The user selects the deliverable only through the normal workflow entry:

```bash
manturhub skill run drama-asset-seedance-pipeline --project "$PROJECT_DIR" -- \
  --stage video --deliverable jianying-drafts
```

The Agent may then call the allowlisted internal export action. Version 1 supports only `jianying-macos-5.9`, the last widely used plaintext JianYing format. JianYing 6.0+ and unknown versions fail closed because the format is encrypted or lacks reliable compatibility evidence. Do not decrypt, force-write, relabel another profile, or claim GUI-open validation without actually opening it.

## Input contract

Pass a JSON object with `schema_version=1`, `project_name`, `episodes[]`, and `clips[]`. Every episode declares its complete target set through `expected_clip_ids`; this prevents a table export that silently omitted a row from producing a partial draft.

```json
{
  "schema_version": 1,
  "project_name": "示例漫剧",
  "episodes": [
    {"episode_number": 1, "expected_clip_ids": ["CLIP-001", "CLIP-002"]}
  ],
  "clips": [
    {
      "clip_id": "CLIP-001",
      "episode_number": 1,
      "scene_index": 1,
      "clip_index": 1,
      "status": "completed",
      "video_path": "/project/videos/CLIP-001.mp4",
      "video_url": "https://optional-download-url",
      "sha256": "64-lowercase-hex",
      "planned_duration_seconds": 10
    }
  ]
}
```

Rules:

- sort only by `episode_number`, then `scene_index`, then `clip_index`; table record order is never evidence;
- all positions and Clip IDs are unique;
- each expected Clip is present exactly once and has `status=completed`;
- a local file wins when supplied; otherwise download the HTTPS URL into package staging;
- verify the real bytes against the declared SHA-256 and parse MP4/MOV duration, dimensions, and audio-track presence with the bundled pure-JS parser;
- planned duration is audit context only and never substitutes for actual media duration;
- all clips in one episode must use one canvas size in version 1; do not invent scaling or crop rules.

## Export contract

The Agent calls the internal action with the user-selected project directory:

```bash
manturhub skill exec drama-asset-seedance-pipeline export-jianying-drafts \
  --project "$PROJECT_DIR" -- completed-videos.json \
  --output-dir deliverables/jianying --target-profile jianying-macos-5.9
```

Each episode produces one portable ZIP containing one draft directory:

```text
manturhub-EP01-<idempotency-prefix>/
├── draft_info.json
├── draft_content.json
├── assets/video/<ordered local clips>
├── manifest.json
├── validation-report.json
└── IMPORT.md
```

The timeline has one video track. Segments are contiguous, preserve Clip boundaries, use hard cuts, retain each source video's own audio, and contain no subtitle, BGM, independent audio, transition, template, sticker, or decorative material. Every package and source file is hashed. The idempotency key is stable for the project name, episode, target profile, sorted Clip identities, and source hashes. A trusted completed package is reused; an untracked conflicting path is never overwritten.

The ZIP contains no source URL or signed query. Draft paths use a portable marker until target-machine import, so the deliverable does not depend on a source-machine absolute path.

## Target-machine import

Import is a separate significant local mutation. It is never performed by default and requires all of:

1. an installed JianYing application whose bundle ID and exact version resolve to `jianying-macos-5.9`;
2. an explicit existing `com.lveditor.draft` target directory;
3. explicit user approval represented by `--confirm-write`;
4. complete package hash verification before any draft-store write.

The internal importer extracts safely, rejects traversal and unsupported ZIP features, copies every local asset, rewrites the portable marker to the target-machine absolute path, creates the per-draft metadata, and appends a new entry to the existing `root_meta_info.json`. It never overwrites an existing draft. When an existing root index is changed, it first writes a named backup. An unreadable or unknown root-index structure blocks import.

Generating a ZIP is not proof that JianYing displayed or opened it. After import, the Agent must open the detected JianYing 5.9.x application, verify the project is visible, open it, and confirm the three timeline invariants: ordered Clips, no gaps/overlaps, and playable source audio. GUI export to MP4 is outside scope.

## Feishu project-file record

Continue using the existing `项目文件` table. Write one record per episode with at least:

- episode number;
- draft ZIP attachment and plain-text public URL after upload;
- Clip count;
- actual total source duration seconds;
- target JianYing profile/version;
- status (`待上传/待导入验收`, `已导入待打开验收`, `已打开验收`, or explicit failure);
- validation summary and package SHA-256.

Do not create another Sheet for JianYing delivery.
