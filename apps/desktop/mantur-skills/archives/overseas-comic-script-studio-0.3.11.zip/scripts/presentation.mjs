// Optional reading views only. Never rewrite receipts, identity keys, evidence or workflow state.
const text = value => typeof value === 'string' && value.trim().length > 0;
const validName = value => text(value) && value.length <= 300 && !/[\u0000-\u001f\u007f-\u009f]/u.test(value);
const array = value => Array.isArray(value) ? value : [];

/** Resolve exact canonical identities to optional display labels, without guessing aliases. */
export function characterNames(assets, language, overrides = []) {
  const names = new Map(), seen = new Set(), ambiguous = new Set();
  if (!['zh', 'en'].includes(language)) return names;
  for (const character of array(assets?.characters)) {
    const canonical = character?.canonicalName;
    if (!text(canonical)) continue;
    if (seen.has(canonical)) ambiguous.add(canonical);
    seen.add(canonical);
    const candidates = array(overrides).filter(row => row?.canonicalName === canonical);
    const override = candidates.length === 1 ? candidates[0]?.displayNames?.[language] : undefined;
    const value = validName(override) ? override : character?.displayNames?.[language];
    if (validName(value)) names.set(canonical, value.trim());
  }
  for (const canonical of ambiguous) names.delete(canonical);
  return names;
}

const normalize = value => value.replace(/\s+/gu, ' ').trim();
const scriptCounts = value => ({ hanCharacterCount: [...value.matchAll(/\p{Script=Han}/gu)].length,
  latinLetterCount: [...value.matchAll(/\p{Script=Latin}/gu)].filter(m => /\p{Letter}/u.test(m[0])).length, complete: true });
const note = 'Quote provenance only; sourceEpisodes is the WORKING comparison, episodes is the reviewed draft. '
  + 'Source-only/unmatched evidence needs inspection, not automatic FIX or dismissal. '
  + 'A text match does not verify the claim; absence claims and unquoted evidence remain unverified. '
  + 'Script counts describe the quoted characters, not their meaning or language quality. Never treat an English quote as proof of Chinese prose. Original issue and workflow are unchanged.';

// Only current reviewed prose: keys and exact canonical identity values are not narrative language.
function reviewedProseScriptCounts(input) {
  const identities = new Set(['characters', 'locations', 'props'].flatMap(kind => array(input.assets?.[kind])
    .map(asset => asset?.canonicalName).filter(value => typeof value === 'string')));
  const count = (node, counts, depth = 0) => {
    if (depth > 32) { counts.complete = false; return; }
    if (typeof node === 'string' && !identities.has(node)) {
      const c = scriptCounts(node); counts.hanCharacterCount += c.hanCharacterCount; counts.latinLetterCount += c.latinLetterCount;
    } else if (node && typeof node === 'object') Object.values(node).forEach(child => count(child, counts, depth + 1));
  };
  return array(input.episodes).filter(episode => episode && typeof episode === 'object').map(episode => {
    const body = scriptCounts(''), continuity = scriptCounts('');
    count(episode.title, body); array(episode.scriptLines).forEach(line => count(line?.text, body));
    count(episode.continuityDelta, continuity); count(episode.continuitySnapshot, continuity);
    return { episodeNumber: Number.isInteger(episode.episodeNumber) ? episode.episodeNumber : 0, body, continuity };
  });
}

/** Locate quoted evidence in the frozen invocation input; no match is never a rejection or a PASS. */
export function evidenceChecks(input, issues) {
  if (!input || !Array.isArray(issues)) return [];
  const passages = [];
  const collect = (value, path, collection, episodeNumber, depth = 0) => {
    if (depth > 32 || passages.length >= 10000) return;
    if (Array.isArray(value)) value.forEach((v, i) => collect(v, `${path}/${i}`, collection, episodeNumber, depth + 1));
    else if (value && typeof value === 'object') {
      for (const [key, child] of Object.entries(value)) if (key !== 'markdown') {
        collect(child, `${path}/${key.replaceAll('~', '~0').replaceAll('/', '~1')}`, collection, episodeNumber, depth + 1);
      }
    } else if (typeof value === 'string' && value.length >= 12) passages.push({ collection, episodeNumber, path, text: normalize(value) });
  };
  for (const collection of ['episodes', 'sourceEpisodes']) array(input[collection]).forEach((episode, i) => {
    collect(episode, `/${collection}/${i}`, collection, Number.isInteger(episode?.episodeNumber) ? episode.episodeNumber : 0);
  });
  const languageFacts = reviewedProseScriptCounts(input);
  return issues.filter(issue => issue && typeof issue === 'object' && !String(issue.id || '').startsWith('PROGRAM_')).map(issue => {
    const candidates = new Set();
    const pattern = /"([^"\r\n]{0,2000})"|“([^”\r\n]{0,2000})”|「([^」\r\n]{0,2000})」/gu;
    const evidence = String(issue.evidence || '');
    for (const match of evidence.matchAll(pattern)) {
      const quote = match[1] ?? match[2] ?? match[3];
      const pathKey = evidence.slice(0, match.index).trimEnd().endsWith('[')
        && evidence.slice(match.index + match[0].length).trimStart().startsWith(']');
      if (!pathKey && quote.length >= 12) candidates.add(quote);
      if (candidates.size === 12) break;
    }
    let target = false, source = false, other = false, missing = false;
    const quotes = [...candidates].map(quote => {
      const matches = [];
      let found = false;
      for (const passage of passages) {
        if (!passage.text.includes(normalize(quote))) continue;
        found = true;
        if (passage.collection === 'episodes') {
          if (!Number.isInteger(issue.episodeNumber) || issue.episodeNumber === passage.episodeNumber) target = true;
          else other = true;
        } else source = true;
        if (matches.length < 6) matches.push({ collection: passage.collection, episodeNumber: passage.episodeNumber, path: passage.path });
      }
      if (!found) missing = true;
      return { quote, matches, scriptCounts: scriptCounts(quote) };
    });
    const status = target ? source || other ? 'MIXED_REFERENCES' : missing ? 'PARTIAL_TARGET_SUPPORT' : 'TARGET_TEXT_FOUND'
      : source ? 'SOURCE_ONLY' : other ? 'OTHER_EPISODE_ONLY' : 'UNVERIFIED';
    return { issueId: issue.id || '', advisory: true, quotes, status, note,
      reviewedProseScriptCounts: languageFacts.filter(fact => !Number.isInteger(issue.episodeNumber) || fact.episodeNumber === issue.episodeNumber) };
  });
}
