import { publicProjectClient } from './integration.mjs';
import { fileURLToPath } from 'node:url';
import { realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';

/** Public update observation only. No installation, private records or automatic updates. */
export async function checkSkillUpdate({ client = publicProjectClient(), skillDir = fileURLToPath(new URL('../', import.meta.url)) } = {}) {
  const result={status:'unknown',local:{managed:false,platformVersion:null,contentVersion:null},server:{platformVersion:null,contentVersion:null},
    changes:[],notesAvailable:false,message:'尚未核实发布版本；原任务与本地产物不受影响。'};
  try{
    const actual=await realpath(skillDir),data=await client.updates();
    const rows=[];
    for(const row of data.skills||[]){try{if(row.path&&await realpath(row.path)===actual)rows.push(row);}catch{}}
    if(rows.length!==1)return {...result,status:'unmanaged',message:'当前安装未由工具纳管，请使用当前安装渠道的更新入口。'};
    const row=rows[0];
    const decision=row.status==='outdated'?{updateTarget:createHash('sha256').update(JSON.stringify({path:actual,slug:row.slug,client:row.client,local:row.local_version,remote:row.online_version,modified:row.modified})).digest('hex'),
      choices:[{id:'update',label:'更新后继续'},{id:'continue',label:'继续当前版本'}]}:{};
    return {...result,status:row.status==='outdated'?'update_available':row.status,
      ...decision,
      local:{...result.local,managed:row.tracked===true,platformVersion:row.local_version,modified:row.modified===true,client:row.client},
      server:{...result.server,platformVersion:row.online_version},
      message:row.status==='outdated'?'发现新版本，请由用户选择更新或继续；公开工具未返回更新摘要。':'已按公开工具核对平台版本；未提供源码版本或更新摘要。'};
  }catch{return result;}
}
