// Keep one request in flight and apply only changed project revisions.
export function createSnapshotSync({read,apply,onError,onSuccess=()=>{}}){
  let pending=null,revision,mediaRevision,initialized=false;
  return function refresh({fresh=false}={}){
    if(pending)return fresh?pending.then(()=>refresh()):pending;
    pending=(async()=>{try{const next=await read();if(!initialized||next.revision===undefined||next.revision!==revision||next.mediaRevision!==mediaRevision){await apply(next);revision=next.revision;mediaRevision=next.mediaRevision;initialized=true;}onSuccess(next);}catch(error){onError(error);}finally{pending=null;}})();
    return pending;
  };
}

// Manual synchronization only asks the local server to reconcile existing jobs.
export function createRemoteRefresh({request,refresh,onStatus=()=>{},onError=()=>{}}){
  let pending=null;
  return function refreshRemote(){
    if(pending)return pending;
    pending=(async()=>{try{const result=await request();onStatus(result.sync);await refresh();}catch(error){onError(error);}finally{pending=null;}})();
    return pending;
  };
}

export function remoteSyncText(sync){
  const labels={idle:'等待同步',syncing:'正在查询任务并同步产物',ok:'已完成同步',partial:'部分任务同步未完成',error:'同步失败',busy:'项目正在处理，稍后重试'};
  const status=labels[sync?.status]||'尚未获取同步状态';
  const parsed=sync?.lastSuccessAt?new Date(sync.lastSuccessAt):null;
  const last=parsed&&Number.isFinite(parsed.getTime())?` · 上次成功 ${parsed.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}`:'';
  return `服务端：${status}${last}${sync?.message?` · ${sync.message}`:''}`;
}

export function pendingResultText(op){
  if(['failed','qa_failed'].includes(op?.status))return '制作或验收遇到问题，请在聊天中处理这条原任务。';
  if(['remote_succeeded','artifact_pending'].includes(op?.status))return '服务端已完成制作，正在下载或验收成片；工作台会同步原任务产物，无需重新制作。';
  if(op?.status==='running')return op.hasError?'原任务已提交，暂时无法同步最新状态；请刷新状态或在聊天中恢复原任务。':'原任务已提交，正在后台处理；完成后工作台会自动同步成片，无需再次开始制作。';
  if(op?.status==='unknown')return '原任务提交状态待核实，请刷新状态或在聊天中核对原任务，避免重复制作。';
  if(op?.status==='succeeded')return '原任务已完成，但本地成片记录暂不可用，请在聊天中恢复原任务产物。';
  return '确认计划后，在聊天中开始制作。';
}

export function movePreservingMedia(parent,node,before){
  if(typeof parent.moveBefore==='function'){parent.moveBefore(node,before);return;}
  const videos=[...(node.nodeName==='VIDEO'?[node]:node.querySelectorAll('video'))];
  const states=videos.map(video=>({video,time:video.currentTime,paused:video.paused,muted:video.muted,volume:video.volume}));
  parent.insertBefore(node,before);
  for(const state of states){const {video,time,paused,muted,volume}=state;
    const restore=()=>{video.currentTime=time;video.muted=muted;video.volume=volume;if(!paused&&video.paused)video.play().catch(()=>{});};
    if(video.readyState>0)restore();else video.addEventListener('loadedmetadata',restore,{once:true});
  }
}

// Reconcile in place: unchanged video elements remain attached and keep playing.
export function reconcile(current,next){
  if(current.nodeType!==next.nodeType||current.nodeName!==next.nodeName){current.replaceWith(next);return next;}
  if(current.nodeType===3){if(current.nodeValue!==next.nodeValue)current.nodeValue=next.nodeValue;return current;}
  if(current.nodeType!==1)return current;
  if(current.nodeName==='VIDEO'||current.nodeName==='IMG'){
    if(current.dataset.mediaKey===next.dataset.mediaKey)return current;
    current.replaceWith(next);return next;
  }
  for(const attr of [...current.attributes])if(!next.hasAttribute(attr.name)&&!(current.nodeName==='DETAILS'&&attr.name==='open'))current.removeAttribute(attr.name);
  for(const attr of [...next.attributes])if(current.getAttribute(attr.name)!==attr.value)current.setAttribute(attr.name,attr.value);
  const keyed=new Map([...current.children].filter(n=>n.dataset.nodeKey).map(n=>[n.dataset.nodeKey,n]));
  let index=0;
  for(const incoming of [...next.childNodes]){
    const key=incoming.nodeType===1?incoming.dataset.nodeKey:null;
    let existing=key?keyed.get(key):current.childNodes[index];
    if(existing?.nodeType===1&&existing.dataset.nodeKey!==key&&existing.dataset.nodeKey)existing=null;
    if(existing){if(existing!==current.childNodes[index])movePreservingMedia(current,existing,current.childNodes[index]||null);reconcile(existing,incoming);}
    else current.insertBefore(incoming,current.childNodes[index]||null);
    index++;
  }
  while(current.childNodes.length>index)current.lastChild.remove();
  return current;
}
