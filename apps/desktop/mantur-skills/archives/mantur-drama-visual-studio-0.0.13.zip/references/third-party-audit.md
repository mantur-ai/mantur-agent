# Third-party format-reference audit

The installable Skill bundles third-party JavaScript dependencies into its backend Runtime and browser UI. Users do not need to install `node_modules`. Backend bundles include schema-validation dependencies such as Ajv; the UI includes React and its bundled dependencies. The exact packages and versions are recorded in [the generated license manifest](../licenses/manifest.json); their upstream license and notice files are included under `licenses/` and combined in [THIRD-PARTY-LICENSES.txt](../THIRD-PARTY-LICENSES.txt). The UI-only notice remains at `ui/THIRD-PARTY-LICENSES.txt`.

The build derives this inventory from esbuild's actual output inputs, including transitive dependencies, and fails if an included package has no license or notice file. Package verification checks dependency coverage and the hashes of bundles and notices. Rebuild the complete package whenever bundled dependencies change.

JianYing draft generation itself has no Python, `ffprobe`, or external CLI dependency.

The implementation was checked against these public format references on 2026-08-15:

- `renezander030/capcut-cli` v0.19.0 source at commit `bf80df13b40f5e0e965e23deba23580d202df022` (MIT, Copyright 2026 Rene Zander): draft layout, microsecond timeline units, material/segment linkage, macOS draft path, registration index behavior, and its explicit JianYing version write guard.
- `notinmood/JianyingDraft.PY` / pyJianYingDraft public documentation (MIT): independent confirmation that timeline and material metadata are stored in the draft JSON family.

No source code, template file, enum catalogue, dependency, binary, or generated artifact from either format-reference project is vendored in this Skill. The draft-format implementation is local and limited to the plain video-only profile described in `jianying-draft-delivery.md`. This statement does not exclude the bundled JavaScript dependencies listed above.

The current portable-v2 generator follows the user-provided working implementation: Windows short draft_info, macOS timeline-copy draft_info, complete metadata library and the editor's draft-path placeholder. Version 5.9.0 is a serialization-format marker, not an installed-application version guard. Installation preserves the placeholder and does not edit the root index. Public reports or schema similarity do not count as local GUI-open verification; application acceptance is recorded separately.
