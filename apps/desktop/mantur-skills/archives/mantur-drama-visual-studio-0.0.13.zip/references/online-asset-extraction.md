# 新 OpenAPI 在线资产提取

本模块接通上传确认、非扣费试算、获批提交、原任务恢复、下载及本地接入。适用 Skill 版本 1.0.5。本文仅负责 extraction；四类素材、分镜和视频分别按 [素材操作](asset-operations.md)、[分镜合同](clip-compilation.md)、[视频合同](video-generation.md) 做阶段预检，不由提取成功放行。模拟验证不代表真实部署或付费验收。

## 四个入口

```text
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" prepare-asset-extraction --input input/online.json
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" submit-asset-extraction --operation-id <本地ID> --approval input/approval.json
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" resume-asset-extraction --operation-id <本地ID>
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" asset-extraction-status --operation-id <本地ID>
```

- prepare 在上传前检查实时算子身份、状态、同源路由和可编译 Schema，不比较指纹或业务版本；通过后校验归档，逐文件 upload/PUT/confirm，按实时 inputSchema 验证请求，保存精确请求、不可变私有合同收据并 precharge；不 invoke。会上传完整剧本原字节，先取得用户上传授权，不是纯本地诊断；全集封存本身不构成费用批准。
- submit 核对本地批准绑定，重新读取实时合同并再次试算。Schema 指纹变化但语义兼容、原请求合法且报价摘要不变时继续并保存提交版收据；金额／规则改变返回 ONLINE_QUOTE_CHANGED，须重新取得批准；语义不兼容在提交前阻断。
- resume 有界恢复，每次最多一次 Job 查询或一次同键受理恢复；成功时可下载并接入，不创建新生产操作。进入 `stage=intake` 后只处理已保存的 Job 与产物，不再联网或复算请求、批准和操作身份。
- status 仅读本地，不联网、加锁或迁移。ok=true 仅表示查询成功，仍须读取 stage/error/snapshot_refresh。

成功结果按提交时收据的输出 Schema 与本地提取结果解析器双重校验。没有提交时 Schema 快照的旧已提交操作可用当前兼容合同恢复并记录恢复收据，但不得将其表述为历史提交时快照。

Agent 在获批提交后自动按 [统一循环策略](async-wait-policy.md) 反复调用 resume；单次动作返回不代表结束监控。

## 输入与批准

每次费用确认前执行 `query-account-balance`，按 [报价与余额展示](quote-and-balance.md) 同时说明本次报价、刚查的余额与预计余量；失败明确显示余额暂不可用。prepare/status 中的报价不能代替余额查询。

```json
{"schema_version":1,"script":"input/script.md","reference_images":[],"parameters":{"scriptName":"剧名","projectStyle":"用户指定风格"}}
```

这里的 `schema_version: 1` 是动作输入和项目私有记录的数字版本，不是 Manifest 的命名协议版本。不得写成 `mantur.drama.local/v1`；各版本字段的适用范围见 [本地项目数据协议](local-project-schema.md#协议版本字段消歧)。

路径相对 PROJECT_DIR。`episodes` 为旧描述兼容字段，新操作可省略；Runtime 总是采用并校验已封存的项目全集，显式值必须与全集完全一致。Runtime 不自动切分或摘要剧本；平台按完整 script 提取全剧资产。script 为 .md/.txt；reference_images 最多 10 个 {path,label,note?}，PNG/JPEG/WebP 必须通过真实签名校验。parameters 只接受 scriptName/projectStyle/visualNegative。若项目存在结构化 `creative_style`，Runtime 在冻结操作时保存其 revision 与摘要，并自动把私有风格提示词追加到 `projectStyle`；描述文件不需要也不得复制预设全文，恢复时不重复追加。`visualNegative` 仍独立保存禁止内容。

网络前归档原字节；首次接入拒绝已有不同报告、匹配或下游生产。提交前输入变化使准备及批准失效，提交后恢复原归档，不采用修改后的源文件。普通 workflow/快照变化不阻断原 Job 查询，项目身份/位置/锁站仍须一致。

报价优先 POST 详情返回的合法 quoteUrl；缺失时使用 BASE 下 /api/openapi/v1/operators/op.drama.asset-extract/precharge，规则见 [双域名路由](manturhub-preflight.md#openapi-双域名路由)。依据参考 Skill 视为非扣费试算，不使用旧 CLI quote、不硬编码价格。算子详情中的 billingMode、unitPoints、pricing.fixedPoints、displayText 或集成说明金额只属于描述信息，不能替代本次精确请求的报价响应。窄响应为 code=0、data 对象、success 不为 false；data 内非负数值 estimatedPoints、非负整数 profileVersion、非空 ruleDigest。未知层级返回 PRECHARGE_RESPONSE_UNVERIFIED，不猜 points/priceVersionTag、不伪造平台报价 Token，也不向用户显示任何默认或估算金额。这些字段有参考说明依据，完整 precharge 原始响应仍待线上验收。

prepare/status 返回 estimated_points 和 approval_binding。**只有用户明确批准费用与范围后**，Agent 才将 binding 写入批准文件，增加 approved_at ISO 时间；绑定模板本身不是用户同意。批准绑定项目、站点、操作、请求与报价。平台仅接收合同字段和 Idempotency-Key，不接收本地批准对象。提交后恢复不重新试算、更改请求或换键。

## 恢复规则

| 状态 | 恢复 |
|---|---|
| 上传槽位申请收到明确 HTTP 非成功响应 | 保持 `not_started`；按返回错误修复或退避后，用同一操作 resume。可重试错误的 `retryable=true`、`polling.state=local_recovery` 与 `next_action=resume-asset-extraction` 必须一致 |
| 请求已发出但未能确认服务端是否创建槽位 | 立即落盘 `application_unknown` 并返回 `UPLOAD_APPLICATION_UNKNOWN`；`retryable=false`、`polling.state=blocked`、`next_action=inspect_upload_application`，不重新申请 |
| 已得槽位未 PUT | 使用原槽位，过期则阻断 |
| PUT/confirm 中断 | 确认原 uploadId；仅 AVAILABLE + fileId 可用；拒绝时停止，不生产替代文件 |
| awaiting_approval | 等待用户批准，resume 不提交 |
| submitting/submission_unknown | 一次原键、完全相同请求恢复；冲突/失效进入 recovery_blocked |
| 已有 Job | 只查原任务；查询超时不改失败 |
| FAILED/CANCELED/TIMED_OUT | 保存终态，不重新生成 |
| SUCCEEDED + COMPLETED | 固定首份成功 Job，下载并校验两份 artifact |
| URL 缺失/过期 | 下次 resume 重查原 Job；仍缺失或保留期结束则下载阻断，不重提 |
| intake 失败 | 只恢复原归档接入 |
| 事实保存、快照失败 | 只恢复快照，不下载或生成 |

HTTP、Job、业务、计费、接入和快照状态分开。INIT/空计费不证明结算，REFUND_FAILED/SYNC_FAILED 待核查，不自动退款。未知状态结构化阻断。

## 持久化与安全

v2 操作位于 .pipeline-state/runtime/online-asset-extraction/<id>/，保存 inputs/request/approval/responses/first-success/artifacts/intake。不得公开原资料。v1 blocked_contract 验证原输入后锁内备份升级，ID 不变，status 不迁移。

首次成功 Job 固定；链接刷新单独归档，fileId/role/SHA/需求血缘不变，接入身份不随 URL 变化。复用 import-asset-extraction，图片仍待处理，音色按基础角色去重，可延后不计必需缺失。

Compiler 仅消费脱敏的资产提取检查点。在线 workflow 在提交、轮询和下载阶段已经核对持久化操作、项目、剧本、范围、请求、批准、受理与首份成功 Job；内部接入不再重放这些历史，只要求当前 operation 的唯一成功检查点。命名与 operation ID 一致的失败／取消／平台超时检查点可作为历史共存；其他成功、非终态、未知算子、命名不一致、匹配或下游记录继续拒绝。手工 `import-asset-extraction` 不持有该内部信任，仍执行完整本地资料校验。

操作锁保护有界动作；项目发布锁只在本地短写入时持有，不跨网络。接入复用批次和一次刷新。页面不新增写接口。

认证按显式 `MANTURHUB_KEY` → CLI 托管浏览器身份选择。显式 Key 使用 `legacy-key-v1` 与原 `SHA256(site + "\\0" + key)`，保证旧操作用同一 Key 恢复；CLI 路径使用 `identityBinding()` 的 `cli-identity-v1` 摘要，不读取明文。私有记录保存 `credential_scheme` 与既有 `credential_sha256`，旧记录缺 scheme 按 legacy 解释；两种 scheme 不互认，切换后返回 `ONLINE_CREDENTIAL_CHANGED`，不改批准、Job 或幂等键。入口站点优先取显式 `MANTURHUB_BASE`，否则使用已校验 CLI `getBaseUrl()`。CLI 托管仅同源，开发双域需显式 Key。PUT 仅用申请返回头，下载不带平台凭据；普通返回地址不能扩展授权集合。

项目配置和已确认 source_script 保存后，先按 [看板自动交接](readonly-http-api.md#项目准备完成后的自动交接) 执行 open-workbench --on-project-ready，再执行远端预检、上传和报价；提取输入 script 使用同一已确认副本。结果快照成功后 open-workbench --after-extraction 仅兼容补漏，返回实际链接并共用一次性展示记录，提取前已处理则不再弹页；尊重仅链接/不启动服务，不自行重启。

## 证据边界

依据用户提供新版 Skill 的 openapi-workflow 及其项目上传/轮询实现、保存受理/终态形状；发布包不依赖参考项目。单次一个上传槽位，不采用未知批量顺序或 data.items 回退。

仍待真实验收：完整 precharge 返回、上传错误/失效分支、幂等冲突/过期语义及双域名实际部署。未知分支阻断不代表整套流程规则缺失。workflow_ready 仅代表包内实现和模拟验证；真实上传、报价和付费验证另行获批。

## 本地结构错误恢复

当前成功提取接入可保留命名及 operation ID 一致的历史失败／取消／平台超时检查点；在途、未知提交、其他成功记录和下游冲突继续阻断。远端成功而本地接入失败时仅修复适配并恢复原操作，不重新上传、报价或调用提取。结构错误的本地诊断提供受限字段路径、规则及枚举，不输出完整内容。原产物已下载且 `stage=intake` 时，更新 Skill 后使用同一 operation-id 的 `resume-asset-extraction`，只执行保存产物的 Job/artifact、Schema、XLSX、结构与项目冲突检查，不重读历史请求、批准、受理和轮询归档。平台 `schema_version=asset_extract_v2.0` 等数字 v2 业务标签按 [资产接入合同](asset-extraction-import.md#本地校验边界) 进入完整 canonical v2 语义校验；这不是跳过产物验证，也不重新上传、询价、提交或扣费。提取成功不等于图片或音色已验收。
