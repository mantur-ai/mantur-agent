# Version compatibility

| Component | Required release | Contract used by Skill 1.11.0 |
|---|---:|---|
| `op.drama.asset-extract` | `v2.4.3` | one full-script `input_file` through Responses, strict JSON Schema, open reference catalog, base asset ID, structured `变体规则JSON`, generation/voice policy, extraction-only empty media fields |
| `op.drama.clip-seedance-compile` | `v2.4.0` | one Responses call with `complete-script.md` and `complete-assets.json` as two `input_file.file_data` items; strict non-empty episode/clip JSON Schema with `variant_decisions`; deterministic variant selector and same-scene state audit reusing `校验状态/连续性冲突`; asymmetric episode-duration planning, fixed Chinese status enums, media-missing planning invariant, template/actual request boundary, `metadata.return_last_frame=true`, and zero-billable idempotent replay metadata |
| `op.image.generate` | live compatible schema | Used only when the Agent has not declared native image generation; `generate/edit`, open reference URLs and explicit pricing |
| `op.video.generate` | live compatible schema | Default video provider; Seedance parameters, reference media and official tail-frame return |
| Preset voice catalog | `drama-preset-voices@1.0.0` | immutable public ManturHub audio assets, checksum/version identity, fail-closed deterministic shortlist, canonical-character voice lock, no automatic use of review-only voices |
| ManturHub CLI | `>=0.10.0` | verified installed-Skill hash, allowlisted package-local actions, Node runtime execution, stable JSON output and explicit failure without interpreter fallback |
| JianYing draft profile | `jianying-macos-5.9` only | plaintext 5.9.x video-only draft; pure-JS MP4/MOV duration parsing, one contiguous video track, portable local assets, explicit target-machine import confirmation; JianYing 6.0+ and unknown versions fail closed |
| Skill | `1.11.0` | Skill 1.10.7 capabilities plus one compact asset variant rule field, one compact Clip variant decision field, and a fail-closed video queue gate that requires `校验状态=校验通过` with no continuity conflict; no new status enum family |

Higher operator versions are acceptable only when their live schema remains backward-compatible with these fields. A missing required field is a hard preflight failure, not permission to guess or silently downgrade.
