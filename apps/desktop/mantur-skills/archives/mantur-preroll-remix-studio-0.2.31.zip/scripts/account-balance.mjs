const messages=Object.freeze({
  CONTRACT_UNSUPPORTED:'余额查询未接入。',LEGACY_PROJECT_READ_ONLY:'历史项目仅供本地审阅，未接入当前账户余额。',
  NOT_STARTED:'余额核对尚未启动。',IDENTITY_PENDING:'正在核对账户身份。',IDENTITY_UNKNOWN:'当前账户身份尚未核实。',
  IDENTITY_TIMEOUT:'账户身份核对超时，余额尚未核实。',IDENTITY_EXPIRED:'账户身份核对已过期，余额尚未核实。',
  BALANCE_PENDING:'正在查询馒头余额。',READY:'余额已核对。',NETWORK_ERROR:'余额更新失败，核对结果暂未刷新。',
  BALANCE_TIMEOUT:'余额查询超时，余额尚未核实。',IDENTITY_MISMATCH:'余额回执与当前账户身份不一致。',
  INVALID_RESPONSE:'余额回执无法核实。',CLOSED:'余额核对已关闭。',CLOSE_TIMEOUT:'余额核对已关闭，部分请求尚未完成清理。',
});
const transient=new Set(['NETWORK_REQUEST_FAILED','HTTP_500','HTTP_502','HTTP_503','HTTP_504','ETIMEDOUT']);
const authentication=new Set(['HTTP_401','HTTP_403','CLI_ORIGIN_MISMATCH','CLI_CONFIGURATION_INVALID','CLI_IDENTITY_MODE_MISMATCH','CLI_BALANCE_IDENTITY_UNAVAILABLE','CLI_BALANCE_IDENTITY_CHANGED','CREDENTIAL_ORIGIN_INVALID','CREDENTIAL_ORIGIN_MISMATCH','API_KEY_REQUIRED','API_KEY_INVALID']);
const same=(a,b)=>!!a&&!!b&&a.bindingId===b.bindingId&&a.authEpoch===b.authEpoch;
const opaque=(value,max)=>typeof value==='string'&&value.trim().length>0&&value.length<=max&&!/[\x00-\x1f\x7f-\x9f]/.test(value);
const validIdentity=value=>value&&!Array.isArray(value)&&opaque(value.bindingId,512)&&opaque(value.authEpoch,128);
function milliseconds(value,max){if(!Number.isInteger(value)||value<1||value>max)throw new Error('Invalid balance monitor timing');return value;}

/** Internal provider port only. No credentials, CLI commands or network implementation. */
export function createBalanceMonitor({identity,readBalance,unavailableReason,intervalMs=30000,identityIntervalMs=5000,
  identityTimeoutMs=3000,balanceTimeoutMs=10000,closeTimeoutMs=2000,manualCooldownMs=5000,now=Date.now}={}){
  milliseconds(intervalMs,3600000);milliseconds(identityIntervalMs,60000);milliseconds(identityTimeoutMs,30000);
  milliseconds(balanceTimeoutMs,120000);milliseconds(closeTimeoutMs,10000);milliseconds(manualCooldownMs,3600000);
  if(typeof now!=='function'||unavailableReason!==undefined&&!['CONTRACT_UNSUPPORTED','LEGACY_PROJECT_READ_ONLY'].includes(unavailableReason))
    throw new Error('Invalid balance monitor configuration');
  let disabled=unavailableReason??(typeof identity!=='function'||typeof readBalance!=='function'?'CONTRACT_UNSUPPORTED':undefined);
  let started=false,closed=false,queued=false,timer,closing,binding,generation=0,expiresAt=-Infinity;
  let identityRequest,balanceRequest,lastIdentityStart=-Infinity,lastBalanceStart=-Infinity,lastBalanceIdentity,forceRequested=false;
  let state={status:'unavailable',totalBalance:null,lastAttemptAt:null,checkedAt:null,
    reasonCode:disabled??'NOT_STARTED',message:messages[disabled??'NOT_STARTED']};
  const copy=()=>({...state});
  function clear(reasonCode,{status='unavailable',resetAttempt=false}={}){
    state={...state,status,totalBalance:null,checkedAt:null,...(resetAttempt?{lastAttemptAt:null}:{}),reasonCode,message:messages[reasonCode]};
  }
  function loseIdentity(reasonCode,abort=true){
    binding=undefined;expiresAt=-Infinity;generation++;if(abort)balanceRequest?.controller.abort();
    clear(reasonCode,{resetAttempt:true});
  }
  function unsupported(){
    disabled='CONTRACT_UNSUPPORTED';loseIdentity(disabled);if(timer)clearTimeout(timer);
    for(const record of [identityRequest,balanceRequest].filter(Boolean)){clearTimeout(record.timer);record.controller.abort();}
  }
  function expire(abort=true){if(binding&&now()>=expiresAt)loseIdentity('IDENTITY_EXPIRED',abort);}
  function snapshot(){if(!closed)expire(false);return copy();}
  function queue(){
    if(queued||closed||!started||disabled)return;
    queued=true;queueMicrotask(()=>{queued=false;pump();});
  }
  function schedule(){
    if(timer)clearTimeout(timer);
    if(closed||!started||disabled)return;
    const due=[];
    if(!identityRequest)due.push(lastIdentityStart+identityIntervalMs);
    if(binding){
      due.push(expiresAt);
      if(!identityRequest&&!balanceRequest)due.push(lastBalanceStart+(forceRequested?manualCooldownMs:intervalMs));
    }
    if(!due.length)return;
    timer=setTimeout(pump,Math.max(1,Math.min(...due)-now()));timer.unref?.();
  }
  function request(kind,callback,timeoutMs,onResult,onError){
    const record={controller:new AbortController(),timedOut:false};
    record.timer=setTimeout(()=>{
      if(closed||disabled)return;
      record.timedOut=true;record.controller.abort();
      if(kind==='identity')loseIdentity('IDENTITY_TIMEOUT');else clear('BALANCE_TIMEOUT');
      queue();
    },timeoutMs);record.timer.unref?.();
    record.promise=Promise.resolve().then(()=>{
      if(closed||disabled||record.controller.signal.aborted)return;
      return callback(record.controller.signal);
    }).then(result=>{if(!closed&&!disabled&&!record.timedOut&&!record.controller.signal.aborted)onResult(result);})
      .catch(error=>{if(!closed&&!disabled&&!record.timedOut&&!record.controller.signal.aborted)onError(error);})
      .finally(()=>{
        clearTimeout(record.timer);
        if(kind==='identity'){if(identityRequest===record)identityRequest=undefined;}
        else if(balanceRequest===record)balanceRequest=undefined;
        queue();
      });
    return record;
  }
  function startIdentity(){
    lastIdentityStart=now();
    identityRequest=request('identity',signal=>identity({signal}),identityTimeoutMs,result=>{
      if(!validIdentity(result)){loseIdentity('IDENTITY_UNKNOWN');return;}
      if(!same(binding,result)){
        generation++;balanceRequest?.controller.abort();
        if(!same(lastBalanceIdentity,result))lastBalanceStart=-Infinity;
        clear('BALANCE_PENDING',{status:'loading',resetAttempt:true});
      }
      binding=Object.freeze({bindingId:result.bindingId,authEpoch:result.authEpoch});
      expiresAt=now()+identityIntervalMs+identityTimeoutMs;
    },error=>{if(error?.code==='BALANCE_CONTRACT_UNSUPPORTED')unsupported();else loseIdentity('IDENTITY_UNKNOWN');});
  }
  function startBalance(){
    const expected=Object.freeze({...binding}),epoch=generation;
    forceRequested=false;lastBalanceStart=now();lastBalanceIdentity=expected;
    state={...state,status:'loading',lastAttemptAt:new Date(lastBalanceStart).toISOString(),reasonCode:'BALANCE_PENDING',message:messages.BALANCE_PENDING};
    const current=()=>{
      expire();return epoch===generation&&same(binding,expected);
    };
    balanceRequest=request('balance',signal=>readBalance(expected,{signal}),balanceTimeoutMs,result=>{
      if(!current())return;
      if(!validIdentity(result?.identity)||typeof result?.totalBalance!=='number'||!Number.isFinite(result.totalBalance)){
        clear('INVALID_RESPONSE');return;
      }
      if(!same(expected,result.identity)){loseIdentity('IDENTITY_MISMATCH');return;}
      state={status:'ready',totalBalance:result.totalBalance,lastAttemptAt:state.lastAttemptAt,checkedAt:new Date(now()).toISOString(),reasonCode:'READY',message:messages.READY};
    },error=>{
      if(!current())return;
      if(error?.code==='BALANCE_CONTRACT_UNSUPPORTED')unsupported();
      else if(authentication.has(error?.code))loseIdentity('IDENTITY_UNKNOWN');
      else if(transient.has(error?.code)){
        state={...state,status:state.totalBalance===null?'unavailable':'stale',reasonCode:'NETWORK_ERROR',message:messages.NETWORK_ERROR};
      }else clear('INVALID_RESPONSE');
    });
  }
  function pump(){
    if(closed||!started||disabled)return;
    expire();
    if(!binding)balanceRequest?.controller.abort();
    if(!identityRequest&&now()-lastIdentityStart>=identityIntervalMs)startIdentity();
    if(binding&&!identityRequest&&!balanceRequest&&now()-lastBalanceStart>=(forceRequested?manualCooldownMs:intervalMs))startBalance();
    schedule();
  }
  function start(){
    if(!closed&&!started&&!disabled){started=true;clear('IDENTITY_PENDING',{status:'loading'});queue();}
    return snapshot();
  }
  function trigger({force=false}={}){
    if(!closed&&started&&!disabled){if(force&&!balanceRequest)forceRequested=true;queue();}
    return snapshot();
  }
  function close(){
    if(closing)return closing;
    closed=true;started=false;generation++;binding=undefined;clear('CLOSED',{resetAttempt:true});
    if(timer)clearTimeout(timer);
    const owned=[identityRequest,balanceRequest].filter(Boolean);
    for(const record of owned){clearTimeout(record.timer);record.controller.abort();}
    closing=(async()=>{
      let timeout;
      const cleaned=await Promise.race([Promise.allSettled(owned.map(record=>record.promise)).then(()=>true),
        new Promise(resolve=>{timeout=setTimeout(()=>resolve(false),closeTimeoutMs);})]);
      clearTimeout(timeout);
      const pendingRequests=[identityRequest,balanceRequest].filter(Boolean).length;
      const reasonCode=cleaned?'CLOSED':'CLOSE_TIMEOUT';clear(reasonCode,{resetAttempt:true});
      return {closed:true,cleanupComplete:cleaned,pendingRequests,reasonCode};
    })();
    return closing;
  }
  return {start,trigger,snapshot,close};
}
