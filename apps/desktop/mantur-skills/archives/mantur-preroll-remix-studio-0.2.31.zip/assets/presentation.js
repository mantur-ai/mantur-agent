// Shared by cards and tests; fee facts come from the platform, never inferred from job success.
export function feeLines(op) {
  if (!op) return [];
  const final = ['COMPLETED','SETTLED','CHARGED','REFUNDED'].includes(op.billingStatus);
  const lines = [
    Number.isFinite(op.estimatedPoints) ? `预计费用 ${op.estimatedPoints} 馒头` : '预计费用：尚未获取',
    `结算状态：${op.billingLabel || '待核对'}`,
    final && Number.isFinite(op.actualPoints) ? `实际消耗 ${op.actualPoints} 馒头` : '实际消耗：待最终结算核对',
    Number.isFinite(op.refundedPoints) ? `已退款 ${op.refundedPoints} 馒头` : '退款金额：尚无确认记录',
  ];
  if(op.billingStatus==='DEDUCTED'&&Number.isFinite(op.prechargedPoints)&&op.prechargedPoints>=0)lines.splice(2,0,`已预扣 ${op.prechargedPoints} 馒头`);
  return lines;
}
export function assetOperation(asset, operations) {
  return operations.find(op => op.assetId === asset.id && ['fronts','highlights','compose'].includes(op.stage));
}
export function packagingLines(packaging) {
  return [packaging?.ending===false?'不添加尾贴':null,packaging?.logo===false?'不添加水印':null].filter(Boolean);
}
export function timelineLegend(output) {
  const rows=output.segments?.length?output.segments:(output.body||[]).map(s=>({...s,kind:'episode'}));
  return [['front','前贴'],['episode','正片'],['ending','尾贴']].filter(([kind])=>rows.some(s=>s.kind===kind));
}
export function highlightPresentation(h, assets) {
  if (h.clipMediaUrl) return {media:{id:h.clipAssetId,mediaUrl:h.clipMediaUrl,name:`第 ${h.episode} 集高光`,role:'front'},start:0,end:null,legacy:false,downloadUrl:h.clipMediaUrl};
  if (Object.hasOwn(h,'clipStatus')) return {media:null,start:0,end:null,legacy:false,downloadUrl:null};
  return {media:assets.find(a=>a.role==='episode'&&a.episode===h.episode)||null,start:h.start,end:h.end,legacy:true,downloadUrl:null};
}

// Placement is relative to original episode time, never to rendered clip duration.
export function analysisTimeline(detail) {
  const scale=detail?.scaleDuration??detail?.sourceDuration;
  if(!Number.isFinite(scale)||scale<=0)return {scale:null,sourceWidth:null,segments:[],ticks:[],lanes:0};
  const ends=[],segments=[];
  for(const record of [...(detail.records||[])].sort((a,b)=>a.start-b.start||a.end-b.end||String(a.id).localeCompare(String(b.id)))){
    if(!Number.isFinite(record.start)||!Number.isFinite(record.end)||record.start<0||record.end<=record.start||record.end>scale)continue;
    let lane=ends.findIndex(end=>end<=record.start);if(lane<0)lane=ends.length;ends[lane]=record.end;
    segments.push({id:record.id,number:record.number,start:record.start,end:record.end,selected:record.selected===true,left:100*record.start/scale,width:100*(record.end-record.start)/scale,lane});
  }
  return {scale,sourceWidth:Number.isFinite(detail.sourceDuration)&&detail.sourceDuration>0?Math.min(100,100*detail.sourceDuration/scale):null,
    segments,ticks:Array.from({length:5},(_,i)=>({value:scale*i/4,left:25*i})),lanes:Math.max(1,ends.length)};
}

export function balancePresentation(balance) {
  if(balance?.mode==='query'){
    const verified=typeof balance.checkedAt==='string'&&!Number.isNaN(Date.parse(balance.checkedAt));
    const ready=balance.status==='ready'&&balance.reasonCode==='READY'&&balance.unit==='馒头'&&Number.isFinite(balance.totalBalance)&&Math.abs(balance.totalBalance)<=Number.MAX_SAFE_INTEGER&&verified;
    const format=value=>new Intl.NumberFormat('zh-CN',{maximumFractionDigits:20}).format(value);
    const time=verified?new Date(balance.checkedAt).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}):null;
    const reasons={CONTRACT_UNSUPPORTED:'当前接入尚不支持余额查询',LEGACY_PROJECT_READ_ONLY:'历史项目仅供审阅，未查询余额',
      NOT_STARTED:'余额查询尚未启动',BALANCE_PENDING:'正在查询余额',QUERY_FAILED:'余额查询失败，请检查授权和网络后刷新',
      INVALID_RESPONSE:'余额查询结果无法核实',BALANCE_TIMEOUT:'余额查询超时，请刷新重试',CLOSED:'余额查询已关闭',CLOSE_TIMEOUT:'余额查询清理尚未完成'};
    const details=ready?[['giftBalance','赠送'],['rechargeBalance','充值']].filter(([key])=>Number.isFinite(balance[key])&&Math.abs(balance[key])<=Number.MAX_SAFE_INTEGER)
      .map(([key,label])=>`${label} ${format(balance[key])} 馒头`).join(' · '):'';
    return {amount:ready?format(balance.totalBalance):'—',message:ready?`最近查询 ${time} · 非实时`:reasons[balance.reasonCode]||'余额暂不可用',
      details,stale:false,available:ready,refreshable:!['CONTRACT_UNSUPPORTED','LEGACY_PROJECT_READ_ONLY','CLOSED','CLOSE_TIMEOUT'].includes(balance.reasonCode),loading:balance.status==='loading'};
  }
  const reasons={CONTRACT_UNSUPPORTED:'当前接入尚不支持账户绑定余额',LEGACY_PROJECT_READ_ONLY:'历史项目仅供审阅，未查询余额',
    NOT_STARTED:'余额核对尚未启动',IDENTITY_PENDING:'正在核对账户身份',IDENTITY_UNKNOWN:'当前账户身份尚未核实',
    IDENTITY_TIMEOUT:'账户核验超时，余额暂不可用',IDENTITY_EXPIRED:'账户核验已过期，余额暂不可用',
    IDENTITY_MISMATCH:'余额账户核验未通过',INVALID_RESPONSE:'余额结果尚未核实',BALANCE_TIMEOUT:'余额查询超时',
    CLOSED:'余额核对已关闭',CLOSE_TIMEOUT:'余额查询清理尚未完成'};
  const blocked=reasons[balance?.reasonCode];
  const known=Number.isFinite(balance?.totalBalance),state=balance?.status;
  const verified=typeof balance?.checkedAt==='string'&&!Number.isNaN(Date.parse(balance.checkedAt))?balance.checkedAt:null;
  const time=verified?new Date(verified).toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',second:'2-digit'}):null;
  const amount=!blocked&&known&&verified&&['ready','loading','stale'].includes(state)?new Intl.NumberFormat('zh-CN',{maximumFractionDigits:20}).format(balance.totalBalance):'—';
  let message;
  if(blocked)message=blocked;
  else if(state==='ready'&&known&&verified)message=`账户余额 · ${time} 已核对`;
  else if(state==='stale'&&known&&verified)message=`暂未刷新 · 上次核对 ${time}`;
  else if(state==='loading')message=known&&time?`正在核对 · 显示 ${time} 的余额`:'正在核对账户余额';
  else message='账户余额暂未核实';
  return {amount,message,stale:!blocked&&state==='stale',available:amount!=='—'};
}

// Submission facts are projected by the server; completion and polling times never order cards.
function timestamp(value, requireZone=true) {
  if(typeof value!=='string')return null;
  const match=value.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?(Z|[+-]\d{2}:\d{2})?$/);
  if(!match||requireZone&&!match[8])return null;
  const [year,month,day,hour,minute,second]=match.slice(1,7).map(Number);
  const leap=year%4===0&&(year%100!==0||year%400===0),days=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31];
  if(month<1||month>12||day<1||day>days[month-1]||hour>23||minute>59||second>59)return null;
  if(match[8]&&match[8]!=='Z'&&(Number(match[8].slice(1,3))>23||Number(match[8].slice(4))>59))return null;
  if(!match[8])return requireZone?null:value;
  const parsed=Date.parse(value);return Number.isFinite(parsed)?parsed:null;
}
function submittedTime(op) {
  return ['local_attempt','remote_created'].includes(op?.submission?.source)?timestamp(op.submission.time):null;
}
function episodeNumber(op) {
  const episode=op?.analysisDetail?.episode;
  return typeof episode==='number'&&Number.isSafeInteger(episode)&&episode>0?episode:Infinity;
}
export function sortAnalysisOperations(operations) {
  return [...operations].sort((a,b)=>{
    const first=episodeNumber(a),second=episodeNumber(b);
    if(first!==second)return first<second?-1:1;
    const aSubmitted=submittedTime(a),bSubmitted=submittedTime(b);
    if((aSubmitted===null)!==(bSubmitted===null))return aSubmitted===null?1:-1;
    const aTime=aSubmitted??timestamp(a?.submission?.preparedAt),bTime=bSubmitted??timestamp(b?.submission?.preparedAt);
    if(aTime!==bTime){if(aTime===null)return 1;if(bTime===null)return -1;return bTime-aTime;}
    const aId=String(a?.id??''),bId=String(b?.id??'');return aId<bId?-1:aId>bId?1:0;
  });
}
export function submissionPresentation(op) {
  const parsed=submittedTime(op);
  const serverCreatedAt=typeof op?.submission?.serverCreatedAt==='string'?op.submission.serverCreatedAt.replace(' ','T'):null;
  const serverNote=serverCreatedAt&&timestamp(serverCreatedAt,false)!==null&&!/[Zz]|[+-]\d{2}:\d{2}$/.test(serverCreatedAt)?`平台创建 ${serverCreatedAt.replace('T',' ')}（服务器时间未标时区）`:null;
  if(parsed===null)return {text:op?.submission?.source==='not_submitted'||['prepared','not_prepared'].includes(op?.status??'prepared')?'尚未提交':'提交时间未记录',dateTime:null,title:serverNote||'旧记录没有可核实的提交时间，不使用完成或刷新时间替代。'};
  const date=new Date(parsed),pad=value=>String(value).padStart(2,'0');
  const shown=`${String(date.getFullYear()).padStart(4,'0')}-${pad(date.getMonth()+1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  const source=op.submission.source==='local_attempt'?'首次本机提交记录':'平台创建记录';
  return {text:`提交 ${shown}`,dateTime:op.submission.time,title:[`${source} · ${op.submission.time}（显示为浏览器本地时间）`,serverNote].filter(Boolean).join('；')};
}

export function highlightSelectionNote(summary) {
  if(summary?.selectionRequired&&Number.isFinite(summary.available)&&summary.available>=summary.requested)
    return `部分原已选片段已失效，其余已选保留；请从现有 ${summary.available} 条候选中重新选定 ${summary.requested} 条。`;
  if(summary?.shortage>0)return `还缺 ${summary.shortage} 条符合要求的高光，请在聊天中调整识别范围。`;
  return null;
}

/** These facts are about local checks, independent of job completion or billing. */
export function qaLines(op){
  const qa=op?.qa;
  if(!qa)return [];
  if(qa.decodeStatus==='failed')return ['本机完整解码验收未通过，请核对原产物。'];
  if(qa.decode===true)return ['历史或本机加强完整解码验收通过'];
  if(qa.metadata!==true||qa.container!==true)return [];
  const lines=['媒体参数与容器结构已核验 · 本机未做完整解码'];
  if(qa.metadataSource==='platform+container')lines.push('已复用平台媒体参数，其余信息由文件容器补齐。');
  if(qa.platformMetadataStatus==='inconsistent')lines.push('平台参数与当前文件存在差异，以文件容器核验及制作计划为准。');
  return lines;
}
export function productionModePresentation(value) {
  const names = {viral:'爆款前贴智剪',highlight:'高光前贴智剪'};
  const confirmed = value?.status === 'confirmed' && Object.hasOwn(names,value?.mode);
  return confirmed ? {status:'confirmed',label:names[value.mode],hint:'制作方式已确认；后续操作通过聊天完成。'}
    : {status:'unconfirmed',label:'未确认',hint:'请在聊天中选择爆款前贴智剪或高光前贴智剪。'};
}
export function frontEmptyPresentation(value) {
  const view=productionModePresentation(value);
  if(view.status==='confirmed'&&value.mode==='viral')return {title:'还没有爆款前贴',hint:'请在聊天中提供文案或参考视频生成前贴，也可以明确指定复用已有前贴。'};
  if(view.status==='confirmed'&&value.mode==='highlight')return {title:'还没有高光前贴',hint:'请在聊天中说明要分析哪些集数，以及需要选定几条高光作为前贴。'};
  return {title:'先确认制作模式',hint:'请在聊天中选择爆款前贴智剪或高光前贴智剪，再继续制作。'};
}

// Result history is a read-only projection. Never add these records to production scope.
export function resultGroups(records, filter='all') {
  const groups=new Map();
  for(const record of records||[]){
    if(filter==='current'&&!record.current||filter==='history'&&record.current)continue;
    const key=record.groupId||'unlinked';
    if(!groups.has(key))groups.set(key,{id:key,label:record.groupLabel||'方案详情未记录',records:[],submittedAt:null,order:record.groupOrder??-Infinity});
    const group=groups.get(key),time=submittedTime(record);
    group.records.push(record);
    if(time!==null&&(group.submittedAt===null||time>group.submittedAt))group.submittedAt=time;
  }
  for(const group of groups.values())group.records.sort((a,b)=>(a.outputOrder??Infinity)-(b.outputOrder??Infinity));
  return [...groups.values()].sort((a,b)=>{
    if(a.submittedAt!==b.submittedAt){if(a.submittedAt===null)return 1;if(b.submittedAt===null)return -1;return b.submittedAt-a.submittedAt;}
    return b.order-a.order||a.id.localeCompare(b.id);
  });
}
export function frontRecordPresentation(record) {
  const current=!!(record?.currentRequest||record?.selected||record?.adoptedByCurrentPlan);
  const kind={generated:'生成前贴',highlight:'高光片段',imported:'导入前贴'}[record?.kind]||'前贴素材';
  const usage=record?.adoptedByCurrentPlan?'当前采用':record?.selected?'当前选定':record?.currentRequest?'当前制作范围':record?.kind==='imported'?'尚未采用':'历史前贴';
  return {current,kind,usage};
}
export function operationProgressText(op, current=true) {
  if(['prepared','not_prepared'].includes(op?.status??'prepared'))return current?'等待确认或提交，尚未开始制作。':'历史准备记录，未提交，不会自动制作。';
  if(op?.status==='running')return op.hasError?'原任务已提交，暂时无法同步最新状态；请恢复原任务。':'原任务已提交，正在制作，页面会自动同步。';
  if(op?.status==='unknown')return '提交状态待核实，请先核对原任务，避免重复制作。';
  if(['remote_succeeded','artifact_pending'].includes(op?.status))return '原任务已完成，产物等待下载或恢复；无需重新制作。';
  if(op?.status==='qa_failed')return '原产物验收未通过，请在聊天中核对原任务，不会自动重新制作。';
  if(op?.status==='failed')return '原任务制作失败，费用以该任务结算记录为准。';
  if(op?.status==='succeeded')return '原任务已完成，产物记录待恢复；请在聊天中恢复原产物。';
  return '任务状态待核对，请在聊天中查看原记录。';
}
export function mediaAvailability(value) {
  const status=value?.availability?.status;
  const available=!!value?.mediaUrl&&(!status||['available','unchecked'].includes(status));
  const messages={missing:'本地文件缺失，请在聊天中恢复原任务产物，无需重新制作。',unavailable:'本地文件暂不可读取，请核对文件或恢复原任务产物。',missing_record:'原产物记录缺失，请在聊天中核对并恢复原任务产物。',not_downloaded:'产物尚未下载，页面会同步原任务的下载状态。'};
  return {available,message:messages[status]||'媒体尚未准备好。'};
}
export function recordedPackagingLines(plan) {
  if(!plan)return ['历史方案详情未记录；下方仅展示可核实的原任务信息。'];
  return [
    plan.packaging?.ending===true?'添加尾贴':plan.packaging?.ending===false?'不添加尾贴':'尾贴设置未记录',
    plan.packaging?.logo===true?'添加全程水印':plan.packaging?.logo===false?'不添加水印':'水印设置未记录',
  ];
}
export function highlightSourceText(highlight) {
  if(!Number.isSafeInteger(highlight?.episode)||highlight.episode<=0||!Number.isFinite(highlight.start)||!Number.isFinite(highlight.end))return '来源集数与区间未记录';
  const time=value=>`${Math.floor(value/60).toString().padStart(2,'0')}:${(value%60).toFixed(2).padStart(5,'0')}`;
  return `来源：第 ${highlight.episode} 集 · ${time(highlight.start)}–${time(highlight.end)}`;
}
export function logoPlacementText(plan) {
  if(!plan?.logo||plan.packaging?.logo===false)return null;
  const logo=plan.logo;
  return [
    plan.packaging?.logo===true?'全程 Logo':'已记录的 Logo 参数',
    Number.isFinite(logo.x)&&Number.isFinite(logo.y)?`位置 (${logo.x}, ${logo.y})`:'位置未记录',
    Number.isFinite(logo.width)&&Number.isFinite(logo.height)?`${logo.width} × ${logo.height}`:'尺寸未记录',
    Number.isFinite(logo.opacity)?`不透明度 ${Math.round(logo.opacity*100)}%`:'不透明度未记录',
  ].join(' · ');
}
