---
name: "mantur-drama-visual-studio"
title: "全自动漫剧生产线（可视化）"
description: "从完整本地剧本和任意参考素材批量生产漫剧，完成资产提取、已有素材匹配、资产图片与音色、分镜提示词、Seedance 或 WAN 3.0\
  \ 视频、真实尾帧连续性、按集 ZIP、可选剪映草稿，以及本机只读进度快照。用户要求跑新剧、批量跑剧、拆资产、生资产图、配音色、生成分镜或整部剧视频、导出每集片\
  段、交付剪映草稿、查询生产进度时使用；不用于普通视频剪辑或无剧本的单条视频生成。"
category: "漫剧制作"
version: "0.0.13"
triggers:
- "全自动漫剧生产线（可视化）"
- "全自动漫剧生产线"
- "跑新剧"
- "批量跑剧"
- "拆剧本资产"
- "生成资产图"
- "匹配角色音色"
- "生成分镜提示词"
- "生成整部剧视频"
- "导出每集片段"
- "交付剪映草稿"
- "查询漫剧生产进度"
uses_operators:
- "op.drama.asset-extract"
- "op.drama.clip-seedance-compile"
- "op.drama.clip-wan-compile"
- "op.image.generate"
- "op.video.understand-v2"
- "op.voice.design"
- "op.audio.generate"
- "op.video.generate"
input_schema:
  type: "object"
output_schema:
  type: "object"
steps: []
permissions: []
---

<!-- MANTUR_AGENT_PLATFORM_ACCESS_START -->
## 平台接入（Mantur Agent 自动注入）

### 认证
公开目录和本安装包可匿名访问。调用算子时必须传入 `X-API-Key: <YOUR_API_KEY>` 和 `Idempotency-Key: <UNIQUE_REQUEST_ID>`；API Key 由用户在开放平台控制台自行创建，对外运行时不再额外要求用户访问令牌。

### 算子调用
先通过匿名接口 `GET /api/public/agent/v1/operators/{operatorCode}` 获取公开详情，使用响应中的完整 `invokeUrl` 发起 `POST` 调用。异步调用会返回 `jobId` 和完整 `pollUrl`，使用同一 `X-API-Key` 轮询 `GET {pollUrl}` 直到终态；不得把 `jobId` 再次提交给 invoke 接口。

OpenAPI 的规范路径分别为 `POST /api/openapi/v1/operators/{apiCode}/invoke` 和 `GET /api/openapi/v1/jobs/{jobId}`；Skill 文档不得引用 Agent 内部接口、内部 MCP 路由或内部工具名。

### 文件与下载
需要文件输入时，先调用 `POST /api/openapi/v1/files/upload` 获取 `uploadId/fileId` 和预签名 PUT 地址，按响应 headers 直传文件，再调用 `POST /api/openapi/v1/files/{uploadId}/confirm`；确认返回的 `fileId/mediaRef` 才能作为算子输入。上传、确认和算子调用必须使用同一 `X-API-Key`。

本安装包由 Mantur Agent 后台校验、注入并重新打包；公开且已上架时可匿名下载，下架或转为私有后原公共地址立即失效。

### 本 Skill 依赖算子 & 积分估算
- `op.drama.asset-extract`（剧本全局资产提取）：调用前通过该算子的 `precharge` 接口获取当前已发布计费配置下的实时预计积分；默认配置为固定 50 积分/次，实际价格以返回的 profileVersion、ruleDigest 和 estimatedPoints 为准
- `op.drama.clip-seedance-compile`（Seedance 分镜请求编译）：调用前通过该算子的 `precharge` 接口获取当前已发布计费配置下的实时预计积分；默认配置为固定 50 积分/次，实际价格以返回的 profileVersion、ruleDigest 和 estimatedPoints 为准
- `op.drama.clip-wan-compile`（wan分镜请求编译）：调用前通过该算子的 `precharge` 接口获取当前已发布计费配置下的实时预计积分；默认配置为固定 50 积分/次，实际价格以返回的 profileVersion、ruleDigest 和 estimatedPoints 为准
- `op.image.generate`（AI图片生成）：调用前通过该算子的 `precharge` 接口获取当前已发布计费配置下的实时预计积分；默认配置为固定 50 积分/次，实际价格以返回的 profileVersion、ruleDigest 和 estimatedPoints 为准
- `op.video.understand-v2`（视频/图像理解算子）：调用前通过该算子的 `precharge` 接口获取当前已发布计费配置下的实时预计积分；默认配置为固定 50 积分/次，实际价格以返回的 profileVersion、ruleDigest 和 estimatedPoints 为准
- `op.voice.design`（音色设计）：调用前通过该算子的 `precharge` 接口获取当前已发布计费配置下的实时预计积分；默认配置为固定 50 积分/次，实际价格以返回的 profileVersion、ruleDigest 和 estimatedPoints 为准
- `op.audio.generate`（音频生成）：调用前通过该算子的 `precharge` 接口获取当前已发布计费配置下的实时预计积分；默认配置为固定 50 积分/次，实际价格以返回的 profileVersion、ruleDigest 和 estimatedPoints 为准
- `op.video.generate`（AI视频生成）：调用前通过该算子的 `precharge` 接口获取当前已发布计费配置下的实时预计积分；默认配置为固定 50 积分/次，实际价格以返回的 profileVersion、ruleDigest 和 estimatedPoints 为准

<!-- MANTUR_AGENT_PLATFORM_ACCESS_END -->

---

# 全自动漫剧生产线（可视化）

Agent 按用户范围编排生产；Runtime 保存项目内的权威事实、校验请求并恢复原任务；Snapshot Compiler 发布脱敏快照；看板只读。流程为：项目准备 → 资产提取 → 已有素材匹配及图片/音色 → 分镜与 Clip → 视频与真实尾帧 → 按集 ZIP／可选剪映草稿。

## 入口与执行原则

从当前 `SKILL.md` 所在目录取得 `SKILL_DIR`，用户持久项目根目录为 `PROJECT_DIR`，均使用实际绝对路径。完整 Skill 包自带 Runtime、Schema 和 UI，安装后不依赖开发仓库、`node_modules`、可信安装记录或 npm 构建。

```text
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" <action> [参数]
```

最低兼容 Node.js 18.20.8，保留 Node 20/22 支持；新环境优先使用仍受维护的 LTS。遇到 `NODE_VERSION_UNSUPPORTED` 先升级，再重试原命令。依赖不兼容时读 [版本兼容性](references/version-compatibility.md)；安装包或许可证检查读 [第三方组件审计](references/third-party-audit.md)。

新项目初始化环境检查时（即使尚未提供剧本），按 [CLI 首次使用](references/cli-onboarding.md) 检测已有安装，并执行其中的初始化账号检查与登录确认；不得等到首次上传才发现未登录。缺失时先展示来源、精确版本、安装范围与命令，询问是否允许 Agent 安装，获批后安装并复检、继续原步骤。PATH 不可见优先复用已有入口；版本不兼容单独确认升级，不把安装授权当作登录或生产费用批准。用户拒绝时暂停依赖 CLI 的步骤，不反复追问或用 npx 绕过。已有项目首次远端使用也遵循该依赖合同，纯本地查看不触发登录要求。

每个新任务首次进入本 Skill 时，如已有可用 ManturHub CLI，完整读取 [Skill 版本检查与升级](references/skill-update.md)，只执行一次 `manturhub skill outdated --json`。当前版本已是最新时保持静默；发现当前宿主安装有新版时先说明本地／线上版本并询问是否更新，未经明确授权不得运行更新。检查失败、CLI 不支持或没有受跟踪安装时不阻断本地查看或生产，也不为检查更新单独安装／升级 CLI；异步轮询与恢复循环中不得重复检查。

更新并复检成功后，明确提示用户完全退出并重新打开当前智能体应用，等待重启后再恢复生产；不能只在原会话重读文件就继续。恢复时读取新版入口及相关合同，核对版本、项目进度和有效授权；看板服务独立检查，具体执行以上述升级合同为准。

- 以项目文件恢复状态，不依赖聊天记忆。所有输入副本、状态、检查点和采用的媒体位于项目内；不猜最新文件、不借用其他项目批准。
- 用户已明确的范围、素材确认和有效费用批准继续有效，不重复索要。范围授权、素材审核、版本选择和费用批准各有作用；准备动作的上传／试算不等于付费提交授权。
- 只读查看、媒体检查、快照和服务无需登录；上传、远端查询、报价、提交及轮询须认证。显式 `MANTURHUB_KEY` 继续用于自动化；未设置时，稳定版 CLI `>=1.2.5` 复用 `manturhub auth login --workbuddy` 的浏览器登录身份。不得读取、导出或迁移 CLI 私有凭据库中的明文 Key，密钥不得进入聊天、项目、命令参数文件、日志或快照；开发双域跨域请求仍要求显式 `MANTURHUB_KEY`。
- 不伪造素材、批准、验收或完成状态；不因超时、下载或展示失败重新付费，不静默切换模型、provider 或素材。
- 正常图片经真实视觉检查自动采用，正常分镜和视频通过相应技术校验后也不再逐段询问人工确认；素材检查、分镜生产清单确认、已有版本替换及导出选片仍按对应合同执行。

## 面向新手的用户沟通

默认把用户当作首次制作漫剧的创作者，而不是开发者。对话先说制作结论、原因、需要用户做的选择及其创作／费用影响；用“画面说明”代替提示词模板、“参考素材”代替引用资产、“AI 自动配音”代替 AI 直出。`Clip` 与 `EP` 一样是可直接使用的制作编号，不要求机械替换为“镜头”；需要帮助首次接触的用户理解时，可写成“Clip 03（第 3 个镜头）”。

面向用户的报价、余额、预计余量、预算和不足差额统一使用“馒头”，格式为“<平台本次返回的原值> 馒头”。用户说“积分”时按同一单位理解，回复仍使用“馒头”；底层 `points` 与“馒头”等值一一对应，只改变展示名称，不换算、不取整，小数原值保留。具体费用数字只能来自当前站点的已验证实时报价：普通操作按精确请求，图片与定制音色按素材合同的本批同配置代表请求计价并乘数量；公开详情、说明文档、历史记录、评测样例和模型常识中的金额都不能作为报价，也不能在尚未取得实时报价时向用户展示任何估算或默认金额。API、Runtime、私有记录与批准继续使用既有 `points` 字段；仅在用户明确要求技术排障时按需解释该对应关系。

- 不向普通用户展示或要求理解命令名、JSON 字段、状态码、Schema／Manifest／Runtime、provider、Job／Run、内部 ID、哈希、协议名或内部私有路径。它们只用于 Agent 执行和校验；用户明确要求技术排障详情时才按需解释。读取本地剧本／素材、选择持久项目目录以及交付 ZIP／剪映草稿时，可以请求用户选择或提供必要位置，并用可点击文件或易懂的位置说明返回交付物；不要要求用户理解内部目录结构，也不要暴露 Runtime 私有文件。
- 需要确认时，说明正在制作什么、为什么现在需要确认、可选方案以及对费用或后续制作的影响；不要只说“待确认”“已阻断”或要求用户输入内部术语。
- 进度、失败和恢复都用作品语言描述，例如“第 3 个镜头正在生成”“女主音色需要试听确认”。不得把内部检查失败包装成制作成功，也不得因语言简化省略费用、素材或交付门禁。

### 生视频关键节点的陪伴式沟通

生视频时采用原则式引导，不背诵固定话术。关键回复按当时需要覆盖：作品现在是什么状态、这一事实对连续制作意味着什么、接下来会发生什么、用户此刻有哪些可执行选择，以及是否需要回复。先带用户走到当前节点，再解释刚遇到的真实概念；真实尾帧连续性、技术校验、候选结果和交付选片均在首次相关时简要说明，后续不重复教学。

只在批次规划、前序候选决策、费用批准、首个合规视频、重要状态变化和整批结束时主动引导。正常结果继续自动推进，可合并反馈，不逐 Clip 索要“继续”或新增成片审核。无需用户决定时明确说明会自动继续、无需回复；需要决定时集中给出当前有效选项及各自影响。临时排队、限流、网络恢复和独立链继续不重新索要选择。

整批进入终态后，无论用户此前是否说明 ZIP 或剪映等交付目标，都先汇总完成、失败、阻断和未生成数量，再暂停并重新让用户从“导出按集 ZIP、导出剪映草稿、重生成指定 Clip、继续生成其他片段”中选择。只把已满足前提的选项标为可立即执行；不自动导出、不自动重生成或建立新批次，也不沿用旧批次费用批准。详细分支见[批次授权](references/video-batch-approval.md)、[视频合同](references/video-generation.md)、[等待与恢复](references/async-wait-policy.md)和[候选与交付](references/video-result-selection.md)。

普通用户的选择、报价、进度、失败和恢复统一使用以下制作语言；实际调用、持久化字段和技术校验只在 Agent 内部执行。技术排障详情或用户明确要求查看命令时才例外按需说明。

| 内部动作的用户说法 | 对用户的解释 |
|---|---|
| 整理剧本素材 | 分析剧本并整理角色、场景、道具和声音需求 |
| Agent 内置生图 | 使用当前 Agent 自带的图片生成能力 |
| ManturHub 平台生图 | 通过 ManturHub 图片生成服务制作，可能涉及平台额度和费用 |
| 音色库 | 从预制音色库为角色匹配声音，预制音色免费 |
| 定制角色声音 | 设计角色专属声音 |
| 生成试听音频 | 生成可试听的角色声音 |
| 生成分镜 | 把剧本整理为镜头和画面说明 |
| 分析参考素材 | 分析参考素材以辅助制作 |
| 生成视频镜头 | 生成视频镜头 |

## 先按用户意图选路径

执行某条路径前，完整读取该行合同；遇到合同内明确要求的子流程再读取其引用，不预先加载所有参考文档。

| 用户意图 | 执行前必读 | 动作与边界 |
|---|---|---|
| 新建／继续制作 | [输入准备](references/input-preparation.md)、[本地协议](references/local-project-schema.md) | 按下方生产流程；继续时先核对已保存操作与当前阶段 |
| 查询进度、解释阻塞 | [本地协议](references/local-project-schema.md) | 只刷新并读取快照，不提交、重试远端任务或改变业务事实 |
| 打开看板、状态 API、停止服务 | [只读服务](references/readonly-http-api.md) | 按宿主能力使用 detached 或 `serve-readonly-service`，跨工具调用复核同一实例后用 `open-workbench --require-existing`；仅用户明确停止时执行 `stop-readonly-service --confirm-stop` |
| 接入已保存的资产产物 | [资产接入](references/asset-extraction-import.md) | 明确剧本、JSON/XLSX、成功 Job 与范围，`import-asset-extraction --input`；可先 `--no-write`，不重新提取 |

修改与交付按独立意图处理：

| 用户意图 | 执行前必读 | 动作与边界 |
|---|---|---|
| 修改服装、资产外观、变体、图片提示词或将合格资产设为可延后／恢复必需 | [需求修订](references/asset-revisions.md) | `prepare-asset-revision` 展示差异、策略资格及影响，确认后 `apply-asset-revision`；不删除资产、不改原提取，不自动重编译或生成 |
| 修改 Clip 提示词或引用 | [提示词写回](references/runtime-and-export.md#修改-clip-提示词的写回流程) | 修改唯一请求模板，同步派生正文／引用，使过期批准失效，原子保存并刷新回读；不改历史 Run，不授权重新生成 |
| 修改默认或所选 Clip 分辨率 | [分辨率设置](references/video-resolution.md) | 按明确范围 inspect／apply；不只改 project.json，不改已提交视频，修改项重新报价批准 |
| 修改视频创作风格 | [创作风格](references/creative-style.md) | `inspect-creative-style-change` 先展示影响，确认后 `apply-creative-style-change`；不改历史产物或已提交任务 |

生成与交付：

| 用户意图 | 执行前必读 | 动作与边界 |
|---|---|---|
| 整集重编译、追加集数、切回分镜 | [分镜版本](references/clip-revisions.md) | 区分新生成意图与原操作恢复；检查影响后显式切换，不按相同 Clip ID 复用旧视频／尾帧 |
| 批量视频／单 Clip 重生成 | [候选与依赖](references/video-result-selection.md)、[批次授权](references/video-batch-approval.md)、[视频合同](references/video-generation.md) | 按下方批次流程；依赖以分镜声明为准 |
| 视频 ZIP／剪映交付 | [候选选择](references/video-result-selection.md)、[导出合同](references/runtime-and-export.md#按集-zip-输入合同) | 建立共享交付选片计划；剪映另读 [剪映交付](references/jianying-draft-delivery.md) |
| 恢复异步任务 | [等待与恢复](references/async-wait-policy.md)及原任务所属阶段合同 | 恢复原操作／请求／幂等键；不把“继续”解释为新生成意图 |

## 生产流程

### 0. 项目准备与当前阶段预检

初始化先只读检查登录状态，未登录时询问用户是否现在登录，明确同意后才执行授权；暂不登录仍可准备本地项目。检查字段、异常分流与登录后复检统一按 [初始化账号检查与登录确认](references/cli-onboarding.md#初始化账号检查与登录确认)，不得用“CLI 已安装”代替“已登录”或“算子已就绪”。

完整读取 [输入准备](references/input-preparation.md)、[模型选择](references/video-models.md)、[平台预检](references/manturhub-preflight.md) 和 [看板交接](references/readonly-http-api.md#项目准备完成后的自动交接)，按合同取得已确认剧本、封存全集、保存配置并只预检当前阶段。正常流程明确询问模型、比例、分辨率和风格；若比例选择被绕过，Runtime 在首次封存时持久化 `9:16` 兜底，模型、分辨率或风格缺失仍停止。只有 doctor 判定 `legacy` 后才读取 [legacy 流程](references/legacy-production.md)。

完整读取剧本后、资产提取前，按 [剧本内容初审](references/input-preparation.md#剧本内容初审) 结合上下文检查血腥、暴力、色情三类内容风险。发现问题时先指出具体位置、原因和尽量保留剧情及人物动机的修改建议，再集中提供“保持原剧本继续（后续制作可能因内容审核失败）／让 Agent 按上述建议修改／我自己修改剧本”三个选择，等待用户决定后再继续使用该剧本的上传和新生产步骤。明确选择 Agent 修改且范围清楚即授权本次改稿，无需重复确认，修改不授权重新生成或付费。未发现明显风险时简短说明并继续原流程。初审不保证平台通过，也不据此认定后续不明原因的生成失败属于内容审核失败；不新增 Runtime 审核硬门禁。

收到完整剧本后，按输入准备合同推荐用户提供 3～5 张代表剧集风格的参考图，帮助理解期望的资产风格；这是可选建议，没有参考图也可继续。已有明确参考或用户已拒绝时不重复询问。

用户以本地文件提供完整剧本时，在资产提取前先按输入准备合同只读查看剧本所在目录及其直接父目录，盘点其中的图片和音频。按目录向用户汇报发现数量，由用户决定全部纳入、只纳入部分目录或不纳入；不得因为文件与剧本相邻就自动采用。确认后的素材来源目录写入项目私有配置，续跑时直接复用有效记录，不重复询问来源范围；记录缺失或来源实际变化时再核对，不依赖聊天记忆。这里只确认后续盘点范围，不等于任何文件已经匹配、验收或就绪；真正采用的媒体仍须复制进项目并通过现有素材审核。

用户只要求提取或做到分镜时，将其视为本次停止点，不保存为项目配置。项目全集不等于本次批次、费用授权或交付授权。每次准备资产提取、分镜或视频前按输入准备合同读取当前 `production_brief`；它不替代结构化风格、素材验收、生成授权、模型选择或费用批准。

### 1. 资产提取

完整读取 [在线资产提取](references/online-asset-extraction.md)，使用已封存全集准备、报价批准、提交并恢复原任务。Runtime 接入并回读原产物、派生报告和项目指针后才报告完成；提取完成不等于素材就绪。已有成功产物或远端成功后的本地接入失败走原操作恢复，不重新付费提取。

### 2. 匹配已有素材与图片生成

匹配已有素材时完整读取 [输入准备](references/input-preparation.md)、[视觉匹配](references/visual-matching.md) 和 [素材操作](references/asset-operations.md)；仅在要路由参考图、调用生图或核对生成图参考用途时再完整读取 [参考路由](references/reference-routing.md)。复用已确认的素材来源，逐张查看实际画面并完成唯一关联；同一资产多张候选由 Agent 择优采用一张，其他保留。已有图片、内置生图和平台生图均在检查通过后逐条调用 `apply-asset-review` 自动采用，正常图片直接在看板显示已就绪，不等待用户确认整份清单，不填写虚假的用户确认。汇总采用结果供用户自行查看，有异议再在对话中修改；仅身份冲突、无法可靠检查、无法明确选图或替换既有采用图片等异常需要处理。平台候选下载后留在私有操作，继续检查、采用和发布，不能在队列返回待审核时结束制作。已有用户音频按素材合同及时接入；待试听音色不能随图片一起报为阶段完成。只有缺少必需图片且用户要求生成时才进入用户选择的生图路线；素材自动就绪不授权新付费生成、视频或重生成。

内置或平台图片生成、采用并在看板刷新回读成功后，主动提醒用户到看板查看并确认画面效果，附实际看板链接；不满意可在对话中要求修改。该提醒不等待用户回复、不改变已就绪状态，具体话术及批量反馈按素材操作合同执行。

### 3. 音色

完整读取 [预制音色与匹配](references/preset-voice-library.md) 和 [素材操作](references/asset-operations.md)。按合同先处理用户音频；没有可直接采用的用户音频且需要用户在预制匹配与定制之间选择时，面向用户的两项名称固定为“音色库”和“定制角色声音”，其中音色库的解释写为“从预制音色库为角色匹配声音，预制音色免费”，免费说明不放进选项名称，也不展示算子名。再按选择处理预制、定制或角色级明确许可的 AI 直出；provider 失败不授权自动跳到下一条路线。只有有效绑定、明确直出或无需参考策略才算就绪，待审核、身份冲突、媒体异常或缺失绑定继续阻断。

### 4. 分镜与请求模板

WAN 上传前按资产表合同运行 `inspect-wan-asset-table`，展开已确认的变体共享音色并封存原字节；已成功编译却接入失败时，保留原任务并走本地恢复诊断，不修改原上传文件或建议直接付费重跑。基础音色继承的适用条件与异常处理以以下 WAN 合同为准。

先按项目模型分流：新wan完整读取 [完整资产表 v3 调用](references/wan-compilation-v3.md) 和 [资产表结构](references/wan-asset-table-v3.md)，通过 CLI 提交剧本与最终确认完整资产表两个文件 ID，不发送 `requirementsResultId`，不使用旧 Runtime 分镜准备和提交动作。成功后必须使用含 `production_asset_table` 的 `import-clip-compilation` 描述文件接入完整资产表和分镜，描述中的版本标签不参与兼容判定；刷新并回读看板，文件交付与看板同步分别报告，失败只恢复本地导入。视频仍单独检查素材与费用授权；已有页面与历史记录保留。Seedance 完整读取 [分镜编译](references/clip-compilation.md) 和所选 [模型合同](references/video-models.md)。分镜编译默认采用已封存全集，不主动询问集数范围；用户明确只要部分集数时，按合同基于全剧分镜规划建议全集，不预先断言全集与部分集数同价，用户仍坚持后按其范围执行，恢复既有部分集数操作时不重复提醒或扩大范围。Seedance 从当前库存、匹配、审核和需求修订构建清单；素材通过、清单确认、费用批准和技术校验分别成立。技术通过的分镜按合同采用，未解决依赖继续阻断；已有分镜的新结果按版本合同显式切换。动态尾帧只进入实际请求副本，不覆盖基础模板。

### 5. 视频生成与真实尾帧

完整读取 [候选与依赖](references/video-result-selection.md)、[批次授权](references/video-batch-approval.md)、[视频合同](references/video-generation.md) 和 [场次并发](references/video-concurrency-policy.md)。先让用户选择要生成视频的具体分镜（单个、多个或全部；已明确选择则沿用），不把全集分镜完成视为全量视频授权。固定范围、生成意图与分镜声明的依赖，再逐项实时报价并取得整批批准；Runtime 在真实尾帧就绪后构建实际请求，并在批准范围内自动推进。同场串行、跨场受控并发；未知受理、失败、候选选择、替换采用和批次终态后的下一步均按合同处理，不推断前序、不静默降级、不自动追加付费重跑。

### 6. 按集 ZIP 与剪映草稿

完整读取 [候选选择](references/video-result-selection.md)、[导出合同](references/runtime-and-export.md#按集-zip-输入合同)；需要剪映时再读 [剪映交付](references/jianying-draft-delivery.md)。交付选择独立于生产采用；发布前复核选片、连续性、媒体和完整集，源变化时停止新发布并保留旧交付。ZIP、草稿包、实际安装和剪映打开验收分别报告。

## 共用报价、恢复与发布规则

批量平台图片与定制角色声音必须使用素材合同中的 `prepare-asset-batch`：同配置只询价一次，按数量汇总，一次展示和批准整批。文生图与图生图同价，不因提示词、参考图有无或数量不同拆组；不要先单独试算一张再准备其余图片，也不要逐项调用单图入口获取报价。先按实时 Schema 构造整批合法请求；上传、校验和恢复过程留在内部，集中展示范围、单价、数量和总价。各资产仍有独立请求和批准绑定，依赖、图片检查及音色试听规则不变；预制音色复用不进入付费批次。

费用批准前读 [报价与余额](references/quote-and-balance.md)，执行 `query-account-balance`。聊天同时给出范围、当前站点／上传目的地、报价、余额及查询时间、预计余量。不能用 doctor 认证代替余额；查询失败明确“余额暂不可用”及安全原因，不猜值或沿用旧余额；不足说明差额并等待处理。报价／额度占用不冒充真实结算，业务批准不绕过宿主权限。

所有异步制作／恢复按 [统一循环](references/async-wait-policy.md) 持续推进：保存原任务 → 读取 polling 指令 → 分段等待 → 调用同一恢复动作，直到终态、需人工处理、不可恢复错误、用户停止或宿主中断。中断后从项目原记录继续，不要求每轮回复。

批量平台生图与锁故障按 [锁与标准队列](references/lock-and-queue-recovery.md) 执行。使用包内单次队列恢复，查询失败不释放槽位；不临时编写批量清锁或按退出码判定完成的脚本。重复故障保留现场并诊断，不靠反复重启与清理宣称根治。

- 60 秒无终态不是失败；单次查询网络错误只表示本次查询失败。仅明确 failed/error/cancelled 才标失败；临时排队／限流按阶段合同退避，独立链继续。
- 受理不明保存 `submission_unknown`，核对原任务前不重提或换幂等键。远端成功但本地接入失败只恢复下载／校验／接入。
- 权威变化按 [本地协议](references/local-project-schema.md) 原子保存、更新项目指针、刷新并回读同一 Manifest/revision 后才能报告新状态。Runtime 已自动刷新时不重复发布；`snapshot_refresh.ok=false` 只重试 `refresh-ui-snapshot`。
- Agent 直接写文件或纯媒体变化仍须主动刷新。批量生图、转码、库存重建／JSON 更新前读 [快照协调](references/readonly-http-api.md#权威-json-自动同步)，使用 begin／heartbeat／commit／abort 快照批次，稳定落盘后只发布一次。
- 状态、问题、证据与 `chat_next_action` 如实保存；不满足门禁用对应 blocked／waiting_for_user／submission_unknown 等状态。请求、Job/Task、幂等键、签名 URL、完整远端响应及密钥不能进入 UI 或状态 API。

## 看板、完成判断与结果反馈

看板只通过本机 `127.0.0.1` 上的已发布快照展示资产、分镜与视频，筛选、预览或播放不改变生产事实。Header 余额通过独立私有缓存接口获取，不进入 Manifest、快照或 revision，也不替代聊天中的费用批准；生产事件只触发受限余额刷新，不改变任务状态或重提任务。详细 UI／同步／媒体边界见只读服务及本地协议，不由 Agent 临时改写快照改善数字。

打开看板前按只读服务合同选择生命周期：宿主有明确长期后台命令能力时，用它持有 `serve-readonly-service`；否则使用 detached 启动。启动工具调用结束后，必须在新的独立工具调用中用 `readonly-service-status` 核对相同 `instance_id`，再执行 `open-workbench --require-existing`，不得把启动命令内部的一次健康检查当作跨宿主存活证明。detached 失败后最多切换一次；仍不可用时不编造链接、不安装系统服务或创建隧道，可提供用户手动保持前台命令。使用入口实际返回的 URL，不硬编码端口。自动交接仅在 `ok=true`、`open_via_agent=true` 且用户允许时由宿主尝试打开；优先内部独立标签页，已有可识别页面优先复用。无工具或“只给链接”用 `--link-only`；用户禁止服务则跳过。始终在聊天提供有效 Markdown 链接，queued 不声称已打开；远程宿主不承诺用户能访问回环地址。不擅自重启健康服务，展示失败不撤销生产结果。

| 阶段 | 宣布完成所需事实 |
|---|---|
| 资产提取 | 四类结构及身份、变体、证据、提示词、策略完整；不等于素材就绪 |
| 素材 | 必需图片正确关联并验收；参考用途合规；音色按基础角色具有有效绑定、明确直出或无需参考策略。待确认仍不能用于生产；媒体来源、质量与摘要通过 |
| 分镜 | 目标集／Clip、模板、引用、台词、时长、枚举和连续性校验通过；未解决依赖明确阻断 |
| 视频 | 原操作与技术证据有效，本地视频及真实尾帧位于项目内、非空、MIME／哈希合规并经 Compiler 回读；预览、采用和交付分开判断 |
| 导出 | 每集目标完整，ZIP 摘要可验证；剪映另核对媒体、实际时长、轨道顺序与连续时间线，应用验收独立 |

新视频下载并通过本地校验后主动返回集数、Clip 编号和真实状态，优先用已保存视频的可播放附件／内嵌预览；宿主不支持或展示失败时直接提供实际看板入口，不改成裸文件路径或签名链接。批量可合并新增结果，轮询／恢复不重复回传；展示不增加验收门禁、不暂停已批准生成、不触发重新生成。
