# 新资产提取：保存产物的本地接入

这是完整生产链路中“已下载产物 → 本地报告 → 看板”的共用模块，不是离线替代生产，也不包含上传、提交、轮询或下载。在线资产适配器在下载完成后调用同一转换与产物门禁，但以当前成功检查点作为内部可信交接，不重复复算操作、请求、批准或轮询历史；手工入口没有该信任，仍完整验证外部资料。

## 入口与准备

```
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" import-asset-extraction --input "input/intake.json" --no-write
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" import-asset-extraction --input "input/intake.json"
```

动作只处理已有本地资料，不需要认证；在线上传、报价、提交和远端查询仍要求认证、实时合同和费用批准。切勿将本地接入失败解释为重新提取的授权。

由 Agent 明确复制所选资料到独立项目内，建立合法 `.pipeline-state/project.json`；新项目先按输入准备合同封存完整剧本全集，站点按资料实际环境锁定。不得扫描目录选择最新文件。描述文件所有路径相对 PROJECT_DIR，不相对描述文件：

```json
{
  "schema_version": 1,
  "script": "input/script-EP01-04.md",
  "primary_json": "input/PRIMARY_JSON.json",
  "tabular_xlsx": "input/TABULAR_XLSX.xlsx",
  "job": "input/job-final.json",
  "episodes": [1, 2, 3, 4]
}
```

剧本必须是本次提取实际使用的完整原字节副本。描述文件 `episodes` 可省略并自动采用封存全集；旧描述显式提供时必须与全集完全一致。资产接入不得缩小项目范围；某集没有资产行不直接判定遗漏。

## 本地校验边界

在线内部调用与手工导入只在历史信任来源上不同；下列 Job、artifact、文件、结构和语义检查两者全部执行。`validation.live_job_verified=false` 仍表示本地接入本身没有实时查询远端，不否定在线 workflow 在下载前已经完成的 Job 验证。

- `platformSchemaVersion` 与 PRIMARY_JSON 的 `schema_version` 作为平台原始标签归档，不参与兼容放行或拒绝。Runtime 在内存副本上套用当前结构校验档案，完整验证字段、关系、策略与下列语义；标签可以是 `v2/v3`、其他版本或缺省，但不兼容结构仍停止，不猜默认值。包内 `schemas/asset-extraction-import.schema.json` 是本地接入约束，不是平台完整正式 Schema。
- Job 文件为已解包对象：`apiCode=op.drama.asset-extract`、`status=SUCCEEDED`、`output.businessStatus=COMPLETED`，无非空错误。HTTP 成功或 progress=100 不等于成功终态。
- `output.artifacts` 中 PRIMARY_JSON、TABULAR_XLSX 各唯一，有 fileId 和相符的原字节 SHA-256；两类产物必须同时提供。XLSX 只做有界 ZIP/CRC 与 OOXML 必要成员校验，**不以工作表单元格反向改写 JSON，也不声称完整 Excel 语义验证**。
- JSON 内 `requirementsResultId/sourceScriptSha256` 与 Job.output 一致，后者与实际剧本 SHA 一致；不验证远端当前状态，不把保存记录当本轮实时查询证据。
- 四张表的字段类型、非空名称/提示词/证据、唯一 ID、基础关联和集数表达式合法；基础 ID 保留 `-V01`，变体同基础实体，不按名字合并。空资产集合拒绝。
- 仅项目内普通文件；拒绝越界及文件/父目录符号链接。描述文件上限 64 KiB，单输入文件上限 32 MiB；XLSX 最多 256 成员、单成员解压 16 MiB、总解压 64 MiB。超过限制须审查后改实现，不能偷偷跳过校验。

## 转换与状态

项目 `production_scope` 由全集封存动作生成，Agent 不从自然语言范围写入。资产 `出现集数` 仅接受可复现的单集 `EP01`/`第1集`、列表及连续区间；零/负数、倒序、空项、不完整或其他自然语言表达阻断接入。

生成 `mantur.drama.asset-extraction/v1` 本地报告，完整保留全剧资产的 ID、基础 ID、名称、语义变体、别名、证据、提示词和美术规范。`出现集数` 在派生报告中规范为去重排序的 `EPxx` 单集数组；原始区间文本仍仅保留在受 SHA-256 保护的私有 PRIMARY_JSON 归档。Compiler、素材操作与 Production Manifest 使用封存全集及所需 V01 基础依赖。`资产适配场景` 保留文本，不猜场景 ID。

提取记录不产生素材批准。`pending_match_or_generation/待补全` 保持待处理，媒体与音色绑定初始为空；不采用参考项目 `covered` 记录，不把任意 URL 当已验收媒体。`defer_to_video` 保持可延后，不计入必需图片缺失。音色需求按基础角色去重，未绑定时待处理，不默认 AI 直出。

## 保存、并发与恢复

1. 完成全部验证，再取得项目批次锁与发布锁，复核输入及配置。
2. 原始 bytes 与收据保存在 `.pipeline-state/runtime/asset-extraction/<import_id>/`；签名地址、真实远端 ID 留在此私有归档，不进入快照。不要把该目录加入公开媒体或版本控制。
3. 派生 `report.json/state.json` 保存在 `.pipeline-state/results/asset-extraction/<import_id>/` 不可变目录；state 记录本地接入成功及保存提取结果来源，不创建虚假的远端 Task。
4. 原子更新 `project.workflow_state.extraction_result/extraction_state/asset_extraction_import`；刷新一次并回读 Manifest 对应的项目/资产快照。

接入身份包含输入原字节摘要、转换器版本、站点与封存全集。首版仅支持首次接入及同一产物恢复；不同选定报告、匹配报告、全集冲突或已有下游记录拒绝覆盖/合并。同一身份也要重新验证，不跳过原字节检查；归档或派生报告被修改时报告冲突。Runtime 仅在内存校验副本写入本地结构档案需要的标签，原始 JSON 字节、哈希和平台版本名完整归档。

`--no-write` 不创建目录、锁、收据或快照。写入期间共用批次租约和发布锁，自动同步等待。输入变化返回 `SOURCE_CHANGED`，保留未被选中的不可变归档供重试，绝不切换到半份报告。

结果含 `import_id/summary/validation`、报告引用、`skipped`、`production_result_preserved` 和独立 `snapshot_refresh`。`validation.live_job_verified=false` 固定说明本次只验证保存资料一致性。重复接入复用身份并完整刷新校验；数据没变时 Compiler 复用 revision。

若报告已保存而 `snapshot_refresh.ok=false`，只恢复 `refresh-ui-snapshot`，不能重提交提取。不同报告冲突应另建明确范围的新项目或由用户决定后续迁移，不能删除冲突事实让接入通过。

## Agent 看板交接

快照回读成功后沿用 `open-workbench --after-extraction`：首次尝试宿主页面打开，同时返回 Runtime 实际链接；重复接入不反复弹窗。用户要求只返回链接时用 `--link-only`；要求不启动服务时不执行打开动作。Node 接入动作本身不启动服务或浏览器，不重启旧服务。页面失败不撤销本地成功结果。

明确告知用户：资产需求已进入本地项目，图片/音色尚待处理；在线接入现由四个资产入口复用；其他新生产阶段仍待适配。不得把本次接入宣布为新版生产全链路通过。


## 2026-09-16 资产产物兼容与恢复

角色表兼容 CHAR-* 与 CROWD-*，群众仍属于角色；场景/道具保留 SCN/PROP 前缀，ID 和基础关系不重写。重要度支持 S/A/B/C，仅生成策略决定图片是否必需。音色策略 bind_or_generate 与 ai_direct_allowed 均遵守项目授权、有效绑定优先；none 表示无需独立参考音色，不计音色需求或 VOICE 引用，存在绑定时报告冲突。音色按基础角色去重，变体策略矛盾阻断；旧报告缺策略保留原行为。

当前成功提取接入可保留命名及 operation ID 一致的历史失败／取消／平台超时检查点；内部接入不重读这些历史操作的请求、批准、受理或 poll 归档。在途、未知提交、其他成功记录和下游冲突继续阻断。远端成功而本地接入失败时仅修复适配并恢复原操作，不重新上传、报价或调用提取。结构错误的本地诊断提供受限字段路径、规则及枚举，不输出完整内容。

线上已见多个不同 `schema_version` 标签但结构兼容的产物。更新 Skill 后，对原 `stage=intake` 操作使用同一 operation-id 执行 `resume-asset-extraction`；Runtime 只重验并接入已保存产物，不创建新的上传、报价、Job 或扣费。版本标签不代表结构通过，任一完整门禁失败仍保留原归档并返回本地接入错误。


1.0.5 起资产版本标签不再是接入门禁：所有标签进入同一完整结构校验，不改写原始字节；新 wan 完整资产表和分镜接入按 [完整资产表本地导入合同](wan-compilation-v3.md) 执行。
