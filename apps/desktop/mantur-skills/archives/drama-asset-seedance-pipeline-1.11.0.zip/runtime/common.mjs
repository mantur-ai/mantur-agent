import { spawnSync } from "node:child_process";
import {
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { dirname, isAbsolute, relative, resolve } from "node:path";

export function plainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

export function parseOptions(tokens, specification) {
  const values = new Set(specification.values || []);
  const booleans = new Set(specification.booleans || []);
  const repeated = new Set(specification.repeated || []);
  const options = Object.fromEntries([...repeated].map((name) => [name, []]));
  const positionals = [];
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (token === "--") {
      positionals.push(...tokens.slice(i + 1));
      break;
    }
    if (!token.startsWith("--")) {
      positionals.push(token);
      continue;
    }
    const equals = token.indexOf("=");
    const name = token.slice(2, equals > 2 ? equals : undefined);
    if (booleans.has(name)) {
      if (equals > 2) throw new Error(`option --${name} does not accept a value`);
      options[name] = true;
      continue;
    }
    if (!values.has(name) && !repeated.has(name)) throw new Error(`unknown option: --${name}`);
    let value;
    if (equals > 2) value = token.slice(equals + 1);
    else value = tokens[++i];
    if (!value || value.startsWith("--")) throw new Error(`option --${name} requires a value`);
    if (repeated.has(name)) options[name].push(value);
    else options[name] = value;
  }
  const expected = specification.positionals ?? 0;
  if (positionals.length !== expected) {
    throw new Error(`expected ${expected} positional argument(s), received ${positionals.length}`);
  }
  return { options, positionals };
}

export function readJson(path, { object = false } = {}) {
  const value = JSON.parse(readFileSync(path, "utf8"));
  if (object && !plainObject(value)) throw new Error(`JSON must be an object: ${path}`);
  return value;
}

export function writeJson(path, payload) {
  const target = assertProjectWritePath(path);
  mkdirSync(dirname(target), { recursive: true });
  const temporary = resolve(dirname(target), `.${target.split(/[\\/]/).pop()}.${process.pid}.tmp`);
  try {
    writeFileSync(temporary, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
    renameSync(temporary, target);
  } finally {
    rmSync(temporary, { force: true });
  }
  return target;
}

export function projectRoot() {
  const configured = process.env.MANTURHUB_PROJECT;
  if (!configured) throw new Error("MANTURHUB_PROJECT is missing; run this action through ManturHub CLI");
  const root = resolve(configured);
  if (!existsSync(root) || !lstatSync(root).isDirectory()) throw new Error(`project directory is invalid: ${configured}`);
  return root;
}

export function assertProjectWritePath(path) {
  const root = projectRoot();
  const target = resolve(root, path);
  const relation = relative(root, target);
  if (relation.startsWith("..") || isAbsolute(relation)) {
    throw new Error(`output path must stay inside the project directory: ${path}`);
  }
  if (existsSync(target) && lstatSync(target).isSymbolicLink()) {
    throw new Error(`output path is a symbolic link: ${target}`);
  }
  let cursor = dirname(target);
  while (cursor !== root && cursor !== dirname(cursor)) {
    if (existsSync(cursor) && lstatSync(cursor).isSymbolicLink()) {
      throw new Error(`output path contains a symbolic link: ${cursor}`);
    }
    cursor = dirname(cursor);
  }
  return target;
}

export function httpUrl(value, field = "URL", { httpsOnly = false, noQuery = false } = {}) {
  let url;
  try {
    url = new URL(String(value || ""));
  } catch {
    throw new Error(`${field} must be a valid HTTP/HTTPS URL`);
  }
  if ((!httpsOnly && !["http:", "https:"].includes(url.protocol)) || (httpsOnly && url.protocol !== "https:")) {
    throw new Error(`${field} must be a valid ${httpsOnly ? "HTTPS" : "HTTP/HTTPS"} URL`);
  }
  if (!url.hostname || url.username || url.password || (noQuery && (url.search || url.hash))) {
    throw new Error(`${field} is not an allowed URL`);
  }
  return url.href;
}

export function runCli(args, { allowNonZeroJson = false } = {}) {
  const entry = process.env.MANTURHUB_CLI_ENTRY;
  if (!entry || !existsSync(entry)) throw new Error("ManturHub CLI entry is unavailable");
  const result = spawnSync(process.execPath, [entry, ...args], {
    encoding: "utf8",
    env: { ...process.env, MANTURHUB_DISABLE_UPDATE_CHECK: "1" },
    maxBuffer: 16 * 1024 * 1024,
  });
  if (result.error) throw new Error(`ManturHub CLI failed to start: ${result.error.message}`);
  let payload;
  try {
    payload = JSON.parse(result.stdout);
  } catch {
    payload = null;
  }
  if (result.status !== 0 && !(allowNonZeroJson && plainObject(payload))) {
    throw new Error(`ManturHub CLI command failed (exit ${result.status ?? "unknown"})`);
  }
  if (!plainObject(payload)) throw new Error("ManturHub CLI returned invalid JSON");
  return { status: result.status, payload };
}

export function runExternal(command, args = []) {
  const result = spawnSync(command, args, {
    encoding: "utf8",
    env: process.env,
    maxBuffer: 16 * 1024 * 1024,
  });
  return {
    found: result.error?.code !== "ENOENT",
    status: result.status,
    stdout: result.stdout || "",
    stderr: result.stderr || "",
  };
}

export function outputPath(value, label) {
  if (!value) throw new Error(`${label} is required`);
  return assertProjectWritePath(value);
}
