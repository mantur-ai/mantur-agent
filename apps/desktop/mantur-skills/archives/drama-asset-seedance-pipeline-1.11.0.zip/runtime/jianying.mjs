import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import {
  constants,
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  realpathSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
  writeSync,
  closeSync,
} from "node:fs";
import { basename, dirname, extname, isAbsolute, relative, resolve } from "node:path";
import { homedir } from "node:os";
import {
  assertProjectWritePath,
  parseOptions,
  plainObject,
  projectRoot,
  readJson,
  writeJson,
} from "./common.mjs";
import { inspectIsoBmff, sha256Media } from "./media.mjs";
import { createStoredZip, extractStoredZip } from "./zip.mjs";

const PROFILE = Object.freeze({
  id: "jianying-macos-5.9",
  app_source: "lv",
  app_version: "5.9.0",
  app_version_range: "5.9.x",
  os: "mac",
  primary_file: "draft_info.json",
});
const PORTABLE_ROOT = "__MANTURHUB_PORTABLE_DRAFT__";
const MAX_DOWNLOAD_BYTES = 4 * 1024 ** 3;
const APP_BUNDLE_IDS = new Set(["com.lemon.lvpro"]);
const STANDARD_APP_PATHS = [
  "/Applications/剪映专业版.app",
  "/Applications/JianyingPro.app",
  resolve(homedir(), "Applications", "剪映专业版.app"),
  resolve(homedir(), "Applications", "JianyingPro.app"),
];

function sha256Text(value) {
  return createHash("sha256").update(value).digest("hex");
}

function stableUuid(seed) {
  const hex = sha256Text(seed).slice(0, 32).split("");
  hex[12] = "5";
  hex[16] = ((Number.parseInt(hex[16], 16) & 0x3) | 0x8).toString(16);
  const raw = hex.join("");
  return `${raw.slice(0, 8)}-${raw.slice(8, 12)}-${raw.slice(12, 16)}-${raw.slice(16, 20)}-${raw.slice(20)}`;
}

function safeName(value, fallback = "draft") {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u0000-\u001f<>:"/\\|?*]+/g, "-")
    .replace(/\s+/g, " ")
    .replace(/^[-. ]+|[-. ]+$/g, "")
    .slice(0, 80) || fallback;
}

function portableName(value, fallback = "item") {
  return String(value || "")
    .normalize("NFKD")
    .replace(/[^A-Za-z0-9._-]+/g, "-")
    .replace(/^[-.]+|[-.]+$/g, "")
    .slice(0, 60) || fallback;
}

function semverTuple(value) {
  const match = String(value || "").match(/^(\d+)\.(\d+)(?:\.(\d+))?/);
  return match ? match.slice(1, 4).map((item) => Number(item || 0)) : null;
}

function profileForAppVersion(version) {
  const tuple = semverTuple(version);
  if (!tuple) throw new Error(`无法识别剪映专业版版本: ${version || "(空)"}`);
  if (tuple[0] === 5 && tuple[1] === 9) return PROFILE;
  if (tuple[0] >= 6) {
    throw new Error(`剪映专业版 ${version} 使用未受支持的加密/新版草稿格式；当前只支持 5.9.x，已停止写入`);
  }
  throw new Error(`剪映专业版 ${version} 不在已验证 profile jianying-macos-5.9 范围内`);
}

function plistXmlValue(text, key) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return text.match(new RegExp(`<key>\\s*${escaped}\\s*</key>\\s*<string>([^<]+)</string>`))?.[1] || null;
}

function plistValue(plist, key) {
  if (process.platform === "darwin" && existsSync("/usr/bin/plutil")) {
    const result = spawnSync("/usr/bin/plutil", ["-extract", key, "raw", plist], {
      encoding: "utf8",
      maxBuffer: 1024 * 1024,
    });
    if (result.status === 0 && result.stdout.trim()) return result.stdout.trim();
  }
  return plistXmlValue(readFileSync(plist, "utf8"), key);
}

export function inspectJianyingApp(appPath) {
  const selected = appPath || STANDARD_APP_PATHS.find((candidate) => existsSync(candidate));
  if (!selected) throw new Error("本机未检测到剪映专业版；不能执行本机草稿导入验收");
  if (!existsSync(selected) || lstatSync(selected).isSymbolicLink() || !lstatSync(selected).isDirectory()) {
    throw new Error(`剪映应用路径不是可信目录: ${selected}`);
  }
  const plist = resolve(selected, "Contents", "Info.plist");
  if (!existsSync(plist) || !lstatSync(plist).isFile()) throw new Error("剪映应用缺少 Info.plist");
  const bundleId = plistValue(plist, "CFBundleIdentifier");
  const version = plistValue(plist, "CFBundleShortVersionString");
  if (!APP_BUNDLE_IDS.has(bundleId)) throw new Error(`不支持的剪映应用标识: ${bundleId || "(空)"}`);
  const profile = profileForAppVersion(version);
  return { app_path: realpathSync(selected), bundle_id: bundleId, version, profile: profile.id };
}

function requireProfile(value) {
  if (value !== PROFILE.id) throw new Error(`未知或未支持的剪映 profile: ${value || "(空)"}`);
  return PROFILE;
}

function validateSha(value, label) {
  const normalized = String(value || "").toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(normalized)) throw new Error(`${label} 缺少有效 SHA-256`);
  return normalized;
}

function validateSourceUrl(value) {
  let url;
  try { url = new URL(String(value || "")); } catch { throw new Error("视频 URL 不是有效 URL"); }
  const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if ((url.protocol !== "https:" && !(url.protocol === "http:" && loopback)) || url.username || url.password) {
    throw new Error("视频 URL 必须使用 HTTPS（本机测试地址除外）且不得包含凭据");
  }
  return url;
}

function extensionFor(row) {
  const candidate = row.video_path || row.video_url || "video.mp4";
  const suffix = extname(String(candidate).split("?")[0]).toLowerCase();
  return [".mp4", ".mov", ".m4v"].includes(suffix) ? suffix : ".mp4";
}

function writeAll(fd, buffer) {
  let offset = 0;
  while (offset < buffer.length) {
    const written = writeSync(fd, buffer, offset, buffer.length - offset);
    if (!written) throw new Error(`failed to write video at byte ${offset}`);
    offset += written;
  }
}

function parseManifest(inputPath) {
  const payload = readJson(resolve(inputPath), { object: true });
  if (payload.schema_version !== 1 || !Array.isArray(payload.clips) || !Array.isArray(payload.episodes)) {
    throw new Error("剪映交付清单必须是 schema_version=1 且包含 clips[]/episodes[]");
  }
  const projectName = safeName(payload.project_name, "漫剧项目");
  const clips = [];
  const clipIds = new Set();
  const positions = new Set();
  for (const [index, raw] of payload.clips.entries()) {
    if (!plainObject(raw)) throw new Error(`clips[${index}] 必须是 object`);
    const clipId = String(raw.clip_id || "").trim();
    const episode = Number(raw.episode_number ?? raw.episode);
    const scene = Number(raw.scene_index);
    const clip = Number(raw.clip_index ?? raw.order);
    if (!clipId || clipIds.has(clipId)) throw new Error(`clips[${index}] Clip ID 缺失或重复`);
    if (![episode, scene, clip].every((item) => Number.isInteger(item) && item >= 1)) {
      throw new Error(`${clipId} 缺少合法 episode_number/scene_index/clip_index`);
    }
    if (String(raw.status || "").toLowerCase() !== "completed") throw new Error(`${clipId} 尚未完成，拒绝生成残缺草稿`);
    if (!raw.video_path && !raw.video_url) throw new Error(`${clipId} 缺少本地视频或视频 URL`);
    const position = `${episode}:${scene}:${clip}`;
    if (positions.has(position)) throw new Error(`重复时间线位置: ${position}`);
    positions.add(position);
    clipIds.add(clipId);
    clips.push({
      clip_id: clipId,
      episode_number: episode,
      scene_index: scene,
      clip_index: clip,
      video_path: raw.video_path ? resolve(String(raw.video_path)) : null,
      video_url: raw.video_url ? validateSourceUrl(raw.video_url).href : null,
      sha256: validateSha(raw.sha256, clipId),
      planned_duration_seconds: raw.planned_duration_seconds === undefined ? null : Number(raw.planned_duration_seconds),
      extension: extensionFor(raw),
    });
  }
  const expectations = new Map();
  for (const row of payload.episodes) {
    if (!plainObject(row) || !Number.isInteger(Number(row.episode_number)) || Number(row.episode_number) < 1) {
      throw new Error("episodes[] 包含非法 episode_number");
    }
    const episode = Number(row.episode_number);
    if (expectations.has(episode) || !Array.isArray(row.expected_clip_ids) || !row.expected_clip_ids.length) {
      throw new Error(`EP${episode} 缺少唯一 expected_clip_ids`);
    }
    const expected = row.expected_clip_ids.map((item) => String(item || "").trim());
    if (expected.some((item) => !item) || new Set(expected).size !== expected.length) {
      throw new Error(`EP${episode} expected_clip_ids 为空或重复`);
    }
    expectations.set(episode, new Set(expected));
  }
  const grouped = new Map();
  for (const row of clips) {
    if (!grouped.has(row.episode_number)) grouped.set(row.episode_number, []);
    grouped.get(row.episode_number).push(row);
  }
  if (new Set([...grouped.keys(), ...expectations.keys()]).size !== grouped.size || grouped.size !== expectations.size) {
    throw new Error("clips[] 与 episodes[] 的集数集合不一致");
  }
  for (const [episode, rows] of grouped) {
    const actual = new Set(rows.map((row) => row.clip_id));
    const expected = expectations.get(episode);
    const missing = [...expected].filter((id) => !actual.has(id));
    const extra = [...actual].filter((id) => !expected.has(id));
    if (missing.length || extra.length) {
      throw new Error(`EP${episode} 目标 Clip 不完整；missing=${missing.join(",") || "-"}; extra=${extra.join(",") || "-"}`);
    }
    rows.sort((a, b) => a.scene_index - b.scene_index || a.clip_index - b.clip_index || a.clip_id.localeCompare(b.clip_id));
  }
  return { projectName, grouped };
}

async function downloadVideo(url, target) {
  const response = await fetch(url, { signal: AbortSignal.timeout(120000), redirect: "follow" });
  const finalUrl = validateSourceUrl(response.url || url.href);
  void finalUrl;
  if (!response.ok) throw new Error(`视频下载失败 (HTTP ${response.status})`);
  const contentType = String(response.headers.get("content-type") || "").toLowerCase();
  if (contentType && !contentType.startsWith("video/") && !contentType.startsWith("application/octet-stream")) {
    throw new Error(`视频下载返回了非视频 Content-Type: ${contentType.split(";")[0]}`);
  }
  const declared = Number(response.headers.get("content-length") || 0);
  if (declared > MAX_DOWNLOAD_BYTES) throw new Error("视频超过 4 GiB 下载上限");
  if (!response.body) throw new Error("视频下载响应没有 body");
  const fd = openSync(target, "wx");
  const reader = response.body.getReader();
  let total = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MAX_DOWNLOAD_BYTES) throw new Error("视频超过 4 GiB 下载上限");
      writeAll(fd, value);
    }
  } catch (error) {
    closeSync(fd);
    rmSync(target, { force: true });
    throw error;
  } finally {
    try { closeSync(fd); } catch { /* already closed after failure */ }
  }
  if (!total) throw new Error("下载的视频为空");
}

async function stageClip(row, assetsDir, index) {
  const name = `${String(index + 1).padStart(3, "0")}-${portableName(row.clip_id, "clip")}${row.extension}`;
  const target = resolve(assetsDir, name);
  if (row.video_path) {
    if (!existsSync(row.video_path) || lstatSync(row.video_path).isSymbolicLink() || !lstatSync(row.video_path).isFile()) {
      throw new Error(`${row.clip_id} 本地视频不存在或不是普通文件`);
    }
    copyFileSync(row.video_path, target, constants.COPYFILE_EXCL);
  } else {
    await downloadVideo(new URL(row.video_url), target);
  }
  const sha256 = sha256Media(target);
  if (sha256 !== row.sha256) throw new Error(`${row.clip_id} 视频 SHA-256 不匹配`);
  const media = inspectIsoBmff(target);
  return { ...row, asset_name: name, staged_path: target, ...media };
}

function companions(key, clipId) {
  const make = (suffix) => stableUuid(`${key}:${clipId}:${suffix}`);
  const speed = { id: make("speed"), type: "speed", speed: 1, mode: 0, curve_speed: null };
  const placeholder = { id: make("placeholder"), type: "placeholder_info", error_path: "", error_text: "", meta_type: "none", res_path: "", res_text: "" };
  const channel = { id: make("channel"), type: "none", audio_channel_mapping: 0, is_config_open: false };
  const vocal = { id: make("vocal"), type: "vocal_separation", choice: 0, enter_from: "", final_algorithm: "", production_path: "", removed_sounds: [], time_range: null };
  const canvas = { id: make("canvas"), type: "canvas_color", album_image: "", blur: 0, color: "", image: "", image_id: "", image_name: "", source_platform: 0, team_id: "" };
  const color = { id: make("color"), type: "material_color", gradient_angle: 90, gradient_colors: [], gradient_percents: [], height: 0, is_color_clip: false, is_gradient: false, solid_color: "", width: 0 };
  return {
    ids: [speed.id, placeholder.id, channel.id, vocal.id, canvas.id, color.id],
    rows: { speed, placeholder, channel, vocal, canvas, color },
  };
}

function createDraft(key, name, rows) {
  const width = rows[0].width;
  const height = rows[0].height;
  if (rows.some((row) => row.width !== width || row.height !== height)) {
    throw new Error("同一集视频画幅不一致；第一版不会猜测缩放或裁切策略");
  }
  const id = stableUuid(`${key}:draft`);
  const trackId = stableUuid(`${key}:video-track`);
  const materials = {
    videos: [], audios: [], texts: [], stickers: [], video_effects: [], transitions: [], masks: [],
    chromas: [], audio_fades: [], audio_effects: [], canvases: [], speeds: [], sound_channel_mappings: [],
    vocal_separations: [], placeholder_infos: [], material_colors: [], common_mask: [],
  };
  const segments = [];
  let start = 0;
  for (const row of rows) {
    const materialId = stableUuid(`${key}:${row.clip_id}:material`);
    const segmentId = stableUuid(`${key}:${row.clip_id}:segment`);
    const companion = companions(key, row.clip_id);
    materials.speeds.push(companion.rows.speed);
    materials.placeholder_infos.push(companion.rows.placeholder);
    materials.sound_channel_mappings.push(companion.rows.channel);
    materials.vocal_separations.push(companion.rows.vocal);
    materials.canvases.push(companion.rows.canvas);
    materials.material_colors.push(companion.rows.color);
    materials.videos.push({
      id: materialId,
      path: `${PORTABLE_ROOT}/assets/video/${row.asset_name}`,
      material_name: row.asset_name,
      type: "video",
      duration: row.duration_us,
      width: row.width,
      height: row.height,
      category_id: "",
      category_name: "local",
      check_flag: 7,
      crop: { lower_left_x: 0, lower_left_y: 1, lower_right_x: 1, lower_right_y: 1, upper_left_x: 0, upper_left_y: 0, upper_right_x: 1, upper_right_y: 0 },
      has_audio: row.has_audio,
      extra_type_option: 0,
      formula_id: "",
      freeze: null,
      intensifies_audio_path: "",
      intensifies_path: "",
      is_ai_generate_content: true,
      is_copyright: false,
      is_text_edit_overdub: false,
      is_unified_beauty_mode: false,
      local_id: "",
      local_material_id: "",
      material_url: "",
      media_path: "",
      object_locked: null,
      origin_material_id: "",
      request_id: "",
      reverse_path: "",
      source_platform: 0,
      stable: { matrix_path: "", stable_level: 0, time_range: { duration: 0, start: 0 } },
      team_id: "",
      video_algorithm: { algorithms: [], deflicker: null, motion_blur_config: null, noise_reduction: null, path: "", quality_enhance: null, time_range: null },
    });
    segments.push({
      id: segmentId,
      material_id: materialId,
      raw_segment_id: trackId,
      target_timerange: { start, duration: row.duration_us },
      source_timerange: { start: 0, duration: row.duration_us },
      speed: 1,
      volume: 1,
      visible: true,
      reverse: false,
      clip: { alpha: 1, rotation: 0, scale: { x: 1, y: 1 }, transform: { x: 0, y: 0 }, flip: { horizontal: false, vertical: false } },
      render_index: 14000,
      track_render_index: 0,
      track_attribute: 0,
      extra_material_refs: companion.ids,
      common_keyframes: [],
      keyframe_refs: [],
    });
    start += row.duration_us;
  }
  const draft = {
    id,
    name,
    duration: start,
    fps: 30,
    canvas_config: { width, height, ratio: `${width}:${height}` },
    platform: { app_source: PROFILE.app_source, app_version: PROFILE.app_version, os: PROFILE.os },
    tracks: [{ id: trackId, type: "video", name: "主视频", segments, attribute: 0, flag: 0, is_default_name: false }],
    materials,
    extra_info: { created_via: "ManturHub Skill", target_profile: PROFILE.id },
  };
  return draft;
}

function validateDraft(draft, rows) {
  const track = draft.tracks.length === 1 && draft.tracks[0];
  if (!track || track.type !== "video" || track.segments.length !== rows.length) throw new Error("草稿主视频轨结构不合法");
  if (draft.materials.transitions.length || draft.materials.texts.length || draft.materials.audios.length) {
    throw new Error("草稿包含第一版禁止的转场、字幕或独立音频轨");
  }
  let cursor = 0;
  const timeline = [];
  for (let index = 0; index < rows.length; index++) {
    const segment = track.segments[index];
    const row = rows[index];
    if (segment.target_timerange.start !== cursor || segment.target_timerange.duration !== row.duration_us) {
      throw new Error(`${row.clip_id} 时间线存在间隙、重叠或时长漂移`);
    }
    timeline.push({
      clip_id: row.clip_id,
      scene_index: row.scene_index,
      clip_index: row.clip_index,
      start_us: cursor,
      duration_us: row.duration_us,
      end_us: cursor + row.duration_us,
      source_duration_us: row.duration_us,
      has_audio: row.has_audio,
    });
    cursor += row.duration_us;
  }
  if (cursor !== draft.duration) throw new Error("草稿总时长与主轨不一致");
  return timeline;
}

function writeText(path, body) {
  const target = assertProjectWritePath(path);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, body, { encoding: "utf8", flag: "wx" });
  return target;
}

function idempotencyKey(projectName, episode, rows, profile) {
  return sha256Text(JSON.stringify({
    schema: 1,
    project_name: projectName,
    episode_number: episode,
    target_profile: profile.id,
    clips: rows.map((row) => ({
      clip_id: row.clip_id,
      scene_index: row.scene_index,
      clip_index: row.clip_index,
      sha256: row.sha256,
    })),
  }));
}

function statePathFor(key) {
  return assertProjectWritePath(resolve(projectRoot(), ".pipeline-state", "jianying-drafts", `${key}.json`));
}

function reusableDelivery(key, expectedZip) {
  const statePath = statePathFor(key);
  if (!existsSync(statePath)) return null;
  const state = readJson(statePath, { object: true });
  if (state.idempotency_key !== key || resolve(state.zip_path || "") !== expectedZip) {
    throw new Error(`剪映交付幂等状态异常: ${key.slice(0, 12)}`);
  }
  if (!existsSync(expectedZip) || !lstatSync(expectedZip).isFile()) return null;
  if (sha256Media(expectedZip) !== state.zip_sha256) throw new Error("既有剪映 ZIP 哈希与幂等状态不一致，拒绝覆盖");
  return { ...state, reused: true };
}

async function buildEpisode(projectName, episode, rows, outputDir, profile) {
  const key = idempotencyKey(projectName, episode, rows, profile);
  const folderName = `manturhub-EP${String(episode).padStart(2, "0")}-${key.slice(0, 12)}`;
  const zipPath = assertProjectWritePath(resolve(outputDir, `${folderName}.zip`));
  const reusable = reusableDelivery(key, zipPath);
  if (reusable) return reusable;
  if (existsSync(zipPath)) throw new Error(`目标 ZIP 已存在但不属于可信幂等记录: ${zipPath}`);
  const staging = assertProjectWritePath(resolve(outputDir, `.manturhub-jianying-${process.pid}-${key.slice(0, 12)}`));
  if (existsSync(staging)) throw new Error(`剪映暂存目录已存在: ${staging}`);
  const packageRoot = resolve(staging, folderName);
  const assetsDir = resolve(packageRoot, "assets", "video");
  mkdirSync(assetsDir, { recursive: true });
  try {
    const staged = [];
    for (let index = 0; index < rows.length; index++) staged.push(await stageClip(rows[index], assetsDir, index));
    const draftName = `${projectName} 第${episode}集`;
    const draft = createDraft(key, draftName, staged);
    const timeline = validateDraft(draft, staged);
    const draftInfo = writeText(resolve(packageRoot, "draft_info.json"), `${JSON.stringify(draft)}\n`);
    const draftContent = writeText(resolve(packageRoot, "draft_content.json"), `${JSON.stringify(draft)}\n`);
    const actualTotalUs = staged.reduce((sum, row) => sum + row.duration_us, 0);
    const report = {
      schema_version: 1,
      ok: true,
      target_profile: profile.id,
      episode_number: episode,
      clip_count: staged.length,
      checks: {
        all_target_clips_completed: true,
        source_media_parseable: true,
        source_hashes_match: true,
        deterministic_order: "episode_number,scene_index,clip_index",
        single_video_track: true,
        contiguous_timeline: true,
        no_transitions: true,
        no_subtitles: true,
        no_bgm: true,
        source_audio_preserved: true,
      },
      actual_total_duration_us: actualTotalUs,
      timeline_total_duration_us: draft.duration,
      timeline,
    };
    const reportPath = writeText(resolve(packageRoot, "validation-report.json"), `${JSON.stringify(report, null, 2)}\n`);
    const instructions = writeText(resolve(packageRoot, "IMPORT.md"), [
      "# 剪映草稿导入说明",
      "",
      `目标版本：剪映专业版 ${profile.app_version_range}（macOS）`,
      "",
      "此 ZIP 默认不会写入剪映目录。请在目标机器安装匹配版本的剪映专业版后，",
      "由 Agent 在用户明确确认本地写入的前提下运行 ManturHub Skill 的受控导入动作。",
      "导入动作会复制全部 assets、重写本机绝对路径，并登记到草稿索引。",
      "不要手工删除 manifest.json 或 validation-report.json。剪映 6.0+ 不受支持。",
      "",
    ].join("\n"));
    const packageFiles = [draftInfo, draftContent, reportPath, instructions, ...staged.map((row) => row.staged_path)].map((path) => ({
      path: relative(packageRoot, path).replaceAll("\\", "/"),
      size_bytes: statSync(path).size,
      sha256: sha256Media(path),
    }));
    const manifest = {
      schema_version: 1,
      delivery_type: "jianying-portable-draft",
      idempotency_key: key,
      target_profile: profile.id,
      target_jianying_version: profile.app_version_range,
      target_platform: "macOS",
      draft_folder_name: folderName,
      draft_id: draft.id,
      draft_name: draft.name,
      episode_number: episode,
      clip_count: staged.length,
      actual_total_duration_us: actualTotalUs,
      timeline_total_duration_us: draft.duration,
      clips: staged.map((row) => ({
        clip_id: row.clip_id,
        episode_number: row.episode_number,
        scene_index: row.scene_index,
        clip_index: row.clip_index,
        asset_path: `assets/video/${row.asset_name}`,
        sha256: row.sha256,
        size_bytes: row.size_bytes,
        actual_duration_us: row.duration_us,
        actual_duration_seconds: row.duration_seconds,
        planned_duration_seconds: Number.isFinite(row.planned_duration_seconds) ? row.planned_duration_seconds : null,
        width: row.width,
        height: row.height,
        has_audio: row.has_audio,
      })),
      files: packageFiles,
    };
    const manifestPath = writeText(resolve(packageRoot, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
    const zipFiles = [manifestPath, ...packageFiles.map((row) => resolve(packageRoot, row.path))].map((path) => ({
      path,
      name: `${folderName}/${relative(packageRoot, path).replaceAll("\\", "/")}`,
    }));
    createStoredZip(zipPath, zipFiles);
    const zipSha = sha256Media(zipPath);
    const state = {
      schema_version: 1,
      idempotency_key: key,
      episode_number: episode,
      zip_path: zipPath,
      zip_sha256: zipSha,
      clip_count: staged.length,
      actual_total_duration_seconds: Number((actualTotalUs / 1000000).toFixed(6)),
      target_profile: profile.id,
      target_jianying_version: profile.app_version_range,
      status: "ready",
      validation_summary: `${staged.length} Clips；真实媒体可解析；主轨连续；无转场/字幕/BGM`,
      project_file_record: {
        episode_number: episode,
        draft_zip_url: null,
        draft_zip_local_file: zipPath,
        clip_count: staged.length,
        actual_total_duration_seconds: Number((actualTotalUs / 1000000).toFixed(6)),
        target_jianying_version: profile.app_version_range,
        status: "待上传/待导入验收",
        validation_summary: `${staged.length} Clips；主轨连续；素材哈希通过`,
      },
    };
    writeJson(statePathFor(key), state);
    return { ...state, reused: false };
  } catch (error) {
    if (existsSync(zipPath)) rmSync(zipPath, { force: true });
    throw error;
  } finally {
    rmSync(staging, { recursive: true, force: true });
  }
}

export async function exportJianyingDrafts(tokens) {
  const { options, positionals } = parseOptions(tokens, {
    positionals: 1,
    values: ["output-dir", "target-profile"],
  });
  const profile = requireProfile(options["target-profile"]);
  if (!options["output-dir"]) throw new Error("--output-dir is required");
  const outputDir = assertProjectWritePath(options["output-dir"]);
  mkdirSync(outputDir, { recursive: true });
  const { projectName, grouped } = parseManifest(positionals[0]);
  const deliveries = [];
  for (const [episode, rows] of [...grouped.entries()].sort((a, b) => a[0] - b[0])) {
    deliveries.push(await buildEpisode(projectName, episode, rows, outputDir, profile));
  }
  return { ok: true, delivery: "jianying-drafts", target_profile: profile.id, deliveries };
}

function replacePortablePaths(value, draftRoot) {
  if (typeof value === "string") {
    if (value === PORTABLE_ROOT) return draftRoot;
    if (value.startsWith(`${PORTABLE_ROOT}/`)) return resolve(draftRoot, value.slice(PORTABLE_ROOT.length + 1));
    return value;
  }
  if (Array.isArray(value)) return value.map((item) => replacePortablePaths(item, draftRoot));
  if (plainObject(value)) return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, replacePortablePaths(item, draftRoot)]));
  return value;
}

function findStoreKey(index) {
  for (const [key, value] of Object.entries(index)) {
    if (Array.isArray(value) && /all_draft_store|draft_store/i.test(key)) return key;
  }
  return null;
}

function draftIndexEntry(manifest, draftPath, filePath, draftsDir, nowMs) {
  return {
    draft_cover: "",
    draft_fold_path: draftPath,
    draft_id: manifest.draft_id,
    draft_is_ai_shorts: false,
    draft_is_invisible: false,
    draft_json_file: filePath,
    draft_name: manifest.draft_name,
    draft_new_version: "",
    draft_root_path: draftsDir,
    draft_timeline_materials_size: manifest.files.filter((row) => row.path.startsWith("assets/video/")).reduce((sum, row) => sum + row.size_bytes, 0),
    tm_draft_create: nowMs * 1000,
    tm_draft_modified: nowMs * 1000,
    tm_draft_removed: 0,
    tm_duration: manifest.timeline_total_duration_us,
  };
}

function prepareIndex(draftsDir, entry) {
  const indexPath = resolve(draftsDir, "root_meta_info.json");
  if (!existsSync(indexPath)) return { indexPath, previous: null, body: JSON.stringify({ all_draft_store: [entry] }) };
  if (lstatSync(indexPath).isSymbolicLink() || !lstatSync(indexPath).isFile()) throw new Error("剪映 root_meta_info.json 不是可信普通文件");
  const previous = readFileSync(indexPath, "utf8");
  let index;
  try { index = JSON.parse(previous); } catch { throw new Error("剪映 root_meta_info.json 不是可读 JSON，拒绝覆盖"); }
  if (!plainObject(index)) throw new Error("剪映 root_meta_info.json 顶层结构未知");
  const key = findStoreKey(index);
  if (!key) throw new Error("剪映 root_meta_info.json 未发现已知草稿索引字段，拒绝猜测写入");
  const rows = index[key];
  if (rows.some((row) => row?.draft_id === entry.draft_id || row?.draft_fold_path === entry.draft_fold_path)) {
    throw new Error("剪映草稿索引已存在冲突记录，拒绝覆盖");
  }
  index[key] = [...rows, entry];
  return { indexPath, previous, body: JSON.stringify(index) };
}

function verifyPackage(packageRoot, manifest) {
  if (manifest.schema_version !== 1 || manifest.delivery_type !== "jianying-portable-draft" || !Array.isArray(manifest.files)) {
    throw new Error("ZIP manifest 不是受支持的剪映便携包");
  }
  requireProfile(manifest.target_profile);
  for (const file of manifest.files) {
    if (!plainObject(file) || isAbsolute(file.path) || String(file.path).split("/").some((part) => !part || part === "." || part === "..")) {
      throw new Error("ZIP manifest 包含非法文件路径");
    }
    const target = resolve(packageRoot, file.path);
    const relation = relative(packageRoot, target);
    if (relation.startsWith("..") || !existsSync(target) || lstatSync(target).isSymbolicLink() || !lstatSync(target).isFile()) {
      throw new Error(`ZIP manifest 文件缺失或越界: ${file.path}`);
    }
    if (statSync(target).size !== file.size_bytes || sha256Media(target) !== validateSha(file.sha256, file.path)) {
      throw new Error(`ZIP manifest 文件校验失败: ${file.path}`);
    }
  }
}

export function importJianyingDraft(tokens) {
  const { options, positionals } = parseOptions(tokens, {
    positionals: 1,
    values: ["drafts-dir", "app"],
    booleans: ["confirm-write"],
  });
  if (!options["confirm-write"]) throw new Error("导入会写入用户剪映目录；必须显式提供 --confirm-write");
  const app = inspectJianyingApp(options.app);
  if (!options["drafts-dir"]) throw new Error("--drafts-dir is required");
  const draftsDir = resolve(options["drafts-dir"]);
  if (!existsSync(draftsDir) || lstatSync(draftsDir).isSymbolicLink() || !lstatSync(draftsDir).isDirectory()) {
    throw new Error("剪映草稿根目录不存在或不是可信普通目录");
  }
  if (basename(draftsDir) !== "com.lveditor.draft") throw new Error("--drafts-dir 必须指向 com.lveditor.draft 目录");
  const archive = resolve(positionals[0]);
  if (!existsSync(archive) || lstatSync(archive).isSymbolicLink() || !lstatSync(archive).isFile()) throw new Error("剪映 ZIP 不存在或不是普通文件");
  const extractRoot = resolve(draftsDir, `.manturhub-import-${process.pid}-${sha256Media(archive).slice(0, 12)}`);
  const extracted = extractStoredZip(archive, extractRoot);
  try {
    const manifests = extracted.filter((row) => row.name.endsWith("/manifest.json"));
    if (manifests.length !== 1) throw new Error("剪映 ZIP 必须恰好包含一个 manifest.json");
    const packageRoot = dirname(manifests[0].path);
    const top = relative(extractRoot, packageRoot).replaceAll("\\", "/");
    if (!top || top.includes("/")) throw new Error("剪映 ZIP 顶层目录结构不合法");
    if (extracted.some((row) => !row.name.startsWith(`${top}/`))) throw new Error("剪映 ZIP 包含顶层目录外文件");
    const manifest = readJson(manifests[0].path, { object: true });
    verifyPackage(packageRoot, manifest);
    if (manifest.target_profile !== app.profile) throw new Error("剪映 ZIP profile 与本机应用版本不一致");
    const destination = resolve(draftsDir, manifest.draft_folder_name);
    if (existsSync(destination)) {
      const existingManifest = resolve(destination, "manifest.json");
      if (existsSync(existingManifest) && readJson(existingManifest, { object: true }).idempotency_key === manifest.idempotency_key) {
        return { ok: true, reused: true, imported_path: destination, draft_id: manifest.draft_id, app };
      }
      throw new Error(`目标剪映草稿已存在，拒绝覆盖: ${destination}`);
    }
    const primary = resolve(packageRoot, PROFILE.primary_file);
    const mirror = resolve(packageRoot, "draft_content.json");
    for (const path of [primary, mirror]) {
      const rewritten = replacePortablePaths(readJson(path, { object: true }), destination);
      writeFileSync(path, `${JSON.stringify(rewritten)}\n`, "utf8");
    }
    const nowMs = Date.now();
    const entry = draftIndexEntry(manifest, destination, resolve(destination, PROFILE.primary_file), draftsDir, nowMs);
    writeFileSync(resolve(packageRoot, "draft_meta_info.json"), JSON.stringify(entry), { encoding: "utf8", flag: "wx" });
    const index = prepareIndex(draftsDir, entry);
    renameSync(packageRoot, destination);
    let backupPath = null;
    try {
      if (index.previous !== null) {
        backupPath = resolve(draftsDir, `root_meta_info.json.manturhub-backup-${manifest.idempotency_key.slice(0, 12)}`);
        writeFileSync(backupPath, index.previous, { encoding: "utf8", flag: "wx" });
      }
      const temporary = resolve(draftsDir, `.root_meta_info.${process.pid}.tmp`);
      writeFileSync(temporary, index.body, { encoding: "utf8", flag: "wx" });
      renameSync(temporary, index.indexPath);
    } catch (error) {
      rmSync(destination, { recursive: true, force: true });
      throw error;
    }
    return {
      ok: true,
      reused: false,
      imported_path: destination,
      draft_id: manifest.draft_id,
      root_index_backup: backupPath,
      app,
    };
  } finally {
    rmSync(extractRoot, { recursive: true, force: true });
  }
}
