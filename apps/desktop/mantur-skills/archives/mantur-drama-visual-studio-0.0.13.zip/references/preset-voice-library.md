# 预制音色库与角色绑定合同

包内 `voice-library/catalog.json` 是机器可读来源。目录保存不可变、永久公开的 ManturHub 音频资产，不是临时上传链接集合。项目接受一条音色后仍要下载到本地缓存并校验，远端 URL 只用于算子请求。

免费仅指复用包内预制音色库中的现有音频，不代表定制音色、额外语音合成或视频生成免费；这些算子调用仍须按实际请求实时报价并取得费用批准。

## 优先级与所有权

1. 用户明确提供且唯一匹配的音色始终最高优先。存在相关用户音频时，先完成身份、媒体和质量分析，并按 [本地用户音频的审核与绑定](asset-operations.md#本地用户音频的审核与绑定) 立即写入基础角色绑定或可播放待试听状态；不能只盘点图片、只看到文件名就跳到预制音色，或只把音频留在聊天附件中。
2. 只有项目策略允许时才使用预制音色自动匹配。
3. 用户明确要求定制音色时，新 OpenAPI 先仅对 `op.voice.design` 校验、报价并取得批准。返回的 `previewAudio` 经媒体校验后立即接入；唯一身份和可靠质量分析全部通过时自动就绪，否则保留可播放待试听状态，由用户在看板试听后通过聊天确认。不默认追加 `op.audio.generate`。确实需要额外参考音频时才独立报价并获批；使用其声明的 text_prompt/reference_audio_url 合同，不传未声明的 voice_id。legacy 设计/合成流程只在对应合同预检通过后使用；具体动作见 [素材操作合同](asset-operations.md)。
4. AI 直出只在项目事先允许且没有用户、预制或定制音色时使用。

Provider 失败不得自动改变顺序。保持角色 `review_required` 或 `unresolved`，暴露真实错误并等待聊天决策。

资产提取后，如果当前角色没有可直接采用的用户音频，并且需要用户在预制匹配与定制路线之间作选择，聊天中固定展示“音色库”和“定制角色声音”两项。音色库的对用户解释固定为“从预制音色库为角色匹配声音，预制音色免费”；免费说明不得放进选项名称。不得把 `op.voice.design`、provider 或其他内部路线值展示给普通用户，也不得因为该后缀跳过预制音频的匹配、媒体、质量和试听审核。定制路线仍按实时报价与费用批准执行，选择失败也不自动改走另一项。

用户音频处理范围是当前制作角色及准备采用的候选，不要求将 `voice_directories` 中每个无关、备用或未选文件全部接入库存或逐一拒绝。是否能离开素材阶段看当前必需基础角色的有效绑定、明确直出或无需参考策略，不看目录文件是否全量对账。

## 角色声线结构

匹配前将资产提取结果规范为至少以下结构：

```json
{
  "asset_id": "CHAR-001",
  "canonical_name": "Example",
  "gender": "female",
  "age_range": "young-adult",
  "voice_presentation": "女声",
  "age_feel": "青年感",
  "pitch_band": "中音",
  "timbre_tags": ["清亮干练"],
  "expression_tags": ["冷静沉稳"],
  "role_tags": ["女主", "白领"],
  "voice_description": "青年女性，中音，清亮干练，语速稳定",
  "personality": "理性、克制"
}
```

自动匹配前 `voice_presentation` 与 `age_feel` 必须已知。不得根据姓名、文件名、服装或角色物种猜测性别。`童声` 只用于确实需要儿童声音的角色，不用于性格活泼的成人。

## 确定性匹配

运行：

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" match-voice character-voice-profile.json --reserved-voice-id M001 --output .pipeline-state/results/voice-match.json
```

把已被其他具名角色占用的预制音色通过重复 `--reserved-voice-id` 传入。只有用户允许群众或一次性角色复用时才使用 `--allow-reuse`。同一 canonical character 的普通视觉变体传 `--existing-voice-id`，锁定声音身份而不是重新匹配。

候选评分可以并行，但最终分配必须按角色重要度执行确定性全局提交。每提交一个角色，就把占用音色传给后续角色。两个主要角色竞争同一音色时，保留高优先级分配，另一个重新评估或进入人工试听；不得接受并发写入中先完成的随机结果。

只有 `status=matched` 或 `matched_locked_identity` 才形成唯一身份候选；选中对象必须同时携带 catalog 中的 `voice_id`、`asset_id`、`public_url` 和 `sha256`。身份唯一后仍须通过与用户音频相同的媒体及质量门禁，才能写入最终 `matched/passed` 绑定；否则以 `review_required/pending` 携带本地音频供看板试听。`review_required` 暴露候选及原因；`unresolved/no_candidate` 保持未绑定。低分差、声线资料缺失、inactive、reserved 冲突或标记为待试听的目录项不得自动选择。

## URL 与完整性门禁

每次首次引用某个目录音色前验证：

- `active=true` 且 `asset_id` 非空；
- public URL 为 HTTPS、没有 query、支持匿名 GET 或 Range；
- MIME 为 `audio/mpeg`，实际内容 SHA-256 与 catalog 一致；
- 实际时长至少两秒；
- 保存 `catalog_version`、`match_policy_version`、voice ID、asset ID、checksum 和匹配原因。

不得用私有上传 URL 或看似长期有效的签名 URL 替换 catalog URL。预制音色是不可变资产；音频内容变化必须使用新对象键、checksum 和 catalog 版本。

绑定接受后，将音频下载到项目缓存，验证其位于项目内、为普通非空文件、MIME/时长/SHA-256 有效，再更新 `.pipeline-state/asset-inventory.json` 和资产匹配结果。项目内记录保存本地相对路径；永久 URL 只保留在 Runtime 权威文件中。Snapshot Compiler 不得把该 URL、签名参数或上游标识发布到只读快照。

## Seedance 引用

每个由该角色说话的 Clip，提示词必须在说话人旁包含对应 `@AudioN`；同一请求的 `metadata.content` 必须以相同顺序包含该永久 URL 的 `reference_audio`。`@AudioN` 编号按 content 中 `audio_url` 项出现顺序生成。已绑定预制音色不得继续出现在 `missing_voice_assets`，也不得标记为 `ai_direct_voices`。

用户或定制音色也遵守同一本地完整性与引用合同。只有 `voice_id` 没有可播放音频 URL 时不能进入 Seedance 请求。

## 定制音色与 AI 直出

新 OpenAPI 定制声音先仅执行 `op.voice.design` 的实时校验、试算及费用批准；返回 voiceProfile 和 previewAudio 后，合规试听素材按统一自动质量门禁或用户聊天确认完成审核即可绑定，不再统一要求第二次音频生成。追加参考音频需独立批准，按 text_prompt/reference_audio_url 合同执行；固定 voice_id 合成没有依据继续阻断。legacy 保留其已核验的原流程。参见 [素材操作合同](asset-operations.md)。失败不得静默转成预制音色或 AI 直出。

新 `apply-asset-review` 保留基础角色 ID、候选 SHA、明确审核证据和旧记录基线。预制音频必须匹配包内 active 目录身份及 SHA；人工或自动质量通过都不能使错误目录身份有效。自动通过记录不得伪造 `user_confirmed`，并须将六项结构化质量检查绑定当前 SHA。服装变体共享基础 ID 的音色，其他主要角色占用冲突仍拒绝。待审核音色允许在看板试听，但不计为已就绪。

只有项目预先允许 AI 直出且没有安全绑定时，才把角色写为 `ai_direct`；不创建 `@AudioN/reference_audio`，请求保持 `generate_audio=true`，并记录采用该策略的原因。

## 声音状态变体

服装、地点、情绪以及普通表情或姿势变化不创建新音色。只有剧本明确出现童年/成年、衰老、变身、电子处理或刻意变声等声音状态切换时，才能建立音色变体。记录事件、集数和证据行，独立匹配或生成，同时保持与 canonical character 的关联。
