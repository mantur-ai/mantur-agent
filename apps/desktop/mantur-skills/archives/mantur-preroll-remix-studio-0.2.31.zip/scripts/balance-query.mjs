// The public CLI balance command returns native Mantur points in totalBalance.
// This is a query receipt, not a continuously verified account identity contract.
const invalid = () => Object.assign(new Error('余额查询结果无法核实。'), { code: 'BALANCE_QUERY_INVALID_RESPONSE' });
const failure = code => Object.assign(new Error('余额查询未完成，请重新查询。'), { code });

function amount(value) {
  if (typeof value === 'string' && /^-?(?:0|[1-9]\d*)(?:\.\d+)?$/.test(value)) value = Number(value);
  if (typeof value !== 'number' || !Number.isFinite(value) || Math.abs(value) > Number.MAX_SAFE_INTEGER) throw invalid();
  return value;
}

/** Strip identity, URLs, converted currency and provider diagnostics at the boundary. */
export function parseBalanceQueryResult(result) {
  if (result?.canceled) throw failure('BALANCE_QUERY_CANCELED');
  if (result?.code !== 0) throw failure('BALANCE_QUERY_FAILED');
  if (typeof result.stdout !== 'string' || Buffer.byteLength(result.stdout) > 65536) throw invalid();
  let value;
  try { value = JSON.parse(result.stdout); } catch { throw invalid(); }
  return normalizeBalanceQuery(value);
}

export function normalizeBalanceQuery(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || value.success === false || value.error
    || value.code !== undefined && value.code !== 0
    || value.unit !== undefined && value.unit !== '馒头') throw invalid();
  const receipt = { totalBalance: amount(value.totalBalance), unit: '馒头' };
  for (const key of ['giftBalance', 'rechargeBalance']) if (Object.hasOwn(value, key)) receipt[key] = amount(value[key]);
  return receipt;
}
