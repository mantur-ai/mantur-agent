import {check} from './project.mjs';

const resolutions=new Map([['480p',480],['720p',720],['1080p',1080]]);
const standardRatios=new Set(['16:9','9:16','4:3','3:4','1:1','21:9']);
const positive=value=>Number.isInteger(value)&&value>0;
const gcd=(a,b)=>b?gcd(b,a%b):a;
const nonempty=value=>typeof value==='string'&&value.trim();

function nativeSize(ratio,resolution) {
  const side=resolutions.get(resolution),match=/^(\d+):(\d+)$/.exec(ratio);
  if(!side||!match)return null;
  const x=Number(match[1]),y=Number(match[2]);if(!positive(x)||!positive(y))return null;
  const scale=side/Math.min(x,y),width=x*scale,height=y*scale;
  return positive(width)&&positive(height)&&width%2===0&&height%2===0?{width,height}:null;
}

function bodyGeometry(p,scope) {
  const episodes=p.assets.filter(a=>a.role==='episode');
  let selected;
  if(scope!==undefined){
    check(Array.isArray(scope)&&scope.length>0&&scope.every(positive)&&new Set(scope).size===scope.length,'FRONT_BODY_EPISODES_INVALID','正片范围需要不同的正整数集号。');
    selected=scope.map(episode=>{const asset=episodes.find(a=>a.episode===episode);check(asset,'FRONT_BODY_EPISODES_MISSING',`缺少用于匹配前贴尺寸的第 ${episode} 集。`);return asset;});
  }else selected=[...episodes].sort((a,b)=>a.episode-b.episode);
  const dimensions=selected.map(a=>({width:a.displayWidth??a.width,height:a.displayHeight??a.height,known:a.displayGeometryKnown!==false}));
  const known=dimensions.length>0&&dimensions.every(d=>d.known&&positive(d.width)&&positive(d.height));
  const same=known&&dimensions.every(d=>d.width===dimensions[0].width&&d.height===dimensions[0].height);
  return {bodyEpisodes:selected.map(a=>a.episode),bodyWidth:same?dimensions[0].width:null,bodyHeight:same?dimensions[0].height:null,known,same};
}

/** Resolve Skill defaults before network access; reference media never sets the target. */
export function resolveFrontSizes(p,spec) {
  return spec.items.map(item=>{
    const body=bodyGeometry(p,item.bodyEpisodes!==undefined?item.bodyEpisodes:spec.bodyEpisodes);
    const decision=item.sizeDecision!==undefined?item.sizeDecision:spec.sizeDecision;
    if(decision!==undefined)check(decision&&decision.mode==='custom'&&nonempty(decision.note),'FRONT_SIZE_DECISION_INVALID','自定义前贴尺寸需要记录用户明确覆盖或适配的决定。');
    const custom=decision!==undefined;
    let ratio,resolution;
    if(custom){
      check(nonempty(item.input.ratio)&&nonempty(item.input.resolution),'FRONT_SIZE_CUSTOM_FIELDS_REQUIRED','自定义前贴尺寸必须同时明确 ratio 和 resolution。');
      ratio=item.input.ratio;resolution=item.input.resolution;
    }else{
      check(body.known,'FRONT_BODY_DIMENSIONS_REQUIRED','正片显示尺寸缺失或无法精确确定，请核对素材，或明确选择自定义前贴比例和分辨率。');
      check(body.same,'FRONT_BODY_DIMENSIONS_MIXED','所选正片尺寸不一致，请明确正片范围，或选择自定义前贴比例和分辨率。');
      const divisor=gcd(body.bodyWidth,body.bodyHeight);ratio=`${body.bodyWidth/divisor}:${body.bodyHeight/divisor}`;
      resolution=[...resolutions].find(([,side])=>side===Math.min(body.bodyWidth,body.bodyHeight))?.[0];
      const native=resolution&&nativeSize(ratio,resolution);
      check(standardRatios.has(ratio)&&native&&native.width===body.bodyWidth&&native.height===body.bodyHeight,
        'FRONT_SIZE_PROFILE_UNSUPPORTED','正片尺寸不能精确映射到支持的原生生成档位，请明确可用比例、分辨率和适配决定。');
      check((item.input.ratio===undefined||item.input.ratio===ratio)&&(item.input.resolution===undefined||item.input.resolution===resolution),
        'FRONT_SIZE_DECISION_REQUIRED','输入的前贴比例或分辨率与正片不同，请先记录用户明确覆盖的决定。');
    }
    const expected=nativeSize(ratio,resolution);
    return {input:{ratio,resolution},metadata:{policy:custom?'custom':'follow_body',bodyEpisodes:body.bodyEpisodes,
      bodyWidth:body.bodyWidth,bodyHeight:body.bodyHeight,ratio,resolution,expectedWidth:expected?.width??null,expectedHeight:expected?.height??null,
      confirmationNote:custom?decision.note.trim():null}};
  });
}

/** Intersect the public common enum with the selected model's current branch. */
export function validateFrontSizeModel(input,model,detail) {
  const schema=detail?.inputSchema||{},properties=schema.properties||{};
  if(Array.isArray(properties.model?.enum))check(properties.model.enum.includes(model),'FRONT_SIZE_MODEL_UNSUPPORTED','当前公开算子不支持所选模型。');
  const branches=(schema.allOf||[]).filter(branch=>{
    const condition=branch.if?.properties?.model;
    return condition?.const===model||Array.isArray(condition?.enum)&&condition.enum.includes(model);
  }).map(branch=>branch.then?.properties||{});
  for(const key of ['ratio','resolution'])for(const source of [properties,...branches]){
    const enumValues=source[key]?.enum;
    if(Array.isArray(enumValues))check(enumValues.includes(input[key]),'FRONT_SIZE_MODEL_UNSUPPORTED',`所选模型当前不支持前贴 ${key}=${input[key]}，请依据公开合同调整。`);
  }
}
