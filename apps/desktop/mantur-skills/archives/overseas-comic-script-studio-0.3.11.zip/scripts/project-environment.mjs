// Optional planner integration for explicit-test-v1 packages; contains no business state migrations.
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { context } from './access.mjs';
import { environmentIdentity, environmentDigest, projectEnvironment } from './test-mode.mjs';
export function prepareProjectAccess(project, env = process.env) {
  const profile = JSON.parse(readFileSync(new URL('./access-profile.json', import.meta.url), 'utf8'));
  const identity = environmentIdentity(profile, context(profile, env));
  projectEnvironment(project, identity, { commit: true, packageRoot: fileURLToPath(new URL('../', import.meta.url)) });
  return ['--project', project, '--environment-binding', environmentDigest(identity)];
}
