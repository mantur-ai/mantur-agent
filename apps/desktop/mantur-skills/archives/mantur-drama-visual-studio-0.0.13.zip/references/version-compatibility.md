# 版本兼容性

| 组件 | 要求 | 合同 |
|---|---:|---|
| Skill | `mantur-drama-visual-studio@1.0.5` | 独立安装、包内 Compiler 与只读服务、本地权威状态 |
| Node.js | `>=18.20.8` | 运行已打包 `.mjs`，安装后无需 npm；保留 Node 20/22 兼容 |
| ManturHub CLI | 显式 Key：稳定版 `>=0.10.0` 或精确 `0.9.10-dev.20260810.9`；浏览器登录复用：稳定版 `>=1.2.5` 且能力探测通过 | 仅生产/远端诊断需要；未知预发布版和认证私有接口漂移阻断 |
| `op.drama.asset-extract` | `>=v2.3.0` 且兼容 | 完整剧本单个 `input_file`、严格 JSON Schema |
| `op.drama.clip-seedance-compile` | `>=v2.3.3` 且兼容 | 完整剧本与资产清单两个 `input_file.file_data`、固定状态与时长审计 |
| `op.image.generate` | live 兼容 schema | Agent 无原生生图能力时使用，执行前实时报价 |
| `op.video.understand-v2` | live 兼容 schema | 分析参考图中的角色、服装、环境与画风；以实时字段为准 |
| `op.voice.design` | live 兼容 schema | 定制角色音色并保留后续复用所需的音色引用 |
| `op.audio.generate` | live 兼容 schema | 确需额外参考音频时独立预检、报价和批准；合规 previewAudio 可直接审核复用 |
| `op.video.generate` | live 兼容 schema | Seedance 参数、参考媒体、音色和官方尾帧 |
| Snapshot | `mantur.drama.ui-snapshot/v1` | 完整 Envelope、revision、ETag、脱敏字段 |
| Local protocol | `mantur.drama.local/v1` | Manifest、权威文件、媒体完整性和兼容适配器 |
| JianYing profile | `jianying-windows-portable-v2` / `jianying-macos-portable-v2` | 5.9.0 生成格式与应用版本分开；本机自动安装，跨平台只打包；应用验收另记 |

更高算子版本只在 live schema 仍满足当前必需字段时兼容。缺字段、未知状态或供应商变化必须预检失败，不得猜测、静默降级或更换 provider。

legacy 与新 OpenAPI 都不比较算子业务版本、`apiVersion`、打包指纹或 checker 版本。实时 inputSchema/outputSchema 必须可编译，实际请求与结果在动作边界按实时／提交时 Schema 校验。资产提取、四类素材及 Seedance/WAN 分镜按各自阶段合同与预检开放；Seedance/WAN 视频在所有合法锁定站点按实时合同、模型和技术门禁准备和提交，不再以平台额度是否独立核实区分正式站与开发站。WAN 按用户授权允许 wan3.0-video 报价与获批提交；费用批准、请求一致性与实际尾帧校验保持有效，平台实测状态另行记录。固定 voice_id 合成、缺少取链合同的 fileId-only 结果、实际请求／结果不符合 Schema 及未知响应继续阻断。具体资产、参数、清单确认和费用批准另行校验，阶段 doctor 的 ok=true 才允许继续；workflow_ready=false 必须停止提交。代码就绪不代表真实付费或部署验收。详见 [公共预检](manturhub-preflight.md)、[模型门禁](video-models.md)和[视频合同](video-generation.md)。不自动迁移旧项目站点；旧包 Schema 不认识开发网关，读取须用新包。

Node 18 已停止官方维护，仅作为旧环境兼容下限，不建议新装环境使用。优先使用仍受维护的 Node.js LTS。低于最低版本或预发布版本，统一入口在执行动作前返回 `NODE_VERSION_UNSUPPORTED`；升级运行时后重试同一命令，不修改生产事实或重新提交远端任务。

此要求针对安装包运行，不代表仓库开发依赖均支持 Node 18。开发构建和 Playwright 使用 Node 22；运行产物以 `node18` 为构建目标。兼容测试须在 Node 18.20.8、20.19.0 和当前 Node 22 下运行同一份产物，包括假 CLI 与隔离安装；不因版本声明代替实际测试。ManturHub CLI 还须满足自身 Node 要求，升级 CLI 后需要重新核对。

不同 Agent 宿主可能通过 `NODE_OPTIONS` 注入安全或语言 shim。Skill 的包内 Compiler 与只读服务不需要该注入，启动前会隔离 `NODE_OPTIONS`／`NODE_PATH`；ManturHub CLI 属于外部平台边界，继续继承宿主安全 Hook。Skill 不通过清空外部 CLI 环境规避宿主安全策略；宿主 Hook 自行派生的窗口、进程或兼容问题仍须在对应宿主实测和修复。
