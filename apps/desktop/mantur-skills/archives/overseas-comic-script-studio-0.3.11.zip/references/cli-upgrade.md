# CLI 检查后的用户提示

只在需要实际调用而执行环境检查时使用本页。单纯咨询、设置帮助、读取报告或制作本地看板不额外检查 CLI。检查结果仍须在对话中用普通语言告诉用户，不能只留在工具 JSON 中。

## 根据结果提示

- `UPDATE_AVAILABLE`：“当前 CLI 是 {currentVersion}，检测到新版 {latestVersion}。建议升级到最新正式版，命令如下。”展示下面的命令；Node 要求只引用本次返回的 nodeRequirement 和包内兼容要求，不猜测。
- `UP_TO_DATE`：“已检查 CLI {currentVersion}，按本次检查结果无需升级。”首次检查时仍可附一句“以后更新可使用下面的命令”。本地版本比 latest 高时不要降级或声称它等于 latest。
- `CHECK_UNAVAILABLE` / `DISABLED`：“当前 CLI {currentVersion} 满足本技能要求；这次未能确认最新版本。需要更新时可使用下面的命令。”不能把查询失败当成过旧，也不阻断兼容版本。
- `REGISTRY_BELOW_MINIMUM`：说明 registry 的 latest 低于技能最低要求，暂不执行更新，保留可用本地版本；不能引导安装已知不兼容的版本。
- `PINNED_PROFILE` 或检查没有返回 `cliUpdate`：环境检查已通过且实际 CLI 版本满足下限时，说明“已检查 CLI {currentVersion}，符合本技能 1.2.10 或更高版本的要求”。首次检查附下面的指定版本命令供后续安装/升级使用；不把“符合要求”说成“已是最新版”，不要求兼容的高版本降级。
- CLI 缺失或低于最低要求：说明“这个技能需要 CLI 1.2.10 或更高版本。当前未安装或版本不足，请先用下面的命令安装或升级，完成后我会重新检查并继续当前任务。”展示以下指定版本命令；版本已满足要求时不要求降级或重复安装：

```bash
npm install -g @manturhub/cli@1.2.10 --include=optional --engine-strict --registry=https://registry.npmjs.org
```

指定版本尚未发布、registry 查不到该版本或安装失败时，说明“所需版本暂未可用，请等待发布后再继续”，停止业务调用，不回退到不满足要求的 latest 或旧版本，不编造安装成功。

已有兼容 CLI、希望更新到最新正式版时，默认 npm 全局安装的命令如下。缺失或低于下限时优先展示上面的指定版本命令，不同时给两条命令让用户猜选：

```bash
npm install -g @manturhub/cli@latest --include=optional --engine-strict --registry=https://registry.npmjs.org
```

Windows 使用 `npm.cmd`；check 返回 `upgradeInstructions.command/args` 时以其为准，参数逐项传递，不拼接未经转义的 shell 字符串。命令必须展示在对话代码块中，不让用户自行翻工具输出。只建议更新，不擅自执行；用户已经明确授权升级时不重复索取批准。

## 安装归属与续接

执行全局升级前，在同一 Node/npm 环境执行 `npm root -g`，核对其结果与 `upgradeInstructions.verifyGlobalRoot` 及原 cliPath 对应。显式绑定或非全局安装不能直接套用全局命令：明确上面的命令仅适用于默认全局安装，先确认原安装方式，再给该方式的具体命令；不能安装另一个副本假装原入口已升级。连接器由宿主升级，不引导普通终端修改宿主 CLI。

升级完成重新执行同一环境 check，保持原 CLI 路径、配置目录、站点、bindingArgs/bindingEnv 及业务身份。未完成任务仍按原回执恢复，不改账号，不重新发起任务。CLI 升级许可不等于算子费用或制作许可。

同一会话、同一 CLI 路径与同一检查结果只完整展示一次升级命令；切换技能沿用已展示提示。再次检查时简短同步结果即可；发现不同版本、入口变化、先前漏给命令或用户询问升级时再展示。不要在每次算子调用前重复这段提示。
