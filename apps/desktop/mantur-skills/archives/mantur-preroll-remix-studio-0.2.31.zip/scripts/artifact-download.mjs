// Public media transfer only. Never attach credentials or authenticate a request.
import { request as httpsRequest } from 'node:https';
import { lookup } from 'node:dns/promises';
import { BlockList, isIP } from 'node:net';
import { lstat, mkdir, open, realpath, rename, rm } from 'node:fs/promises';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';

const fail = code => Object.assign(new Error(code), { code });
const blocked = new BlockList();
for (const [address, prefix] of [['0.0.0.0',8],['10.0.0.0',8],['100.64.0.0',10],['127.0.0.0',8],
  ['169.254.0.0',16],['172.16.0.0',12],['192.0.0.0',24],['192.0.2.0',24],['192.88.99.0',24],
  ['192.168.0.0',16],['198.18.0.0',15],['198.51.100.0',24],['203.0.113.0',24],['224.0.0.0',4],['240.0.0.0',4]])
  blocked.addSubnet(address,prefix,'ipv4');
for (const [address,prefix] of [['2001::',23],['2001:db8::',32],['2002::',16],['3fff::',20]])
  blocked.addSubnet(address,prefix,'ipv6');
const globalV6 = new BlockList(); globalV6.addSubnet('2000::',3,'ipv6');
export function isPublicArtifactAddress(address) {
  if(typeof address!=='string')return false;
  const family=isIP(address);
  return family===4 ? !blocked.check(address,'ipv4')
    : family===6 && globalV6.check(address,'ipv6') && !blocked.check(address,'ipv6');
}

// This is a package-maintained trust declaration, never a user URL/CIDR override.
export function validateArtifactOrigins(origins) {
  if(!Array.isArray(origins)||origins.length>16)throw fail('ARTIFACT_ORIGIN_REJECTED');
  const checked=origins.map(value=>{
    let url;try{url=new URL(value);}catch{throw fail('ARTIFACT_ORIGIN_REJECTED');}
    const host=url.hostname;
    if(typeof value!=='string'||value!==url.origin||url.protocol!=='https:'||url.port
      ||isIP(host.replace(/^\[|\]$/g,''))||host.length>253||!host.includes('.')
      ||host.split('.').some(label=>!(/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label)))
      ||/(^|\.)(localhost|local|localdomain|internal)$/.test(host))throw fail('ARTIFACT_ORIGIN_REJECTED');
    return value;
  });
  if(new Set(checked).size!==checked.length)throw fail('ARTIFACT_ORIGIN_REJECTED');
  return Object.freeze(checked);
}

// Only package-approved origins may resolve through an RFC1918 tunnel/private
// route. Hostname TLS verification still applies. Other special-use ranges,
// including loopback, link-local metadata, CGNAT and IPv6 ULA, remain forbidden.
const privateV4=new BlockList();
for(const [address,prefix] of [['10.0.0.0',8],['172.16.0.0',12],['192.168.0.0',16]])privateV4.addSubnet(address,prefix,'ipv4');

function mediaUrl(value) {
  if(typeof value!=='string'||value.length>16384||value.trim()!==value||/[\x00-\x20\x7f\\#]/.test(value)
    ||!/^https:\/\//i.test(value)||value.match(/^https:\/\/([^/?#]*)/i)?.[1].includes('@'))throw fail('ARTIFACT_URL_REJECTED');
  let url;try{url=new URL(value);}catch{throw fail('ARTIFACT_URL_REJECTED');}
  if(url.protocol!=='https:'||url.username||url.password||url.hash||url.port==='0')throw fail('ARTIFACT_URL_REJECTED');
  return url;
}

async function safeTarget(projectDir,target) {
  if(!isAbsolute(projectDir||'')||!isAbsolute(target||''))throw fail('ARTIFACT_PATH_REJECTED');
  const root=await realpath(projectDir),part=relative(resolve(projectDir),resolve(target));
  if(!part||part==='..'||part.startsWith('..'+sep)||isAbsolute(part))throw fail('ARTIFACT_PATH_REJECTED');
  const selected=join(root,part),parts=part.split(sep);let cursor=root;
  for(let index=0;index<parts.length;index++){
    cursor=join(cursor,parts[index]);
    let fact;try{fact=await lstat(cursor);}catch(error){if(error.code!=='ENOENT')throw error;}
    const last=index===parts.length-1;
    if(fact&&(fact.isSymbolicLink()||!(last?fact.isFile():fact.isDirectory())))throw fail('ARTIFACT_PATH_REJECTED');
    if(!fact&&!last){try{await mkdir(cursor);}catch(error){if(error.code!=='EEXIST')throw error;}
      const created=await lstat(cursor);if(!created.isDirectory()||created.isSymbolicLink())throw fail('ARTIFACT_PATH_REJECTED');}
  }
  if(await realpath(dirname(selected))!==dirname(selected))throw fail('ARTIFACT_PATH_REJECTED');
  return selected;
}

function abortable(promise,signal) {
  return new Promise((resolveValue,reject)=>{
    const abort=()=>reject(fail(signal.reason?.code==='ARTIFACT_DOWNLOAD_CANCELED'?'ARTIFACT_DOWNLOAD_CANCELED':'ARTIFACT_DOWNLOAD_TIMEOUT'));
    if(signal.aborted){abort();return;}
    signal.addEventListener('abort',abort,{once:true});
    Promise.resolve(promise).then(resolveValue,reject).finally(()=>signal.removeEventListener('abort',abort));
  });
}

// Dependency injection is for framework tests. The packaged caller uses the fixed
// production instance below and exposes no transport, DNS or security overrides.
export function createArtifactDownloader({ resolveHost=lookup, request=httpsRequest, trustedOrigins=[],
  maxBytes=4*1024*1024*1024, timeoutMs=1_800_000 }={}) {
  if(!Number.isSafeInteger(maxBytes)||maxBytes<=0||!Number.isSafeInteger(timeoutMs)||timeoutMs<=0)throw fail('ARTIFACT_DOWNLOAD_LIMIT_INVALID');
  const trusted=new Set(validateArtifactOrigins(trustedOrigins));
  return async function downloadArtifact(value,target,{projectDir,signal}={}) {
    if(signal?.aborted)throw fail('ARTIFACT_DOWNLOAD_CANCELED');
    const controller=new AbortController();
    const cancel=()=>controller.abort(fail('ARTIFACT_DOWNLOAD_CANCELED'));
    signal?.addEventListener('abort',cancel,{once:true});
    const timer=setTimeout(()=>controller.abort(fail('ARTIFACT_DOWNLOAD_TIMEOUT')),timeoutMs);timer.unref?.();
    let temporary,handle,response,activeRequest,requestStopped=false;
    const stopTransport=()=>{
      if(!requestStopped){requestStopped=true;activeRequest?.destroy?.();}
      response?.destroy();
    };
    controller.signal.addEventListener('abort',stopTransport,{once:true});
    const throwIfAborted=()=>{if(controller.signal.aborted)throw controller.signal.reason;};
    try{
      if(signal?.aborted)cancel();throwIfAborted();
      const url=mediaUrl(value),host=url.hostname.replace(/^\[|\]$/g,'');
      const destination=await safeTarget(projectDir,target);
      throwIfAborted();
      const literal=isIP(host);
      const records=literal?[{address:host,family:literal}]:await abortable(resolveHost(host,{all:true,verbatim:true}),controller.signal);
      const trustedOrigin=trusted.has(url.origin);
      const allowedAddress=address=>isPublicArtifactAddress(address)||(trustedOrigin&&typeof address==='string'&&isIP(address)===4&&privateV4.check(address,'ipv4'));
      if(!Array.isArray(records)||!records.length||records.some(item=>!item||!allowedAddress(item.address)
        ||isIP(item.address)!==item.family))throw fail('ARTIFACT_ADDRESS_REJECTED');
      throwIfAborted();
      const pinned=Object.freeze({address:records[0].address,family:records[0].family});
      temporary=join(dirname(destination),`.artifact-${randomUUID()}.partial`);
      handle=await open(temporary,'wx',0o600);
      await safeTarget(projectDir,temporary);
      throwIfAborted();
      response=await abortable(new Promise((resolveResponse,reject)=>{
        const req=activeRequest=request(url,{method:'GET',agent:false,signal:controller.signal,family:pinned.family,autoSelectFamily:false,
          rejectUnauthorized:true,...(trustedOrigin?{servername:host}:{}),
          headers:{Accept:'application/octet-stream'},lookup:(_host,options,callback)=>options?.all
            ?callback(null,[{...pinned}]):callback(null,pinned.address,pinned.family)},resolveResponse);
        req.once('error',reject);req.end();
      }),controller.signal);
      if(response.statusCode!==200)throw fail(response.statusCode>=300&&response.statusCode<400?'ARTIFACT_REDIRECT_REJECTED':'ARTIFACT_HTTP_REJECTED');
      const raw=response.headers['content-length'];
      if(raw!==undefined&&(typeof raw!=='string'||!/^\d+$/.test(raw)||!Number.isSafeInteger(Number(raw))))throw fail('ARTIFACT_LENGTH_INVALID');
      const expected=raw===undefined?undefined:Number(raw);
      if(expected>maxBytes)throw fail('ARTIFACT_TOO_LARGE');
      const hash=createHash('sha256');let size=0;
      const digest=new Transform({transform(chunk,_encoding,done){
        size+=chunk.length;if(size>maxBytes){done(fail('ARTIFACT_TOO_LARGE'));return;}
        hash.update(chunk);done(null,chunk);
      }});
      await pipeline(response,digest,handle.createWriteStream(),{signal:controller.signal});
      handle=undefined;
      if(!size)throw fail('ARTIFACT_EMPTY');
      if(expected!==undefined&&size!==expected)throw fail('ARTIFACT_LENGTH_MISMATCH');
      await safeTarget(projectDir,destination);
      throwIfAborted();
      await rename(temporary,destination);temporary=undefined;
      return {sha256:hash.digest('hex'),size};
    }catch(error){
      if(controller.signal.aborted)throw fail(controller.signal.reason?.code==='ARTIFACT_DOWNLOAD_CANCELED'?'ARTIFACT_DOWNLOAD_CANCELED':'ARTIFACT_DOWNLOAD_TIMEOUT');
      throw fail(/^ARTIFACT_[A-Z_]+$/.test(error.code||'')?error.code:'ARTIFACT_DOWNLOAD_FAILED');
    }finally{
      clearTimeout(timer);signal?.removeEventListener('abort',cancel);
      controller.signal.removeEventListener('abort',stopTransport);stopTransport();await handle?.close().catch(()=>{});
      if(temporary)await rm(temporary,{force:true});
    }
  };
}

export const downloadArtifact=createArtifactDownloader();
