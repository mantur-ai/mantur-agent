// Presentation only: never alter stored receipts, narrative facts, IDs or script text.
import { characterNames } from './presentation.mjs';
const labels = {
  name: '项目名称', mode: '创作模式', brief: '创作要求', targetMarket: '目标市场', languagePlan: '语言计划',
  sourceScope: '源稿范围（用户确认）', sourceInspection: '本地源稿检查', label: '范围名称', limitations: '未覆盖内容与限制',
  textUnits: 'UTF-16 字符单元数', lineCount: '文本行数', bytes: '字节数', sha256: '内容 SHA256', range: '原文行范围', startLine: '起始行（含）', endLine: '结束行（含）',
  workingLanguage: '工作稿语言', targetLanguage: '成品语言', outputLanguage: '稿件语言', carrier: '载体',
  episodeCount: '集数', targetWordsMin: '工作稿目标下限', targetWordsMax: '工作稿目标上限', deliveryWordsMin: '成品目标下限', deliveryWordsMax: '成品目标上限',
  concepts: '创意方案', id: '标识', title: '标题', logline: '一句话故事', synopsis: '故事梗概',
  episodeArc: '逐集弧线（episodeArc）', episode: '集号', episodeNumber: '集号', protagonistAction: '主角行动', visibleConsequence: '可见后果', emotionalTurn: '情绪转折',
  characters: '人物', locations: '场景', props: '道具', canonicalName: '锁定名称', displayName: '展示名', goal: '目标', motivation: '动机', relationships: '关系', rules: '规则',
  openingHook: '开场钩子', cliffhanger: '结尾悬念', hook: '钩子', payoff: '兑现', beats: '情节拍点', episodeBeats: '逐集拍单', units: '叙事单元',
  foreshadowLedger: '伏笔台账', readthroughReport: '通读检查', sourceDecisionChecks: '源稿决定核对',
  issues: '待处理问题', findings: '检查发现', severity: '严重程度', category: '类别', description: '说明', evidence: '证据', suggestion: '建议',
  question: '待确认问题', risks: '风险', requiredRisks: '待确认风险', requiresConfirmation: '需要确认',
  sourceBible: '源稿设定', protectedElements: '必须保留', allowedChanges: '允许调整', forbiddenChanges: '禁止改动', sourceDecisions: '源稿澄清',
  summary: '摘要', status: '状态', quality: '质量验收', qualityAccepted: '是否已验收', notes: '核查说明', manual: '人工检查',
  stop: '停止原因', instruction: '下一步指引', repairDecision: '修订待确认', newlyReported: '复扫新发现（不等于新引入）', stillReported: '仍被报告的已选问题', noLongerReported: '复扫未再报告（需核查）',
  operator: '算子', callId: '本地调用 ID', jobId: '服务端任务 ID', recoveryId: '恢复 ID', errorCode: '错误码', errorMessage: '错误原因', validationError: '本地结果校验失败', billing: '账务回执',
  coreHook: '核心钩子', targetAudience: '目标受众', genre: '题材', localizationNotes: '本地化说明', score: '方案评分', decisionNotes: '选择说明', recommendedConceptId: '推荐方案 ID',
  displayNames: '双语展示名', role: '角色定位', condition: '当前状态', knowledge: '已知信息', newKnowledge: '新增知识', custody: '持有状态', holder: '持有人', location: '所在地点',
  globalArc: '全季弧线', objective: '本集目标', endingHook: '结尾钩子', carryForward: '承接事项', unresolvedSetups: '未兑现伏笔', continuityConstraints: '连续性约束',
  continuity: '连续性', hookAndPacing: '钩子与节奏', setupPayoff: '埋线与兑现', characterConsistency: '人物一致性', format: '格式', length: '篇幅', localization: '本地化', contentRedlines: '内容红线', adaptationProtection: '改编保护',
  statistics: '正文统计', episodeStatistics: '当前有效稿统计', statisticsBasis: '统计口径', wordCount: '正文计数', sceneCount: '场景数', dialogueCount: '对白行数',
  modelSummary: '模型摘要（非验收结论）', modelStatus: '模型自报状态', conclusion: '结论', issueCount: '问题数', programIssueCount: '程序检查问题数', warnings: '警告',
  programFindings: '程序问题索引（独立于模型评价）', dimension: '检查维度',
  evidenceCheck: '引句归属提示（不裁定问题真伪）', evidenceChecks: '引句归属提示（不裁定问题真伪）',
  reviewedProseScriptCounts: '被审稿实际字形统计（排除身份键及对照稿）', body: '正文',
  scriptCounts: '引句字形统计（非语言质量结论）', hanCharacterCount: '汉字数', latinLetterCount: '拉丁字母数',
  issueId: '原问题ID', advisory: '非阻断提示', quotes: '原文引句', quote: '引句', matches: '匹配位置',
  collection: '输入集合（episodes被审稿/sourceEpisodes对照稿）', path: '原始字段路径', note: '说明',
  reviewEpoch: '当前稿别审校轮次（0为首次）', currentReview: '属于当前审校覆盖',
  reviewCoverage: '算子审校覆盖（不是验收结论）', complete: '是否完整覆盖', availableEpisodes: '已完成集数', reviewedBatches: '已有有效报告的批次', capacityWarning: '可选审校容量提示',
  optional: '可选项', defaultCount: '默认调用次数', baseOperatorCalls: '不含可选审校的基础调用次数', steps: '完整步骤', count: '调用次数', pricing: '报价与费用说明',
  generationMode: '正文生成方式', additionalCalls: '额外本地化调用次数', additionalCostCredits: '额外转换积分（—为待报价，非免费）', quoteStatus: '本地化报价状态', scope: '计划范围',
  kind: '下一步类型', type: '类型', action: '动作', numbers: '集号范围', draftKind: '稿别', options: '待选项', reason: '停止原因',
  standardError: '公开错误详情', supportId: '排障支持编号', suggestedActions: '服务端处理建议（不是执行授权）',
  knownNetPoints: '已确认实际消耗（馒头）', totalNetPoints: '合计实际消耗（—为待核对）', unknownCallCount: '待核对调用数',
  netPoints: '本次实际消耗（馒头）', reservedPoints: '预扣（待最终结算）', final: '是否最终结算', callIds: '关联本地调用', rows: '逐任务费用',
  advisoryOnly: '仅提醒、不阻断交付', actual: '实际计数', min: '目标下限', max: '目标上限', countBasis: '计数依据',
  billingStatus: '账务状态', actualPoints: '实际积分', chargedPoints: '已扣积分', refundedPoints: '已退积分', estimatedPoints: '预估积分', points: '积分',
};
const technical = new Set(['schemaVersion', 'appliedRecipes', 'assetsDigest', 'blueprintDigest', 'sourceDigest', 'recipeBindings', 'operatorRecipeBindings', 'signature', 'snapshotId', 'fixCallId', 'rescanCallId']);

/** Escape untrusted prose without interpreting it as HTML, links or headings. */
export function plain(value) {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/[\\`*_{}\[\]()#+.!|~\-]/g, '\\$&').replace(/\r\n?/g, '\n');
}
const scalar = value => value === null || value === undefined || value === '' ? '—' : plain(value);

/** Attribute model opinions separately from final report status, including legacy reports. */
export function renderReview(report, numbers, checks = report.summary?.evidenceChecks) {
  const summary = report.summary || {};
  const hasModelSummary = summary.modelSummary && typeof summary.modelSummary === 'object';
  const merged = hasModelSummary ? Object.fromEntries(Object.entries(summary).filter(([key]) => !['modelSummary', 'evidenceChecks'].includes(key))) : {};
  return `## 审校批次：${numbers.map(plain).join('、')}\n\n`
    + renderData({ ...merged, action: report.action, status: report.status })
    + (checks?.length ? '\n\n### 引句归属核对\n\nSOURCE_ONLY 表示引句只在工作稿对照中找到，OTHER_EPISODE_ONLY 表示仅命中其他集；先核对归属，不据此自动改稿或删问题。TARGET_TEXT_FOUND 只证明出现过原句；须核对结论是否与引句相符，不能引用英文原句却称整段中文。字形统计不是翻译质量结论，MIXED_REFERENCES 可用于合法双稿对照；UNVERIFIED/部分匹配均不代表问题为假。所有提示均不阻断继续和导出。\n\n' + renderData({ evidenceChecks: checks }) : '')
    + '\n\n程序问题与模型意见都见上方待处理清单。模型分项称“无问题”不能覆盖清单中的相反证据；完整覆盖也不代表全季语义已通过。'
    + '\n\n### 模型原始评价（不是验收结论）\n\n'
    + renderData(hasModelSummary ? summary.modelSummary : summary, 4);
}

/** Render nested data as named sections, concise fields and numbered records (no JSON dump). */
export function renderData(value, depth = 2) {
  if (Array.isArray(value)) {
    if (!value.length) return '（空数组）';
    return value.map((item, index) => item && typeof item === 'object'
      ? `${'#'.repeat(Math.min(depth, 4))} ${index + 1}. ${plain(item.title || item.canonicalName || item.id || item.name || '条目')}\n\n${renderData(item, depth + 1)}`
      : `- ${scalar(item)}`).join('\n\n');
  }
  if (value && typeof value === 'object') return Object.entries(value).filter(([key, item]) => !technical.has(key) && item !== undefined).map(([key, item]) => {
    const label = plain(labels[key] || key.replace(/([a-z])([A-Z])/g, '$1 $2'));
    if (item && typeof item === 'object') return `${'#'.repeat(Math.min(depth, 4))} ${label}\n\n${renderData(item, depth + 1)}`;
    return `**${label}：** ${scalar(item).replace(/\n/g, '  \n')}`;
  }).join('\n\n');
  return scalar(value);
}

/** Keep actionable stops visible, with machine IDs and accounting in the separate run record. */
export function renderNext(step) {
  const instructions = {
    pending: ['REJECTED', 'NOT_SUBMITTED'].includes(step.status)
      ? '本次请求已明确拒绝受理或停在报价阶段，不是模型仍在执行。保留错误回执，先处理原因；由用户明确决定停止或重新尝试，不自动重提，也不据此承诺历史任务退款。'
      : '当前调用尚未闭环。先查运行记录中的原任务与恢复信息，不重新提交；明确失败后的新尝试需要用户授权。',
    blocked: '项目已暂停，请先处理停止原因并取得用户决定。',
    'warning-triage': '先本地阅读新警告及原句，按根因归并和分级；轻微问题记录后继续，不调用付费审校。',
    'issue-decision': '已确认的核心矛盾、修改后连续性问题或用户明确暂停需说明证据、影响及可选处理，等待具体决定；“继续”不等于改稿、费用或最终验收授权。',
    'continuity-check': '局部修订已保留其他剧集；本地核对修改集及后续正文、连续性快照，不能将旧状态直接当作已修复。无需购买审校。',
    'repair-decision': '对照前后稿与两次审校，由用户决定保留或撤回；新发现不等于新引入，不自动追加改稿。',
    pause: '展示当前阶段产物与待选项，等待用户确认；不要代替用户推进。',
    operator: '仅在用户要求的范围内准备下一阶段，并按工具合同处理费用确认。',
    'review-choice': '当前稿件可按已完成范围导出。审校是可选收费项：说明范围、批次和实时报价，明确同意才调用；跳过或未确认不收费，可继续交付未审校稿。不能把“继续”当质量验收。',
    quality: step.partial ? '用户要求的中途审校已结束。展示问题，可继续写作；不自动改稿。' : step.draftKind === 'WORKING' ? '展示工作稿、已有问题与未审校范围，等待确认作为成品来源；审校可跳过，这不是最终验收。' : '可直接交付并标明审校覆盖。最终质量验收须另行明确确认，不因“继续”自动通过。',
    done: step.qualityAccepted ? '已记录用户明确质量验收；仍须披露未审校范围，不能冒充模型审校通过。' : '已交付，尚未质量验收；保留未审校标识、已知问题和原始回执。',
  };
  const fields = Object.fromEntries(['status', 'operator', 'episodeNumber', 'action', 'numbers', 'type', 'options', 'draftKind', 'reason', 'errorCode', 'errorMessage', 'validationError'].filter(key => step[key] !== undefined).map(key => [key, step[key]]));
  return renderData({ ...fields, instruction: instructions[step.kind] || '查看运行记录并核对当前状态。' })
    + (step.localCheck ? `\n\n### 尚待本地核对（非付费审校）\n\n${renderNext(step.localCheck)}` : '');
}

/** Rebuild a reading view from authoritative lines, not a second model-authored manuscript. */
export function renderEpisode(ep, number, language, presentation = {}) {
  const en = /^en(?:[-_]|$)/i.test(language);
  const title = `# ${en ? `Episode ${number}` : `第 ${number} 集`} · ${plain(ep.title).replace(/\n/g, ' ')}`;
  const names = characterNames(presentation.assets, language, presentation.characters);
  const body = ep.scriptLines.map(line => {
    const text = plain(line.text).replace(/\n/g, '  \n');
    switch (line.type) {
      case 'SCENE': return `## ${text.replace(/  \n/g, ' ')}`;
      case 'DIALOGUE': return `**${plain(names.get(line.character) ?? line.character).replace(/\n/g, ' ')}**\n\n> ${text.replace(/\n/g, '\n> ')}`;
      case 'CAPTION': return `**${en ? 'Caption' : '字幕'}：** ${text}`;
      case 'SFX': return `**${en ? 'Sound' : '音效'}：** ${text}`;
      default: return text;
    }
  }).join('\n\n');
  return `${title}\n\n${body}`;
}
