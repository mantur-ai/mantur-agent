---
name: mantur-smartclip
title: 漫剧高光智能剪
description: 把一整部漫剧/短剧自动剪成投放素材：AI 识别高光片段（约15秒）→ 切片入库 → 配花字标题/警示语模板 → 批量合成竖版前贴素材（可拼续播集/尾贴）。用户说「高光智能剪 / 剪高光 / 切高光 / 高光切片 / 做投放素材 / 素材裂变 / 把这部剧剪成素材」时使用——即使没说"高光"二字，只要是"从整部剧里自动挑精彩片段做广告素材"就用本 skill。支持红果/红果漫剧/河马平台剧名直接拉取，或用户自备视频文件/URL。不适用于：复刻别人的爆款视频（→ mantur-copyhit）、从零生成剧情视频（→ 视频生成）。
category: 视频制作
version: 1.0.1
triggers:
  - 高光智能剪
  - 高光剪辑
  - 剪高光
  - 切高光
  - 高光切片
  - 投放素材
  - 素材裂变
  - 漫剧智能剪
  - 智能剪辑
  - 把这部剧剪成素材
uses_operators:
  - op.drama.search
  - op.drama.episodes
  - op.drama.download
  - op.video.understand-v2
  - op.video.grid
  - op.video.compose
  - op.image.fancytext
---

## 平台接入（ManturHub 自动注入）

### 认证
首次使用先运行 `manturhub login` 完成浏览器授权；CLI 会保存并复用登录凭证。
自动化环境也可设置 `MANTURHUB_KEY`。REST 请求统一使用 `x-api-key: <YOUR_KEY>`，API Key 可在当前 ManturHub 站点的 `/dashboard/api-keys` 创建。

### 算子调用
优先使用 `manturhub run <算子ID> --json '{...}'`；异步任务由 CLI 自动轮询并返回最终结果。
直接调用 REST 时，以 `manturhub describe <算子ID>` 返回的实时 schema 和轮询说明为准。
任务失败由平台自动退费，无需在 Skill 中实现重复扣费或退款逻辑。

### 文件上传
本地文件必须先换成公网 URL 再传给算子：
- CLI：`manturhub upload <本地文件>` → 返回可直接传给算子的公网 URL
- REST：`POST /api/v1/uploads/presign` → 拿 `put_url` PUT 上传 → 用 `access_url`

### 执行前自检
1. 先运行 `manturhub describe <算子ID>` 获取实时参数 schema，不要凭 Skill 内的历史示例猜参数。
2. 调用前运行 `manturhub quote <算子ID>` 查实时价格。
3. 调用所需的本地素材先运行 `manturhub upload <本地文件>`，不要把本地路径直接传给算子。

### 本 Skill 依赖算子
- `op.drama.search`（短剧关键字搜索）：`manturhub quote op.drama.search`
- `op.drama.episodes`（短剧分集元数据）：`manturhub quote op.drama.episodes`
- `op.drama.download`（短剧视频下载链接）：`manturhub quote op.drama.download`
- `op.video.understand-v2`（视频/图像理解算子）：`manturhub quote op.video.understand-v2`
- `op.video.grid`（视频宫格图生成）：`manturhub quote op.video.grid`
- `op.video.compose`（视频合成拼接）：`manturhub quote op.video.compose`
- `op.image.fancytext`（花字渲染）：`manturhub quote op.image.fancytext`

---

# 漫剧高光智能剪

输入一部剧（平台剧名，或本地视频/URL 列表）→ 产出一批可直接投放的竖版前贴素材。五步流程，全程走 ManturHub 算子，切片库与模板保存在本地项目目录，可反复增量出片。

## 0. 前置自检（开工前必做）

1. `manturhub balance` 确认 CLI 可用且有余额；没装 → `npm i -g @manturhub/cli && manturhub login --key sk-xxx`。
2. 建项目目录并进入（一部剧一个目录，状态文件都在这）：
   ```
   smartclip-<剧名>/
     project.json      # 剧集清单+排序+每集 URL/时长
     clips.json        # 切片库（高光识别结果 + 切片成片链接）
     templates.json    # 花字/尾贴模板
     output/manifest.md  # 交付清单
   ```
3. **成本先行**：每一步动手前用 `manturhub describe <算子>` 看单价说明，批量操作（≥10 次调用）先把预估馒头总数报给用户确认再执行。

## 1. 剧集获取与排序

**路径 A · 平台拉取**（用户给剧名/平台）：
```bash
manturhub run op.drama.search --json '{"keyword":"<剧名>","platforms":"hgmj"}'   # 红果漫剧=hgmj 红果=hg 河马=hm
manturhub run op.drama.episodes --json '{"platform":"hgmj","book_id":"<book_id>"}'
manturhub run op.drama.download --json '{"platform":"hgmj","video_id":"<video_id>"}'  # 逐集拿 video_url
```
⚠️ drama.* 属受限算子，若返回 403 说明当前 key 无权限 → 走路径 B，让用户自备视频。

**路径 B · 用户自备**（本地文件或 URL 列表）：本地文件逐个 `manturhub upload <文件>` 转公网 URL。

**排序（AI+人）**：按文件名/标题推断 `episode_number`，把排序表打给用户确认，用户可改；确认后写入 `project.json`。

🔴 **所有视频喂算子前必须是平台 TOS URL**：平台 CDN 直链（如 douyinvod）无 .mp4 扩展名，喂理解算子会 504——先 `curl -L 下载` 再 `manturhub upload` 转 URL（实测坑）。

## 2. 高光识别

用户可指定范围（如「只识别前 5 集」）。逐集调用视频理解，**用这个实测通过的提示词**（帧级精度已验证）：

```bash
manturhub run op.video.understand-v2 --json '{
  "video_url": "<TOS URL>",
  "prompt": "你是短剧投放素材剪辑师。请分析这集漫剧，找出 2-4 个最适合做投放前贴的高光片段。对每个片段严格按视频真实时间轴给出：start_sec(开始秒)、end_sec(结束秒，片段时长控制在12-18秒)、score(投放吸引力0-100)、reason(为什么是高光，一句话)、dialogue(该片段内的关键台词原文)。同时给出 total_duration_sec(整集时长秒)。只输出 JSON：{\"total_duration_sec\":N,\"highlights\":[{\"start_sec\":N,\"end_sec\":N,\"score\":N,\"reason\":\"...\",\"dialogue\":\"...\"}]}"
}'
```

- 结果写入 `clips.json`（每条：episode / start_sec / end_sec / score / reason / dialogue / status）。
- 校验：时间戳不得越界 total_duration_sec；时长应在 12-18s，异常段丢弃或重试一次。
- 识别出的 dialogue 可能与画面字幕有轻微出入（实测「我不想被饿死啊」被写成「我不想死啊」），**做花字文案时以画面字幕为准**——需要精确核对时用宫格抽帧：
  ```bash
  manturhub run op.video.grid --json '{"src":"<URL>","timestamps":[<各高光起止秒>],"label_timestamps":true}'
  ```
  把宫格图给用户看，人工确认高光准不准（可选步骤，识别置信度存疑时才做）。

## 3. 高光切片（入库）

对每条确认的高光，用 compose 裁剪，**两端各留 1s buffer**（clamp 到 [0, 总时长]）：

```bash
manturhub run op.video.compose --json '{
  "canvas": {"width": 720, "height": 1280},
  "tracks": [[{"type":"video","src":"<集URL>","target_time":{"start":0,"end":<时长>},
    "extra":[{"type":"trim","start":<start-1>,"end":<end+1>},
             {"type":"transform","x":0,"y":0,"width":720,"height":1280}]}]]
}'
```
- canvas 跟源片方向走（漫剧多为竖版 720×1280；横版素材用 1280×720）。
- 成片 `result_url` 回写 clips.json 的 `slice_video_url`。
- 用户手工补充高光：给「第 N 集 X 秒到 Y 秒」即可同流程切片入库。
- ⚠️ 产物为带时效的签名链接（约 7 天），交付时提醒用户及时转存。

## 4. 模板配置

首次新建（问用户三项，都可留默认）；已有模板（templates.json 非空）则列出让用户选或改：

```json
{
  "title": { "text": "<标题文案，默认剧名>", "styles": ["variety-orange", "sticker-goldflame"],
             "position": "top", "scale_ratio": 0.5 },
  "warning": { "text": "<警示语，可空>", "style": "warn-redwhite", "position": "bottom", "scale_ratio": 0.3 },
  "ending_video_url": "<尾贴视频URL，可空>",
  "follow_episodes": 0
}
```

- **styles 数组 = 批量多版本**：每个款式出一版素材（字体×字效笛卡尔积思路）。款式清单以 `manturhub describe op.image.fancytext` 返回的实时 schema 为准。
- scale_ratio 经验值：标题 0.4-0.55，警示语 0.25-0.35（视频里花字大小只看 scale_ratio，font_size 无关）。

## 5. 批量合成 + 交付

对「选中的切片 × 模板款式」逐个出片：

1. **叠标题花字**（视频模式，1 馒头/次）：
   ```bash
   manturhub run op.image.fancytext --json '{"text":"<标题>","style":"<款式>","video_url":"<切片URL>","position":"top","scale_ratio":0.5}'
   ```
2. **叠警示语**（配置了才做）：对上一步产物再调一次 fancytext（position 用 bottom/middle 避开标题）。
3. **拼续播/尾贴**（配置了才做）：compose 多段 tracks 顺序拼接 [花字成片, 续播集 1..N, 尾贴]，`target_time` 依次累加各段时长。
4. 每个成片登记进 `output/manifest.md`：素材名（剧名-EP-高光序号-款式）、时长、来源高光（start/end/score/reason）、链接。

**批量前必报价**：素材数 = 切片数 × 款式数，按「fancytext 1 馒头 ×（1+警示语）+ compose 20 馒头（仅拼接时）」估总价，超过 100 馒头必须等用户确认。

交付：把 manifest.md 全部链接给用户，提醒 7 天时效；问是否需要对某几条调整款式/文案（增量重出只花对应素材的钱）。

## 快速模式（一句话出样片）

用户只想快速看效果（如「用这集先出一条看看」）：跳过模板交互——识别→取最高分 1 段→切片→默认款式 `variety-orange` + 剧名做标题→出 1 条，全程不问问题，末尾报实际花费。

## 坑速查（都是实测踩过的）

| 坑 | 规避 |
|---|---|
| CDN 直链喂理解算子 504 | 无 .mp4 扩展名 mimeType 识别失败——先下载再 upload 转 TOS URL |
| 识别台词与字幕有出入 | 花字/文案以画面字幕为准，必要时 grid 抽帧核对 |
| 切片掐头去尾 | trim 两端各留 1s buffer 并 clamp 到 [0,总时长] |
| 高光时间越界 | 校验 end_sec ≤ total_duration_sec，异常段重试一次仍异常则丢弃 |
| 视频里花字过大 | 用 scale_ratio 控制（标题 ~0.5），font_size 不影响叠加尺寸 |
| 产物链接过期 | 签名链接约 7 天时效，交付时明确提醒转存 |
| 异步算子重复提交 | run 已自动轮询到结果，别重复调（会重复扣费）|
| drama.* 返回 403 | 受限算子无权限——改走用户自备视频路径，别死磕 |
