// Display only the amounts explicitly returned by the original receipt.
const amount=value=>typeof value==='number'&&Number.isFinite(value)?value:null;
const settled=new Set(['COMPLETED','SETTLED','CHARGED','REFUNDED']);
export function billingView(billing){
  const billingStatus=billing?.billingStatus??billing?.status;
  return {billingStatus,
    actualPoints:settled.has(billingStatus)?amount(billing.actualPoints??billing.points):null,
    prechargedPoints:billingStatus==='DEDUCTED'?amount(billing.prechargedPoints??billing.points):null,
    refundedPoints:amount(billing?.refundedPoints)};
}
