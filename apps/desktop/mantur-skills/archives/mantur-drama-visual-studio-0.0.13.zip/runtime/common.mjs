import {
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { delimiter, dirname, isAbsolute, relative, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { spawnExternalCliSync, spawnInternalNodeSync } from "./child-process.mjs";
import { realpathSync } from 'node:fs';
import { parseCliVersion, classifyCliFailure, diagnostic, responseError } from './manturhub-contract.mjs';

export function plainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

export function parseOptions(tokens, specification) {
  const values = new Set(specification.values || []);
  const booleans = new Set(specification.booleans || []);
  const repeated = new Set(specification.repeated || []);
  const options = Object.fromEntries([...repeated].map((name) => [name, []]));
  const positionals = [];
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (token === "--") {
      positionals.push(...tokens.slice(i + 1));
      break;
    }
    if (!token.startsWith("--")) {
      positionals.push(token);
      continue;
    }
    const equals = token.indexOf("=");
    const name = token.slice(2, equals > 2 ? equals : undefined);
    if (booleans.has(name)) {
      if (equals > 2) throw new Error(`option --${name} does not accept a value`);
      options[name] = true;
      continue;
    }
    if (!values.has(name) && !repeated.has(name)) throw new Error(`unknown option: --${name}`);
    let value;
    if (equals > 2) value = token.slice(equals + 1);
    else value = tokens[++i];
    if (!value || value.startsWith("--")) throw new Error(`option --${name} requires a value`);
    if (repeated.has(name)) options[name].push(value);
    else options[name] = value;
  }
  const expected = specification.positionals ?? 0;
  if (positionals.length !== expected) {
    throw new Error(`expected ${expected} positional argument(s), received ${positionals.length}`);
  }
  return { options, positionals };
}

export function readJson(path, { object = false } = {}) {
  const value = JSON.parse(readFileSync(path, "utf8"));
  if (object && !plainObject(value)) throw new Error(`JSON must be an object: ${path}`);
  return value;
}

export function writeJson(path, payload) {
  const target = assertProjectWritePath(path);
  mkdirSync(dirname(target), { recursive: true });
  const temporary = resolve(dirname(target), `.${target.split(/[\\/]/).pop()}.${process.pid}.tmp`);
  try {
    writeFileSync(temporary, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
    for(let attempt=0;;attempt++) {
      try {renameSync(temporary,target);break;}
      catch(error) {if(process.platform!=='win32'||!['EPERM','EACCES','EBUSY'].includes(error.code)||attempt>=80)throw error;Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,25);}
    }
  } finally {
    rmSync(temporary, { force: true });
  }
  return target;
}

export function projectRoot() {
  const configured = process.env.MANTURHUB_PROJECT;
  if (!configured) throw new Error('Project is missing; use scripts/studio.mjs --project <directory> <action>');
  const root = resolve(configured);
  if (!existsSync(root) || !lstatSync(root).isDirectory()) throw new Error(`project directory is invalid: ${configured}`);
  return root;
}

export function assertProjectWritePath(path) {
  const root = projectRoot();
  const target = resolve(root, path);
  const relation = relative(root, target);
  if (relation.startsWith("..") || isAbsolute(relation)) {
    throw new Error(`output path must stay inside the project directory: ${path}`);
  }
  if (existsSync(target) && lstatSync(target).isSymbolicLink()) {
    throw new Error(`output path is a symbolic link: ${target}`);
  }
  let cursor = dirname(target);
  while (cursor !== root && cursor !== dirname(cursor)) {
    if (existsSync(cursor) && lstatSync(cursor).isSymbolicLink()) {
      throw new Error(`output path contains a symbolic link: ${cursor}`);
    }
    cursor = dirname(cursor);
  }
  return target;
}

export function httpUrl(value, field = "URL", { httpsOnly = false, noQuery = false } = {}) {
  let url;
  try {
    url = new URL(String(value || ""));
  } catch {
    throw new Error(`${field} must be a valid HTTP/HTTPS URL`);
  }
  if ((!httpsOnly && !["http:", "https:"].includes(url.protocol)) || (httpsOnly && url.protocol !== "https:")) {
    throw new Error(`${field} must be a valid ${httpsOnly ? "HTTPS" : "HTTP/HTTPS"} URL`);
  }
  if (!url.hostname || url.username || url.password || (noQuery && (url.search || url.hash))) {
    throw new Error(`${field} is not an allowed URL`);
  }
  return url.href;
}

export function resolveCliEntry() {
  const isNodeEntry = path => {
    try {return lstatSync(path).isFile() && (/\.[cm]?js$/i.test(path)||/^#!.*\bnode\b/.test(readFileSync(path,'utf8').split(/\r?\n/,1)[0]));}catch{return false;}
  };
  const explicit = process.env.MANTURHUB_CLI_ENTRY;
  if (explicit && isNodeEntry(explicit)) return resolve(explicit);
  for (const directory of (process.env.PATH || '').split(delimiter).filter(Boolean)) {
    for (const name of ['manturhub', 'manturhub.cmd', 'manturhub.ps1']) {
      const shim = resolve(directory, name);
      if (!existsSync(shim)) continue;
      const actual = realpathSync(shim);
      for (const candidate of [resolve(directory, 'node_modules/@manturhub/cli/bin/cli.js'), resolve(directory, '../lib/node_modules/@manturhub/cli/bin/cli.js'), actual]) {
        if (!existsSync(candidate) || !lstatSync(candidate).isFile()) continue;
        if (isNodeEntry(candidate)) return candidate;
      }
    }
  }
  throw Object.assign(new Error('ManturHub CLI entry is unavailable; install ManturHub CLI or set MANTURHUB_CLI_ENTRY to its Node entry.'),{code:'CLI_UNAVAILABLE'});
}

export function cliVersionInfo() {
  const entry = resolveCliEntry();
  const version = spawnExternalCliSync(entry,['--version'],{
    encoding:'utf8',timeout:10000,stdio:['ignore','pipe','pipe'],parentEnvironment:process.env,
    environmentOverrides:{MANTURHUB_DISABLE_UPDATE_CHECK:'1'},
  });
  if(version.status!==0) throw diagnostic('CLI_VERSION_UNSUPPORTED');
  return {...parseCliVersion(version.stdout || ''), entry};
}

function cliBaseUrlError() {
  return Object.assign(new Error('ManturHub CLI getBaseUrl() is unavailable.'),{code:'CLI_BASE_URL_UNAVAILABLE'});
}

export async function hydrateManturhubBaseFromCli(environ = process.env) {
  if (typeof environ.MANTURHUB_BASE === 'string' && environ.MANTURHUB_BASE.trim() !== '') {
    environ.MANTURHUB_BASE_SOURCE = 'environment';
    return {base:environ.MANTURHUB_BASE,source:'environment'};
  }
  try {
    const entry=resolveCliEntry();
    const packageRoot=realpathSync(resolve(dirname(entry),'..'));
    const manifest=JSON.parse(readFileSync(resolve(packageRoot,'package.json'),'utf8'));
    if(manifest?.name!=='@manturhub/cli')throw cliBaseUrlError();
    const cli=parseCliVersion(manifest.version);
    const configPath=realpathSync(resolve(packageRoot,'lib','config.js'));
    const relation=relative(packageRoot,configPath);
    if(relation.startsWith('..')||isAbsolute(relation)||!lstatSync(configPath).isFile())throw cliBaseUrlError();
    const config=await import(pathToFileURL(configPath).href);
    if(typeof config.getBaseUrl!=='function')throw cliBaseUrlError();
    const base=config.getBaseUrl();
    if(typeof base!=='string'||base.trim()==='')throw cliBaseUrlError();
    environ.MANTURHUB_BASE=base;
    environ.MANTURHUB_BASE_SOURCE='cli_getBaseUrl';
    return {base,source:'cli_getBaseUrl',cli_version:cli.version};
  } catch(error) {
    if(error?.code==='CLI_VERSION_UNSUPPORTED'||error?.code==='CLI_UNAVAILABLE'||error?.code==='CLI_BASE_URL_UNAVAILABLE')throw error;
    throw cliBaseUrlError();
  }
}

export function runCli(args, { allowNonZeroJson = false, cli = null, base = null, readOnlyRetry = false } = {}) {
  const {entry} = cli ?? cliVersionInfo();
  // Retry only these harmless reads; never retry submit/quote/upload or checkpoint mutation here.
  const attempts = readOnlyRetry && ['balance','describe'].includes(args[0]) ? 2 : 1;
  for (let attempt=0; attempt<attempts; attempt++) {
  const result = spawnExternalCliSync(entry, args, {
    encoding: "utf8",
    stdio: ['ignore','pipe','pipe'],
    parentEnvironment: process.env,
    environmentOverrides: { ...(base ? {MANTURHUB_BASE:base} : {}), MANTURHUB_DISABLE_UPDATE_CHECK: "1" },
    maxBuffer: 16 * 1024 * 1024,
    timeout: 60000,
  });
  let payload;
  try {
    payload = JSON.parse(result.stdout);
  } catch {
    payload = null;
  }
  let code = result.error ? classifyCliFailure('', result.error.code) : null;
  if (!code && result.status !== 0 && !(allowNonZeroJson && plainObject(payload))) code = classifyCliFailure(`${result.stdout || ''}\n${result.stderr || ''}`);
  if (!code && !plainObject(payload)) code = 'MANTURHUB_RESPONSE_INCOMPATIBLE';
  if (!code && readOnlyRetry) code = responseError(payload);
  if (code) {
    if (attempt + 1 < attempts && ['MANTURHUB_TIMEOUT','MANTURHUB_NETWORK_ERROR','MANTURHUB_SERVICE_UNAVAILABLE'].includes(code)) {
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,250);
      continue;
    }
    throw diagnostic(code);
  }
  return { status: result.status, payload };
  }
}

export function runInternalNode(entry, args = []) {
  const result = spawnInternalNodeSync(entry, args, {
    encoding: "utf8",
    stdio: ['ignore','pipe','pipe'],
    parentEnvironment: process.env,
    environmentProfile: 'isolated',
    maxBuffer: 16 * 1024 * 1024,
  });
  return {
    found: result.error?.code !== "ENOENT",
    status: result.status,
    stdout: result.stdout || "",
    stderr: result.stderr || "",
  };
}

export function outputPath(value, label) {
  if (!value) throw new Error(`${label} is required`);
  return assertProjectWritePath(value);
}
