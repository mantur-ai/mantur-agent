# @manturhub/cli

ManturHub 算子广场的统一 Agent 调用通道。CLI 通过 REST 实时发现和调用全部上线算子，也可浏览配方、安装平台 Skill 和 Agent 套件；新算子上线后无需更新 CLI 即可发现。

## 安装与登录

```bash
npm install -g @manturhub/cli
manturhub login
```

正式版默认连接 `https://hub.mantur.ai`，无需额外配置域名。升级前若设置过测试用 `MANTURHUB_BASE` 或自定义 `baseUrl`，请显式切换到生产站点并重新授权；不要复制测试凭据。使用 `manturhub doctor --json` 核对实际站点和版本。

`login` 使用 `/api/auth/client/sessions` 的 DEVICE 授权流程：浏览器复用网页登录态，核对用户码后点击授权，CLI 在后台领取 accessToken / refreshToken。无浏览器终端可运行 `manturhub login --no-browser`，在另一台设备打开显示的地址。Ctrl+C 取消等待；会话最长 10 分钟，不自动切换旧接口或 API Key 登录。

账号凭据保存在 `~/.manturhub/client-credentials-v2.sqlite`（权限 `600`），按网关 origin 隔离，每个站点只激活一个账号。**CLI 使用本机私有明文凭据库，不宣称使用系统钥匙串**；不要分享此文件及其日志文件。新授权成功后一次提交切换账号，拒绝或取消登录保留旧账号。后发登录或登出会使之前等待中的浏览器授权失效。`manturhub logout` 清理本机账号并尝试撤销专用 Key/远端会话，手工 Key 不受影响；`manturhub auth logout` 还清除本站保存的手工 Key，外部环境变量需从宿主移除。

账号余额使用 `/api/billing/accounts/me`，API Key 余额继续使用 `/api/openapi/v1/credits/balance`。账号请求使用 `Authorization`；到期前 65 分钟刷新，并在 HTTP 401 后刷新重试一次。本地事务中的操作记录防止不同 CLI 进程同时轮换凭证，流式上传遇到 401 刷新后要求重新执行，不重复发送已经消费的流。服务端撤销或封禁会清除该站点账号。业务接口刷新后仍返回 401 时，先调用账号校验接口；账号仍有效则保留凭证并提示接口鉴权不匹配，不会用其他凭证静默重试。

登录、登出只用短事务提交本地状态，不等待后台刷新或 Key 创建的网络请求。每次会话切换都有独立版本；旧操作的成功或失败都不能覆盖新登录，业务请求也不能切换账号重试。进程崩溃后事务由 SQLite 恢复，不再需要人工删除凭据锁。凭据库仅支持本机磁盘，不支持多主机共享文件系统。

首次修改凭据时，若无旧锁，一次性导入旧 `client-credentials.json`；若存在旧锁，则隔离旧会话并记录待撤销信息，直接重新登录即可。旧文件与 `client-credentials.lock` 保留，初始化后不再读取它们。请停止使用旧版 CLI/宿主内嵌旧包；旧进程不理解新协议，新版无法阻止它继续使用旧凭据。不要通过删除新库来回退，否则可能重新导入旧账号。此改造尚未发布，已发布的 1.2.4 仍使用目录锁。

登出先提交本机退出，再处理持久化的远端撤销记录；每次最多处理 4 条，每个请求超时 1.5 秒。Key 撤销失败时保留账号令牌供后续重试，后续登录/登出继续处理。远端失败会明确提示，不恢复本地登录。已发出的请求不能保证撤回；旧刷新响应丢失或创建 Key 结果不确定时，仍需在平台核对会话/Key。完整会话族撤销需要服务端支持。`auth status` 只观察本地账号状态，不迁移或清理凭据。

本地事务使用 `libsql` 原生依赖，安装需保留 npm optional dependencies。已提供 macOS、Linux 及 Windows x64 的平台包；其他架构须先核对运行支持，不依赖系统安装 SQLite。

已登录账号首次访问 `/api/openapi/v1/` 时，CLI 创建名为 `Mantur CLI`、有效期 90 天的专用 Key，明确提示后保存到同一个权限 `600` 的凭据库。权限由服务端决定，不传当前后端未支持的 scopes。`auth login --workbuddy` 会在登录完成前准备此 Key；报价、算子调用、上传与作业查询统一使用此 Key，账号余额仍使用账号 Token。显式环境变量或传入的 API Key 保持优先。

创建专用 Key 受会话内操作记录保护，发送请求前记录创建意图。超时、响应不完整或进程中断后不会自动重复创建：请在当前站点的 Key 管理核对并撤销 `Mantur CLI` Key，再重新登录。专用 Key 被拒绝或过期时明确报错，不清除账号登录、不自动换 Key、不重放付费提交。退出时远端撤销失败会提示手动处理，本地凭证仍清除。凭证文件包含长期调用密钥，请勿复制或上传。

API Key 仍可显式使用 `MANTURHUB_KEY` 或 stdin 导入，走原有 `x-api-key` 通道：

```bash
printf '%s' "$YOUR_MANTURHUB_KEY" | manturhub login --key-stdin
```

`MANTURHUB_KEY` 优先于账号登录；设置该变量时先取消它才能发起浏览器授权。已有 `config.json` 中的 Key 保留；已登录站点优先使用账号凭证。

所有发行版本默认连接 `https://hub.mantur.ai`。旧配置中的非生产 `baseUrl` 会报错；移除该字段后使用生产站点。开发联调通过 `MANTURHUB_BASE` 显式提供 HTTPS 网关，并通过 `MANTURHUB_CONFIG_DIR` 隔离凭据。浏览器授权页必须与所选网关同源。

`MANTURHUB_CONFIG_DIR` 隔离账号凭据、手工 Key、上传缓存和调用恢复记录。旧无站点 Key 只用于其记录的 baseUrl，未记录则只属于包默认站点；不会复制到另一站点。旧 Skill 安装状态及更新缓存仍采用原位置。不要把测试凭据目录提交到 Git。服务端必须返回同站点 `/auth/device?user_code=...` 授权地址。

### WorkBuddy 与剧本文档（1.2）

```bash
manturhub auth login --workbuddy
manturhub auth status --json
manturhub doctor --json
manturhub run op.script.source-analyze --file sourceFileId=./source.docx --json-file analysis-input.json
# 用户确认后，原命令追加 --confirm <confirmation_token>
manturhub upload ./source.docx --json
manturhub resume <调用恢复ID>
```

`auth status` 仅检查本地凭据，不访问网络、不刷新、不创建 Key；`verification=local` 不能证明远端没有撤销。退出 0 表示本地账号及算子凭据就绪，退出 1 表示需要处理。doctor 返回能力清单，不代表真实服务验收。

`--file` 必须绑定线上 Schema 带 `x-workbuddy-file` 声明的字段；上传成功后还必须 confirm 为 AVAILABLE，才向算子传 fileId。支持 TXT/MD/JSON/DOCX/PDF（文档默认 5MB 上限）及已有媒体类型。上传缓存按站点和身份隔离，有效期一小时；上传后用户修改文件会触发新报价确认。`run` 始终输出 JSON，`--json` 是入参，不是单独输出开关。

确认标识有效期 15 分钟，绑定身份、站点、参数和报价版本。它是客户端防误操作措施，不是服务端签名报价或价格锁。提交前保存私有恢复记录；已有恢复记录的确认标识不能再次run覆盖，已受理任务使用resume查询，绝不重新invoke。未知提交结果需以原恢复ID核对平台记录，无jobId时停止人工核对，不能新建幂等身份盲重提。

`run`在报价HTTP失败时向stdout输出`mantur.cli.submission.v1`、`status=NOT_SUBMITTED`；只有服务端明确受理前拒绝（422101、AGENT_INPUT_SCHEMA_INVALID、retryable=false、details.submissionState=REJECTED、operation=OPERATOR_INVOKE，且无任务/账务等冲突事实）才输出并保存`status=REJECTED`。两者退出1，不是成功或退款凭证。回执含operatorCode、原JSON的SHA256 inputDigest、submission阶段/证据及错误，提交拒绝另含recoveryId；摘要在文件绑定插入fileId之前计算。`resume`对明确拒绝只返回本地公开回执，不请求网络。修正原因、获得用户确认后才能新建调用。无标记422、5xx、断网和畸形响应仍为未知；不迁移旧SUBMITTING记录、不打印私有身份或确认令牌。其它错误仍可能只有stderr，调用方必须兼容。

退出码：0 成功；1 校验/网络/失败/取消/未知任务状态；2 用户取消费用确认；3 需要费用确认（stderr JSON）。`--no-wait` 的 0 只代表受理，不代表任务成功。现有错误文本仍写 stderr；本版本不承诺所有错误都是同一种 JSON envelope。

零积分报价只有明确 `billable=false` 且无后扣费合同时才能直接调用。支持 `postExecutionSettlement` 声明的后扣费：必须明确 `billable=true`、`currency=POINT`、预扣金额为 0、`calculationTiming=POST_EXECUTION`、`prechargeRequired=false`，并提供有效的 `unit`、正数 `unitPoints` / `maximumUsage` / `maximumPoints`、非空 `formula` 和 `priceVersionTag`。缺失或冲突的合同仍退出 1，不提交算子。

后扣费确认会显示计费依据、用量上限和最高费用；交互终端需确认，非交互返回退出码 3 与 `post_execution_settlement` 完整合同，用户确认后追加 `--confirm`。确认标识额外绑定整个后扣费合同，任一规则或费用上限变化（即使报价版本未变）都需重新确认；原固定预扣确认不能授权后扣费。预扣 0 不代表免费。提交和受理记录保存该合同，`resume` 只查询原任务。最终消耗以服务端 `billing` 结算为准，未知结算状态不会显示为免费。

这是客户端费用授权与变更检查，不是服务端签名的价格锁，也不替代服务端对费用上限的执行。`quote --json` 可只读查看原始报价；该门禁在 `--file` 上传之后，不代表文件未上传。

WorkBuddy 专用 Skill、连接器、专家和 Buddy 应用统一在独立仓库 `mantur-workbuddy` 维护、校验和打包；后端业务与算子在 `mantur-cloud`。本仓库仅维护通用 CLI 及其接入能力，不携带业务 Skill 或连接器发布资产。仓库规范见 [AGENTS.md](AGENTS.md)（仅源码仓库提供，不包含在 npm 包中）。

需要 Node.js ≥ 18。也可免安装运行：`npx -y @manturhub/cli <命令>`。

### 漫途 Agent 内置模式

`MANTURHUB_IDENTITY_MODE=desktop-managed` 时，CLI 只读取 Main 发放的短期本地授权描述文件，所有 OpenAPI 请求通过 loopback broker。账号 token 和专用调用 Key 不传给 CLI，也不读取全局 Key 或独立 CLI 登录文件。描述文件缺失、过期、跨站请求或非法路径均明确失败。登录、退出和切换账号在漫途 Agent 中操作；独立终端仍使用上述浏览器授权流程。生产默认地址为 `https://hub.mantur.ai`，测试环境仅由显式配置选择。

## 快速开始

```bash
# 发现与查看当前 Key 已授权的算子
manturhub ls --cat text
manturhub describe 电商文案生成

# 先按入参查实时预扣，再调用
manturhub quote 电商文案生成 --json '{"product_info":"便携榨汁杯，USB 充电，300ml","scene":"product_title","tone":"lively"}'
manturhub run 电商文案生成 --json '{"product_info":"便携榨汁杯，USB 充电，300ml","scene":"product_title","tone":"lively"}'
```

CLI 会在付费调用前按算子实时 schema 校验未知字段、必填项、类型、枚举和长度/数值范围，校验失败不会发起 invoke。校验通过后会显示本次预计消耗和计费依据，获得确认才调用；公开任务在最终 JSON 的 `billing` 返回结算状态、`points` 和 `refundedPoints`，兼容旧通道的 `_billing`，并同步显示到终端。批量参数按整批请求试算；多次调用应按服务端最终结算逐笔汇总，不把预扣当最终消耗，不得自行估算。

面向用户的列表、详情、报价、确认和结算统一显示中文算子名，也可直接用中文名调用。英文算子 ID 仅保留在 `--json` 机器输出和内部 API 请求中，供 Agent 与脚本稳定使用。

在 Agent 或脚本等非交互环境中，付费调用第一次运行只返回报价和 `confirmation_token`，不会提交；Agent 向用户确认后，使用提示中的 `--confirm <confirmation_token>` 执行。确认标识绑定算子、入参、价格版本和幂等 ID：内容或价格变化时拒绝调用，已产生恢复记录后按上述resume规则处理，不能反复run同一确认标识。

## 主要命令

| 命令 | 说明 |
|---|---|
| `manturhub ls [--cat image\|video\|audio\|text\|data] [--json]` | 实时列出上线算子 |
| `manturhub describe <中文算子名> [--json]` | 查看精确入参与异步属性 |
| `manturhub quote <中文算子名> [--json '{...}' \| --json-file params.json]` | 按入参查询服务端实时预扣；是否允许无入参由算子合同决定 |
| `manturhub run <中文算子名> --json '{}' [--confirm <confirmation_token>] [--no-wait]` | 调用算子；非交互确认传确认标识，异步任务默认轮询到终态 |
| `manturhub run <中文算子名> --json-file params.json` | 从文件读取参数，适合长提示词和自动化 |
| `manturhub upload <本地文件> [--json]` | 上传文档或媒体并确认 AVAILABLE；JSON 含 fileId，普通输出优先 downloadUrl |
| `manturhub status <poll_url>` | 查询 `run --no-wait` 返回的异步任务 |
| `manturhub balance [--json]` | 查询余额及美元等值（1 馒头 = $0.01 USD） |
| `manturhub skill ls [--json]` / `skill add <slug> [--client codex]` | 浏览并从当前 ManturHub 站点安装业务 Skill |
| `manturhub skill outdated [--json]` / `skill update <slug> [--force]` | 比较本地与线上版本并更新；本地修改默认不覆盖 |
| `manturhub skill doctor <slug>` / `skill run <slug> --project <目录>` | 验证 Skill 安装与依赖；从指定项目目录启动或恢复工作流 |
| `manturhub skill exec <slug> <action> -- <参数>` | 给 Agent 使用的安全机器入口；只执行 Skill 包声明的白名单动作 |
| `manturhub recipe [关键词]` / `recipe get <ID>` | 搜索并查看已验证配方 |
| `manturhub suite ls [--json]` / `suite install <slug>` | 安装多角色 Agent 套件，不复制 API Key |
| `manturhub init [--force]` | 从线上安装核心 `manturhub` Skill，并给当前项目写入 Agent 使用引导 |

机器消费输出可在支持的查询命令上加 `--json`；`quote` 的 `--json` 不带值时仅输出机器 JSON，带 JSON 值时同时作为本次试算入参。进度和提示写入 stderr，JSON 结果写入 stdout。

## Skill 本地运行契约

需要确定性本地动作的 Skill 可在包根目录声明 `skill-runtime.json`：

```json
{
  "schema_version": 1,
  "runtime": "node",
  "minimum_cli_version": "0.9.10-dev.20260810.11",
  "entry": "runtime/runner.mjs",
  "doctor_action": "doctor",
  "run_action": "run",
  "actions": ["doctor", "run", "validate-input"]
}
```

CLI 只执行 `actions` 白名单内的动作，且入口必须是 Skill 包内的 `.mjs` 文件。执行前会验证当前站点、可信安装记录、整包 SHA-256、frontmatter 版本和最低 CLI 版本；本地内容被修改、入口越界或动作未声明时直接失败，不会寻找其他脚本或解释器。动作必须只向 stdout 写一个 JSON object，日志与进度写 stderr。

环境变量：`MANTURHUB_KEY`（优先于配置文件） · `MANTURHUB_BASE`（显式覆盖当前发布通道的默认网关）。

ManturHub 算子广场：https://hub.mantur.ai

### WorkBuddy 安装

```bash
manturhub skill add <slug> --client workbuddy
manturhub skill update <slug> --client workbuddy
manturhub skill outdated
```

安装到用户目录 `~/.workbuddy/skills/<slug>/`，完成后重新打开 WorkBuddy 加载技能。
未指定 `--client` 时会检测 `~/.workbuddy`；检测到多个客户端时需要交互选择或显式指定。
`--client all` 会同时安装到 Claude Code、Codex 和 WorkBuddy。
`skill update <slug>` 未指定客户端时只更新已有安装，不会新增其他客户端安装。
`skill doctor/run/exec` 也支持 `--client workbuddy`（Skill 必须声明对应运行入口）。

添加 Skill 无需在命令行指定版本号，平台详情提供 `version` 时记录该版本，否则记录为未知。平台版本与包内 `SKILL.md.version` 均存在时必须一致，不一致则在替换本地安装前拒绝；历史缺版本包保持可安装兼容。更新时比较平台版本与安装记录，只安装更新的版本，不自动降级；版本相同默认跳过，`--force` 可明确重装相同版本。缺少可比较版本时停止更新并提示；`outdated` 显示版本未知。包内 `name`、安全解压和本地修改保护保持有效。现有 ZIP 哈希用于记录，本地内容哈希用于修改检查，尚未与服务端 `bundleDigest` 核对。

### Skill 安装解压失败

CLI 调用系统 `unzip` 或 `tar` 检查和解压安装包，读取清单时忽略 stdin 并保留 stdout/stderr。命令失败会显示工具名、执行阶段、错误码及可用的错误详情；`EBUSY` 等执行错误不能单独证明 ZIP 已损坏。报告问题时请保留这些信息及 Node/CLI 版本，不要提供登录凭据。

## 注册与调用来源

登录引流使用 `auth login --from codex --business-code story-studio`。调用使用 `run <算子编码> --source codex --business-code story-studio --skill-code story-studio --skill-version 1.0.0 --json-file params.json`；流程可加 `--skill-run-id <32位无横线UUID>`、`--step-code episode-write`，发行与接入可加 `--distribution-target generic --access-mode existing-cli`。以上归因与 input 平级，cliVersion 自动取实际版本。 `distributionTarget` 支持 generic、mantur、standalone、connector、skillhub；source 表示实际运行宿主。例如 SkillHub 包在 WorkBuddy 执行时为 source=workbuddy、distributionTarget=skillhub，同一技能的 skillCode 保持一致。SkillHub 渠道需要 CLI >=1.2.10 和后端白名单支持；不将渠道写入算子编码，确认与恢复保持首次归因。

兼容旧动态入参：未使用 `--json`/`--json-file` 且算子 Schema 声明业务字段 `source` 时，`--source` 仍写入 `input.source`，不套用渠道长度/格式限制。同时传调用渠道可设置 `MANTURHUB_SOURCE`，或使用 JSON 入参配合 `--source`。Schema 未声明该业务字段时，`--source` 仍是渠道参数；业务 JSON 中的同名字段始终保持原样。

当前进程可由接入层注入 MANTURHUB_SOURCE、MANTURHUB_BUSINESS_CODE、MANTURHUB_SKILL_CODE、MANTURHUB_SKILL_VERSION、MANTURHUB_DISTRIBUTION_TARGET、MANTURHUB_ACCESS_MODE。显式选项优先；没有来源时识别当前宿主，普通终端为 cli，未知 Agent 为 unknown，不从安装目录推断。

确认冻结首次归因，resume 不更新来源或重新提交；旧确认标识不补历史归因。注册页面、受理/统计由服务端决定，CLI 不再次发送成功埋点。1.2.8 支持上述归因合同，接入时需配套验证后端接收和网页透传。

通过CLI启动已安装Skill时，`skill doctor/run/exec`支持`--source workbuddy|codex|claude-code`及`--business-code <调用业务>`，并把本次宿主、业务、Skill源版本、发行目标、接入方式只传给当前子进程。业务码优先级为显式参数→当前进程MANTURHUB_BUSINESS_CODE→profile默认业务码；逻辑skillCode仍取包身份，允许同一Skill被不同业务复用。例如`skill run story-studio --project ./marketing --client codex --source codex --business-code marketing-video`。控制参数放在分隔符`--`之前，之后同名参数仍属于业务输入。`--client`仅用于选择安装，不作为运行来源；未显式传source时按当前进程env和可靠宿主信号识别。WorkBuddy独立入口应明确传来源，避免普通命令环境丢失宿主。算子平台下载包的`mantur`与市场包的`standalone`标记来自profile，不能用安装目录、平台自动版本或账号注册来源替代。

执行另一个已安装Skill时，只有业务和宿主上下文沿用调用方；当前Skill的身份、源版本、发行目标和接入方式重新从当前包取得。旧profile或无profile包缺少的元数据保持未采集，不能继承上层Skill的同名值。此隔离仅作用于当前子进程，不修改父进程环境或历史确认快照。

注册的businessCode表示引导注册的产品，调用的businessCode表示本次调用业务；两者独立。业务A/B应各建项目/流程，确认令牌与恢复沿用首次归因。Skill升级或自动环境变化后，确认继续保留原版本/宿主/发行信息；原快照已记录的业务、Skill身份、流程/步骤冲突和显式改写仍拒绝。旧Skill升级后新增的控制字段若原快照未采集，则保持未采集，不阻断原确认、不回填历史；旧CLI无归因快照的令牌同样保持原请求。原输入/账号/站点/费用检查不变。
