# Open visual reference routing

## Principle

Reference images preserve visual information that prose loses: proportions, facial language, palette, material response, spatial layout, camera angle, and presentation design. Therefore the extraction model should see the full catalog, while each image-generation call should receive the smallest relevant original subset.

Do not define fixed slots such as female, male, scene 1, or four mandatory images. The user may supply any number of references with arbitrary semantic roles.

## Catalog schema

```json
{
  "version": "reference-routing-v4",
  "references": [
    {
      "reference_id": "REF-001",
      "label": "user-defined meaning",
      "note": "what to borrow or avoid",
      "local_path": "input/references/source.png",
      "public_url": "https://raw-public-image-url",
      "checksum": "sha256",
      "width": 1672,
      "height": 941,
      "visible_style_facts": ["observable fact"],
      "scope": "global"
    }
  ],
  "bindings": [
    {
      "asset_id": "CHAR-001-V01",
      "selected_reference_ids": ["REF-001", "REF-004"],
      "reference_uses": [
        {
          "reference_id": "REF-001",
          "roles": ["style", "palette", "rendering", "layout"],
          "literal_embedding": "forbidden",
          "rationale": "borrow the presentation system and lighting only"
        },
        {
          "reference_id": "REF-004",
          "roles": ["identity"],
          "literal_embedding": "forbidden",
          "rationale": "preserve the approved character identity only"
        }
      ],
      "base_asset_reference": null,
      "rationale": "why each selected reference is relevant",
      "status": "ready"
    }
  ]
}
```

## Routing rules

- Preserve user labels and notes, but verify them against pixels.
- Persist `local_path` and `base_asset_reference.local_path` as `/`-separated paths relative to the project root. Do not store an absolute path, the project directory name, or `..`.
- Pass every catalog image to asset extraction in stable order.
- Route references per asset based on semantic relevance, not array position.
- Every selected reference must have exactly one `reference_uses` entry. Allowed roles are `style / palette / material / rendering / layout / identity / wardrobe / structure`; unlabelled references block generation.
- `style / palette / material / rendering / layout` are non-content roles. They may influence visual language and presentation only; they must not transfer the source subject, character identity, clothing, props, setting, readable text, logo or narrative action.
- `identity / wardrobe / structure` permit only the named feature class. They still do not permit copying source pose, framing, background, unrelated objects, text or logos.
- Every reference use must set `literal_embedding=forbidden`. Never render a reference as a framed image, screen, poster, card, thumbnail, inset panel, split-screen source, collage element, decal or texture inside the new asset.
- Use no reference when none is relevant; do not force a match.
- Use multiple references when they contribute compatible dimensions, such as character proportions plus wardrobe material plus sheet layout.
- Reference images do not control generated canvas orientation or aspect ratio. Agent selects the image canvas per target asset according to its intended use, legibility and later shot requirements; this must not be inferred from the project's video ratio.
- `layout` may guide composition or presentation design, but is not an instruction to copy the reference canvas. A user may explicitly ask to follow a reference composition or canvas as a generation preference; it is not a Runtime aspect-ratio gate.
- Mixed landscape, portrait and square references are valid when their declared uses are compatible. Resolve only genuine identity, wardrobe, structure or visual-style conflicts; do not block merely because their dimensions differ.
- Block and ask when references conflict on a defining trait and the user did not state priority.
- Character variants include the approved base-character image as the first continuity input through `base_asset_reference`; it preserves identity and declared variant facts, not its canvas ratio. This generated base is not added to the immutable source-reference catalog, but the same project-relative file must also be the first item of the asset-operation descriptor's `references` array.
- Mixed or unspecified crowds may be generated as a group when the prompt clearly defines composition. Split by gender or another trait only when the user's references or story require it; never impose a universal gender split.

## Generation gate

Before bulk generation, verify:

1. every selected reference ID exists and has a reachable raw image URL;
2. every local path exists and checksum matches the catalog;
3. the prompt names the relevant visible traits instead of merely saying “same style”;
4. every selected reference has an explicit role and the prompt contains the guard clauses returned by `validate-references`; style-only references are described as non-content conditioning, not as objects to reproduce;
5. every reference records verified source dimensions; a character variant additionally records an integrity-checked `base_asset_reference` when it uses the approved base image;
6. the asset-operation descriptor and resulting imagegen call include only the selected original files, with the same `base_asset_reference.local_path` first when present; after stable de-duplication, descriptor `references[].path` exactly equals the routing plan's base-first path list;
7. the Agent selects and records any provider-required image size in the individual request; it must not copy a reference image or the video ratio by default;
8. visual review confirms the result does not contain a literal copy, thumbnail, frame, screen, poster, text or logo from any reference;
9. representative test images have explicit user approval.
