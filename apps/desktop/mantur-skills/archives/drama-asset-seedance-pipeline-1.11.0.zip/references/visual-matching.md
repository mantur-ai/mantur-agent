# Visual asset matching rules

## Evidence order

Use all evidence together:

1. User-declared asset ID, character name, type, and variant.
2. Canonical names, aliases, and evidence lines extracted from the script.
3. Visible pixels or video content.
4. Filename and folder naming.

A filename alone never proves identity when two script assets remain plausible.

Style references are not identity evidence unless the user explicitly identifies the depicted asset. A visual match can guide rendering style without asserting that the pictured subject is a script character.

A style reference is also not an output element. Do not treat the source image, its depicted character, its background, its props, its text or its logo as something that should appear inside the newly generated asset. Only an explicit `identity / wardrobe / structure` role permits transfer of that named feature class, and literal embedding of the source image remains forbidden.

## Match decision

Accept a match only when it is unique and has no conflicting evidence.

- `matched`: explicit metadata or a unique script candidate agrees with visible facts.
- `variant_match`: identity is known and visible state agrees with one declared variant.
- `unresolved`: multiple candidates remain, visual facts contradict metadata, or the file lacks sufficient evidence.

Do not emit artificial probability scores. Record the evidence and contradiction instead.

## Duplicate and variant handling

- Compare checksums first; identical bytes are one source file.
- Keep the clearest user-provided image when multiple files depict the same base variant.
- Do not merge materially different clothing, age, injury, disguise, or story phase.
- Do not create a variant solely because framing, pose, crop, lighting, or expression differs.
- Do not use a group image as a single-character identity asset unless the target person is explicitly and unambiguously isolated.
- Classify single-person files as character assets, not crowd assets.
- Use crowd assets only for multi-person compositions and record the visible headcount class.

## Output entry

Every resolved image entry must include:

```json
{
  "filename": "local-or-uploaded-name.png",
  "url": "https://public-object-url",
  "kind": "character",
  "asset_id": "CHAR-001",
  "canonical_name": "Name",
  "variant_id": "CHAR-001-V02",
  "variant_name": "Wardrobe or state",
  "is_base": false,
  "visual_facts": ["visible fact"],
  "applicable_episode_range": "EP11-20",
  "applicable_scenes": ["scene evidence"],
  "forbidden_tags": ["conflicting state"],
  "primary_layout_reference": "REF-001",
  "target_width": 1672,
  "target_height": 941,
  "output_width": 1672,
  "output_height": 941,
  "aspect_validation_status": "passed",
  "provenance": "user_uploaded"
}
```

Use `variant_id: null` only for a canonical base asset or a type without variants. Public URLs must be raw text, never Markdown links.

For generated assets, acceptance also requires `output_width/output_height` to match the chosen primary layout reference ratio within 1%. A visually attractive image with the wrong orientation is still rejected.

Reject generated assets that reproduce a reference as a picture-in-picture, frame, screen, poster, thumbnail, collage panel, decal or readable source text/logo. For style-only references, also reject copied source subjects, clothing, props, backgrounds or narrative actions.
