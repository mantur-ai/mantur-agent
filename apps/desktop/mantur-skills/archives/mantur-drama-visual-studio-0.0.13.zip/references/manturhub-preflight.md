# ManturHub 公共接入预检

公共预检只核查合同与诊断连接，不负责上传、提交、结果下载或报告转换。保存产物转换已由独立接入器实现；[在线资产模块](online-asset-extraction.md) 已接通 extraction 四个入口。包内 Runtime 生产流程先执行 doctor；包内 run 只返回预检与下一步建议。新 WAN v3 是独立 CLI 路线，直接核对实时 describe、上传和报价，按 [新版调用](wan-compilation-v3.md) 执行 `manturhub run` 提交，不运行包内 clips doctor 或 prepare。

## 诊断字段

- connection_ready：远端路径下，CLI 版本、环境站点、项目锁站协调与认证检查全部成功；纯原生本地路径不要求远端连接。totalBalance=0 仍是已认证，余额数字不出现在 doctor 诊断报告。费用确认时须另外执行 `query-account-balance` 并按 [报价与余额展示](quote-and-balance.md) 在聊天中展示；诊断脱敏不代表省略报价时的余额。
- contract_ready：当前阶段必需算子的实时详情及所需业务文件合同可识别。5A 已增加基于保存资料的清单/fileId 分镜窄合同；operator_contracts 单独反映外层识别。原生图像/视觉能力只跳过对应平台路径；定制音色须加 `--custom-voice`，且仅用于 asset-production。
- workflow_ready：所需本地请求构建与解析已实现；legacy、extraction、素材、clips 和 video 的已实现路径按合同开放。视频不再按正式站／开发站或平台额度核实状态阻断；video_capabilities 标记 platform_limits_required=false、platform_limits_verified=null、quota_source=skill_default、quota_coordination=agent_guidance、quota_enforcement=platform、local_shared_quota=false，表示项目内采用默认 5 条活动场次链，账号级限制由平台最终执行。实时 Schema 必须可编译，实际请求与结果在动作边界按该 Schema 校验。具体参数、清单、素材、费用与实际平台响应仍单独校验；未知 wire 响应、fileId-only 下载与固定 voice_id 合成继续阻断，不将代码就绪视为部署验收或费用批准。
- contract_profile：legacy、openapi_v1、openapi_unverified、mixed 或 unverified。mixed 不表示全部适配；逐算子诊断在 operator_contracts。
- ok：包括本地门禁在内的全部必要检查通过。任何单个 ready 字段都不能替代 ok 或用户费用批准。

`run.next_action` 失败时分别为 repair_connection_checks、review_operator_contract、complete_workflow_adapter 或 repair_failed_checks，通过时为 continue_with_skill_workflow。clip_capabilities 标记已支持 profile、未知路径和 video/deployment 未就绪，详见 [分镜接入边界](clip-compilation.md)。不要反复登录、换站、跳过检查或通过 project.json 伪造能力。

每个 online `prepare` 都必须在实际动作前重跑对应 stage 的 doctor，并同时要求 `ok=true`、`connection_ready=true`、`contract_ready=true`、`workflow_ready=true` 以及该流程要求的 `contract_profile`；不能只挑部分 ready 字段通过。prepare 返回 doctor 失败时保留安全错误码和脱敏的失败检查路径，瞬时连接错误保持 retryable 并指向原 resume，合同或 workflow 不就绪则指向对应修复动作；诊断不得包含余额、凭据、远端任务标识、签名 URL 或本地绝对路径。

素材可指定 `--stage asset-production --asset-operation image|understanding|voice-design|audio`。asset_capabilities.implemented 是包内实现范围，selected_path_ready 才是当前路径合同/实现判断；提交另需具体参数、媒体与批准。固定 voice_id 与 fileId-only 获取地址能力为 false。明确 `--native-imagegen/--native-image` 的纯原生路径不依赖 CLI、认证、`MANTURHUB_BASE` 和对应平台算子；本地路由可保持 `connection_ready=true`，不代表已验证远端连接。定制音色只检查设计算子，不强制检查音频生成。

## CLI 与站点

首次使用或 CLI 发现／版本／配置入口失败时，先执行 [CLI 检测、授权安装与复检](cli-onboarding.md)。先查现有 npm 安装和入口，不直接认定未安装；确认缺失才主动询问安装，已有有效授权不重复询问。Runtime 不执行安装，Agent 取得授权后操作；复检成功继续原步骤，不重新初始化项目或提交任务。

### 认证入口

CLI 托管上下文固定初次确认的身份摘要，每次 OpenAPI 请求发送前与返回后（包括抛错）重新读取本地认证状态及身份，核对站点、登录和算子就绪状态。身份变化返回 `ONLINE_CREDENTIAL_CHANGED`，不自动更新旧操作／报价／批准的绑定；同一账号和调用 Key 的令牌刷新不改变该摘要。检查失败保留原身份和恢复路径，恢复原身份后再继续；不能以新账号继续旧批准。独立 Runtime 包间必须保留这些安全错误码，不误报为可重试网络错误。

请求期间发现变化时不得接纳该响应或自动重放，也不能断言平台未受理；沿用原操作的受理不明保护。CLI 自身负责单次调用的账号代际检查，适配器补充调用前后复核；当前 CLI 未提供原子绑定 expected identity 的接口，因此该复核不承诺消除外部并发切号的所有时间窗口。生产期间保持 CLI 身份稳定，不由 Skill 导出凭据或替换 CLI 的全局传输实现。

新项目在初始化时按 [账号检查与登录确认](cli-onboarding.md#初始化账号检查与登录确认) 提前只读检查；已有有效认证直接复用，需要登录或补齐授权时先征得用户同意，再使用 `manturhub auth login --workbuddy`，不等首次上传才检查。CLI 1.2.5 及以上会保存账号会话并准备有期限的算子身份。Skill 在未设置 `MANTURHUB_KEY` 时通过已验证 CLI 包内的 `authStatus()`、`identityBinding()` 和 `apiFetch()` 复用该身份，只取得不可逆身份摘要并让 CLI 托管请求，不读取 `client-credentials-v2.sqlite`、旧 `config.json` 或明文算子 Key，也不提供“导出 Key”恢复步骤。自动化环境可显式注入 `MANTURHUB_KEY`，此路径优先且不加载 CLI 私有认证模块；不得在聊天粘贴密钥。

CLI 托管 JSON 请求由 `apiFetch()` 唯一设置 `Content-Type`；适配器不区分大小写过滤调用方的该请求头，避免重复合并为 `application/json, application/json`。显式 Key 直连仍由 Runtime 设置 JSON 类型，对象存储 PUT 仍保留上传槽位所需的文件 MIME 类型；认证头禁传、业务头白名单和 POST 不自动重试规则不变。

doctor 先运行本地 `manturhub auth status --json`，要求 `authenticated=true`、`operatorReady=true` 且 `baseUrl` 与锁定站点一致，再执行余额与合同读取；实际生产复用同一个认证上下文。算子身份尚未就绪返回 `MANTURHUB_OPERATOR_KEY_NOT_READY` 并引导重新执行上述 workbuddy 登录；凭据库不可访问返回 `MANTURHUB_AUTH_STORE_UNAVAILABLE`。有效 `totalBalance`（含 0）仍证明远端认证可用，不要求 email。权限、网络、503 与响应不兼容分别诊断，不一律要求重新登录。凭据及账号不得写入项目、Skill、命令参数文件、日志、Manifest 或快照；本地查看、媒体检查、快照和只读服务不需要登录。

### CLI 解析与项目锁站

支持稳定版 >=0.10.0 和精确的 `0.9.10-dev.20260810.9`；拒绝未知预发布版，完整保留 prerelease 标识。该全局下限只保证显式 `MANTURHUB_KEY` 路径；复用浏览器登录必须是稳定版 CLI >=1.2.5 且三个私有模块能力探测通过。有效 MANTURHUB_CLI_ENTRY 优先，否则从 PATH/npm Windows shim 解析 Node 入口；不拼接 shell 命令。认证适配器把 CLI 私有模块视为受控临时接口：每次校验真实路径、包名、精确版本和函数能力，任何漂移返回 `CLI_AUTH_ADAPTER_UNAVAILABLE` 并在发网前失败关闭。

Skill 入口优先采用显式 `MANTURHUB_BASE`；未设置时通过已解析的 CLI Node 入口定位同包 `package.json` 与 `lib/config.js`，校验包名和受支持版本后在当前进程直接调用 `getBaseUrl()`。因此 CLI 自己决定配置和版本通道默认值，Skill 不复制默认域名、不读取安装记录，也不向用户询问站点。Skill 只保留返回的站点及来源标记，不输出配置或 Key。规范化后的同一 HTTPS origin 传给 CLI 子进程和 Skill 直连请求；路径、凭证、查询或 fragment 均返回 `MANTURHUB_ENVIRONMENT_INVALID`。CLI 私有入口、包身份或 `getBaseUrl()` 不可用时返回 `CLI_BASE_URL_UNAVAILABLE`，在网络前停止。

新项目在写 `project.json` 前运行 `resolve-manturhub-environment`，离线取得 `manturhub_base` 与 `source=environment|cli_getBaseUrl`。`doctor` 同样返回 `manturhub_base_source` 和 `project_site_status`：`current` 表示当前解析站点与项目锁站一致；`unbound` 表示项目尚无锁站；`rebindable` 表示不同站但不存在任何远端血缘；`conflict_remote_lineage` 表示不同站且已有远端身份或付费/提交证据。`doctor` 不改项目。`unbound/rebindable` 项目在首次远端 `prepare-*` 前写入当前解析站点、真实来源和私有审计收据并刷新快照；`conflict_remote_lineage` 的所有远端动作返回 `MANTURHUB_SITE_CONFLICT`。本地快照、媒体检查和导出不受影响。不提供跨站迁移。

### OpenAPI 双域名路由

兼容策略仅允许现有两个开发 API origin 互相配合，不要求调用地址与入口 BASE 同源；这项白名单不参与当前入口站点选择。显式 `MANTURHUB_KEY` 可继续用于这两个开发域间的受控双域请求；CLI 托管身份严格限制在其 `baseUrl` 同源 `/api/openapi/v1/**`，开发域返回另一开发域地址时返回 `MANTURHUB_DEV_CROSS_ORIGIN_KEY_REQUIRED`，不得从 CLI 私有库导出 Key。任意其他合法 `MANTURHUB_BASE` 只允许同源平台请求，跨域一律 `MANTURHUB_SITE_CONFLICT`。上传申请/确认及详情读取保留 BASE。报价优先使用详情的合法 quoteUrl（目标算子的 quote/precharge 路径），字段缺失才用 BASE 下 precharge；提交使用合法 invokeUrl，查询使用合法 pollUrl。字段存在但非法直接阻断，不回退。

地址仍须 HTTPS、无 URL 用户名/密码及查询/fragment，并匹配目标算子或原 Job；不自动跟随认证请求重定向。任意返回域名不能扩展授权集合。对象存储仅匿名下载或按上传槽位必要头 PUT，不携带平台 Key。

实际采用地址只保存在 Runtime 私有操作记录，恢复沿用原地址、请求和幂等键。旧记录缺少路由字段时保留原 BASE 路径；已有保存地址仍须校验，不自动换站重提。此路由规则不因视频额度改为非阻断信息而放宽，不改变同源／开发双域名凭据边界，也不允许换站、换请求或换幂等键重提。

## 合同识别与证据边界

新详情接受一致的 apiCode/operatorCode（兼容 id），多个身份字段冲突直接拒绝。缺旧 status 不代表离线；明确不可用状态仍拒绝。inputSchema/outputSchema 必须是合法、可编译的对象 JSON Schema。预检不比较打包指纹、不检查 `apiVersion`、业务 `v2/v3` 标签、checker 版本或 legacy 最低版本，也不以本地代表性样例决定兼容。实际请求在报价／提交前按本次实时 inputSchema 校验，实际结果按提交时保存的 outputSchema 和本地业务解析器校验；字段、枚举或条件不满足时在具体动作边界返回对应错误。

legacy 只核对 id、明确可用状态与当前动作需要的结构化字段；不比较算子业务版本。reference_images/referenceImages 检查结构化数组字段，不搜索描述文字。单次预检缓存同一算子详情，不重复请求。查询失败不使用旧证据冒充实时通过。

八个生产算子的外层请求和结果均使用实时 Schema；视频仅保留[分辨率合同](video-resolution.md)中既有的 Seedance 1080p 局部枚举例外，WAN 不扩展。资产和分镜 PRIMARY_JSON 的真实保存资料继续执行受控结构、语义、血缘和媒体完整性校验。包内不再携带任何算子指纹白名单；兼容保留的旧 `manturhub-profiles.json` 文件名即使存在，也不含算子摘要且运行时不读取。

每次操作仍把算子 ID、实际输入／输出 Schema 摘要和完整 Schema 快照保存为不可变私有合同收据，用于证明同一请求、结果和恢复链路，不能作为“已知版本”白名单。准备、报价和首次提交分别读取实时合同；只要已保存请求仍符合实时 Schema 且最新报价摘要不变即可继续，并追加新收据。报价改变沿用原批准失效机制。提交后的输出使用提交时收据中的输出 Schema 和本地业务解析器双重校验，不用后来变化的实时 Schema。旧未提交操作在下次动作补建收据；没有提交时快照的旧已提交操作只记录兼容恢复收据，不冒充历史提交证据。

已知后续适配重点：资产提取改 scriptFileId；Seedance 分镜按独立实时契约准备；新wan仅提交 scriptFileId 与 productionAssetManifestFileId，完整资产表格式为 drama.production-asset-table.v3（见 [新版调用](wan-compilation-v3.md)）；文件须 upload/PUT/confirm 后 AVAILABLE；新结果在 Job.output，视频为 videos[] 与 lastFrame。以上仅用于说明阻断原因，不能把旧 URL 清单当新 Manifest 或把新 Job 喂给旧 Task 解析器。音频 text_prompt 不支持顶层 voice_id，需另核实定制音色复用链路。分镜与视频本地最高 1080p，2k 禁止提交且不可静默转换，AI 直出默认值不能替代项目批准。

## 错误与重试

401 → MANTURHUB_AUTH_REQUIRED；operatorReady=false → MANTURHUB_OPERATOR_KEY_NOT_READY；认证库访问失败 → MANTURHUB_AUTH_STORE_UNAVAILABLE；CLI 私有能力不兼容 → CLI_AUTH_ADAPTER_UNAVAILABLE；开发双域无显式 Key → MANTURHUB_DEV_CROSS_ORIGIN_KEY_REQUIRED；403 → MANTURHUB_FORBIDDEN；503 等 → MANTURHUB_SERVICE_UNAVAILABLE；超时/网络/损坏 JSON 单独诊断。仅认证错误提示在锁定环境执行 `manturhub auth login --workbuddy`；503 不要求登录。报告不输出 CLI 路径、响应正文、账号信息、密钥或完整远端 URL。

CLI 托管 `apiFetch` 的只读 GET 最多两次底层传输尝试，作为一次逻辑查询；POST 上传申请、确认、报价和提交只有一次，不由 Skill 自动重试。适配器拿不到 `Retry-After` 时保留安全默认轮询间隔，不立即重试。旧 CLI balance/describe 诊断也只允许既有的有限只读重试；不无限等待、不重试生产提交。查看本地快照、媒体和看板不要求 CLI/登录，也不会触发这些网络诊断。

## 新wan预检入口

新wan 使用 [CLI 调用流程](wan-compilation-v3.md)，直接核对实时 Schema。包内 clips 阶段预检/请求构造仍按旧契约，不用于提交新wan，也不修改其状态来强行放行；成功产物按新版调用文档使用含 `production_asset_table` 的结构化描述文件同步看板，描述中的版本标签不参与路由或兼容判定。其余模型和历史项目按原合同处理。
