import {createSnapshotSync,createRemoteRefresh,remoteSyncText,reconcile} from './sync.js';
import {feeLines,assetOperation,highlightPresentation,packagingLines,timelineLegend,analysisTimeline,balancePresentation,sortAnalysisOperations,submissionPresentation,highlightSelectionNote,qaLines,productionModePresentation,frontEmptyPresentation,resultGroups,frontRecordPresentation,operationProgressText as baseOperationProgressText,mediaAvailability,recordedPackagingLines,highlightSourceText,logoPlacementText} from './presentation.js';
let snapshot=null, tab='assets',userSelectedTab=false,resultFilter='all',frontFilter='all';
const $=s=>document.querySelector(s);
const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
const time=n=>{if(!Number.isFinite(n))return '—';return `${Math.floor(n/60).toString().padStart(2,'0')}:${(n%60).toFixed(2).padStart(5,'0')}`;};
const stateNames={not_prepared:'待裁剪',prepared:'等待制作',unknown:'等待核实',running:'制作中',remote_succeeded:'等待下载',artifact_pending:'等待恢复下载',qa_failed:'待修复验收',succeeded:'已完成',failed:'制作失败',rejected:'未受理'};
const roleNames={episode:'原始剧集',ending:'尾贴',logo:'Logo',reference:'参考视频',front:'前贴素材',result:'成片'};
const findAsset=id=>snapshot.assets.find(a=>a.id===id);
function empty(title,body){const n=el('div',undefined,'empty');n.append(el('strong',title),el('div',body));return n;}
function badge(status){return el('span',stateNames[status]||status,`badge ${status==='succeeded'?'success':status==='failed'||status==='qa_failed'?'failure':''}`);}
function submissionStatus(op,status=op?.status||'prepared'){
  const row=el('div',undefined,'operation-meta'),shown=submissionPresentation(op);
  const submitted=el(shown.dateTime?'time':'span',shown.text,'submission-time');submitted.title=shown.title;if(shown.dateTime)submitted.dateTime=shown.dateTime;
  row.append(submitted,badge(status));return row;
}
function player(asset,start=0,end=null,legacy=false){const frame=el('div',undefined,'screen');const local=mediaAvailability(asset);if(!local.available){frame.append(el('p',local.message,'media-unavailable'));return frame;}
  const image=asset.role==='logo', v=el(image?'img':'video');v.src=asset.mediaUrl;v.dataset.mediaKey=`${asset.id}|${asset.mediaUrl}|${start}|${end}`;
  if(image)v.alt=asset.name||'水印预览';else{v.controls=true;v.preload='metadata';v.playsInline=true;v.setAttribute('aria-label',asset.name||'视频预览');
    if(legacy){v.setAttribute('controlsList','nodownload');v.addEventListener('contextmenu',e=>e.preventDefault());}
    const clamp=()=>{if(end!==null&&v.currentTime>=end){v.pause();v.currentTime=Math.max(start,end-.01);}};
    v.addEventListener('loadedmetadata',()=>{if(start>0)v.currentTime=start;});
    v.addEventListener('timeupdate',clamp);v.addEventListener('seeking',()=>{if(v.currentTime<start)v.currentTime=start;clamp();});
    v.addEventListener('play',()=>{if(end!==null&&v.currentTime>=end-.05)v.currentTime=start;});
  }
  v.addEventListener('error',()=>{const parent=v.closest('.screen');if(parent&&!parent.querySelector('.media-error'))parent.append(el('div','视频或图片暂不可用。请在聊天中恢复下载后刷新。','media-error'));});frame.append(v);return frame;
}
function download(asset,label='下载文件 ↗'){const a=el('a',label,'download');a.href=`${asset.mediaUrl}?download=1`;a.download='';return a;}
function actions(...items){const row=el('div',undefined,'card-actions');row.append(...items);return row;}
function operationProgressText(op,current=true){return op?.status==='rejected'?'本次请求未受理；请在聊天中修正原因，并决定是否发起新调用。':baseOperationProgressText(op,current);}
function fees(op){const d=el('div',undefined,'fees');if(op?.status==='rejected'){d.append(el('p','本次请求未受理；实际账务未记录。','muted'));return d;}for(const text of feeLines(op))d.append(el('p',text,'muted'));for(const text of qaLines(op))d.append(el('p',text,'qa-note'));return d;}
function appendFrontStyle(container,op){
  if(op?.frontStyle?.name)container.append(el('p',`前贴视觉风格：${op.frontStyle.name}`,'muted'));
  const size=op?.frontSize;
  if(size){const dimensions=size.expectedWidth&&size.expectedHeight?`${size.expectedWidth} × ${size.expectedHeight} · `:'';container.append(el('p',`前贴生成目标：${dimensions}${size.resolution} · ${size.ratio} · ${size.policy==='follow_body'?'跟随正片':'用户指定'}${dimensions?'':'（实际尺寸以生成结果为准）'}`,'muted'));}
}
function timeline(o){const box=el('div'),segments=o.segments||[];const segmentTitle=s=>s.kind==='front'?'前贴':s.kind==='ending'?'尾贴':Number.isFinite(s.episode)?`第 ${s.episode} 集`:'正片（集号未记录）';
  const timed=segments.length&&segments.every(s=>Number.isFinite(s.outputStart)&&Number.isFinite(s.outputEnd)&&s.outputEnd>s.outputStart);
  if(timed){const line=el('div',undefined,'timeline');line.setAttribute('aria-label','素材拼接时间线');for(const s of segments){const title=segmentTitle(s),part=el('div',title,`segment ${s.kind}`);part.style.flexGrow=Math.max(.01,s.outputEnd-s.outputStart);part.style.flexBasis='0';part.title=`${title} · 源 ${time(s.start)}–${time(s.end)} · 成片 ${time(s.outputStart)}–${time(s.outputEnd)}`;line.append(part);}box.append(line);const marks=el('div',undefined,'timeline-labels');marks.append(el('span','00:00.00'),el('span',time(o.duration||segments.at(-1)?.outputEnd)));box.append(marks);}
  else if(segments.length)box.append(el('p','部分时间信息未记录，已保留下面的拼接顺序。','muted'));
  const legend=el('div',undefined,'legend');for(const [kind,title] of timelineLegend(o))legend.append(el('span',title,kind));box.append(legend);
  const details=el('details'),summary=el('summary','查看素材时间与拼接顺序');details.append(summary);const list=el('ol',undefined,'segment-list');
  const rows=segments.length?segments:(o.body||[]).map(s=>({...s,kind:'episode'}));
  for(const s of rows){const item=el('li');item.append(el('span',segmentTitle(s)),el('time',`${time(s.start)} → ${time(s.end)}`));list.append(item);}details.append(list);if(!rows.length)details.append(el('p','素材区间未记录。','muted'));box.append(details);return box;
}
function planFacts(plan,op){const d=el('div',undefined,'plan-facts');if(plan.canvas?.width&&plan.canvas?.height)d.append(el('p',`输出尺寸 ${plan.canvas.width} × ${plan.canvas.height} · ${plan.canvas.fps} fps`,'muted'));for(const text of packagingLines(plan.packaging))d.append(el('p',text,'muted'));const logoText=logoPlacementText(plan);if(logoText)d.append(el('p',logoText,'muted'));if(op){d.append(fees(op));if(op.errorMessage)d.append(el('p',op.errorMessage,'muted'));}return d;}
function planCards(){const cards=el('div');let count=0;for(const plan of snapshot.plans){for(const output of plan.outputs){count++;const op=snapshot.operations.find(o=>o.id===output.operationId);const card=el('article',undefined,'card'),head=el('div',undefined,'card-head'),heading=el('div');card.dataset.nodeKey=`output:${output.operationId||output.id||count}`;heading.append(el('h3',output.label||`成片 ${count}`),el('small',output.duration?`成片时长 ${time(output.duration)}`:'待确认时长'));head.append(heading,submissionStatus(op));card.append(head);
    const detail=el('div',undefined,'detail');if(plan.intent)detail.append(el('p',plan.intent,'muted'));detail.append(el('h4','合成前核对'));
    for(const body of output.body||[])detail.append(el('p',`接第 ${body.episode} 集：${time(body.start)} → ${time(body.end)}${body.start===0?'（从片头开始）':''}`,'body-review'));
    detail.append(timeline(output),planFacts(plan,op));const f=output.front;if(f?.highlightId){const h=snapshot.highlights.find(h=>h.id===f.highlightId);if(h)detail.append(el('p',`高光前贴：第 ${h.episode} 集 ${time(h.start)}–${time(h.end)}`,'muted'));}else if(f?.assetId)detail.append(el('p',`前贴：${findAsset(f.assetId)?.name||'已选前贴'}`,'muted'));
    const change=el('button','复制修改这条计划的请求','guidance-choice');change.type='button';change.addEventListener('click',()=>copyGuidanceReply(`请修改当前计划“${output.label||output.id||count}”（计划 ${output.id||plan.id}）：先让我选择接续集数、起止时间、尺寸及尾贴水印；保留已完成前贴，只重新准备受影响的合成并报价，先不要制作。`));detail.append(change,el('p','这里只复制请求，请回到聊天发送；不提交制作或确认费用。','muted'));card.append(detail);cards.append(card);}}
  if(!count)cards.append(empty('还没有剪辑计划','告诉 Agent 从哪一集、哪一秒开始，以及希望怎样续接。'));return cards;
}
function historyFilters(kind,value,labels){const row=el('div',undefined,'history-filters');row.dataset.nodeKey=`${kind}-filters`;row.setAttribute('aria-label',kind==='result'?'筛选成片范围':'筛选前贴范围');for(const [key,label] of labels){const button=el('button',label,'scope-filter');button.type='button';button.dataset.historyFilter=kind;button.dataset.value=key;button.setAttribute('aria-pressed',String(value===key));row.append(button);}return row;}
function operationDetails(operationId){const details=el('details',undefined,'record-details');details.dataset.nodeKey=`record-detail:${operationId}`;details.append(el('summary','查看制作记录'),el('p',`制作记录：${operationId}`,'record-id'),el('p',snapshot.operations.find(o=>o.id===operationId)?.status==='rejected'?'本次请求未受理，请在聊天中核对原因；继续须修正并决定是否发起新调用。':'需要恢复时，把此制作记录告诉助手，优先恢复原产物。','muted'));return details;}
function resultCards(){
  const box=el('div',undefined,'result-browser');
  const all=snapshot.allResultCount??snapshot.currentResultCount??0,current=snapshot.currentResultCount??0,history=snapshot.historicalResultCount??Math.max(0,all-current);
  const summary=el('p',`制作成功 ${all} 条 · 当前计划 ${current} 条 · 历史 ${history} 条`,'result-summary');summary.dataset.nodeKey='result-summary';box.append(summary,historyFilters('result',resultFilter,[['all','全部成片'],['current','当前计划'],['history','历史成片']]));
  // The server owns history association and deduplication; this fallback keeps old snapshots readable.
  const records=snapshot.resultRecords??snapshot.plans.flatMap(plan=>plan.outputs.map(output=>({operationId:output.operationId,id:output.operationId,current:true,groupId:'current',groupLabel:'当前计划',groupOrder:0,plan,output,detailAvailable:true,submission:snapshot.operations.find(op=>op.id===output.operationId)?.submission})));
  const groups=resultGroups(records,resultFilter);
  for(const group of groups){
    const section=el('section',undefined,'result-group');section.dataset.nodeKey=`result-group:${group.id}`;
    const title=el('div',undefined,'history-heading');title.append(el('h3',group.label),el('span',`${group.records.length} 条制作记录`,'muted'));section.append(title);
    for(const record of group.records){
      const op=snapshot.operations.find(o=>o.id===record.operationId),asset=findAsset(record.assetId||op?.assetId),output=record.output,plan=record.plan;
      const card=el('article',undefined,'card result-card'),head=el('div',undefined,'card-head'),heading=el('div');card.dataset.nodeKey=`output:${record.operationId||record.id}`;
      heading.append(el('h3',output?.label||op?.label||asset?.name||'成片记录'),el('small',`${record.current?'当前计划':'历史记录'}${output?.duration?` · ${time(output.duration)}`:''}`));head.append(heading,submissionStatus(op));card.append(head);
      const body=el('div',undefined,'review'),info=el('div',undefined,'review-info');
      body.append(asset?player(asset):empty(op?.status==='succeeded'?'原任务已完成，产物待恢复':'成片尚未就绪',operationProgressText(op,record.current)));
      if(output){info.append(el('h3','这一条怎样拼接'),timeline(output));}
      for(const text of recordedPackagingLines(plan))info.append(el('p',text,'muted'));
      if(plan?.intent)info.append(el('p',plan.intent,'muted'));
      if(plan?.canvas?.width&&plan.canvas?.height)info.append(el('p',`成片尺寸 ${plan.canvas.width} × ${plan.canvas.height}${plan.canvas.fps?` · ${plan.canvas.fps} fps`:''}`,'muted'));
      const logoText=logoPlacementText(plan);if(logoText)info.append(el('p',logoText,'muted'));
      if(op){info.append(fees(op));if(op.hasError)info.append(el('p',op.errorMessage,'muted'));if(op.status==='prepared')info.append(el('p',operationProgressText(op,record.current),'muted'));}
      if(asset&&mediaAvailability(asset).available)info.append(download(asset,'下载成片 ↗'));
      if(record.operationId)info.append(operationDetails(record.operationId));
      body.append(info);card.append(body);section.append(card);
    }
    box.append(section);
  }
  if(!groups.length)box.append(empty(resultFilter==='history'?'还没有历史成片':resultFilter==='current'?'当前计划还没有成片记录':'还没有成片','切换展示范围可查看已有记录；制作仍通过聊天按当前计划执行。'));
  return box;
}
function assetCard(a,record=(snapshot.frontRecords||[]).find(row=>row.assetId===a.id)){
  const card=el('article',undefined,'card'),view=frontRecordPresentation(record);card.dataset.nodeKey=record?.operationId?`front-operation:${record.operationId}`:`asset:${a.id}`;card.append(player(a));
  const head=el('div',undefined,'card-head'),d=el('div');d.append(el('h3',a.name||roleNames[a.role]),el('small',`${a.role==='front'?view.kind:roleNames[a.role]}${a.episode?` · 第 ${a.episode} 集`:''}`));head.append(d);
  const op=record?.operationId?snapshot.operations.find(o=>o.id===record.operationId):assetOperation(a,snapshot.operations);if(op)head.append(submissionStatus(op));card.append(head);
  const detail=el('div',undefined,'detail'),metrics=el('div',undefined,'metrics');if(a.duration)metrics.append(el('span',time(a.duration)));const width=a.displayWidth||a.width,height=a.displayHeight||a.height;if(width&&height)metrics.append(el('span',`${width} × ${height}`));detail.append(metrics);
  if(a.role==='front'&&record){detail.append(el('p',view.usage,`front-usage ${view.current?'current':'historical'}`));if(record.kind==='highlight'){const h=record.highlight;detail.append(el('p',highlightSourceText(h),'clip-caption'));if(h?.reason)detail.append(el('p',h.reason,'muted'));}}
  if(mediaAvailability(a).available)detail.append(download(a,a.role==='front'&&record?.kind==='highlight'?'下载高光片段 ↗':'下载文件 ↗'));
  if(op){appendFrontStyle(detail,op);detail.append(fees(op),operationDetails(op.id));}else if(a.role==='front')detail.append(el('p','复用已有前贴 · 本项目未发起生成；历史费用未记录。','muted'));
  card.append(detail);return card;
}
function analysisRecords(detail){
  const box=el('section',undefined,'analysis-records');box.setAttribute('aria-label','本集高光分析结果');
  const messages={pending:'本集分析尚未完成，详细记录会随原任务状态自动更新。',invalid:'分析结果格式或时间区间需要核对，请让助手查看原任务；不会自动重新分析。',unavailable:'没有可追溯的详细分析记录，已保留原任务与已选片段，请在聊天中核对。'};
  if(!detail||detail.detailStatus!=='ready'){box.append(el('p',messages[detail?.detailStatus]||messages.unavailable,'analysis-note'));return box;}
  const records=detail.records||[];
  box.append(el('h4','本集高光候选'),el('p',`${records.length} 条候选 · 已选 ${detail.selectedCount??0} 条${detail.sourceDuration?` · 原片 ${time(detail.sourceDuration)}`:''}`,'analysis-summary'));
  if(detail.excludedCount>0)box.append(el('p',`已排除 ${detail.excludedCount} 条区间、时长或评分不符合要求的候选，原分析记录保留；不会自动重分析。`,'analysis-note'));
  if(!detail.current)box.append(el('p','历史分析记录，本次未选用。','analysis-note'));
  if(detail.criteriaStatus==='recorded')box.append(el('p',`当次时长筛选：${detail.minDuration}–${detail.maxDuration} 秒。`,'analysis-note'));
  else if(detail.criteriaStatus==='legacy_unrecorded')box.append(el('p',detail.recordSource==='output'?'未记录当次筛选条件，以下为原始返回记录，不代表当时全部候选。':'未记录当次筛选条件，以下仅显示已保存候选。','analysis-note'));
  if(detail.recordSource==='legacy_saved')box.append(el('p','仅展示旧项目已保存且能追溯来源的记录，可能不是完整分析结果。','analysis-note'));
  else if(detail.recordSource==='output')box.append(el('p','这是原分析任务返回的区间记录，候选选择仍由助手按你的要求保存。','analysis-note'));
  if(!records.length){box.append(el('p',detail.criteriaStatus==='legacy_unrecorded'?'没有可显示的有效分析记录。':'本集在约定范围内没有有效高光记录。','analysis-note'));return box;}
  const placement=analysisTimeline(detail),figure=el('figure',undefined,'analysis-figure');
  if(placement.scale){
    const chart=el('div',undefined,'analysis-chart');chart.style.height=`${placement.lanes*32+4}px`;chart.setAttribute('role','img');chart.setAttribute('aria-label',`第 ${detail.episode} 集原片时间轴，${records.length} 条记录，已选 ${detail.selectedCount??0} 条。具体区间见下方表格。`);
    for(let lane=0;lane<placement.lanes;lane++){const track=el('div',undefined,'analysis-track');track.style.top=`${lane*32+4}px`;track.style.width=`${placement.sourceWidth??100}%`;chart.append(track);}
    for(const segment of placement.segments){const block=el('span',String(segment.number),`analysis-block ${segment.selected?'selected':'reserve'}`);block.style.left=`${segment.left}%`;block.style.width=`${segment.width}%`;block.style.top=`${segment.lane*32+4}px`;block.title=`本集记录 ${segment.number} · ${time(segment.start)}–${time(segment.end)} · ${segment.selected?'已选':'备选'}`;block.setAttribute('aria-hidden','true');chart.append(block);}
    const axis=el('div',undefined,'analysis-axis');axis.setAttribute('aria-hidden','true');for(const tick of placement.ticks){const mark=el('span',`${Math.round(tick.value*10)/10}s`);mark.style.left=`${tick.left}%`;axis.append(mark);}
    const legend=el('figcaption',undefined,'analysis-legend');legend.append(el('span','已选（用于裁剪）','selected'),el('span','备选（尚未选用）','reserve'));figure.append(chart,axis,legend);box.append(figure);
  }else box.append(el('p','原片时长信息不足，暂不绘制时间轴；详细记录仍在下方。','analysis-note'));
  const table=el('table',undefined,'analysis-table'),caption=el('caption',`第 ${detail.episode} 集高光候选详情`),thead=el('thead'),head=el('tr');
  for(const title of ['编号','区间 / 时长','分析内容','评分 / 状态']){const th=el('th',title);th.scope='col';head.append(th);}thead.append(head);table.append(caption,thead);const tbody=el('tbody');
  for(const record of records){const row=el('tr',undefined,record.selected?'analysis-row-selected':'');row.dataset.nodeKey=`analysis-record:${record.id}`;
    const number=el('th',String(record.number),'analysis-number');number.scope='row';const interval=el('td',undefined,'analysis-interval');interval.append(el('span',`${time(record.start)}–${time(record.end)}`),el('small',`${Math.round(record.duration*100)/100} 秒`));
    const content=el('td',record.reason||'暂无内容说明','analysis-reason'),status=el('td',undefined,'analysis-record-status');status.append(el('span',Number.isFinite(record.score)?`评分 ${record.score}`:'评分未提供'),el('span',record.selected?'已选':'备选',`analysis-selection ${record.selected?'selected':'reserve'}`));row.append(number,interval,content,status);tbody.append(row);
  }
  table.append(tbody);box.append(table,el('p','更换时告诉助手“第几集、记录几”，并带上时间区间。这里只展示分析记录，不会额外裁剪备选片段。','analysis-help'));return box;
}
function analysisCard(op){
  const card=el('article',undefined,'card analysis-card'),head=el('div',undefined,'card-head');card.dataset.nodeKey=`operation:${op.id}`;
  head.append(el('h3',op.label||`第 ${op.analysisDetail?.episode??''} 集高光分析`),submissionStatus(op));card.append(head);const detail=el('div',undefined,'detail');
  const historicalPrepared=op.analysisDetail?.current===false&&op.status==='prepared';
  if(historicalPrepared)detail.append(el('p','历史待提交计划，已不在本次分析范围中，不会自动新建分析任务。','analysis-note'));
  if(op.hasError)detail.append(el('p',op.errorMessage,'analysis-note'));detail.append(fees(op));if(!historicalPrepared)detail.append(analysisRecords(op.analysisDetail));card.append(detail);return card;
}
function frontPendingCard(record){
  const op=snapshot.operations.find(o=>o.id===record.operationId),view=frontRecordPresentation(record),card=el('article',undefined,'card'),head=el('div',undefined,'card-head');card.dataset.nodeKey=`front-operation:${record.operationId||record.id}`;
  head.append(el('h3',op?.label||view.kind),submissionStatus(op));card.append(head);const detail=el('div',undefined,'detail');
  detail.append(el('p',`${view.kind} · ${view.usage}`,`front-usage ${view.current?'current':'historical'}`));
  if(record.highlight){const h=record.highlight;detail.append(el('p',highlightSourceText(h),'clip-caption'));}
  appendFrontStyle(detail,op);detail.append(el('p',operationProgressText(op,view.current),'muted'));if(op?.hasError)detail.append(el('p',op.errorMessage,'muted'));if(op)detail.append(fees(op),operationDetails(op.id));card.append(detail);return card;
}
function selectedHighlightCard(h,summary){
  const shown=highlightPresentation(h,snapshot.assets),clip=findAsset(h.clipAssetId),media=shown.media||clip,{start,end,legacy}=shown;
  const downloadUrl=mediaAvailability(media).available?shown.downloadUrl:null;
  const op=snapshot.operations.find(o=>o.id===h.clipOperationId)||(media?assetOperation(media,snapshot.operations):null);
  const card=el('article',undefined,'card');card.dataset.nodeKey=h.clipOperationId?`front-operation:${h.clipOperationId}`:`highlight:${h.id}`;
  const needsRecovery=op?.status==='succeeded'&&!downloadUrl;
  const pendingTitle=needsRecovery?'高光原产物待恢复':({running:'高光片段制作中',unknown:'高光任务待核对',remote_succeeded:'高光片段待下载',artifact_pending:'高光片段待恢复下载',qa_failed:'高光片段待修复验收',failed:'高光制作失败'}[op?.status]||'高光片段待裁剪');
  card.append(media?player(media,start,end,legacy):empty(pendingTitle,op?operationProgressText(op,true):'已选定此高光，在聊天中继续裁剪后即可播放。'));
  const d=el('div',undefined,'detail');d.append(el('h3',`第 ${h.episode} 集 · 高光选定`),el('p',`${time(h.start)} — ${time(h.end)}`,'clip-caption'),el('p',h.reason||'选定高光片段','muted'));
  if(!legacy){const status=el('div',undefined,'card-status');status.append(submissionStatus(op,downloadUrl?'succeeded':h.clipStatus||'not_prepared'));d.append(status);}
  else d.append(el('p','这是原片区间预览，不是独立高光文件。已隐藏原片下载入口以避免误下载整集。','muted'));
  if(!downloadUrl&&!needsRecovery)d.append(el('p',op?operationProgressText(op,true):`请在聊天中让 Agent 裁剪已选的 ${summary?.selected??snapshot.highlights.length} 条高光，确认费用后再执行；完成后可下载独立片段。`,'muted'));
  if(op)d.append(fees(op),operationDetails(op.id));
  if(mediaAvailability(media).available){const b=el('button','重播这个高光','preview-button');b.dataset.start=String(start);d.append(actions(...(downloadUrl?[b,download(media,'下载高光片段 ↗')]:[b])));}
  card.append(d);return card;
}
function frontCards(){
  const box=el('div'),currentGrid=el('div',undefined,'grid'),historyGrid=el('div',undefined,'grid'),summary=snapshot.highlightSummary;
  currentGrid.dataset.nodeKey='current-front-grid';historyGrid.dataset.nodeKey='history-front-grid';
  if(snapshot.frontStyleDecision)box.append(el('p',snapshot.frontStyleDecision.mode==='uniform'?'当前新生成前贴：统一视觉风格；历史前贴保留原有风格。':'当前新生成前贴：分别指定视觉风格；历史前贴保留原有风格。','muted'));
  if(summary){box.append(el('p',`高光选定 · 目标 ${summary.requested} 条 / 当前已选 ${summary.selected} 条 / 片段就绪 ${summary.ready} 条`,'muted'));const note=highlightSelectionNote(summary);if(note)box.append(el('p',note,'muted'));}
  box.append(historyFilters('front',frontFilter,[['all','全部前贴'],['current','当前前贴'],['history','历史与未采用']]));
  const usedOperations=new Set();
  for(const h of snapshot.highlights){if(h.clipOperationId)usedOperations.add(h.clipOperationId);if(frontFilter!=='history')currentGrid.append(selectedHighlightCard(h,summary));}
  const records=snapshot.frontRecords??snapshot.assets.filter(a=>a.role==='front').map(a=>({id:a.id,assetId:a.id,operationId:assetOperation(a,snapshot.operations)?.id,kind:assetOperation(a,snapshot.operations)?.stage==='highlights'?'highlight':assetOperation(a,snapshot.operations)?'generated':'imported',currentRequest:true}));
  for(const record of records){
    if(record.operationId&&usedOperations.has(record.operationId))continue;
    const view=frontRecordPresentation(record);if(frontFilter==='current'&&!view.current||frontFilter==='history'&&view.current)continue;
    const asset=findAsset(record.assetId),card=asset?assetCard(asset,record):frontPendingCard(record);(view.current?currentGrid:historyGrid).append(card);
  }
  if(!snapshot.frontRecords)for(const op of snapshot.operations.filter(o=>o.stage==='fronts'&&!findAsset(o.assetId)))currentGrid.append(frontPendingCard({id:op.id,operationId:op.id,kind:'generated',currentRequest:true}));
  for(const [key,title,grid] of [['current','当前前贴与选定高光',currentGrid],['history','历史与未采用前贴',historyGrid]])if(grid.children.length){const section=el('section',undefined,'front-group');section.dataset.nodeKey=`front-group:${key}`;section.append(el('h3',title,'history-heading'),grid);box.append(section);}
  const analyses=sortAnalysisOperations(snapshot.operations.filter(o=>o.stage==='analysis'));
  if(!currentGrid.children.length&&!historyGrid.children.length){if(frontFilter==='all'&&!analyses.length){const view=frontEmptyPresentation(snapshot.productionMode);box.append(empty(view.title,view.hint));}else box.append(empty('这个范围内还没有前贴','切换展示范围可查看其他前贴；分集分析记录仍保留在下方。'));}
  if(analyses.length){const group=el('div',undefined,'grid analysis-grid');group.dataset.nodeKey='analysis-grid';for(const op of analyses)group.append(analysisCard(op));const title=el('h3','分集高光分析','analysis-section-title');title.dataset.nodeKey='analysis-title';box.append(title,group);}return box;
}
function render(){if(!snapshot)return;const titles={results:['审阅 / 交付','成片审阅'],plans:['安排 / 时间线','剪辑计划'],fronts:['挑选 / 前贴','前贴与高光'],assets:['来源 / 素材','素材库']};$('#section-eyebrow').textContent=titles[tab][0];$('#section-title').textContent=titles[tab][1];$('#filters').hidden=tab!=='assets';document.querySelectorAll('[data-tab]').forEach(b=>{if(b.dataset.tab===tab)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});let view;
  if(tab==='results')view=resultCards();else if(tab==='plans')view=planCards();else if(tab==='fronts')view=frontCards();else{view=el('div',undefined,'grid');const role=$('#role-filter').value,query=$('#search').value.toLowerCase();for(const a of snapshot.assets.filter(a=>a.role!=='result'&&(role==='all'||a.role===role)&&`${a.name} ${a.episode||''}`.toLowerCase().includes(query)))view.append(assetCard(a));if(!view.children.length)view=empty('没有匹配的素材','调整筛选，或在聊天中添加原始剧集、尾贴与 Logo。');}
  if(tab==='assets'&&snapshot.episodeRequirement){const requirement=snapshot.episodeRequirement,box=el('div');box.append(el('p',`原片已导入 ${requirement.available} 集 · 最少 ${requirement.minimum} 集（尾贴和 PNG 不计入）`,'muted'));if(!requirement.ready)box.append(el('p',`还需导入 ${requirement.missing} 集原始剧集，再开始付费制作。`,'muted'));box.append(view);view=box;}
  const content=$('#content'),scroll=[window.scrollX,window.scrollY];
  if(content.dataset.tab===tab&&content.firstChild)reconcile(content.firstChild,view);else content.replaceChildren(view);
  content.dataset.tab=tab;window.scrollTo(...scroll);
}
function renderProductionMode(value){const view=productionModePresentation(value);$('#production-mode-label').textContent=view.label;$('#production-mode-hint').textContent=view.hint;$('.production-mode').classList.toggle('is-unconfirmed',view.status==='unconfirmed');}
let guidanceKey='',guidanceRevision=0,guidanceStale=true;
function renderGuidance(value,{stale=false}={}){
  const view=value?.title?value:{title:'请先核对项目进度',message:'下一步信息尚未就绪。可以回到聊天，让助手核对原项目并说明需要补充什么。',actor:'user',choices:[{id:'check-project',label:'核对项目进度',reply:'请核对这个原项目的当前进度，告诉我下一步需要做什么；先不要新建收费任务。'}]};
  const key=JSON.stringify([view,stale]);if(key===guidanceKey)return;guidanceKey=key;guidanceStale=stale;guidanceRevision++;
  $('#next-step-title').textContent=view.title;$('#next-step-message').textContent=view.message||'';
  $('#next-step-actor').textContent=stale?'提示待更新':({user:'等待你的选择或补充',assistant:'由助手接着处理',wait:'等待原任务结果',none:'可以查看或结束'}[view.actor]||'请在聊天中继续');
  $('#next-step-question').textContent=view.question||'';$('#next-step-question').hidden=!view.question;
  $('#next-step-stale').textContent=stale?'连接中断，以上是上次读取的提示，尚未更新。旧选项已暂停；请让助手重新打开原项目，核对进度后再继续。若重新打开仍失败，请让助手核对原项目状态，保留文件，不另建替代项目。':'';$('#next-step-stale').hidden=!stale;
  $('#next-step').classList.toggle('is-stale',stale);$('#next-step-feedback').textContent='';$('#next-step-reply').hidden=true;$('#next-step-reply-text').value='';
  const choices=$('#next-step-choices');choices.replaceChildren();
  for(const choice of (view.choices||[]).slice(0,3)){
    const button=el('button',`复制回复：${choice.label}`,'guidance-choice');button.type='button';button.disabled=stale;
    button.addEventListener('click',()=>copyGuidanceReply(choice.reply));choices.append(button);
  }
  if(stale){const reopen=el('button','复制重开原项目的话','guidance-choice');reopen.type='button';reopen.addEventListener('click',()=>copyGuidanceReply('请重新打开这个原项目的工作台，核对当前进度，告诉我下一步怎么继续；先不要重新制作。若重新打开仍失败，请核对原项目状态，保留文件，不另建替代项目。',{recovery:true}));choices.append(reopen);}
}
async function copyGuidanceReply(reply,{recovery=false}={}){
  if(guidanceStale&&!recovery)return;
  const revision=guidanceRevision;$('#next-step-reply').hidden=false;$('#next-step-reply-text').value=reply;
  try{
    if(!navigator.clipboard?.writeText)throw new Error('Clipboard unavailable');
    await navigator.clipboard.writeText(reply);
    if(revision!==guidanceRevision)return;
    $('#next-step-feedback').textContent='已复制。请回到聊天粘贴并发送；这里只复制文字，尚未执行任何制作操作。';
  }catch{
    if(revision!==guidanceRevision)return;
    $('#next-step-feedback').textContent='无法自动复制。请选中上面的文字手动复制，回到聊天粘贴并发送。';
    $('#next-step-reply-text').focus();$('#next-step-reply-text').select();
  }
}
let balanceRevision=-1,minimumBalanceRevision=-1,balanceRefreshing=false,balanceRefreshAvailable=false;
function renderBalance(balance){if(balance?.mode==='query'&&Number.isSafeInteger(balance.queryRevision)){if(balance.queryRevision<Math.max(balanceRevision,minimumBalanceRevision))return;balanceRevision=balance.queryRevision;}const view=balancePresentation(balance),amount=$('#balance-amount'),status=$('#balance-status');if(Number.isSafeInteger(balance?.queryRevision))balanceRefreshAvailable=view.refreshable===true;if(amount.textContent!==view.amount)amount.textContent=view.amount;if(status.textContent!==view.message)status.textContent=view.message;const badge=$('.balance-badge');badge.classList.toggle('is-stale',view.stale);badge.title=[view.message,view.details].filter(Boolean).join('；');const details=$('#balance-details');details.textContent=view.details||'';details.hidden=!view.details;const refresh=$('#balance-refresh');refresh.hidden=view.refreshable!==true;refresh.disabled=view.loading===true;}
function renderProjectOrigin(value){
  const origin=value.historicalEnvironment==='live'?'历史来源：正式环境；当前接入未核实':value.historicalEnvironment==='local-test'?'历史来源：本地测试；当前接入未核实':value.environment==='local-test'?'本地测试夹具':'当前接入未核实';
  $('#project-meta').textContent=`${value.assets.filter(a=>a.role==='episode').length} 集原片 · ${origin}`;
}
const sync=createSnapshotSync({
  read:async()=>{try{const r=await fetch('/api/snapshot',{cache:'no-store',signal:AbortSignal.timeout(10000)});if(!r.ok)throw new Error();const next=await r.json();renderGuidance(next.guidance);return next;}catch(error){renderGuidance(snapshot?.guidance,{stale:true});throw error;}},
  apply:next=>{if(!snapshot&&!userSelectedTab)tab=(next.allResultCount??next.currentResultCount)>0?'results':'assets';snapshot=next;$('#project-title').textContent=snapshot.title||'前贴与混剪';renderProjectOrigin(snapshot);renderProductionMode(snapshot.productionMode);$('#test-banner').hidden=snapshot.environment!=='local-test';$('#result-count').textContent=snapshot.allResultCount??snapshot.currentResultCount;render();},
  onSuccess:next=>{if(!balanceRefreshing)renderBalance(next.balance);$('#notice').hidden=true;$('#connection').textContent=`本地数据读取于 ${new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}`;$('#remote-sync').textContent=remoteSyncText(next.sync);},
  onError:()=>{$('#notice').hidden=false;$('#notice').textContent='暂时无法读取本地工作台，已保留当前内容并自动重试。若服务已退出，请在聊天中让助手重新打开原项目；若仍失败，请核对原项目状态，保留文件，不另建替代项目。';$('#connection').textContent='本地工作台连接中断';renderBalance({...(balanceRefreshAvailable?{mode:'query',reasonCode:'QUERY_FAILED'}:{}),status:'unavailable',totalBalance:null});if(!snapshot)$('#content').replaceChildren(empty('无法读取项目','请保留当前文件，让助手核对原项目状态和工作台；不要另建替代项目。'));}
});
const refreshRemote=createRemoteRefresh({
  request:async()=>{const r=await fetch('/api/sync',{method:'POST',headers:{'X-Workbench-Sync':'1'},signal:AbortSignal.timeout(10000)});if(!r.ok)throw new Error();return r.json();},
  refresh:()=>sync({fresh:true}),
  onStatus:state=>{$('#remote-sync').textContent=remoteSyncText(state);},
  onError:()=>{$('#remote-sync').textContent='服务端：同步请求失败，请重试；不会重新提交制作任务。';}
});
async function refreshBalance(){if(balanceRefreshing)return;minimumBalanceRevision=balanceRevision+1;balanceRefreshing=true;renderBalance({mode:'query',status:'loading',reasonCode:'BALANCE_PENDING'});try{const response=await fetch('/api/balance',{method:'POST',headers:{'X-Workbench-Sync':'1'},signal:AbortSignal.timeout(10000)});if(!response.ok)throw new Error();const value=await response.json();balanceRefreshing=false;renderBalance(value.balance);await sync({fresh:true});}catch{balanceRefreshing=false;renderBalance({mode:'query',status:'unavailable',reasonCode:'QUERY_FAILED'});}}
async function refresh(){$('#refresh').disabled=true;try{await refreshRemote();}finally{$('#refresh').disabled=false;}}
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{tab=b.dataset.tab;userSelectedTab=true;render();}));
$('#content').addEventListener('click',event=>{const filter=event.target.closest('[data-history-filter]');if(filter){if(filter.dataset.historyFilter==='result')resultFilter=filter.dataset.value;else frontFilter=filter.dataset.value;render();return;}const b=event.target.closest('.preview-button');if(!b)return;const v=b.closest('article').querySelector('video');if(v){v.currentTime=Number(b.dataset.start);v.play().catch(()=>{});}});
$('#balance-refresh').addEventListener('click',refreshBalance);$('#refresh').addEventListener('click',refresh);$('#role-filter').addEventListener('change',render);$('#search').addEventListener('input',render);
setInterval(()=>{if(!document.hidden)sync();},2500);
window.addEventListener('focus',()=>{if(!document.hidden)sync();});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)sync();});sync();
