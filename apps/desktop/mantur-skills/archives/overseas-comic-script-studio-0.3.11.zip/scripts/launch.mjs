#!/usr/bin/env node
// CLI-managed local entry. Network, authorization and operator execution remain in ACCESS.
import assert from 'node:assert/strict';
import { existsSync, lstatSync, readFileSync, realpathSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execute } from './project.mjs';

export function launch(action, args = [], env = process.env) {
  assert(['doctor', 'run', 'status', 'next', 'plan', 'export'].includes(action), 'Unsupported local action');
  assert(args.length === 0 || args.length === 2 && args[0] === '--project' && args[1], 'Only --project <directory> is accepted');
  assert(Number(process.versions.node.split('.')[0]) >= 20, 'Node.js 20 or newer is required');
  const root = fileURLToPath(new URL('../', import.meta.url));
  const required = ['SKILL.md', 'skill-runtime.json', 'scripts/access.mjs', 'scripts/access-profile.json', 'scripts/project.mjs', 'scripts/receipts.mjs', 'references/runtime.md'];
  for (const file of required) assert(existsSync(resolve(root, file)) && lstatSync(resolve(root, file)).isFile(), `Incomplete skill installation: ${file}`);
  const manifest = JSON.parse(readFileSync(resolve(root, 'skill-runtime.json'), 'utf8'));
  assert(manifest.entry === 'scripts/launch.mjs' && manifest.actions.includes(action), 'Invalid local runtime manifest');
  if (action === 'doctor') return { ok: true, localOnly: true, status: 'READY', contentVersion: manifest.content_version,
    instruction: '本地入口完整；尚未检查远程授权或算子。开始业务调用前按 references/cli.md 检查接入。' };
  const project = args[1] || env.MANTURHUB_PROJECT;
  assert(project, 'A user-selected project directory is required');
  const projectPath = resolve(project);
  const stat = lstatSync(projectPath, { throwIfNoEntry: false });
  assert(stat && !stat.isSymbolicLink() && stat.isDirectory(), 'Project must be an existing directory, not a symlink or file');
  if (action === 'run' && !existsSync(resolve(projectPath, 'state.json'))) return { ok: true, localOnly: true, status: 'NEEDS_CONFIGURATION', project: projectPath,
    instruction: '先读取 SKILL.md，沿用已确认的创作方向；只补问缺少的信息。确认新建原创或改编、目标市场、语言、集数与篇幅后按 references/runtime.md 初始化。启动未上传、生成或扣费。',
    required: ['创作方式与已有素材', '已确认方向及目标市场', '工作语言与交付语言', '集数与每集篇幅'], reference: resolve(root, 'references/runtime.md') };
  return { ok: true, localOnly: true, ...execute(action === 'run' ? 'status' : action, { project: projectPath }) };
}

if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  try { console.log(JSON.stringify(launch(process.argv[2], process.argv.slice(3)))); }
  catch (error) { console.log(JSON.stringify({ ok: false, error: error.message })); process.exitCode = 1; }
}
