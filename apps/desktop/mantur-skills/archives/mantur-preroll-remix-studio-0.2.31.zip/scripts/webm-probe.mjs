import fs from 'node:fs/promises';

// Matroska element definitions: https://www.matroska.org/technical/elements.html
// This reader verifies container metadata only; it does not decode compressed media.
const MAX_METADATA = 16 * 1024 * 1024;
const MAX_ELEMENTS = 100000;
const MAX_DEPTH = 12;
const ID = {header:0x1a45dfa3,segment:0x18538067,info:0x1549a966,tracks:0x1654ae6b,cluster:0x1f43b675};
function unsupported(reason) {
  const error = new Error(`MEDIA_METADATA_UNSUPPORTED: ${reason}`);
  error.code = 'MEDIA_METADATA_UNSUPPORTED';
  throw error;
}
function vint(buffer, offset, isId = false) {
  if (offset >= buffer.length || buffer[offset] === 0) unsupported('invalid EBML integer');
  let length = 1;
  while (!(buffer[offset] & (0x80 >> (length - 1)))) length++;
  if (length > (isId ? 4 : 8) || offset + length > buffer.length) unsupported('truncated EBML integer');
  let value = BigInt(isId ? buffer[offset] : buffer[offset] & (0xff >> length));
  for (let n = 1; n < length; n++) value = (value << 8n) | BigInt(buffer[offset+n]);
  const unknown = !isId && value === (1n << BigInt(7 * length)) - 1n;
  if (!unknown && value > BigInt(Number.MAX_SAFE_INTEGER)) unsupported('element size exceeds safe range');
  return {length,value:unknown?null:Number(value)};
}
function element(buffer, offset, parentEnd, absolute = 0) {
  const id = vint(buffer, offset, true), size = vint(buffer, offset + id.length);
  const start = absolute + offset + id.length + size.length;
  const end = size.value === null ? null : start + size.value;
  if (!Number.isSafeInteger(start) || (end !== null && (!Number.isSafeInteger(end) || end > parentEnd))) unsupported('truncated element');
  return {id:id.value,start,end,size:size.value};
}
function children(buffer, budget, depth = 1) {
  if (depth > MAX_DEPTH) unsupported('metadata nesting limit');
  const result = [];
  for (let pos = 0; pos < buffer.length;) {
    if (++budget.elements > MAX_ELEMENTS) unsupported('element count limit');
    const entry = element(buffer,pos,buffer.length);
    if (entry.end === null) unsupported('unknown metadata element size');
    result.push({...entry,data:buffer.subarray(entry.start,entry.end),depth});
    pos = entry.end;
  }
  return result;
}
function field(entries,id) {
  const matches = entries.filter(item => item.id === id);
  if (matches.length > 1) unsupported('ambiguous duplicate metadata');
  return matches[0]?.data;
}
function uint(data, fallback) {
  if (data === undefined) return fallback;
  if (!data.length || data.length > 8) unsupported('invalid unsigned integer');
  let value = 0n;
  for (const byte of data) value = (value << 8n) | BigInt(byte);
  if (value > BigInt(Number.MAX_SAFE_INTEGER)) unsupported('metadata integer exceeds safe range');
  return Number(value);
}
function float(data) {
  if (!data || ![4,8].includes(data.length)) unsupported('missing or invalid duration');
  return data.length === 4 ? data.readFloatBE(0) : data.readDoubleBE(0);
}
function text(data) {
  if (!data || !data.length || data.length > 128 || data.some(byte => byte < 0x20 || byte > 0x7e)) unsupported('invalid metadata string');
  return data.toString('ascii');
}
function tracksMetadata(buffer,budget) {
  const entries = children(buffer,budget);
  const tracks = entries.filter(entry => entry.id === 0xae).map(entry => {
    const fields = children(entry.data,budget,2);
    const type = uint(field(fields,0x83));
    if (type === undefined) unsupported('missing track type');
    const codec = text(field(fields,0x86));
    const enabled = uint(field(fields,0xb9),1);
    if (![0,1].includes(enabled)) unsupported('invalid enabled-track flag');
    const scale = field(fields,0x23314f);
    if (scale && float(scale) !== 1) unsupported('unsupported track timestamp scale');
    const video = field(fields,0xe0);
    return {type,codec,enabled,defaultDuration:uint(field(fields,0x23e383)),video:video?children(video,budget,3):null};
  });
  const videos = tracks.filter(track => track.type === 1 && track.enabled !== 0);
  if (videos.length !== 1 || !videos[0].video) unsupported('expected one enabled video track');
  const track = videos[0], v = track.video;
  const width = uint(field(v,0xb0)), height = uint(field(v,0xba));
  if (!Number.isInteger(width) || !Number.isInteger(height) || width <= 0 || height <= 0) unsupported('missing video dimensions');
  const displayWidth = uint(field(v,0x54b0),width), displayHeight = uint(field(v,0x54ba),height);
  const unit = uint(field(v,0x54b2),0);
  const crop = [0x54aa,0x54bb,0x54cc,0x54dd].some(id => uint(field(v,id),0) !== 0);
  // Non-square pixels, crop, projection or non-pixel display units require explicit sizing.
  const geometryKnown = unit === 0 && !crop && !field(v,0x7670) && displayWidth > 0 && displayHeight > 0 && BigInt(displayWidth)*BigInt(height) === BigInt(displayHeight)*BigInt(width);
  const codecNames = {'V_VP8':'vp8','V_VP9':'vp9','V_AV1':'av1','V_MPEG4/ISO/AVC':'h264','V_MPEGH/ISO/HEVC':'hevc'};
  const fps = track.defaultDuration > 0 ? 1e9 / track.defaultDuration : null;
  return {width,height,displayGeometryKnown:geometryKnown,...(geometryKnown?{displayWidth,displayHeight}:{}),hasAudio:tracks.some(track => track.type === 2),codec:codecNames[track.codec]||track.codec,frames:0,fps:Number.isFinite(fps)&&fps>0?fps:null};
}
export async function probeWebm(file) {
  const handle = await fs.open(file,'r');
  try {
    const stat = await handle.stat();
    if (!stat.isFile() || !Number.isSafeInteger(stat.size) || stat.size < 8) unsupported('invalid file size');
    const budget = {bytes:0,elements:0};
    async function read(position,length) {
      if (!Number.isSafeInteger(position) || !Number.isSafeInteger(length) || position < 0 || length < 0 || position+length > stat.size) unsupported('truncated file');
      budget.bytes += length;
      if (budget.bytes > MAX_METADATA) unsupported('metadata byte limit');
      const data = Buffer.alloc(length);
      for (let offset=0;offset<length;) {
        const {bytesRead} = await handle.read(data,offset,length-offset,position+offset);
        if (!bytesRead) unsupported('truncated file');
        offset+=bytesRead;
      }
      return data;
    }
    async function header(position,parentEnd) {
      if (++budget.elements > MAX_ELEMENTS) unsupported('element count limit');
      const data = await read(position,Math.min(12,parentEnd-position));
      return element(data,0,parentEnd,position);
    }
    const ebml = await header(0,stat.size);
    if (ebml.id !== ID.header || ebml.end === null) unsupported('missing EBML header');
    const fields = children(await read(ebml.start,ebml.size),budget);
    if (!['webm','matroska'].includes(text(field(fields,0x4282)))) unsupported('unsupported document type');
    const maxSizeLength=uint(field(fields,0x42f3),8),readVersion=uint(field(fields,0x4285),1);
    if (uint(field(fields,0x42f7),1)!==1 || uint(field(fields,0x42f2),4)!==4 || maxSizeLength<1 || maxSizeLength>8 || readVersion<1 || readVersion>4) unsupported('unsupported EBML version');
    let pos = ebml.end, segment;
    while (pos < stat.size) {
      const entry = await header(pos,stat.size);
      if (entry.id === ID.segment) {segment=entry;break;}
      if (entry.end === null || entry.id !== 0xec) unsupported('missing Segment');
      pos=entry.end;
    }
    if (!segment) unsupported('missing Segment');
    const segmentEnd = segment.end ?? stat.size;
    // Do not silently combine a first Segment's duration with later Segments.
    for (let trailing=segmentEnd;trailing<stat.size;) {
      const entry=await header(trailing,stat.size);
      if (entry.id!==0xec || entry.end===null) unsupported('multiple Segments or trailing data');
      trailing=entry.end;
    }
    let info,tracks,cluster=false;
    for (pos=segment.start;pos<segmentEnd;) {
      const entry = await header(pos,segmentEnd);
      if (entry.id === ID.info || entry.id === ID.tracks) {
        if (entry.end === null) unsupported('unknown metadata size');
        if (entry.id === ID.info) {if(info)unsupported('duplicate Info');info=await read(entry.start,entry.size);}
        else {if(tracks)unsupported('duplicate Tracks');tracks=await read(entry.start,entry.size);}
      }
      if (entry.id === ID.cluster) {
        if (entry.size === 0) unsupported('empty Cluster');
        cluster=true;
        // Live streams may have an unknown-size Cluster. Its payload cannot safely
        // be searched for IDs; accept only already-present authoritative metadata.
        if (entry.end === null) break;
      } else if (entry.end === null) unsupported('unknown element size');
      pos=entry.end;
    }
    if (!info || !tracks || !cluster) unsupported('incomplete WebM metadata');
    const infoFields = children(info,budget);
    const scale = uint(field(infoFields,0x2ad7b1),1000000);
    const duration = float(field(infoFields,0x4489))*scale/1e9;
    if (!(scale>0) || !Number.isFinite(duration) || duration<=0) unsupported('missing positive duration');
    return {...tracksMetadata(tracks,budget),duration,durationSource:'format',containerDuration:duration,metadataSource:'container',validation:{container:true,decode:'not_performed'}};
  } finally {await handle.close();}
}
