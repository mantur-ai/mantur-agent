// Business receives public services; generated integration owns CLI/environment details.
import { access, mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { check, digest } from './project.mjs';

const clients = new WeakMap();
export function bindProjectClient(project, client) { clients.set(project, client); return project; }
const unsupported = feature => Object.assign(new Error(`公开工具尚无 ${feature} 合同；没有提交或重做任务。`), { code: 'UNSUPPORTED_PUBLIC_CLI_CONTRACT' });

export function projectClient(project) {
  if (clients.has(project)) return clients.get(project);
  const client = publicProjectClient({ project }); clients.set(project, client); return client;
}

export async function executionDefaults() {
  try { return (await import('./cli-client.mjs')).installedExecutionEnvironment(); }
  catch(error){if(await sourceOnly(error))return {};throw error;}
}

async function sourceOnly(error){
  if(error.code!=='ERR_MODULE_NOT_FOUND')return false;
  for(const file of ['../skill-runtime.json','./access-profile.json']){
    try{await access(new URL(file,import.meta.url));return false;}catch(failure){if(failure.code!=='ENOENT')throw failure;}
  }
  return true;
}

export async function readInvocationContext(projectDir){
  try{await access(projectDir);}catch(error){if(error.code==='ENOENT')return null;throw error;}
  try{
    const shared=await import('./workflow-context.mjs');
    return shared.readWorkflowContext(projectDir);
  }catch(error){if(await sourceOnly(error))return null;throw error;}
}

export async function executionContext(env=process.env,options={}){
  try{
    const cli=await import('./cli-client.mjs');
    if(options.bindingArgs!==undefined){
      check(!options.received,'EXECUTION_CONTEXT_INVALID');
      const args=[...options.bindingArgs];
      if(options.projectDir){
        const previous=await readInvocationContext(options.projectDir);
        if(previous){
          const index=args.indexOf('--business-code');
          const requested=index>=0?args[index+1]:env.MANTURHUB_BUSINESS_CODE;
          check(requested===undefined||requested===previous.businessCode,'PROJECT_BUSINESS_CONFLICT');
          if(index<0)args.push('--business-code',previous.businessCode);
        }
      }
      return cli.installedPublicCli({env,bindingArgs:args,...(options.projectDir?{projectDir:options.projectDir,bindingPath:'.preroll/cli-binding.json'}:{})}).executionContext();
    }
    const context=cli.installedExecutionContext(env,{received:options.received===true});
    if(options.projectDir&&!options.received){
      const shared=await import('./workflow-context.mjs'),previous=shared.readWorkflowContext(options.projectDir);
      return cli.installedExecutionContext(env,{projectDir:options.projectDir,bindingPath:'.preroll/cli-binding.json',
        ...(previous?{businessCode:previous.businessCode}:{})});
    }
    return context;
  }
  catch(error){
    if(!await sourceOnly(error))throw error;
    const allowed=['PATH','HOME','USERPROFILE','LANG'];
    check(!options.received||Object.keys(env).every(key=>allowed.includes(key)),'EXECUTION_CONTEXT_INVALID');
    return Object.fromEntries(allowed.filter(key=>typeof env[key]==='string').map(key=>[key,env[key]]));
  }
}

export function publicProjectClient({ bindingArgs, confirm, project, projectDir, signal } = {}) {
  let service,serviceArgs;
  const selectedBusiness=args=>{
    const index=args?.indexOf('--business-code')??-1;
    return index>=0?args[index+1]:args?.find(value=>value.startsWith('--business-code='))?.slice('--business-code='.length);
  };
  function assertRemote() {
    check(!project || project.schemaVersion===2 && !project.legacyOrigin,'LEGACY_REMOTE_BINDING_REQUIRED',
      '迁移的历史项目仅供审阅；旧上传与账户归属尚未核实，请使用原入口恢复，或明确创建新项目。');
  }
  async function services() {
    try {
      const cli=await import('./cli-client.mjs'),defaults=cli.installedExecutionEnvironment();
      const args=[...(bindingArgs??defaults.bindingArgs??[])];
      if(project&&projectDir){
        const shared=await import('./workflow-context.mjs'),previous=shared.readWorkflowContext(projectDir);
        if(previous){
          const requested=selectedBusiness(args)??defaults.businessCode;
          check(requested===undefined||requested===previous.businessCode,
            'PROJECT_BUSINESS_CONFLICT','本次业务与项目绑定冲突；请继续原业务或创建独立项目。');
          if(selectedBusiness(args)===undefined)args.push('--business-code',previous.businessCode);
        }
      }
      const key=JSON.stringify(args);
      if(!service||serviceArgs!==key){
        service=cli.installedPublicCli({projectDir,...(projectDir?{bindingPath:'.preroll/cli-binding.json'}:{}),signal,bindingArgs:args});serviceArgs=key;
      }
      return service;
    }
    catch (error) {
      if (error.code === 'ERR_MODULE_NOT_FOUND') throw Object.assign(new Error('源码目录尚未装配；使用完整渠道包运行。'), { code: 'PACKAGE_NOT_ASSEMBLED' });
      throw error;
    }
  }
  async function prepareContext(stage){
    assertRemote();
    check(project?.schemaVersion===2&&projectDir,'PROJECT_EXECUTION_CONTEXT_REQUIRED');
    const stepCode={fronts:'front-generate',analysis:'highlight-analysis',highlights:'highlight-clip',compose:'compose'}[stage];
    check(stepCode,'STAGE_INVALID');
    const shared=await import('./workflow-context.mjs'),previous=shared.readWorkflowContext(projectDir);
    const observation=await(await services()).check();check(observation.code===0,'PUBLIC_CLI_NOT_READY');
    if(!observation.invocationAttribution)return [];
    if(!previous&&project.operations.length){
      const defaults=await executionDefaults();
      check(selectedBusiness(bindingArgs??defaults.bindingArgs)!==undefined,'PROJECT_BUSINESS_CONFIRMATION_REQUIRED',
        '已有制作记录尚未绑定业务；请明确后续调用的业务，原确认和恢复记录保持不变。');
    }
    check(!previous||observation.invocationAttribution.businessCode===previous.businessCode,'PROJECT_BUSINESS_CONFLICT');
    return shared.workflowContextArgs({project:projectDir,skillRunId:previous?.skillRunId||project.id.replaceAll('-',''),
      stepCode,operator:{fronts:'op.video.generate',analysis:'op.video.understand-v2',highlights:'op.video.compose',compose:'op.video.compose'}[stage],
      businessCode:observation.invocationAttribution.businessCode});
  }
  async function invocationArgs(operator,input) {
    assertRemote();
    check(project?.schemaVersion===2 && projectDir,'PROJECT_EXECUTION_CONTEXT_REQUIRED');
    check(!project.legacyOrigin,'LEGACY_REMOTE_BINDING_REQUIRED','迁移的历史项目仅供审阅；旧上传与账户归属尚未核实，请使用原入口恢复，或明确创建新项目。');
    const operation=project.operations.find(op=>op.requestHash===digest({operatorCode:operator,input}));
    check(operation,'OPERATION_NOT_PREPARED');
    return prepareContext(operation.stage);
  }
  async function inputCall(command, operator, input, extra = []) {
    const attribution=await invocationArgs(operator,input);
    const temporary = await mkdtemp(join(tmpdir(), 'preroll-input-'));
    try {
      const file = join(temporary, 'input.json');
      await writeFile(file, JSON.stringify(input), { mode: 0o600, flag: 'wx' });
      return await (await services()).exec([command, operator, '--json-file', file, ...extra, ...attribution]);
    } finally { await rm(temporary, { recursive: true, force: true }); }
  }
  const value = result => { check(result.code === 0 && result.json && typeof result.json === 'object', 'PUBLIC_CLI_FAILED'); return result.json; };
  function rejected(result, operation, recoveryId) {
    const receipt=result.json;
    if(result.code!==1 || receipt?.status!=='REJECTED')return;
    const taskFields=['jobId','job_id','invocationId','taskId','output','billing','_billing','settlement','pollUrl'];
    const valid=operation && receipt.schemaVersion==='mantur.cli.submission.v1'
      && receipt.submission?.phase==='INVOKE' && receipt.submission.outcome==='REJECTED'
      && receipt.submission.evidence==='SERVER_ADMISSION' && receipt.submission.httpStatus===422
      && receipt.errorCode==='AGENT_INPUT_SCHEMA_INVALID' && /^[a-f0-9-]{36}$/i.test(recoveryId||'')
      && receipt.recoveryId===recoveryId && receipt.operatorCode===operation.operatorCode
      && receipt.inputDigest===digest(operation.input)
      && [receipt,receipt.submission].every(record=>taskFields.every(key=>record[key]==null));
    if(!valid)throw Object.assign(new Error('受理前拒绝回执与原调用不匹配，不能据此重新提交。'),
      {code:'CLI_REJECTION_INVALID',...(recoveryId?{recoveryId}:{})});
    return {receipt,recoveryId,submissionRejected:true};
  }
  return {
    cliManaged: true,
    capabilities: { boundedRecoveryQuery: false, accountBoundBalance: false, balanceQuery: true, artifactDownload: true },
    prepareContext,
    assertSubmissionReady: operation => {
      assertRemote();
      check(!project?.legacyOrigin,'LEGACY_REMOTE_BINDING_REQUIRED');
    },
    check: async () => (await services()).check(),
    // A fresh account query does not reuse project artifacts or establish a remote-project binding.
    queryBalance: async options => (await services(false)).queryBalance(options),
    describe: async operator => { assertRemote(); return value(await (await services()).exec(['describe', operator, '--json'])); },
    quote: async (operator, input) => value(await inputCall('quote', operator, input, ['--json'])),
    upload: async (file, record = {}, save = async () => {}) => {
      assertRemote();
      if (record.receipt?.status === 'AVAILABLE') return record.receipt;
      const receipt = await (await services()).upload(file); record.receipt = receipt; await save(record); return receipt;
    },
    invoke: async (operator, input, operation) => {
      assertRemote();
      const result = await inputCall('run', operator, input, ['--no-wait', ...(confirm ? ['--confirm', confirm] : [])]);
      const { confirmationFrom } = await import('./cli-client.mjs');
      if (result.code === 3) {
        const confirmation = confirmationFrom(result.stderr ?? '');
        check(confirmation, 'CLI_CONFIRMATION_INVALID');
        throw Object.assign(new Error('本次实际报价待用户确认。'), { code: 'CONFIRMATION_REQUIRED', confirmation });
      }
      const recoveryId = result.stderr?.match(/调用恢复 ID:\s*([A-Za-z0-9-]+)/)?.[1] ?? result.json?.recoveryId;
      const rejection=rejected(result,operation,recoveryId);
      if(rejection)return rejection;
      if (result.code !== 0) throw Object.assign(new Error('CLI 调用没有成功回执，请保留原恢复标识。'), { code: 'CLI_SUBMISSION_UNCERTAIN', ...(recoveryId ? { recoveryId } : {}) });
      check(recoveryId, 'CLI_RECOVERY_ID_REQUIRED');
      return { receipt: value(result), recoveryId };
    },
    poll: async (_job, recoveryId, operation) => {
      assertRemote();
      check(recoveryId, 'LEGACY_RECOVERY_UNAVAILABLE');
      const result = await (await services()).exec(['resume', recoveryId]);
      const rejection=rejected(result,operation,recoveryId);
      if(rejection)return rejection;
      const receipt=result.json;
      const knownFailure=receipt?.jobId&&['FAILED','CANCELED','CANCELLED','TIMED_OUT'].includes(receipt.status);
      if (result.code !== 0&&!knownFailure) throw Object.assign(new Error('原调用恢复未完成；不会新建任务。'), { code: 'CLI_RECOVERY_INCOMPLETE', recoveryId });
      check(receipt&&typeof receipt==='object'&&!Array.isArray(receipt),'CLI_RECEIPT_INVALID');
      return receipt;
    },
    // Keep these gates explicit until public contracts can preserve identity and artifacts.
    download: async (url,target) => { assertRemote();return (await services()).download(url,target); },
    balance: async (expectedIdentity,options) => { assertRemote();return (await services()).balance(expectedIdentity,options); },
    balanceIdentity: async options => { assertRemote();return (await services()).balanceIdentity(options); },
    queryOnce: async () => { throw unsupported('原调用有界查询'); },
    updates: async () => { assertRemote(); return (await services()).updates(); },
  };
}
