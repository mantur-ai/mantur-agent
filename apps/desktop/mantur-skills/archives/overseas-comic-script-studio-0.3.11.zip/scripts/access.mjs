// Opt-in diagnostics around the existing adapter. Authentication, environment,
// attribution, fees and recovery remain owned by that adapter and the CLI.
import { readFileSync, realpathSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import * as core from './access-core.mjs';
export * from './access-core.mjs';

export function safeDiagnostic(value) {
  return String(value || '')
    .replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '')
    .replace(/https?:\/\/[^\s<>"']+/gi, '[REDACTED_URL]')
    .replace(/Bearer\s+[^\s,;"']+/gi, 'Bearer [REDACTED]')
    .replace(/mtak_[A-Za-z0-9_-]+/g, '[REDACTED_KEY]')
    .replace(/((?:["']?(?:[\w-]*(?:token|secret|password|cookie)|api[-_]?key|authorization|x-api-key)["']?)\s*[:=]\s*)(?:"[^"\r\n]*"|'[^'\r\n]*'|[^\s,;]+)/gi, '$1[REDACTED]')
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)?\b/g, '[REDACTED_TOKEN]')
    .replace(/[\x00-\x1f\x7f-\x9f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 600);
}
export function diagnosticRunner(run) {
  return async (entry, args, env, options) => {
    const isAuth = args.length === 3 && args[0] === 'auth' && args[1] === 'status' && args[2] === '--json';
    if (!isAuth) return run(entry, args, env, options);
    let result;
    try { result = await run(entry, args, env, options); }
    catch (error) { throw new Error(`CLI auth check failed; no business call was made. ${safeDiagnostic(error.message)}. 请先检查 CLI/Node 安装和依赖；不要反复登录。`); }
    let value; try { value = JSON.parse(result.stdout); } catch { /* Diagnostic below. */ }
    if (!value || typeof value !== 'object' || Array.isArray(value)
      || typeof value.authenticated !== 'boolean' || typeof value.operatorReady !== 'boolean') {
      const code = Number.isInteger(result.code) ? result.code : 'unknown';
      throw new Error(`Invalid CLI auth status; no business call was made. exit=${code}; ${safeDiagnostic(result.stderr) || 'CLI 未返回有效的授权状态 JSON'}。请先检查 CLI/Node 安装和依赖；不要反复登录。`);
    }
    return result;
  };
}
export const status = (entry, ctx, run = core.child) => core.status(entry, ctx, diagnosticRunner(run));
export const runAccess = (profile, argv, options = {}) => core.runAccess(profile, argv, { ...options, run: diagnosticRunner(options.run ?? core.child) });
if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  try {
    const profile = JSON.parse(readFileSync(new URL('./access-profile.json', import.meta.url), 'utf8'));
    process.exitCode = await runAccess(profile, process.argv.slice(2));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
