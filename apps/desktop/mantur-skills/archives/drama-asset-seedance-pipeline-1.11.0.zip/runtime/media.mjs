import { createHash } from "node:crypto";
import { closeSync, fstatSync, openSync, readSync } from "node:fs";

const HEADER_BYTES = 16;
const MAX_ATOMS = 100000;

function readAt(fd, position, length) {
  const buffer = Buffer.alloc(length);
  let offset = 0;
  while (offset < length) {
    const bytes = readSync(fd, buffer, offset, length - offset, position + offset);
    if (!bytes) throw new Error(`truncated media at byte ${position + offset}`);
    offset += bytes;
  }
  return buffer;
}

function uint64(buffer, offset) {
  const value = buffer.readBigUInt64BE(offset);
  if (value > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("media integer exceeds the safe range");
  return Number(value);
}

function atomAt(fd, position, end) {
  if (end - position < 8) throw new Error(`truncated atom header at byte ${position}`);
  const header = readAt(fd, position, Math.min(HEADER_BYTES, end - position));
  const size32 = header.readUInt32BE(0);
  const type = header.toString("ascii", 4, 8);
  let headerSize = 8;
  let size = size32;
  if (size32 === 1) {
    if (header.length < 16) throw new Error(`truncated extended atom header at byte ${position}`);
    size = uint64(header, 8);
    headerSize = 16;
  } else if (size32 === 0) {
    size = end - position;
  }
  if (size < headerSize || position + size > end) throw new Error(`invalid ${type || "unknown"} atom size`);
  return { type, start: position, dataStart: position + headerSize, end: position + size, size };
}

function childAtoms(fd, start, end) {
  const atoms = [];
  let cursor = start;
  while (cursor < end) {
    if (atoms.length >= MAX_ATOMS) throw new Error("media contains too many atoms");
    const atom = atomAt(fd, cursor, end);
    atoms.push(atom);
    cursor = atom.end;
  }
  return atoms;
}

function firstChild(fd, parent, type) {
  return childAtoms(fd, parent.dataStart, parent.end).find((atom) => atom.type === type) || null;
}

function parseMovieDuration(fd, mvhd) {
  const version = readAt(fd, mvhd.dataStart, 1)[0];
  if (version === 0) {
    const body = readAt(fd, mvhd.dataStart, 20);
    return { timescale: body.readUInt32BE(12), duration: body.readUInt32BE(16) };
  }
  if (version === 1) {
    const body = readAt(fd, mvhd.dataStart, 32);
    return { timescale: body.readUInt32BE(20), duration: uint64(body, 24) };
  }
  throw new Error(`unsupported mvhd version ${version}`);
}

function parseTrackHeader(fd, tkhd) {
  const version = readAt(fd, tkhd.dataStart, 1)[0];
  const widthOffset = version === 0 ? 76 : version === 1 ? 88 : null;
  if (widthOffset === null) throw new Error(`unsupported tkhd version ${version}`);
  const body = readAt(fd, tkhd.dataStart + widthOffset, 8);
  return {
    width: Math.round(body.readUInt32BE(0) / 65536),
    height: Math.round(body.readUInt32BE(4) / 65536),
  };
}

function parseHandler(fd, hdlr) {
  const body = readAt(fd, hdlr.dataStart, 12);
  return body.toString("ascii", 8, 12);
}

function inspectTrack(fd, trak) {
  const tkhd = firstChild(fd, trak, "tkhd");
  const mdia = firstChild(fd, trak, "mdia");
  const hdlr = mdia ? firstChild(fd, mdia, "hdlr") : null;
  if (!hdlr) return null;
  const handler = parseHandler(fd, hdlr);
  const dimensions = tkhd ? parseTrackHeader(fd, tkhd) : { width: 0, height: 0 };
  return { handler, ...dimensions };
}

export function sha256Media(path) {
  const hash = createHash("sha256");
  const fd = openSync(path, "r");
  try {
    const size = fstatSync(fd).size;
    const buffer = Buffer.alloc(1024 * 1024);
    let position = 0;
    while (position < size) {
      const bytes = readSync(fd, buffer, 0, Math.min(buffer.length, size - position), position);
      if (!bytes) throw new Error(`failed to read media at byte ${position}`);
      hash.update(buffer.subarray(0, bytes));
      position += bytes;
    }
    return hash.digest("hex");
  } finally {
    closeSync(fd);
  }
}

export function inspectIsoBmff(path) {
  const fd = openSync(path, "r");
  try {
    const fileSize = fstatSync(fd).size;
    if (fileSize < 24) throw new Error("media file is too small");
    const top = childAtoms(fd, 0, fileSize);
    const ftyp = top.find((atom) => atom.type === "ftyp");
    const moov = top.find((atom) => atom.type === "moov");
    if (!ftyp || !moov) throw new Error("media is not a complete MP4/MOV file");
    const brandBytes = readAt(fd, ftyp.dataStart, Math.min(32, ftyp.end - ftyp.dataStart));
    const majorBrand = brandBytes.toString("ascii", 0, Math.min(4, brandBytes.length));
    const mvhd = firstChild(fd, moov, "mvhd");
    if (!mvhd) throw new Error("media is missing mvhd duration metadata");
    const movie = parseMovieDuration(fd, mvhd);
    if (!movie.timescale || !movie.duration) throw new Error("media duration is zero or unreadable");
    const tracks = childAtoms(fd, moov.dataStart, moov.end)
      .filter((atom) => atom.type === "trak")
      .map((atom) => inspectTrack(fd, atom))
      .filter(Boolean);
    const video = tracks.find((track) => track.handler === "vide" && track.width > 0 && track.height > 0);
    if (!video) throw new Error("media has no readable video track");
    const durationUs = Math.round((movie.duration * 1000000) / movie.timescale);
    if (!Number.isSafeInteger(durationUs) || durationUs <= 0) throw new Error("media duration is outside the supported range");
    return {
      format: "iso-bmff",
      major_brand: majorBrand,
      duration_us: durationUs,
      duration_seconds: Number((durationUs / 1000000).toFixed(6)),
      width: video.width,
      height: video.height,
      has_audio: tracks.some((track) => track.handler === "soun"),
      size_bytes: fileSize,
    };
  } finally {
    closeSync(fd);
  }
}
