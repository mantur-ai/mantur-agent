import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";

export function sha256(path) {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

export function imageDimensions(path) {
  const buffer = readFileSync(path);
  if (buffer.length >= 24 && buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
    return [buffer.readUInt32BE(16), buffer.readUInt32BE(20)];
  }
  if (buffer.length >= 4 && buffer[0] === 0xff && buffer[1] === 0xd8) {
    const sof = new Set([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);
    let offset = 2;
    while (offset + 4 <= buffer.length) {
      if (buffer[offset++] !== 0xff) continue;
      while (offset < buffer.length && buffer[offset] === 0xff) offset++;
      const marker = buffer[offset++];
      if (marker === undefined || marker === 0xd8 || marker === 0xd9) continue;
      if (offset + 2 > buffer.length) break;
      const length = buffer.readUInt16BE(offset);
      offset += 2;
      if (sof.has(marker) && offset + 5 <= buffer.length) {
        return [buffer.readUInt16BE(offset + 3), buffer.readUInt16BE(offset + 1)];
      }
      offset += Math.max(0, length - 2);
    }
  }
  if (buffer.length >= 20 && buffer.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WEBP") {
    const type = buffer.toString("ascii", 12, 16);
    const size = buffer.readUInt32LE(16);
    const payload = buffer.subarray(20, 20 + size);
    if (type === "VP8X" && payload.length >= 10) {
      return [1 + payload.readUIntLE(4, 3), 1 + payload.readUIntLE(7, 3)];
    }
    if (type === "VP8L" && payload.length >= 5 && payload[0] === 0x2f) {
      const bits = payload.readUInt32LE(1);
      return [1 + (bits & 0x3fff), 1 + ((bits >> 14) & 0x3fff)];
    }
    if (type === "VP8 ") {
      const start = payload.indexOf(Buffer.from([0x9d, 0x01, 0x2a]));
      if (start >= 0 && payload.length >= start + 7) {
        return [payload.readUInt16LE(start + 3) & 0x3fff, payload.readUInt16LE(start + 5) & 0x3fff];
      }
    }
  }
  throw new Error(`unsupported or invalid image: ${path}`);
}

export function ratioMatches(widthA, heightA, widthB, heightB, tolerance = 0.01) {
  const ratioA = widthA / heightA;
  const ratioB = widthB / heightB;
  return Math.abs(ratioA - ratioB) / ratioA <= tolerance;
}
