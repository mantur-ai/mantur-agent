import { check, digest, validId, number, packagingOptions } from './project.mjs';
export function visibleHighlights(p){
  const rows=p.highlights||[];
  if(Array.isArray(p.highlightPool)||!Number.isInteger(p.analysis?.count)||p.analysis.count<1)return rows;
  const selected=new Set((p.plans||[]).map(x=>x.front?.highlightId).filter(Boolean));
  return [...rows.filter(h=>selected.has(h.id)),...rows.filter(h=>!selected.has(h.id))].slice(0,p.analysis.count);
}

export function episodeAsset(p, episode) {
  const a = p.assets.find(a => a.role === 'episode' && a.episode === episode);
  check(a, 'EPISODE_MISSING', `缺少第 ${episode} 集`); return a;
}
function interval(asset, start = 0, end = asset.duration) {
  check(number(start) && number(end) && start >= 0 && end > start && end <= asset.duration + 0.000001, 'SOURCE_RANGE_INVALID', `素材区间越界：${asset.name}`);
  return { start, end };
}
export function frameCeil(time, fps) {
  const scaled = time * fps; const nearest = Math.round(scaled);
  return Math.abs(scaled-nearest) < Number.EPSILON * Math.max(1,Math.abs(scaled)) * 4 ? nearest : Math.ceil(scaled);
}
export function buildPlans(p, spec) {
  const {canvas,logo,outputs} = spec;
  const packaging=packagingOptions(spec.packaging,p.packaging);
  check(typeof spec.intent === 'string' && spec.intent.trim(), 'INTENT_REQUIRED');
  check(canvas && [canvas.width,canvas.height].every(n => Number.isInteger(n) && n > 0 && n <= 8192 && n % 2 === 0) && Number.isInteger(canvas.fps) && canvas.fps > 0 && canvas.fps <= 120, 'CANVAS_INVALID');
  if(packaging.logo)check(logo && ['x','y','width','height'].every(k => Number.isInteger(logo[k])) && logo.x >= 0 && logo.y >= 0 && logo.width > 0 && logo.height > 0 && logo.x+logo.width <= canvas.width && logo.y+logo.height <= canvas.height && number(logo.opacity) && logo.opacity >= 0 && logo.opacity <= 1, 'LOGO_LAYOUT_INVALID');
  const choose=(role,id)=>{const candidates=p.assets.filter(a=>a.role===role);if(id)return candidates.find(a=>a.id===id);check(candidates.length===1,'PACKAGING_ASSET_SELECTION_REQUIRED',`请明确本次使用哪一个${role==='logo'?'Logo':'尾贴'}`);return candidates[0];};
  const tail = packaging.ending?choose('ending',spec.endingAssetId):null; const image = packaging.logo?choose('logo',logo.assetId):null;
  check((!packaging.ending||tail)&&(!packaging.logo||image), 'ENDING_AND_LOGO_REQUIRED','默认需要尾贴和PNG；仅在用户明确不添加时将对应packaging字段设为false。');
  check(Array.isArray(outputs) && outputs.length > 0, 'OUTPUTS_REQUIRED');
  const ids = new Set();
  return outputs.map(out => {
    check(validId(out.id) && !ids.has(out.id), 'OUTPUT_ID_INVALID'); ids.add(out.id);
    const source = out.front;
    check(source && Boolean(source.assetId) !== Boolean(source.highlightId), 'FRONT_INVALID');
    let front; let frontRange;
    if (source.assetId) {
      front = p.assets.find(a => a.id === source.assetId && a.role === 'front');
      check(front, 'FRONT_NOT_READY', '前贴尚未就绪：已有前贴请以 front 角色导入；reference 是用于模仿生成的参考视频。若角色导入错误，请用新 ID 重新导入并更新计划；若正在生成，请恢复原生成任务。'); frontRange = interval(front);
    } else {
      const h = p.highlights.find(h => h.id === source.highlightId); check(h, 'HIGHLIGHT_NOT_FOUND');
      if(Array.isArray(p.highlightPool)){
        const op=(p.highlightOperationIds||[]).map(id=>p.operations.find(o=>o.id===id)).find(o=>o?.highlightId===h.id);
        check(op?.status==='succeeded'&&op.assetId,'HIGHLIGHT_CLIP_NOT_READY','请先裁剪并验收所选高光片段，再编排最终成片。');
        front=p.assets.find(a=>a.id===op.assetId&&a.role==='front');check(front,'HIGHLIGHT_CLIP_NOT_READY');frontRange=interval(front);
      }else{front = episodeAsset(p,h.episode); frontRange = interval(front,h.start,h.end);}
    }
    check(Array.isArray(out.body) && out.body.length > 0, 'BODY_REQUIRED');
    const raw = [{kind:'front',assetId:front.id, ...frontRange}];
    const body = out.body.map(b => {
      const a = episodeAsset(p,b.episode); const range = interval(a,b.start,b.end);
      raw.push({kind:'episode',assetId:a.id,episode:b.episode,...range}); return {episode:b.episode,...range};
    });
    if(tail)raw.push({kind:'ending',assetId:tail.id,...interval(tail)});
    let cursor = 0;
    const segments = raw.map(s => {
      const frames = frameCeil(s.end-s.start,canvas.fps); check(frames > 0,'EMPTY_SEGMENT');
      // Keep source times separate; snap only the output grid, within one frame.
      const outputStart = cursor/canvas.fps; cursor += frames;
      return {...s,outputStart,outputEnd:cursor/canvas.fps};
    });
    const plan = {id:out.id,label:out.label || out.id,front:source,body,segments,duration:cursor/canvas.fps,canvas:{...canvas},logo:image?{assetId:image.id,...logo}:null,packaging};
    plan.fingerprint = digest({segments,canvas:plan.canvas,logo:plan.logo,inputs:[...segments.map(s=>s.assetId),...(image?[image.id]:[])].map(id=>({id,sha256:p.assets.find(a=>a.id===id).sha256}))});
    const prior = p.plans.find(x=>x.id===plan.id && x.fingerprint===plan.fingerprint);
    return {...plan,operationId:prior?.operationId,revision:p.revision+1};
  });
}
export function compileCompose(p, plan) {
  const binding = id => {
    const asset = p.assets.find(a=>a.id===id); const b = asset?.upload?.receipt;
    check(b?.status === 'AVAILABLE' && b.fileId, 'UPLOAD_REQUIRED');
    return {fileId:b.fileId,...(b.mediaRef ? {mediaRef:b.mediaRef}:{})};
  };
  const timeline = plan.segments.map(s => ({track:'video',source:binding(s.assetId),start:s.outputStart,end:s.outputEnd,extra:[{type:'trim',start:s.start,end:s.end}],volume:1,transform:{width:plan.canvas.width,height:plan.canvas.height},position:{x:0,y:0}}));
  const l=plan.logo;
  if(l)timeline.push({track:'image',source:binding(l.assetId),start:0,end:plan.duration,opacity:l.opacity,position:{x:l.x,y:l.y},transform:{width:l.width,height:l.height}});
  return {canvas:plan.canvas,format:'mp4',timeline};
}
// Only expose execution-relevant fields; never spread persisted plan metadata.
export function planReview(p) {
  return p.plans.map(x=>({id:x.id,label:x.label,
    front:x.front&&{...(x.front.assetId?{assetId:x.front.assetId}:{}),...(x.front.highlightId?{highlightId:x.front.highlightId}:{})},
    body:x.body?.map(({episode,start,end})=>({episode,start,end})),
    canvas:x.canvas&&{width:x.canvas.width,height:x.canvas.height,fps:x.canvas.fps},
    logo:x.logo&&{assetId:x.logo.assetId,x:x.logo.x,y:x.logo.y,width:x.logo.width,height:x.logo.height,opacity:x.logo.opacity},
    endingAssetId:x.segments?.find(s=>s.kind==='ending')?.assetId,
    packaging:{ending:!!x.segments?.some(s=>s.kind==='ending'),logo:!!x.logo},
    duration:x.duration,operationId:x.operationId}));
}
export function parseHighlights(p, analysis, responses, diagnostics = []) {
  const all = []; const seen = new Set();
  for (const {operationId,episode,output} of responses) {
    check(analysis.episodes.includes(episode),'HIGHLIGHT_SCOPE_INVALID');
    const source=episodeAsset(p,episode);
    check(number(source.duration)&&source.duration>0,'HIGHLIGHT_SOURCE_INVALID','原始剧集缺少有效时长，请先核对原素材。');
    check(output&&(typeof output==='string'||typeof output==='object'&&!Array.isArray(output)),'HIGHLIGHT_FORMAT_INVALID');
    // The public operator normalizes scenes at the top level; task-keyed
    // structuredResult may simultaneously contain uppercase SCENES/SUMMARY.
    let rows = output.highlights ?? output.scenes ?? output.segments;
    if(rows === undefined){
      let data = output.structuredResult ?? output;
      if (typeof data === 'string') { try { data=JSON.parse(data); } catch { check(false,'HIGHLIGHT_FORMAT_INVALID'); } }
      rows = data?.highlights ?? data?.scenes ?? data?.segments ?? data?.SCENES ?? data?.HIGHLIGHTS;
    }
    check(Array.isArray(rows),'HIGHLIGHT_FORMAT_INVALID','理解结果没有合法的高光时间戳数组');
    for (const [index,row] of rows.entries()) {
      check(row&&typeof row==='object'&&!Array.isArray(row),'HIGHLIGHT_FORMAT_INVALID');
      const start = row.start ?? row.start_time; const end = row.end ?? row.end_time;
      if (row.episode !== undefined) check(row.episode===episode,'HIGHLIGHT_SOURCE_MISMATCH');
      const reject=code=>diagnostics.push({...(validId(operationId)?{operationId}:{}),episode,index,code});
      if(!number(start)||!number(end)){reject('HIGHLIGHT_FORMAT_INVALID');continue;}
      if(row.score!==undefined&&(!number(row.score)||row.score<0||row.score>100)){reject('HIGHLIGHT_SCORE_INVALID');continue;}
      if(start<0||end<=start||end>source.duration+0.000001){reject('SOURCE_RANGE_INVALID');continue;}
      const duration=end-start;
      if (duration < analysis.minDuration || duration > analysis.maxDuration){reject('HIGHLIGHT_DURATION_OUTSIDE_REQUEST');continue;}
      const key=`${episode}:${start}:${end}`; if (seen.has(key)) continue; seen.add(key);
      all.push({id:`hl-${digest(key).slice(0,16)}`,episode,start,end,reason:String(row.reason ?? row.description ?? ''),score:row.score ?? 0,operationId});
    }
  }
  // Rank is a reproducible suggestion. Agent/user select IDs; never silently expand scope.
  return all.sort((a,b)=> b.score-a.score || a.episode-b.episode || a.start-b.start || a.end-b.end);
}
