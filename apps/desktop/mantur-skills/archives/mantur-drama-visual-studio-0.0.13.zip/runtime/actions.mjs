import {agentPolling} from './agent-polling.mjs';
import {
  accessSync,
  constants,
  existsSync,
  lstatSync,
  mkdirSync,
} from "node:fs";
import { homedir } from "node:os";
import { extname, resolve } from "node:path";
import {
  assertProjectWritePath,
  httpUrl,
  outputPath,
  parseOptions,
  plainObject,
  projectRoot,
  readJson,
  runCli,
  cliVersionInfo,
  writeJson,
} from "./common.mjs";
import { imageDimensions, sha256 } from "./images.mjs";
import { validateVideoCheckpoint, normalizeVideoResponse, videoResultDiagnostic } from './video-status.mjs';
import { validateClipAssets } from './clip-assets.mjs';
import {
  exportJianyingDrafts,
  importJianyingDraft,
} from "./jianying.mjs";
import { createZip } from "./zip.mjs";
import {captureDeliveryGate, publishWithDeliveryGate, verifyEpisodeArchive} from './delivery-gate.mjs';
import {linkSync, readdirSync, rmSync} from 'node:fs';
import { deliveryRecord, saveDelivery, expectedClips } from './deliveries.mjs';
import { withProjectLock } from './project-lock.mjs';
import { readFileSync } from 'node:fs';
import { createHash, randomUUID } from 'node:crypto';
import { readonlyServiceStatus, startReadonlyService, stopReadonlyService, openWorkbench } from "./readonly-service.mjs";
import { refreshUiSnapshot, resolveSkillRoot, snapshotCompilerStatus } from "./studio.mjs";
import { abortSnapshotBatch, beginSnapshotBatch, commitSnapshotBatch, snapshotBatchHeartbeat } from "./snapshot-batch.mjs";
import { VERIFIED_DEV_CLI, authenticationProfile, accountBalancePoints, inspectOperator, hasReferenceImages, repairFor } from './manturhub-contract.mjs';
import {normalizeManturhubBase as normalizeEnvironmentBase,isDevelopmentManturhubSite} from './manturhub-environment.mjs';
import { clipCapabilities } from './clip-capabilities.mjs';
import {projectVideoModel,requireVideoPlatform,requireClipPlatform} from './video-models.mjs';
import {clipRequestTable} from './clip-request-table.mjs';
import {writeAccountBalanceCache} from './account-balance.mjs';

const SKILL_SLUG = "mantur-drama-visual-studio";
const SKILL_VERSION = "1.0.5";
const HARD_ENDING = "不要背景音乐，不要字幕。";
const continuityHardLimit = (token) => `镜头连续性硬性限制：${token} 是上一片段的真实尾帧。本片段开场必须紧接 ${token}，继承同一场景的空间布局、机位方向、景别、光线、人物位置、朝向、服装、表情与动作进度；只能按本段剧本继续动作。不得重新布置场景、不得让人物瞬移、不得无依据改变服装或外观。`;
const NATIVE_IMAGE_PROVIDER = "native_agent_imagegen";
const LEGACY_NATIVE_IMAGE_PROVIDER = "codex_imagegen";
const MANTURHUB_IMAGE_PROVIDER = "manturhub:op.image.generate";
const IMAGE_PROVIDERS = new Set([NATIVE_IMAGE_PROVIDER, MANTURHUB_IMAGE_PROVIDER]);
const IMAGE_PROVIDER_SELECTION_MODES = new Set(["user_selected", "only_available"]);
const STAGE_OPERATORS = {
  extraction: ["op.drama.asset-extract"],
  "asset-production": ["op.drama.asset-extract"],
  clips: ["op.drama.clip-seedance-compile"],
  video: ["op.drama.clip-seedance-compile", "op.video.generate"],
};
const ASSET_OPERATION_OPERATORS = Object.freeze({image:'op.image.generate',understanding:'op.video.understand-v2','voice-design':'op.voice.design',audio:'op.audio.generate'});
const VERSION_KEYS = ["active_version", "version", "version_tag", "active_version_tag"];
const ACTIVE_STATES = new Set(["created", "queued", "running", "pending", "processing", "in_progress"]);
const SUCCESS_STATES = new Set(["succeeded", "success", "completed", "done"]);
const FAILED_STATES = new Set(["failed", "error", "cancelled", "canceled"]);
const ASYNC_WAIT_POLICY_BY_ENVIRONMENT = Object.freeze({
  ai: Object.freeze({
    extraction: Object.freeze({ expected_min_seconds: 300, expected_max_seconds: 900 }),
    clips: Object.freeze({ expected_min_seconds: 300, expected_max_seconds: 900 }),
  }),
  cn: Object.freeze({
    extraction: Object.freeze({ expected_min_seconds: 300, expected_max_seconds: 900 }),
    clips: Object.freeze({ expected_min_seconds: 300, expected_max_seconds: 900 }),
  }),
});
const ASYNC_WAIT_POLICY_COMMON = Object.freeze({
  initial_poll_period_seconds: 120,
  initial_poll_interval_seconds: 15,
  steady_poll_interval_seconds: 30,
  long_running_after_seconds: 1200,
  minimum_observation_seconds: 1800,
  sixty_seconds_without_terminal_is_failure: false,
  active_after_minimum_observation_is_failure: false,
});
const ASYNC_WAIT_STAGES = new Set(["extraction", "clips"]);
const DEFAULT_VIDEO_CONCURRENCY = 5;
const MAX_VIDEO_CONCURRENCY = 20;
const MODEL_MAP = {
  "doubao-seedance-2-0-260128": "seedance",
  "doubao-seedance-2-0-mini-260615": "seedance-mini",
  seedance: "seedance",
  "seedance-fast": "seedance-fast",
  "seedance-mini": "seedance-mini",
};
const IMAGE_ROLES = new Set(["reference_image", "first_frame", "last_frame"]);
const REFERENCE_USE_ROLES = new Set(["style", "palette", "material", "rendering", "layout", "identity", "wardrobe", "structure"]);
const CONTENT_REFERENCE_ROLES = new Set(["identity", "wardrobe", "structure"]);

function localPath(value) {
  const text = String(value || "");
  return resolve(text === "~" ? homedir() : text.startsWith("~/") ? `${homedir()}/${text.slice(2)}` : text);
}

function addCheck(checks, name, ok, detail, repair) {
  const row = { name, ok: Boolean(ok), detail };
  if (!row.ok && repair) row.repair = repair;
  checks.push(row);
}

function checkProjectDirectory() {
  try {
    const root = projectRoot();
    accessSync(root, constants.R_OK | constants.W_OK);
    return [true, "persistent project directory is readable and writable"];
  } catch (error) {
    return [false, error.message];
  }
}

function projectStatePath() {
  return assertProjectWritePath(resolve(projectRoot(), ".pipeline-state", "project.json"));
}

function canonicalImageProvider(value) {
  return value === LEGACY_NATIVE_IMAGE_PROVIDER ? NATIVE_IMAGE_PROVIDER : value;
}

function classifyStoredImageProvider(value) {
  if (value === undefined || value === null || value === "") return "not_recorded";
  if (value === LEGACY_NATIVE_IMAGE_PROVIDER) return "legacy_alias";
  if (IMAGE_PROVIDERS.has(value)) return "supported";
  return "invalid";
}

function storedImageProviderSelection(state) {
  const selection = state.image_provider_selection;
  if (!plainObject(selection)) return null;
  if (!IMAGE_PROVIDERS.has(selection.provider) || !IMAGE_PROVIDER_SELECTION_MODES.has(selection.mode)) return null;
  return { provider: selection.provider, mode: selection.mode };
}

function inspectProjectImageProvider(selectedProvider, stage) {
  const path = projectStatePath();
  if (!existsSync(path)) return { status: "not_initialized", stored_image_provider: null };
  let state;
  try {
    state = readJson(path, { object: true });
  } catch (error) {
    return { status: "invalid", stored_image_provider: null, detail: error.message };
  }
  const stored = state.image_provider;
  const storedStatus = classifyStoredImageProvider(stored);
  if (storedStatus === "not_recorded") return { status: "not_recorded", stored_image_provider: null };
  if (storedStatus === "legacy_alias") {
    const providerChange = selectedProvider === MANTURHUB_IMAGE_PROVIDER;
    return {
      status: stage === "asset-production" ? "migration_required" : "legacy_alias_recognized",
      stored_image_provider: stored,
      canonical_image_provider: NATIVE_IMAGE_PROVIDER,
      selected_image_provider: selectedProvider,
      actual_provider_change_requires_confirmation: providerChange,
    };
  }
  if (storedStatus === "invalid") {
    return { status: "invalid", stored_image_provider: stored, detail: "unknown image_provider in project state" };
  }
  if (stage === "asset-production" && selectedProvider && stored !== selectedProvider) {
    return {
      status: "provider_change_required",
      stored_image_provider: stored,
      selected_image_provider: selectedProvider,
      actual_provider_change_requires_confirmation: true,
    };
  }
  const selection = storedImageProviderSelection(state);
  if (!selection) {
    const hasSelectionRecord = Object.prototype.hasOwnProperty.call(state, "image_provider_selection")
      && state.image_provider_selection !== null
      && state.image_provider_selection !== undefined;
    return {
      status: hasSelectionRecord ? "selection_stale" : "selection_unrecorded",
      stored_image_provider: stored,
      selected_image_provider: selectedProvider,
      blocks_production: false,
      next_action: hasSelectionRecord
        ? "refresh_or_clear_image_provider_selection_when_convenient"
        : "inspect_image_provider_options_when_convenient",
    };
  }
  if (selection.provider !== canonicalImageProvider(stored)) {
    return {
      status: "selection_stale",
      stored_image_provider: stored,
      selected_image_provider: selectedProvider,
      recorded_image_provider: selection.provider,
      selection,
      blocks_production: false,
      next_action: "refresh_or_clear_image_provider_selection_when_convenient",
    };
  }
  return {
    status: "current",
    stored_image_provider: stored,
    selected_image_provider: selectedProvider,
    selection,
  };
}

export function normalizeManturhubBase(value) {
  return normalizeEnvironmentBase(value);
}

export function resolveManturhubBase(environ = process.env) {
  if (typeof environ.MANTURHUB_BASE !== 'string' || environ.MANTURHUB_BASE.trim() === '') {
    const code=environ.MANTURHUB_BASE_RESOLUTION_ERROR||'CLI_BASE_URL_UNAVAILABLE';
    throw Object.assign(new Error('ManturHub CLI could not resolve its current site.'),{code});
  }
  const source=environ.MANTURHUB_BASE_SOURCE==='cli_getBaseUrl'?'cli_getBaseUrl':'environment';
  return [normalizeManturhubBase(environ.MANTURHUB_BASE),source];
}

const REMOTE_LINEAGE_DIRECTORIES = Object.freeze([
  'online-asset-extraction','asset-extraction','asset-operations','clip-operations','clip-compilation-import',
  'video-operations','video-budgets','video-plans','video-adoptions',
]);
const REMOTE_LINEAGE_KEYS = new Set([
  'fileid','jobid','taskid','pollurl','quote','quoteid','quotesha256','approval','approvalsha256',
  'idempotencykey','credentialsha256','apiroutes','remoteurl','downloadurl','uploadurl',
]);

function directoryHasEntries(path) {
  if (!existsSync(path)) return false;
  try {return readdirSync(path,{withFileTypes:true}).some(entry=>entry.isFile()||entry.isDirectory()||entry.isSymbolicLink());}
  catch {return true;}
}

function valueHasRemoteIdentity(value) {
  if (Array.isArray(value)) return value.some(valueHasRemoteIdentity);
  if (!plainObject(value)) return false;
  for (const [key,item] of Object.entries(value)) {
    const normalized=key.toLowerCase().replace(/[^a-z0-9]/g,'');
    if (REMOTE_LINEAGE_KEYS.has(normalized) && item !== null && item !== undefined && item !== '' && item !== false) return true;
    if (valueHasRemoteIdentity(item)) return true;
  }
  return false;
}

function fileTreeHasRemoteIdentity(path) {
  if (!existsSync(path)) return false;
  try {
    const stat=lstatSync(path);
    if (stat.isSymbolicLink()) return true;
    if (stat.isDirectory()) return readdirSync(path).some(name=>fileTreeHasRemoteIdentity(resolve(path,name)));
    if (!stat.isFile() || !/\.json$/i.test(path)) return false;
    return valueHasRemoteIdentity(JSON.parse(readFileSync(path,'utf8')));
  } catch {return true;}
}

export function hasRemoteLineage() {
  const stateRoot=resolve(projectRoot(),'.pipeline-state');
  const runtimeRoot=resolve(stateRoot,'runtime');
  if (REMOTE_LINEAGE_DIRECTORIES.some(name=>directoryHasEntries(resolve(runtimeRoot,name)))) return true;
  return ['tasks.json','tasks','runs.json','runs'].some(name=>fileTreeHasRemoteIdentity(resolve(stateRoot,name)));
}

export function inspectProjectSite(base) {
  const normalized=normalizeManturhubBase(base);
  const project=existsSync(projectStatePath())?readJson(projectStatePath(),{object:true}):{};
  const lineage=hasRemoteLineage();
  const hasStored=typeof project.manturhub_base==='string'&&project.manturhub_base.length>0;
  let stored=null;
  try {stored=project.manturhub_base?normalizeManturhubBase(project.manturhub_base):null;} catch {stored=null;}
  const status=stored===normalized?'current':lineage?'conflict_remote_lineage':hasStored?'rebindable':'unbound';
  return {status,current:normalized,project:stored,remote_lineage:lineage};
}

function siteConflict() {
  return Object.assign(new Error('The project is locked to another ManturHub site with remote lineage.'),{code:'MANTURHUB_SITE_CONFLICT'});
}

function requireCurrentProjectSiteForRemoteAction() {
  const [base]=resolveManturhubBase();
  if(inspectProjectSite(base).status!=='current')throw siteConflict();
  return base;
}

async function ensureProjectSiteForRemotePrepare() {
  const [base,source]=resolveManturhubBase();
  const lock=assertProjectWritePath(resolve(projectRoot(),'.pipeline-state','runtime','site-binding.lock'));
  return withProjectLock(lock,async()=>{
    const inspection=inspectProjectSite(base);
    if(inspection.status==='conflict_remote_lineage')throw siteConflict();
    if(inspection.status==='current')return base;
    const path=projectStatePath();
    if(!existsSync(path))throw Object.assign(new Error('Project state does not exist.'),{code:'PROJECT_NOT_INITIALIZED'});
    const project=readJson(path,{object:true}),before=JSON.stringify(project),updated={...project,manturhub_base:base};
    const changedAt=new Date().toISOString(),receiptId=createHash('sha256').update(`${before}\0${base}\0${changedAt}`).digest('hex');
    const receiptPath=assertProjectWritePath(resolve(projectRoot(),'.pipeline-state','runtime','site-bindings',`${receiptId}.json`));
    writeJson(path,updated);
    let refresh;
    try {
      refresh=await refreshUiSnapshot([]);
      if(refresh?.ok!==true)throw Object.assign(new Error('Snapshot refresh failed after site binding.'),{code:'SNAPSHOT_REFRESH_FAILED'});
      writeJson(receiptPath,{schema_version:1,receipt_id:receiptId,changed_at:changedAt,source,reason:inspection.status==='unbound'?'initial_binding':'safe_rebind',previous_site:inspection.project,current_site:base,remote_lineage_absent:true,project_before_sha256:createHash('sha256').update(before).digest('hex'),project_after_sha256:createHash('sha256').update(JSON.stringify(updated)).digest('hex'),snapshot_refresh:'succeeded'});
      return base;
    } catch(error) {
      writeJson(path,project);
      try {await refreshUiSnapshot([]);} catch {}
      writeJson(receiptPath,{schema_version:1,receipt_id:receiptId,changed_at:changedAt,source,reason:inspection.status==='unbound'?'initial_binding':'safe_rebind',previous_site:inspection.project,current_site:base,remote_lineage_absent:true,snapshot_refresh:'failed',rolled_back:true,error_code:error?.code??'SNAPSHOT_REFRESH_FAILED'});
      throw error;
    }
  });
}

export function asyncWaitPolicy(base, stage) {
  const normalizedBase = normalizeManturhubBase(base);
  const normalizedStage = stage === "asset-production" ? "extraction" : stage;
  if (!ASYNC_WAIT_STAGES.has(normalizedStage)) return null;
  if (isDevelopmentManturhubSite(normalizedBase)) return {environment:'dev',manturhub_base:normalizedBase,stage:normalizedStage,workflow_ready:false,expected_duration_verified:false};
  const environment = normalizedBase.endsWith(".cn") ? "cn" : "ai";
  return {
    environment,
    manturhub_base: normalizedBase,
    stage: normalizedStage,
    ...ASYNC_WAIT_POLICY_BY_ENVIRONMENT[environment][normalizedStage],
    ...ASYNC_WAIT_POLICY_COMMON,
  };
}

export function videoParallelismPolicy(requested = DEFAULT_VIDEO_CONCURRENCY, effective = null) {
  const requestedConcurrency = Number(requested);
  if (!Number.isInteger(requestedConcurrency) || requestedConcurrency < 1 || requestedConcurrency > MAX_VIDEO_CONCURRENCY) {
    throw new Error(`video concurrency must be 1-${MAX_VIDEO_CONCURRENCY}`);
  }
  const effectiveConcurrency = effective === null || effective === undefined ? null : Number(effective);
  if (effectiveConcurrency !== null) {
    if (!Number.isInteger(effectiveConcurrency) || effectiveConcurrency < 1 || effectiveConcurrency > MAX_VIDEO_CONCURRENCY) {
      throw new Error(`effective video concurrency must be 1-${MAX_VIDEO_CONCURRENCY}`);
    }
    if (effectiveConcurrency > requestedConcurrency) {
      throw new Error("effective video concurrency cannot exceed requested video concurrency");
    }
  }
  return {
    requested_video_concurrency: requestedConcurrency,
    effective_video_concurrency: effectiveConcurrency,
    default_video_concurrency: DEFAULT_VIDEO_CONCURRENCY,
    maximum_configurable_video_concurrency: MAX_VIDEO_CONCURRENCY,
    scheduling_unit: "scene_chain",
    scope: "project_global",
    same_chain_serial: true,
    different_chains_parallel: true,
    queue_policy: "fifo_episode_scene",
    live_limit_check_required: effectiveConcurrency === null,
  };
}

function versionTuple(value) {
  const match = String(value || "").trim().match(/^v?(\d+)\.(\d+)\.(\d+)/);
  return match ? match.slice(1, 4).map(Number) : null;
}

function versionAtLeast(actual, minimum) {
  if (!actual) return false;
  for (let index = 0; index < 3; index++) {
    if (actual[index] !== minimum[index]) return actual[index] > minimum[index];
  }
  return true;
}

function liveVersion(payload) {
  for (const key of VERSION_KEYS) if (payload[key]) return payload[key];
  if (plainObject(payload.active)) {
    for (const key of ["tag", "version", "version_tag"]) if (payload.active[key]) return payload.active[key];
  }
  if (Array.isArray(payload.versions)) {
    const activeRows = payload.versions.filter((row) => plainObject(row) && (row.active === true || Number(row.weight) > 0));
    if (activeRows.length === 1) return activeRows[0].tag || activeRows[0].version;
  }
  return null;
}

function describeOperator(operatorId, cli, base) {
  try {
    const { payload } = runCli(["describe", operatorId, "--json"], {cli,base,readOnlyRetry:true});
    const inspected = inspectOperator(payload, operatorId);
    return {...inspected, detail:inspected.code || inspected.profile};
  } catch (error) {
    return { ok: false, code:error.code || 'OPERATOR_CONTRACT_UNVERIFIED', detail:error.code || 'OPERATOR_CONTRACT_UNVERIFIED', profile:'unverified', payload:null };
  }
}

function checkVoiceCatalog() {
  const skillDir = resolveSkillRoot();
  try {
    const payload = readJson(resolve(skillDir, "voice-library", "catalog.json"), { object: true });
    const voices = payload.voices;
    if (!Array.isArray(voices) || !voices.length) return [false, "catalog contains no voices"];
    if (payload.voice_count !== voices.length) return [false, "voice_count does not match catalog rows"];
    const ids = voices.map((row) => row?.voice_id);
    const hashes = voices.map((row) => row?.sha256);
    if (new Set(ids).size !== voices.length || ids.some((id) => !id)) return [false, "voice_id values are missing or duplicated"];
    if (new Set(hashes).size !== voices.length || hashes.some((hash) => typeof hash !== "string" || hash.length !== 64)) {
      return [false, "voice checksums are missing or duplicated"];
    }
    for (const voice of voices) {
      if (!voice.active || !voice.asset_id) return [false, `inactive preset voice: ${voice.voice_id}`];
      httpUrl(voice.public_url, `voice ${voice.voice_id}`, { httpsOnly: true, noQuery: true });
      if (voice.mime_type !== "audio/mpeg" || Number(voice.file_duration_seconds) < 2) {
        return [false, `invalid audio metadata: ${voice.voice_id}`];
      }
    }
    return [true, `${voices.length} immutable preset voices ready`];
  } catch (error) {
    return [false, `catalog invalid: ${error.message}`];
  }
}

export function localMediaContract() {
  const skillDir = resolveSkillRoot();
  const manifest = "assets/local-project-media-contract.json";
  const payload = readJson(resolve(skillDir, manifest), { object: true });
  if (payload.schema_version !== 1 || payload.contract_version !== "mantur-drama-local-media-v1") {
    throw new Error("invalid local project media contract identity");
  }
  const requiredPaths = [
    "project_state",
    "manifest",
    "results",
    "runs",
    "project_snapshot",
    "asset_snapshot",
    "episode_index_snapshot",
    "episode_snapshots",
    "task_snapshot",
    "delivery_snapshot",
  ];
  if (!plainObject(payload.paths) || requiredPaths.some((name) => !String(payload.paths[name] || "").startsWith(".pipeline-state/"))) {
    throw new Error("local project contract contains missing or unsafe paths");
  }
  const mediaFields = payload.media_record_required;
  const expectedFields = ["media_id", "kind", "project_relative_path", "sha256", "mime_type", "bytes", "availability"];
  if (!Array.isArray(mediaFields) || expectedFields.some((name) => !mediaFields.includes(name))) {
    throw new Error("local media records are missing required integrity fields");
  }
  const requiredKinds = payload.completion_gate?.required_media_kinds;
  if (!Array.isArray(requiredKinds) || !requiredKinds.includes("video") || !requiredKinds.includes("last_frame")) {
    throw new Error("video completion gate must require local video and last-frame media");
  }
  for (const flag of [
    "project_relative_path_only",
    "require_existing_regular_file",
    "require_non_empty_file",
    "require_valid_mime",
    "require_sha256",
    "status_may_be_completed_only_after_snapshot_readback",
  ]) {
    if (payload.completion_gate?.[flag] !== true) throw new Error(`local media completion gate must enable ${flag}`);
  }
  return {
    ok: true,
    manifest,
    ...payload,
  };
}

function loadStoryboardStatusContract() {
  const skillDir = resolveSkillRoot();
  const manifest = "assets/storyboard-status-contract.json";
  const payload = readJson(resolve(skillDir, manifest), { object: true });
  if (payload.schema_version !== 1 || payload.contract_version !== "storyboard-status-cn-v1") {
    throw new Error("invalid storyboard status contract identity");
  }
  for (const table of ["Clip总表", "Seedance2.0请求体"]) {
    const fields = payload.tables?.[table];
    if (!plainObject(fields)) throw new Error(`status contract is missing ${table}`);
    for (const [field, spec] of Object.entries(fields)) {
      if (spec?.type !== "select" || spec.multiple !== false || !Array.isArray(spec.values) || !spec.values.length) {
        throw new Error(`${table}.${field} must be a non-empty local enum contract`);
      }
      if (new Set(spec.values).size !== spec.values.length || spec.values.some((value) => typeof value !== "string" || !value.trim())) {
        throw new Error(`${table}.${field} contains invalid or duplicate values`);
      }
      if (spec.default_value && (!Array.isArray(spec.default_value) || spec.default_value.length !== 1 || !spec.values.includes(spec.default_value[0]))) {
        throw new Error(`${table}.${field} has an invalid default_value`);
      }
      for (const [alias, canonical] of Object.entries(spec.legacy_aliases || {})) {
        if (!alias || !spec.values.includes(canonical)) throw new Error(`${table}.${field} has an invalid legacy alias`);
      }
    }
  }
  return { manifest, payload };
}

export function storyboardStatusContract() {
  const { manifest, payload } = loadStoryboardStatusContract();
  const fieldDefinitions = {};
  for (const [table, fields] of Object.entries(payload.tables)) {
    fieldDefinitions[table] = Object.entries(fields).map(([name, spec]) => ({
      type: "enum",
      name,
      ...(spec.default_value ? { default_value: spec.default_value } : {}),
      values: spec.values,
    }));
  }
  return { ok: true, manifest, ...payload, local_json_field_definitions: fieldDefinitions };
}

export function normalizeStoryboardStatuses(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["output"] });
  const input = readJson(localPath(positionals[0]), { object: true });
  const { payload: contract } = loadStoryboardStatusContract();
  const normalized = structuredClone(input);
  let mapped = 0;
  let checked = 0;
  for (const [table, fields] of Object.entries(contract.tables)) {
    const rows = normalized[table==='Seedance2.0请求体'?clipRequestTable(normalized):table];
    if (!Array.isArray(rows)) throw new Error(`input is missing ${table}`);
    rows.forEach((row, rowIndex) => {
      for (const [field, spec] of Object.entries(fields)) {
        const raw = row?.[field];
        if (raw === undefined || raw === null || String(raw).trim() === "") {
          if (Array.isArray(spec.default_value) && spec.default_value.length === 1) {
            row[field] = spec.default_value[0];
            checked += 1;
            mapped += 1;
            continue;
          }
          throw new Error(`${table} row ${rowIndex + 1} is missing required status field ${field}`);
        }
        const value = String(raw).trim();
        checked += 1;
        if (spec.values.includes(value)) continue;
        const canonical = spec.legacy_aliases?.[value];
        if (!canonical) throw new Error(`${table} row ${rowIndex + 1} contains unknown ${field}: ${value}`);
        row[field] = canonical;
        mapped += 1;
      }
    });
  }
  const target = outputPath(options.output, "--output");
  writeJson(target, normalized);
  return { ok: true, contract_version: contract.contract_version, checked_status_cells: checked, migrated_legacy_cells: mapped, output: target };
}

function parseDoctorArgs(tokens) {
  const { options } = parseOptions(tokens, {
    positionals: 0,
    values: ["stage", "video-concurrency", "asset-operation"],
    booleans: ["native-image", "native-video", "native-imagegen", "reference-images", "custom-voice"],
  });
  const stage = options.stage || "video";
  if (!Object.hasOwn(STAGE_OPERATORS, stage)) throw new Error(`invalid stage: ${stage}`);
  if (options['custom-voice'] && stage !== 'asset-production') throw new Error('--custom-voice requires --stage asset-production');
  if(options['asset-operation']&&(stage!=='asset-production'||!Object.hasOwn(ASSET_OPERATION_OPERATORS,options['asset-operation'])))throw new Error('Invalid asset-operation selection');
  const videoParallelism = videoParallelismPolicy(options["video-concurrency"] ?? DEFAULT_VIDEO_CONCURRENCY);
  return { ...options, stage, videoParallelism };
}

export function doctor(tokens) {
  const options = parseDoctorArgs(tokens);
  const selectedVideo = projectVideoModel(existsSync(projectStatePath())?readJson(projectStatePath(),{object:true}):{});
  const nativeOnly=options.stage==='asset-production'&&!options['custom-voice']&&(
    (!options['asset-operation']&&options['native-imagegen']&&options['native-image'])||
    (options['asset-operation']==='image'&&options['native-imagegen'])||
    (options['asset-operation']==='understanding'&&options['native-image']));
  const checks = [];
  let mediaContract = null;
  try {
    mediaContract = localMediaContract();
    addCheck(checks, "local_project_media_contract", true, "local video and tail-frame files have integrity and readback gates");
  } catch (error) {
    addCheck(checks, "local_project_media_contract", false, error.message, "Restore assets/local-project-media-contract.json from the Skill bundle");
  }
  let statusContract = null;
  try {
    statusContract = storyboardStatusContract();
    addCheck(checks, "storyboard_status_contract", true, "storyboard status fields use fixed Chinese JSON enums");
  } catch (error) {
    addCheck(checks, "storyboard_status_contract", false, error.message, "Restore assets/storyboard-status-contract.json from the published Skill bundle");
  }
  const [projectReady, projectDetail] = checkProjectDirectory();
  addCheck(
    checks,
    "project_directory",
    projectReady,
    projectDetail,
    "Choose a persistent project directory and grant the Agent read/write permission"
  );
  let base = null;
  let source = null;
  let projectSiteStatus = null;
  let cli = null;
  if(!nativeOnly){try { cli = cliVersionInfo(); addCheck(checks, 'manturhub_cli', true, `version=${cli.version}; channel=${cli.channel}`); }
  catch (error) { addCheck(checks, 'manturhub_cli', false, error.code || 'CLI_UNAVAILABLE', repairFor(error.code)); }}
  const cliReady = Boolean(cli);
  try {
    [base,source] = resolveManturhubBase(process.env);
    const inspection=inspectProjectSite(base);projectSiteStatus=inspection.status;
    if(inspection.status==='conflict_remote_lineage'&&!nativeOnly)throw siteConflict();
    addCheck(checks, "manturhub_environment", true, nativeOnly?`local route; optional base=${base}; project_site_status=${inspection.status}`:`base=${base}; source=${source}; project_site_status=${inspection.status}`);
  } catch (error) {
    base = null;
    const code=['MANTURHUB_SITE_CONFLICT','MANTURHUB_ENVIRONMENT_INVALID','CLI_UNAVAILABLE','CLI_NOT_FOUND','CLI_VERSION_UNSUPPORTED','CLI_BASE_URL_UNAVAILABLE'].includes(error?.code)?error.code:'CLI_BASE_URL_UNAVAILABLE';
    addCheck(checks, "manturhub_environment", nativeOnly, nativeOnly?`not required for local route; ${code}`:code, nativeOnly?undefined:repairFor(code));
  }
  const descriptions = {};
  let authProfile = null;
  const describe = operatorId => {
    if (descriptions[operatorId]) return descriptions[operatorId];
    const described = describeOperator(operatorId, cli, base);
    descriptions[operatorId] = described;
    addCheck(checks, `operator:${operatorId}`, described.ok, described.detail, repairFor(described.code));
    return described;
  };
  let remoteAuthReady = false;
  if (!nativeOnly&&cliReady && base) {
    try {
      inspectCliAuthStatus(cli,base);
      const { payload } = runCli(["balance", "--json"], {cli,base,readOnlyRetry:true});
      authProfile = authenticationProfile(payload);
      remoteAuthReady = true;
      addCheck(checks, 'manturhub_auth', true, `authenticated; profile=${authProfile}`);
    } catch (error) {
      addCheck(checks, "manturhub_auth", false, error.code || 'MANTURHUB_RESPONSE_INCOMPATIBLE', repairFor(error.code));
    }
    if(remoteAuthReady){
      for (const operatorId of options['asset-operation']?[ASSET_OPERATION_OPERATORS[options['asset-operation']]]:options.stage==='asset-production'?[]:STAGE_OPERATORS[options.stage].map(id=>id==='op.drama.clip-seedance-compile'?selectedVideo.clipOperator:id)) describe(operatorId);
      if (options['custom-voice']&&!options['asset-operation']) describe('op.voice.design');
      if (options["reference-images"]) {
        const result = describe('op.drama.asset-extract');
        const hasField = result.ok && hasReferenceImages(result.payload, result.profile);
        addCheck(checks, "asset_reference_images_schema", hasField, hasField ? "reference image array present" : "OPERATOR_CONTRACT_UNVERIFIED", "Review the structured reference-images field in the current input schema");
      }
    }
  } else if(!nativeOnly)addCheck(checks, 'manturhub_auth', false, 'NOT_CHECKED', 'Resolve CLI and environment checks first; authentication was not attempted');
  else addCheck(checks,'local_route',true,'No remote CLI/auth/operator required for the selected native route');

  let visualRoute = "not_required";
  if (["asset-production", "video"].includes(options.stage)&&(!options['asset-operation']||options['asset-operation']==='understanding')) {
    const nativeVision = options["native-image"] && (options["native-video"] || options.stage === "asset-production");
    if (nativeVision) {
      visualRoute = "native_agent";
      addCheck(checks, "visual_route", true, "native_agent_visual_understanding");
    } else if (remoteAuthReady) {
      const described = describe("op.video.understand-v2");
      addCheck(checks, "visual_route", described.ok, described.ok ? "manturhub_visual_operator" : "no usable visual route");
      visualRoute = described.ok ? "op.video.understand-v2" : null;
    } else {
      visualRoute = null;
      addCheck(checks, "visual_route", false, "no native vision and no ManturHub CLI", "Provide native vision or install ManturHub CLI");
    }
  } else addCheck(checks, "visual_route", true, "not required for this stage");

  let imageProvider = "not_required";
  if (options.stage === "asset-production"&&(!options['asset-operation']||options['asset-operation']==='image')) {
    if (options["native-imagegen"]) {
      imageProvider = NATIVE_IMAGE_PROVIDER;
      addCheck(checks, "image_provider", true, imageProvider);
    } else if (remoteAuthReady) {
      const described = describe("op.image.generate");
      imageProvider = described.ok ? MANTURHUB_IMAGE_PROVIDER : null;
      addCheck(checks, "image_provider", described.ok, imageProvider || "no usable image generation route");
    } else {
      imageProvider = null;
      addCheck(
        checks,
        "image_provider",
        false,
        "no Agent-native image generation and no ManturHub CLI",
        "Declare Agent-native image generation with --native-imagegen, or install and authenticate ManturHub CLI"
      );
    }
  }
  const videoProvider = options.stage === "video" ? "manturhub:op.video.generate" : "not_required";
  if (["clips", "video"].includes(options.stage)||(options.stage==='asset-production'&&!options['asset-operation']&&!nativeOnly)) {
    const [ok, detail] = checkVoiceCatalog();
    addCheck(checks, "preset_voice_catalog", ok, detail, "Publish the bundled preset voice catalog to permanent public ManturHub storage");
  }

  const snapshotCompiler = snapshotCompilerStatus();
  addCheck(checks, "snapshot_compiler", snapshotCompiler.ok, snapshotCompiler.detail, snapshotCompiler.repair);
  let projectProviderState = { status: "unavailable", stored_image_provider: null };
  if (projectReady&&imageProvider!=="not_required") {
    projectProviderState = inspectProjectImageProvider(imageProvider, options.stage);
    if (projectProviderState.status === "invalid") {
      addCheck(
        checks,
        "project_image_provider",
        false,
        projectProviderState.detail,
        "Repair .pipeline-state/project.json with an explicitly confirmed supported image provider"
      );
    } else if (projectProviderState.status === "migration_required") {
      const target = projectProviderState.selected_image_provider;
      const confirmation = target === MANTURHUB_IMAGE_PROVIDER
        ? "--confirm-provider-change"
        : "--confirm-native-imagegen";
      addCheck(
        checks,
        "project_image_provider",
        false,
        `${LEGACY_NATIVE_IMAGE_PROVIDER} is a recognized legacy alias; explicit migration to ${target} is required`,
        `Run the allowlisted migrate-image-provider action with --to ${target} ${confirmation}`
      );
    } else if (projectProviderState.status === "provider_change_required") {
      const target = projectProviderState.selected_image_provider;
      const nativeConfirmation = target === NATIVE_IMAGE_PROVIDER ? " --confirm-native-imagegen" : "";
      addCheck(
        checks,
        "project_image_provider",
        false,
        `stored=${projectProviderState.stored_image_provider}; selected=${projectProviderState.selected_image_provider}`,
        `Confirm the provider change through select-image-provider --to ${target} --user-selected --confirm-provider-change${nativeConfirmation}`
      );
    } else if (projectProviderState.status === "selection_unrecorded") {
      addCheck(
        checks,
        "project_image_provider",
        true,
        `stored=${projectProviderState.stored_image_provider}; optional image provider choice has not been recorded`
      );
    } else if (projectProviderState.status === "selection_stale") {
      addCheck(
        checks,
        "project_image_provider",
        true,
        `stored=${projectProviderState.stored_image_provider}; optional image provider choice is stale and ignored`
      );
    } else {
      addCheck(checks, "project_image_provider", true, projectProviderState.status);
    }
  }
  const connectionReady = nativeOnly || ['manturhub_cli','manturhub_environment','manturhub_auth'].every(name => checks.some(row => row.name === name && row.ok));
  const contractChecks = checks.filter(row => row.name.startsWith('operator:') || row.name === 'asset_reference_images_schema');
  const operatorContractReady = (contractChecks.length > 0||nativeOnly) && contractChecks.every(row => row.ok);
  const profiles = [...new Set(Object.values(descriptions).map(row => row.profile))];
  const contractProfile = profiles.length === 1 ? profiles[0] : profiles.length ? 'mixed' : 'unverified';
  const openapi = Object.values(descriptions).some(row => row.profile.startsWith('openapi')) || authProfile === 'openapi';
  const clipCapability = ['clips','video'].includes(options.stage) && openapi
    ? clipCapabilities(descriptions[selectedVideo.clipOperator]?.ok === true,selectedVideo.id) : undefined;
  if (clipCapability) addCheck(checks, 'clip_business_contracts', clipCapability.business_contract_ready, clipCapability.message??'observed file-reference profile; see references/clip-compilation.md',
    'Only the documented manifest/storyboard profile is supported; video uses its independent contract and quota checks.');
  const videoModelReady=selectedVideo.videoEnabled&&selectedVideo.artifactReady;
  if(options.stage==='video')addCheck(checks,'video_model_contract',videoModelReady,videoModelReady?'local video adapter enabled':'VIDEO_MODEL_UNVERIFIED','按所选模型执行；实时合同、参数、费用批准与实际尾帧仍需校验。');
  const contractReady = operatorContractReady && (!clipCapability || clipCapability.business_contract_ready) && (options.stage!=='video'||videoModelReady);
  const workflowReady = contractReady && (nativeOnly||(!openapi && contractProfile === 'legacy') || contractProfile==='openapi_v1');
  addCheck(checks, 'workflow_adapter', workflowReady, workflowReady ? (openapi?'selected asset adapter available; deployment acceptance pending':'local or legacy workflow adapter available') : clipCapability?.error_code??(!contractReady ? 'OPERATOR_CONTRACT_UNVERIFIED' : 'WORKFLOW_ADAPTER_NOT_READY'), 'Complete and test the selected contract workflow before production; do not submit');
  const ok = checks.every((row) => row.ok);
  return {
    ok,
    connection_ready: connectionReady,
    contract_ready: contractReady,
    workflow_ready: workflowReady,
    video_model: selectedVideo.id,
    clip_capabilities: clipCapability,
    video_capabilities: options.stage==='video'&&openapi?{profile:selectedVideo.profile,local_review_and_preview:true,simulation_adapter:true,workflow_ready:workflowReady,platform_model_verified:selectedVideo.platformModelReady,tail_contract_verified:selectedVideo.tailReady,platform_limits_required:false,platform_limits_verified:null,quota_source:'skill_default',quota_coordination:'agent_guidance',quota_enforcement:'platform',local_shared_quota:false,max_active_video_tasks:5,qpm:null,blocking_codes:[...(videoModelReady?[]:['VIDEO_MODEL_UNVERIFIED'])],cross_origin_credential_forwarding:isDevelopmentManturhubSite(base),api_route_policy:'development-pair-production-same-origin',deployment_verified:false}:undefined,
    asset_capabilities: options.stage==='asset-production'?{selected:options['asset-operation']??'project_routes',implemented:{image:true,understanding:true,voice_design:true,audio_reference:true},selected_path_ready:workflowReady,fixed_voice_id_synthesis:false,file_id_only_download:false,deployment_verified:false}:undefined,
    contract_profile: contractProfile,
    operator_contracts: Object.fromEntries(Object.entries(descriptions).map(([id,row]) => [id,{profile:row.profile,ok:row.ok,error_code:row.code}])),
    manturhub_base: base,
    manturhub_base_source: source,
    project_site_status: projectSiteStatus,
    stage: options.stage,
    visual_route: visualRoute,
    image_provider: imageProvider,
    video_provider: videoProvider,
    project_provider_state: projectProviderState,
    async_wait_policy: base ? asyncWaitPolicy(base, options.stage) : null,
    video_parallelism_policy: options.videoParallelism,
    local_project_media_contract: mediaContract,
    storyboard_status_contract: statusContract,
    runtime_requirements: {
      minimum_cli_version: "0.10.0",
      verified_prerelease_cli_versions: [VERIFIED_DEV_CLI],
      manturhub_login_required: true,
      persistent_project_directory: "read_write",
      snapshot_compiler: "required_for_manifest_and_read_only_ui_snapshots",
    },
    checks,
  };
}

function supportsCliManagedAuth(cli){
  if(cli?.channel!=='stable')return false;
  const match=/^(\d+)\.(\d+)\.(\d+)(?:\+[0-9A-Za-z.-]+)?$/.exec(String(cli.version??''));if(!match)return false;
  const parts=match.slice(1).map(Number),minimum=[1,2,5];
  for(let i=0;i<3;i++){if(parts[i]!==minimum[i])return parts[i]>minimum[i];}
  return true;
}

function inspectCliAuthStatus(cli,base){
  if(!supportsCliManagedAuth(cli)){
    if(process.env.MANTURHUB_KEY)return null;
    throw Object.assign(new Error('CLI managed authentication is unavailable.'),{code:'CLI_AUTH_ADAPTER_UNAVAILABLE'});
  }
  const {payload}=runCli(['auth','status','--json'],{allowNonZeroJson:true,cli,base});
  let statusBase;try{statusBase=normalizeEnvironmentBase(payload.baseUrl);}catch{throw Object.assign(new Error('CLI auth status is invalid.'),{code:'CLI_AUTH_ADAPTER_UNAVAILABLE'});}
  if(statusBase!==normalizeEnvironmentBase(base))throw Object.assign(new Error('CLI and project sites differ.'),{code:'MANTURHUB_SITE_CONFLICT'});
  if(payload.authenticated!==true)throw Object.assign(new Error('ManturHub login is required.'),{code:'MANTURHUB_AUTH_REQUIRED'});
  if(payload.operatorReady!==true)throw Object.assign(new Error('ManturHub operator key is not ready.'),{code:'MANTURHUB_OPERATOR_KEY_NOT_READY'});
  return {authenticated:true,operatorReady:true,baseUrl:statusBase,mode:payload.mode};
}

export function onlineAuthFactory(){
  let current;
  return async()=>{
    if(current)return current;
    const [site]=resolveManturhubBase(),inspection=inspectProjectSite(site);
    if(inspection.status!=='current')throw Object.assign(new Error('Project site changed.'),{code:'MANTURHUB_SITE_CONFLICT'});
    const {createLegacyKeyAuth}=await import('./manturhub-online-transport.mjs');
    if(process.env.MANTURHUB_KEY){current=createLegacyKeyAuth(site);return current;}
    const cli=cliVersionInfo();inspectCliAuthStatus(cli,site);
    const {createCliManagedAuth}=await import('./manturhub-cli-auth.mjs');
    current=await createCliManagedAuth({entry:cli.entry,version:cli.version,site});return current;
  };
}

export function inspectImageProviderOptions(tokens) {
  const { options } = parseOptions(tokens, {
    positionals: 0,
    booleans: ["native-imagegen"],
  });
  const routes = [];
  if (options["native-imagegen"]) {
    routes.push({ provider: NATIVE_IMAGE_PROVIDER, available: true, source: "agent_capability" });
  }

  let remoteRoute;
  try {
    const cli = cliVersionInfo();
    const [base, source] = resolveManturhubBase(process.env);
    const site = inspectProjectSite(base);
    if (site.status === "conflict_remote_lineage") throw siteConflict();
    const { payload } = runCli(["balance", "--json"], { cli, base, readOnlyRetry: true });
    authenticationProfile(payload);
    const described = describeOperator("op.image.generate", cli, base);
    if (!described.ok) throw Object.assign(new Error(described.detail), { code: described.code });
    remoteRoute = {
      provider: MANTURHUB_IMAGE_PROVIDER,
      available: true,
      source: "manturhub_current_site",
      manturhub_base: base,
      manturhub_base_source: source,
      contract_profile: described.profile,
    };
    routes.push(remoteRoute);
  } catch (error) {
    remoteRoute = {
      provider: MANTURHUB_IMAGE_PROVIDER,
      available: false,
      source: "manturhub_current_site",
      error_code: error?.code || "OPERATOR_CONTRACT_UNVERIFIED",
    };
  }

  const state = existsSync(projectStatePath()) ? readJson(projectStatePath(), { object: true }) : {};
  const stored = canonicalImageProvider(state.image_provider);
  const selection = storedImageProviderSelection(state);
  const available = routes.map((route) => route.provider);
  const persisted = selection && selection.provider === stored ? selection : null;
  const selectedProvider = persisted?.provider ?? (available.length === 1 ? available[0] : null);
  const selectedAvailable = selectedProvider ? available.includes(selectedProvider) : false;
  const selectionRequired = !persisted && available.length > 1;
  const selectionRecordRequired = !persisted && available.length === 1;
  const providerChangeRequired = Boolean(
    selectionRecordRequired &&
    IMAGE_PROVIDERS.has(stored) &&
    stored !== selectedProvider
  );

  return {
    ok: available.length > 0,
    available_image_providers: available,
    routes: [
      ...routes,
      ...(routes.some((route) => route.provider === MANTURHUB_IMAGE_PROVIDER) ? [] : [remoteRoute]),
    ],
    selected_provider: selectedProvider,
    selected_provider_available: selectedAvailable,
    persisted_selection: persisted,
    selection_required: selectionRequired,
    selection_record_required: selectionRecordRequired,
    provider_change_required: providerChangeRequired,
    next_action: selectionRequired
      ? "ask_user_to_choose_image_provider"
      : providerChangeRequired
        ? "ask_user_to_confirm_image_provider_change"
        : selectionRecordRequired
          ? "record_only_available_image_provider"
          : !selectedAvailable
            ? "repair_selected_image_provider"
            : "continue_with_selected_image_provider",
  };
}

export function runWorkflow(tokens) {
  const report = doctor(tokens);
  return {
    ...report,
    project: projectRoot(),
    orchestration: "agent",
    next_action: report.ok ? "continue_with_skill_workflow" : !report.connection_ready ? "repair_connection_checks" : !report.contract_ready ? "review_operator_contract" : !report.workflow_ready ? "complete_workflow_adapter" : "repair_failed_checks",
    snapshot_refresh_action: "refresh-ui-snapshot",
  };
}

function updateImageProvider(tokens, requireSelectionMode) {
  const { options } = parseOptions(tokens, {
    positionals: 0,
    values: ["to"],
    booleans: ["confirm-native-imagegen", "confirm-provider-change", "user-selected", "only-available"],
  });
  const target = options.to;
  if (!IMAGE_PROVIDERS.has(target)) throw new Error(`unsupported image provider: ${target || "(empty)"}`);
  if (options["user-selected"] && options["only-available"]) {
    throw new Error("--user-selected and --only-available are mutually exclusive");
  }
  const selectionMode = options["user-selected"]
    ? "user_selected"
    : options["only-available"]
      ? "only_available"
      : null;
  if (requireSelectionMode && !selectionMode) {
    throw new Error("select-image-provider requires --user-selected or --only-available");
  }
  const path = projectStatePath();
  if (!existsSync(path)) throw new Error("project state does not exist: .pipeline-state/project.json");
  const state = readJson(path, { object: true });
  const current = state.image_provider;
  const currentStatus = classifyStoredImageProvider(current);
  const providerUnrecorded = currentStatus === "not_recorded";
  if (currentStatus === "invalid") {
    throw new Error(`unsupported stored image provider: ${current || "(empty)"}`);
  }
  if (providerUnrecorded && !requireSelectionMode) {
    throw new Error("image provider is not recorded; use select-image-provider with --user-selected or --only-available");
  }
  const aliasOnly = currentStatus === "legacy_alias" && target === NATIVE_IMAGE_PROVIDER;
  const actualProviderChanged = !providerUnrecorded && current !== target && !aliasOnly;
  if (target === NATIVE_IMAGE_PROVIDER && !options["confirm-native-imagegen"]) {
    throw new Error("--confirm-native-imagegen is required to confirm the current Agent exposes native image generation");
  }
  if (actualProviderChanged && !options["confirm-provider-change"]) {
    throw new Error("--confirm-provider-change is required because this changes the actual image provider");
  }
  if (target === MANTURHUB_IMAGE_PROVIDER) {
    const described = describeOperator("op.image.generate");
    if (!described.ok) throw new Error("current-site ManturHub op.image.generate is unavailable");
  }
  const priorSelection = storedImageProviderSelection(state);
  if (current === target && (!selectionMode || (priorSelection?.provider === target && priorSelection.mode === selectionMode))) {
    return {
      ok: true,
      changed: false,
      image_provider: target,
      selection: priorSelection,
      audit: "already_current",
    };
  }
  const migrations = Array.isArray(state.provider_migrations) ? state.provider_migrations : [];
  const providerAudit = providerUnrecorded || current === target ? null : {
    sequence: migrations.length + 1,
    from: current,
    to: target,
    actual_provider_changed: actualProviderChanged,
    reason: aliasOnly ? "legacy_alias_normalization" : "explicit_provider_reroute",
    migrated_by: `${SKILL_SLUG}@${SKILL_VERSION}`,
  };
  const selectionAudits = Array.isArray(state.provider_selection_audits) ? state.provider_selection_audits : [];
  const selectionAudit = selectionMode ? {
    sequence: selectionAudits.length + 1,
    from_provider: providerUnrecorded ? null : canonicalImageProvider(current),
    provider: target,
    mode: selectionMode,
    actual_provider_changed: actualProviderChanged,
    selected_by: selectionMode === "user_selected" ? "user" : "capability_resolution",
    recorded_by: `${SKILL_SLUG}@${SKILL_VERSION}`,
  } : null;
  const hasSelectionRecord = Object.prototype.hasOwnProperty.call(state, "image_provider_selection")
    && state.image_provider_selection !== null
    && state.image_provider_selection !== undefined;
  const selectionCleared = Boolean(
    !selectionAudit &&
    hasSelectionRecord &&
    (actualProviderChanged || (aliasOnly && priorSelection?.provider !== NATIVE_IMAGE_PROVIDER))
  );
  const stateWithoutSelection = selectionCleared
    ? Object.fromEntries(Object.entries(state).filter(([key]) => key !== "image_provider_selection"))
    : state;
  writeJson(path, {
    ...stateWithoutSelection,
    image_provider: target,
    ...(providerAudit ? { provider_migrations: [...migrations, providerAudit] } : {}),
    ...(selectionAudit ? {
      image_provider_selection: { provider: target, mode: selectionMode },
      provider_selection_audits: [...selectionAudits, selectionAudit],
    } : {}),
  });
  return {
    ok: true,
    changed: true,
    image_provider: target,
    selection: selectionAudit ? { provider: target, mode: selectionMode } : selectionCleared ? null : priorSelection,
    selection_cleared: selectionCleared,
    provider_migration_audit: providerAudit,
    provider_selection_audit: selectionAudit,
  };
}

export function migrateImageProvider(tokens) {
  return updateImageProvider(tokens, false);
}

export function selectImageProvider(tokens) {
  return updateImageProvider(tokens, true);
}

export function validateReferences(tokens) {
  const { positionals, options } = parseOptions(tokens, { positionals: 1, booleans: ['local-only'] });
  const payload = readJson(localPath(positionals[0]), { object: true });
  const errors = [];
  const generationGuards = [];
  let references = payload.references;
  let bindings = payload.bindings;
  if (payload.version !== "reference-routing-v4") errors.push("version must be reference-routing-v4; reference-routing-v3 is unsupported and must be prepared again before generation");
  if (!Array.isArray(references) || !Array.isArray(bindings)) {
    errors.push("references and bindings must be arrays");
    references = Array.isArray(references) ? references : [];
    bindings = Array.isArray(bindings) ? bindings : [];
  }
  const byId = new Map();
  references.forEach((item, index) => {
    if (!plainObject(item)) {
      errors.push(`references[${index}] must be an object`);
      return;
    }
    const id = String(item.reference_id || "").trim();
    if (!id || byId.has(id)) {
      errors.push(`references[${index}] has missing or duplicate reference_id`);
      return;
    }
    byId.set(id, item);
    const path = localPath(item.local_path);
    if (!existsSync(path) || !lstatSync(path).isFile()) errors.push(`${id} local_path is not a file`);
    else {
      if (!item.checksum || sha256(path) !== String(item.checksum).toLowerCase()) errors.push(`${id} checksum mismatch`);
      try {
        const [width, height] = imageDimensions(path);
        if (item.width !== width || item.height !== height) errors.push(`${id} recorded dimensions do not match source image`);
      } catch (error) { errors.push(`${id} ${error.message}`); }
    }
    if(!options['local-only'])try { httpUrl(item.public_url, `${id} public_url`); } catch { errors.push(`${id} public_url must be raw HTTP/HTTPS`); }
    if (!String(item.label || "").trim()) errors.push(`${id} label is required`);
  });
  const assetIds = new Set();
  bindings.forEach((binding, index) => {
    if (!plainObject(binding)) {
      errors.push(`bindings[${index}] must be an object`);
      return;
    }
    const assetId = String(binding.asset_id || "").trim();
    const label = assetId || index;
    if (!assetId || assetIds.has(assetId)) errors.push(`bindings[${index}] has missing or duplicate asset_id`);
    assetIds.add(assetId);
    const selected = binding.selected_reference_ids;
    if (!Array.isArray(selected)) {
      errors.push(`${label} selected_reference_ids must be an array`);
      return;
    }
    const missing = selected.filter((id) => !byId.has(id));
    if (missing.length) errors.push(`${label} references missing IDs: ${missing.join(", ")}`);
    if (selected.length && !String(binding.rationale || "").trim()) errors.push(`${label} rationale is required when references are selected`);
    const uses = binding.reference_uses;
    const useMap = new Map();
    if (!Array.isArray(uses)) errors.push(`${label} reference_uses must be an array`);
    else {
      uses.forEach((use, useIndex) => {
        if (!plainObject(use)) {
          errors.push(`${label} reference_uses[${useIndex}] must be an object`);
          return;
        }
        const referenceId = String(use.reference_id || "").trim();
        if (!referenceId || useMap.has(referenceId)) {
          errors.push(`${label} reference_uses has missing or duplicate reference_id`);
          return;
        }
        useMap.set(referenceId, use);
        if (!selected.includes(referenceId)) errors.push(`${label} reference_uses includes unselected reference ${referenceId}`);
        const roles = use.roles;
        if (!Array.isArray(roles) || !roles.length || roles.some((role) => !REFERENCE_USE_ROLES.has(role))) {
          errors.push(`${label} ${referenceId} roles must use the allowlisted reference roles`);
        }
        if (use.literal_embedding !== "forbidden") errors.push(`${label} ${referenceId} literal_embedding must be forbidden`);
        if (!String(use.rationale || "").trim()) errors.push(`${label} ${referenceId} reference-use rationale is required`);
      });
      for (const referenceId of selected) if (!useMap.has(referenceId)) errors.push(`${label} selected reference ${referenceId} has no explicit use`);
    }
    const styleOnlyIds = selected.filter((referenceId) => {
      const roles = useMap.get(referenceId)?.roles;
      return Array.isArray(roles) && !roles.some((role) => CONTENT_REFERENCE_ROLES.has(role));
    });
    const contentUses = selected.flatMap((referenceId) => {
      const roles = useMap.get(referenceId)?.roles;
      const allowed = Array.isArray(roles) ? roles.filter((role) => CONTENT_REFERENCE_ROLES.has(role)) : [];
      return allowed.length ? [{ reference_id: referenceId, allowed_roles: allowed }] : [];
    });
    const mandatoryPromptConstraints = [
      "所有参考图仅作为生成模型的外部条件输入；严禁把任何参考图本身绘制为画中画、相框、屏幕、海报、卡片、缩略图、拼贴面板、贴花或纹理。",
      "输出只包含当前目标资产及目标模板要求的视图；不得展示参考图、参考缩略图、参考说明、来源文字或Logo。",
    ];
    if (styleOnlyIds.length) {
      mandatoryPromptConstraints.push(`${styleOnlyIds.join("、")} 仅参考风格、色调、材质、渲染或版式；不得复制其中的主体、人物身份、服装、背景、道具、文字、Logo或剧情动作。`);
    }
    if (contentUses.length) {
      mandatoryPromptConstraints.push(`${contentUses.map((use) => `${use.reference_id}仅允许继承${use.allowed_roles.join("/")}`).join("；")}；除此之外不得复制原图姿势、构图、背景、无关物体、文字或Logo。`);
    }
    generationGuards.push({
      asset_id: assetId,
      style_only_reference_ids: styleOnlyIds,
      controlled_content_references: contentUses,
      mandatory_prompt_constraints: mandatoryPromptConstraints,
    });
    const base = binding.base_asset_reference;
    if (base !== undefined && base !== null) {
      if (!plainObject(base)) {
        errors.push(`${label} base_asset_reference must be an object when present`);
      } else {
        const baseId = String(base.asset_id || "").trim();
        const path = localPath(base.local_path);
        if (!baseId || baseId === assetId || !existsSync(path) || !lstatSync(path).isFile()) errors.push(`${label} base asset reference is incomplete`);
        else {
          if (!base.checksum || sha256(path) !== String(base.checksum).toLowerCase()) errors.push(`${label} base asset reference checksum mismatch`);
          try { imageDimensions(path); } catch (error) { errors.push(`${label} ${error.message}`); }
        }
      }
    }
  });
  return { ok: !errors.length, reference_count: byId.size, binding_count: bindings.length, generation_guards: generationGuards, errors };
}

const AGE_COMPATIBILITY = {
  "童年感": { "童年感": 30, "少年感": 10 },
  "少年感": { "少年感": 30, "青年感": 14, "童年感": 10 },
  "青年感": { "青年感": 30, "少年感": 14, "成熟感": 12 },
  "成熟感": { "成熟感": 30, "青年感": 12, "长者感": 10 },
  "长者感": { "长者感": 30, "成熟感": 12 },
};
const AGE_RANGE_TO_FEEL = { child: "童年感", teen: "少年感", "young-adult": "青年感", adult: "青年感", "middle-aged": "成熟感", senior: "长者感" };
const GENDER_TO_PRESENTATION = { male: "男声", female: "女声", "non-binary": "中性声" };

function normalizedList(value) {
  if (Array.isArray(value)) return value.map((item) => String(item).trim()).filter(Boolean);
  if (typeof value === "string") return value.replaceAll("/", "·").split("·").map((item) => item.trim()).filter(Boolean);
  return [];
}

function desiredAgeFeel(profile) {
  const explicit = String(profile.age_feel || "").trim();
  return Object.hasOwn(AGE_COMPATIBILITY, explicit) ? explicit : AGE_RANGE_TO_FEEL[String(profile.age_range || "").trim()] || null;
}

function presentation(profile) {
  const explicit = String(profile.voice_presentation || "").trim();
  if (["男声", "女声", "童声", "中性声"].includes(explicit)) return explicit;
  if (desiredAgeFeel(profile) === "童年感") return "童声";
  return GENDER_TO_PRESENTATION[String(profile.gender || "").trim()] || null;
}

function scoreVoice(profile, voice, wantedAge) {
  let score = 40;
  const reasons = [`声线呈现=${voice.voice_presentation}`];
  const ageScore = AGE_COMPATIBILITY[wantedAge]?.[voice.age_feel] || 0;
  score += ageScore;
  if (ageScore) reasons.push(`年龄感=${voice.age_feel}(${ageScore})`);
  const pitch = String(profile.pitch_band || "").trim();
  if (pitch && pitch === voice.pitch_band) { score += 8; reasons.push(`音域=${pitch}`); }
  const roles = normalizedList(profile.role_tags).length ? normalizedList(profile.role_tags) : normalizedList(profile.role);
  const roleHits = [...new Set(roles.filter((role) => (voice.role_tags || []).includes(role)))].sort();
  if (roleHits.length) { const amount = Math.min(24, roleHits.length * 8); score += amount; reasons.push(`角色标签=${roleHits.join("/")}`); }
  const freeText = ["voice_description", "personality", "role"].map((key) => String(profile[key] || "")).join(" ");
  const timbres = normalizedList(profile.timbre_tags);
  const expressions = normalizedList(profile.expression_tags);
  if (freeText.includes(voice.core_timbre)) timbres.push(voice.core_timbre);
  if (freeText.includes(voice.expression_tendency)) expressions.push(voice.expression_tendency);
  if (timbres.includes(voice.core_timbre)) { score += 16; reasons.push(`核心音色=${voice.core_timbre}`); }
  if (expressions.includes(voice.expression_tendency)) { score += 12; reasons.push(`表达倾向=${voice.expression_tendency}`); }
  if (voice.confidence === "较高") { score += 5; reasons.push("标签置信度=较高"); }
  return [score, reasons];
}

export function matchVoice(tokens) {
  const { options, positionals } = parseOptions(tokens, {
    positionals: 1,
    values: ["catalog", "output", "existing-voice-id", "max-candidates"],
    repeated: ["reserved-voice-id"],
    booleans: ["allow-reuse"],
  });
  const profile = readJson(localPath(positionals[0]), { object: true });
  const catalogPath = options.catalog
    ? localPath(options.catalog)
    : resolve(process.env.MANTURHUB_SKILL_DIR, "voice-library", "catalog.json");
  const catalog = readJson(catalogPath, { object: true });
  if (!Array.isArray(catalog.voices)) throw new Error("voice catalog must contain voices[]");
  let result;
  if (options["existing-voice-id"]) {
    const selected = catalog.voices.find((voice) => voice.voice_id === options["existing-voice-id"] && voice.active);
    result = selected
      ? { status: "matched_locked_identity", reason: "same_canonical_character_keeps_existing_voice", selected, candidates: [] }
      : { status: "unresolved", reason: "existing_voice_id_not_active_in_catalog", selected: null, candidates: [] };
  } else {
    const wantedPresentation = presentation(profile);
    const wantedAge = desiredAgeFeel(profile);
    if (!wantedPresentation || !wantedAge) result = { status: "unresolved", reason: "voice_presentation_or_age_feel_missing", selected: null, candidates: [] };
    else {
      const reserved = new Set(options["reserved-voice-id"] || []);
      const eligible = catalog.voices.filter((voice) => voice.active && voice.confidence !== "待试听确认" && voice.voice_presentation === wantedPresentation && (options["allow-reuse"] || !reserved.has(voice.voice_id)));
      const ranked = eligible.map((voice) => {
        const [score, reasons] = scoreVoice(profile, voice, wantedAge);
        return { voice_id: voice.voice_id, score, confidence: voice.confidence, reasons, public_url: voice.public_url, asset_id: voice.asset_id };
      }).sort((left, right) => right.score - left.score || left.voice_id.localeCompare(right.voice_id));
      const maxCandidates = options["max-candidates"] === undefined ? 3 : Number(options["max-candidates"]);
      if (!Number.isInteger(maxCandidates) || maxCandidates < 1) throw new Error("max-candidates must be a positive integer");
      const candidates = ranked.slice(0, maxCandidates);
      const top = candidates[0] || null;
      const margin = top ? (candidates.length > 1 ? top.score - candidates[1].score : 999) : null;
      const safe = Boolean(top && top.confidence === "较高" && top.score >= 75 && margin >= 6);
      result = {
        status: safe ? "matched" : top ? "review_required" : "no_candidate",
        reason: safe ? "unique_high_confidence_match" : "manual_review_required",
        selected: safe ? catalog.voices.find((voice) => voice.voice_id === top.voice_id) : null,
        candidates,
        score_margin: margin,
      };
    }
  }
  Object.assign(result, {
    character_id: profile.asset_id || profile.character_id,
    canonical_name: profile.canonical_name,
    catalog_id: catalog.catalog_id,
    catalog_version: catalog.catalog_version,
    match_policy_version: "1.0.0",
  });
  if (options.output) writeJson(options.output, result);
  return result;
}

function rowValue(row, ...keys) {
  for (const key of keys) if (Object.hasOwn(row, key) && row[key] !== null && row[key] !== "") return row[key];
  return null;
}

export function planScenes(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["concurrency", "requested-concurrency", "output"] });
  const concurrency = options.concurrency === undefined ? DEFAULT_VIDEO_CONCURRENCY : Number(options.concurrency);
  const requested = options["requested-concurrency"] === undefined ? concurrency : Number(options["requested-concurrency"]);
  const parallelism = videoParallelismPolicy(requested, concurrency);
  const rows = readJson(localPath(positionals[0]));
  if (!Array.isArray(rows)) throw new Error("clip rows must be a JSON array");
  const errors = [];
  const ids = new Set();
  for (const row of rows) {
    const id = String(rowValue(row, "Clip ID", "clip_id") || "").trim();
    if (!id || ids.has(id)) errors.push(`missing or duplicate Clip ID: ${JSON.stringify(id)}`);
    ids.add(id);
  }
  const chains = new Map();
  for (const row of rows) {
    const episode = Number(rowValue(row, "集数", "episode") || 0);
    const scene = String(rowValue(row, "场次组", "scene_group") || "").trim();
    const order = Number(rowValue(row, "集内序号", "order") || 0);
    const clipId = String(rowValue(row, "Clip ID", "clip_id") || "").trim();
    const previous = String(rowValue(row, "前序Clip ID", "连续性来源Clip ID", "previous_clip_id") || "").trim();
    if (!Number.isInteger(episode) || episode < 1 || !scene || !Number.isInteger(order) || order < 1) errors.push(`${clipId || "<unknown>"} lacks episode/scene_group/order`);
    const key = `${String(episode).padStart(8, "0")}\0${scene}`;
    if (!chains.has(key)) chains.set(key, { episode, scene, clips: [] });
    chains.get(key).clips.push({ clip_id: clipId, episode, scene_group: scene, order, previous_clip_id: previous });
  }
  const outputChains = [...chains.values()].sort((a, b) => a.episode - b.episode || (a.scene < b.scene ? -1 : a.scene > b.scene ? 1 : 0)).map(({ episode, scene, clips }) => {
    clips.sort((a, b) => a.order - b.order);
    clips.forEach((clip, index) => {
      const expected = index ? clips[index - 1].clip_id : "";
      if (clip.previous_clip_id !== expected) errors.push(`${clip.clip_id} previous_clip_id must be ${JSON.stringify(expected)}`);
    });
    return { chain_id: `EP${String(episode).padStart(2, "0")}-${scene}`, episode, scene_group: scene, clips };
  });
  if (errors.length) throw new Error(errors.join("; "));
  const activeChainIds = outputChains.slice(0, concurrency).map((chain) => chain.chain_id);
  const queuedChainIds = outputChains.slice(concurrency).map((chain) => chain.chain_id);
  const payload = {
    version: "scene-chain-plan-v1",
    max_parallel_chains: concurrency,
    ...parallelism,
    active_chain_ids: activeChainIds,
    queued_chain_ids: queuedChainIds,
    chains: outputChains,
  };
  const target = outputPath(options.output, "--output");
  writeJson(target, payload);
  return {
    ok: true,
    chain_count: outputChains.length,
    active_chain_count: activeChainIds.length,
    queued_chain_count: queuedChainIds.length,
    effective_video_concurrency: concurrency,
    output: target,
  };
}

export function materializeVideo(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["previous-tail-url", "output"], booleans: ["needs-previous-tail"] });
  const request = structuredClone(readJson(localPath(positionals[0]), { object: true }));
  if (!plainObject(request.metadata)) throw new Error("metadata must be an object");
  if (request.metadata.return_last_frame !== true) throw new Error("metadata.return_last_frame must be true");
  if (!Array.isArray(request.metadata.content)) throw new Error("metadata.content must be an array");
  const prompt = String(request.prompt || "").trim();
  if (!prompt.endsWith(HARD_ENDING)) throw new Error(`prompt must end exactly with ${HARD_ENDING}`);
  const previous = options["previous-tail-url"] || "";
  if (options["needs-previous-tail"]) {
    const url = httpUrl(previous, "previous tail URL");
    const count = request.metadata.content.filter((item) => plainObject(item) && item.type === "image_url").length;
    const token = `@Image${count + 1}`;
    request.metadata.content.push({ type: "image_url", image_url: { url }, role: "reference_image" });
    const body = prompt.slice(0, -HARD_ENDING.length).trimEnd();
    request.prompt = `${body}\n\n${continuityHardLimit(token)}\n\n${HARD_ENDING}`;
  } else if (previous) throw new Error("scene-start request must not receive a previous tail URL");
  const target = outputPath(options.output, "--output");
  writeJson(target, request);
  return {
    ok: true,
    output: target,
    request_stage: "实际请求体",
    tail_injection_status: options["needs-previous-tail"] ? "已注入前序尾帧" : "无需注入",
    generation_status: "待提交",
  };
}

export function materializeVideoParams(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["output"] });
  const request = readJson(localPath(positionals[0]), { object: true });
  const metadata = request.metadata;
  if (!plainObject(metadata)) throw new Error("metadata must be an object");
  if (metadata.return_last_frame !== true) throw new Error("metadata.return_last_frame must be true");
  const model = MODEL_MAP[String(request.model || "")];
  if (!model) throw new Error(`unsupported video model: ${JSON.stringify(request.model)}`);
  const prompt = String(request.prompt || "").trim();
  if (!prompt) throw new Error("prompt is required");
  if (!Number.isInteger(request.duration) || request.duration < 5 || request.duration > 15) throw new Error("duration must be an integer between 5 and 15");
  if (!Array.isArray(metadata.content)) throw new Error("metadata.content must be an array");
  const images = [];
  const imageRoles = [];
  const audios = [];
  metadata.content.forEach((item, index) => {
    if (!plainObject(item)) throw new Error(`metadata.content[${index}] must be an object`);
    if (item.type === "image_url") {
      if (!plainObject(item.image_url)) throw new Error(`metadata.content[${index}].image_url must be an object`);
      images.push(httpUrl(item.image_url.url, `metadata.content[${index}].image_url.url`));
      const role = String(item.role || "reference_image");
      if (!IMAGE_ROLES.has(role)) throw new Error(`unsupported image role: ${role}`);
      imageRoles.push(role);
    } else if (item.type === "audio_url") {
      if (!plainObject(item.audio_url)) throw new Error(`metadata.content[${index}].audio_url must be an object`);
      audios.push(httpUrl(item.audio_url.url, `metadata.content[${index}].audio_url.url`));
    } else throw new Error(`unsupported metadata content type: ${JSON.stringify(item.type)}`);
  });
  if (images.length > 9) throw new Error("op.video.generate accepts at most 9 reference images");
  if (audios.length > 3) throw new Error("op.video.generate accepts at most 3 reference audios");
  const params = {
    prompt,
    model,
    resolution: String(metadata.resolution || "480p"),
    duration: request.duration,
    ratio: String(metadata.ratio || "9:16"),
    generate_audio: metadata.generate_audio !== false,
    seed: metadata.seed ?? -1,
    return_last_frame: true,
  };
  if (!["480p", "720p", "1080p"].includes(params.resolution)) throw new Error("resolution must be 480p, 720p or 1080p (maximum 1080p)");
  if (images.length) { params.images = images; params.image_roles = imageRoles; }
  if (audios.length) params.ref_audios = audios;
  const target = outputPath(options.output, "--output");
  writeJson(target, params);
  return { ok: true, output: target };
}

function classifyStatus(value) {
  const status = String(value || "").trim().toLowerCase();
  if (!status) throw new Error("ManturHub status response is missing status");
  if (ACTIVE_STATES.has(status)) return { status, terminal: false, failed: false };
  if (SUCCESS_STATES.has(status)) return { status, terminal: true, failed: false };
  if (FAILED_STATES.has(status)) return { status, terminal: true, failed: true };
  return {status:'submission_unknown',terminal:false,failed:false};
}

function redactStatusText(value) {
  if (value === undefined || value === null) return value;
  return String(value)
    .replace(/\bsk-[A-Za-z0-9_-]+\b/g, "[REDACTED_KEY]")
    .replace(/https:\/\/[^\s"'<>?]+\?[^\s"'<>]+/g, (match) => {
      try {
        const url = new URL(match);
        return `${url.origin}${url.pathname}?[REDACTED_QUERY]`;
      } catch {
        return "[REDACTED_URL]";
      }
    });
}

export async function pollCheckpoint(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["state-file", "output-dir", "stage"] });
  if (!options["state-file"] || !options["output-dir"]) throw new Error("--state-file and --output-dir are required");
  const statePath = assertProjectWritePath(options["state-file"]);
  const outputDir = assertProjectWritePath(options["output-dir"]);
  const state = existsSync(statePath) ? readJson(statePath, { object: true }) : {};
  const isVideo = (options.stage || state.stage) === 'video';
  const expectedVideoIdentity = isVideo ? validateVideoCheckpoint(state, positionals[0]) : undefined;
  const [base] = resolveManturhubBase();
  if (inspectProjectSite(base).status !== 'current') throw siteConflict();
  if (new URL(positionals[0]).origin !== base) throw siteConflict();
  process.env.MANTURHUB_BASE = base;
  const waitPolicy = options.stage ? asyncWaitPolicy(base, options.stage) : null;
  if (options.stage && !waitPolicy && options.stage !== 'video') throw new Error('--stage must be extraction, clips or video');
  let status;
  try { ({payload:status}=runCli(["status", positionals[0]], { allowNonZeroJson: true })); }
  catch (error) {
    if (String(error.code||'').startsWith('CLI_')) throw error;
    writeJson(statePath,{...state,run_id:state.run_id||randomUUID(),attempt:state.attempt||1,poll_url:positionals[0],stage:options.stage||state.stage,status:state.status||'submission_unknown',last_poll_error:'POLL_READ_FAILED',last_observed_at:new Date().toISOString()});
    return {...agentPolling({...state,error_code:'POLL_READ_FAILED'},'poll-checkpoint'),ok:false,retryable:true,error:{code:'POLL_READ_FAILED',message:'Query failed; retry the same task query, never resubmit.'},production_result_preserved:true};
  }
  const videoResult = isVideo ? normalizeVideoResponse(status, expectedVideoIdentity) : undefined;
  const classification = classifyStatus(status.status);
  if (!isVideo && !status.task_id) throw new Error("ManturHub status returned an invalid task payload");
  const taskId = videoResult?.task_id ?? String(status.task_id);
  if (!isVideo && state.task_id && state.task_id !== taskId) throw new Error(`state belongs to task ${state.task_id}, not ${taskId}`);
  const resultDiagnostic = videoResult ? videoResultDiagnostic(videoResult, classification) : undefined;
  const videoFields = videoResult ? {
    video_url: videoResult.video_url, result_url: videoResult.result_url,
    last_frame_url: videoResult.last_frame_url, result_diagnostic: resultDiagnostic,
  } : {};
  const previous = Number(state.last_checkpoint_seq || 0);
  const checkpoint = Number(isVideo && status.checkpoint_seq === undefined ? previous : status.checkpoint_seq || 0);
  if (!Number.isInteger(checkpoint) || checkpoint < 0) throw new Error("checkpoint_seq must be a non-negative integer");
  if (checkpoint < previous) throw new Error(`checkpoint regressed from ${previous} to ${checkpoint}`);
  const changed = checkpoint > previous || classification.status !== String(state.status || "").toLowerCase();
  const observedAt = new Date().toISOString();
  const firstObservedAt = state.submitted_at || state.first_observed_at || observedAt;
  const firstObservedMs = Date.parse(firstObservedAt);
  if (!Number.isFinite(firstObservedMs)) throw new Error("state submitted_at/first_observed_at must be a valid timestamp");
  const elapsedSeconds = Math.max(0, Math.floor((Date.parse(observedAt) - firstObservedMs) / 1000));
  const nextPollAfterSeconds = waitPolicy && !classification.terminal
    ? (elapsedSeconds < waitPolicy.initial_poll_period_seconds
        ? waitPolicy.initial_poll_interval_seconds
        : waitPolicy.steady_poll_interval_seconds)
    : null;
  let partialPath = null;
  if (checkpoint > previous && plainObject(status.partial_result) && status.partial_result.result_url) {
    const url = httpUrl(status.partial_result.result_url, "partial result URL", { httpsOnly: true });
    const response = await fetch(url, {
      headers: { "User-Agent": "drama-pipeline-skill/1" },
      signal: AbortSignal.timeout(45000),
    });
    if (!response.ok) throw new Error(`partial checkpoint download failed (HTTP ${response.status})`);
    const partial = await response.json();
    partialPath = resolve(outputDir, `checkpoint-${String(checkpoint).padStart(6, "0")}.json`);
    writeJson(partialPath, partial);
  }
  writeJson(statePath, {
    ...state,
    run_id: state.run_id || randomUUID(),
    attempt: state.attempt || 1,
    task_id: taskId,
    poll_url: positionals[0],
    stage: waitPolicy?.stage || options.stage || state.stage,
    progress: status.progress ?? state.progress,
    error_code: status.error_code,
    error_message: redactStatusText(status.error || status.message),
    last_poll_error: null,
    status: classification.status,
    submitted_at: state.submitted_at,
    first_observed_at: firstObservedAt,
    last_observed_at: observedAt,
    elapsed_seconds: elapsedSeconds,
    last_checkpoint_seq: Math.max(previous, checkpoint),
    updated_at: status.updated_at || observedAt,
    partial_path: partialPath || state.partial_path,
    result_url: status.result_url,
    report_url: status.report_url,
    ...videoFields,
  });
  return {
    ...agentPolling({status:classification.status,terminal:classification.terminal,elapsed_seconds:elapsedSeconds,next_poll_after_seconds:nextPollAfterSeconds},'poll-checkpoint'),
    task_id: taskId,
    status: classification.status,
    terminal: classification.terminal,
    failed: classification.failed,
    job_interpretation: classification.terminal
      ? (classification.failed ? "terminal_failure" : "terminal_success")
      : "running_not_failed",
    changed,
    checkpoint_seq: checkpoint,
    partial_path: partialPath,
    progress: status.progress,
    partial_result_available: Boolean(status.partial_result),
    result_available: Boolean(isVideo ? videoResult.video_url : status.result_url),
    ...videoFields,
    report_available: Boolean(status.report_url),
    error: redactStatusText(status.error),
    message: redactStatusText(status.message),
    remote_retryable: status.retryable,
    wait_policy: waitPolicy,
    elapsed_seconds: elapsedSeconds,
    next_poll_after_seconds: nextPollAfterSeconds,
    long_running: Boolean(waitPolicy && !classification.terminal && elapsedSeconds >= waitPolicy.long_running_after_seconds),
    beyond_minimum_observation: Boolean(waitPolicy && !classification.terminal && elapsedSeconds >= waitPolicy.minimum_observation_seconds),
  };
}

export async function exportEpisodes(tokens) {
  const { options, positionals } = parseOptions(tokens, { positionals: 1, values: ["output-dir", "selection-plan"] });
  const rows = readJson(localPath(positionals[0]));
  if (!Array.isArray(rows)) throw new Error("manifest must be a JSON array");
  if (!rows.length) throw new Error('Export manifest must not be empty');
  const grouped = new Map();
  for (const row of rows) {
    const clipId = String(row?.clip_id || "").trim();
    const episode = Number(row?.episode || 0);
    const order = Number(row?.order || 0);
    const path = assertProjectWritePath(resolve(projectRoot(), row?.video_path || ''));
    if (!clipId || !Number.isInteger(episode) || episode < 1 || !Number.isInteger(order) || order < 1 || String(row?.status || "").toLowerCase() !== "completed" || !existsSync(path) || !lstatSync(path).isFile()) {
      throw new Error(`incomplete export row: ${clipId || "<unknown>"}`);
    }
    if (!grouped.has(episode)) grouped.set(episode, []);
    const bytes = readFileSync(path);
    if (!['.mp4','.mov','.webm'].includes(extname(path).toLowerCase()) || bytes.length===0 || !row.sha256 || sha256(path)!==row.sha256) throw new Error('Export source hash or video type invalid');
    if (extname(path).toLowerCase()==='.webm' ? bytes.subarray(0,4).toString('hex')!=='1a45dfa3' : bytes.subarray(4,8).toString('ascii')!=='ftyp') throw new Error('Export source MIME signature invalid');
    grouped.get(episode).push({ clipId, order, path, sha256:row.sha256 });
  }
  const outputDir = outputPath(options["output-dir"] || "exports", "--output-dir");
  mkdirSync(outputDir, { recursive: true });
  const episodes = [];
  for (const episode of [...grouped.keys()].sort((a, b) => a - b)) {
    const clips = grouped.get(episode).sort((a, b) => a.order - b.order);
    const expected = expectedClips(episode);
    if (new Set(clips.map(row=>row.clipId)).size!==clips.length || new Set(clips.map(row=>row.order)).size!==clips.length || JSON.stringify(clips.map(row=>row.clipId))!==JSON.stringify(expected)) throw new Error('Export target Clips are missing, duplicated or out of order');
    let target;
    await withProjectLock(assertProjectWritePath(resolve(projectRoot(),`.pipeline-state/runtime/export-EP${episode}.lock`)),async()=>{
      const gate=await captureDeliveryGate(projectRoot(),episode,clips.map(c=>({clip_id:c.clipId,video_path:c.path,sha256:c.sha256})),options["selection-plan"]);
      const stem=`EP${String(episode).padStart(2, "0")}`;
      const directoryKey=createHash('sha256').update(process.platform==='win32'?outputDir.toLowerCase():outputDir).digest('hex');
      const journalPath=assertProjectWritePath(resolve(projectRoot(),`.pipeline-state/runtime/export-publications/${stem}-${directoryKey}.json`));
      const previous=existsSync(journalPath)?readJson(journalPath,{object:true}):null;
      const namePattern=new RegExp('^'+stem+'(?:（([1-9][0-9]*)）)?\\.zip$','i');
      if(previous && (previous.schema_version!==1 || !['pending','completed'].includes(previous.status) || previous.episode!==episode || previous.output_dir!==outputDir || typeof previous.filename!=='string' || !namePattern.test(previous.filename))) {
        throw Object.assign(new Error('Invalid export publication record.'),{code:'EXPORT_PUBLICATION_INVALID'});
      }
      const recovering=previous?.status==='pending';
      if(recovering && previous.fingerprint!==gate.fingerprint)throw Object.assign(new Error('Unfinished export sources changed; restore or resolve the original publication before retrying.'),{code:'EXPORT_PENDING_SOURCE_CHANGED'});
      let filename;
      if(recovering) filename=previous.filename;
      else {
        let highest=-1;
        for(const name of readdirSync(outputDir)) {
          const match=name.match(namePattern);
          if(match) {
            const number=match[1]?Number(match[1]):0;
            if(!Number.isSafeInteger(number) || number>=Number.MAX_SAFE_INTEGER)throw new Error('Export filename counter exceeded');
            highest=Math.max(highest,number);
          }
        }
        filename=highest<0?`${stem}.zip`:`${stem}（${highest+1}）.zip`;
      }
      target=assertProjectWritePath(resolve(outputDir,filename));
      const temporary=assertProjectWritePath(`${target}.${randomUUID()}.tmp`);
      const files=clips.map(clip=>({path:clip.path,name:`${stem}-CLIP${String(clip.order).padStart(2,"0")}${extname(clip.path).toLowerCase()}`,sha256:clip.sha256}));
      try {
        const retained=recovering && existsSync(target);
        if(retained && (!lstatSync(target).isFile() || sha256(target)!==previous.zip_sha256))throw Object.assign(new Error('Unfinished export ZIP was changed; original file retained.'),{code:'EXPORT_PUBLICATION_CONFLICT'});
        if(!retained)createZip(temporary,files);
        await verifyEpisodeArchive(retained?target:temporary,files);
        const zipHash=sha256(retained?target:temporary);
        if(recovering && zipHash!==previous.zip_sha256)throw Object.assign(new Error('Unfinished export ZIP differs from its publication record.'),{code:'EXPORT_PUBLICATION_CONFLICT'});
        await publishWithDeliveryGate(projectRoot(),gate,async()=>{
          // Journal before publishing: interrupted index updates reuse this exact name and package.
          const journal={schema_version:1,status:'pending',episode,output_dir:outputDir,filename,fingerprint:gate.fingerprint,zip_sha256:zipHash};
          writeJson(journalPath,journal);
          if(retained) {
            if(sha256(assertProjectWritePath(target))!==zipHash)throw Object.assign(new Error('Unfinished export ZIP changed before publication.'),{code:'EXPORT_PUBLICATION_CONFLICT'});
          } else {
            // An exclusive same-volume hard link publishes the complete ZIP without overwriting any existing file.
            linkSync(temporary,assertProjectWritePath(target));
          }
          await saveDelivery({...deliveryRecord('episode_clips',episode,expected,target),...(gate.selection_receipt?{video_selection:gate.selection_receipt}:{})},{refresh:false});
          writeJson(journalPath,{...journal,status:'completed'});
        });
      } finally {rmSync(temporary,{force:true});}
    });
    episodes.push({ episode, clip_count: clips.length, zip: target });
  }
  return { ok: true, episodes };
}

async function onlineAssetContext() {
  const {OnlineError,doctorPreflightError}=await import('./manturhub-online-transport.mjs');const auth=onlineAuthFactory();
  return {
    auth,
    verifyDetail:(detail)=>{const result=inspectOperator(detail,'op.drama.asset-extract');if(!result.ok||result.profile!=='openapi_v1')throw new OnlineError('OPERATOR_CONTRACT_UNVERIFIED');return result;},
    preflight:async(recovering)=>{
      await auth();if(recovering){
        const [base]=resolveManturhubBase();const cli=cliVersionInfo();
        if(inspectProjectSite(base).status!=='current')throw new OnlineError('MANTURHUB_SITE_CONFLICT');
        const {payload}=runCli(['balance','--json'],{cli,base,readOnlyRetry:true});authenticationProfile(payload);
        return;
      }
      const result=doctor(['--stage','extraction']);
      if(result.ok!==true||result.connection_ready!==true||result.contract_ready!==true||result.workflow_ready!==true||result.contract_profile!=='openapi_v1')throw doctorPreflightError(result);
    },
    refresh:async(updateId)=>refreshUiSnapshot(updateId?['--update-id',updateId]:[]),
  };
}

async function assetOperationContext() {
  const {OnlineError,doctorPreflightError}=await import('./manturhub-online-transport.mjs');const auth=onlineAuthFactory();
  return {
    auth,
    verifyDetail:(detail,id)=>{const result=inspectOperator(detail,id);if(!result.ok||result.profile!=='openapi_v1')throw new OnlineError('OPERATOR_CONTRACT_UNVERIFIED');return result;},
    preflight:async(id,recovering)=>{
      const kind=Object.entries(ASSET_OPERATION_OPERATORS).find(([,operator])=>operator===id)?.[0];
      if(!kind)throw new OnlineError('OPERATOR_CONTRACT_UNVERIFIED');
      await auth();if(recovering){const [base]=resolveManturhubBase(),cli=cliVersionInfo();if(inspectProjectSite(base).status!=='current')throw new OnlineError('MANTURHUB_SITE_CONFLICT');authenticationProfile(runCli(['balance','--json'],{cli,base,readOnlyRetry:true}).payload);return;}
      const result=doctor(['--stage','asset-production','--asset-operation',kind]);
      if(result.ok!==true||result.connection_ready!==true||result.contract_ready!==true||result.workflow_ready!==true||result.contract_profile!=='openapi_v1')throw doctorPreflightError(result);
    },
    validateReferences:async(path)=>{const result=validateReferences([path,'--local-only']);if(!result.ok)throw new OnlineError('REFERENCE_ROUTING_INVALID');return result;},
    validatePreset:async(id,hash)=>{const catalog=readJson(resolve(process.env.MANTURHUB_SKILL_DIR,'voice-library','catalog.json'),{object:true});const matches=catalog.voices.filter(v=>v.voice_id===id&&v.active&&v.sha256===hash);if(matches.length!==1)throw new OnlineError('PRESET_VOICE_IDENTITY_MISMATCH');},
    refresh:async(updateId)=>refreshUiSnapshot(updateId?['--update-id',updateId]:[]),
  };
}

async function clipOperationContext(){
  const {OnlineError,doctorPreflightError}=await import('./manturhub-online-transport.mjs');const auth=onlineAuthFactory();
  const selected=projectVideoModel(readJson(projectStatePath(),{object:true}));
  return {auth,
    preflight:async(recovering)=>{requireClipPlatform(selected.id);
      await auth();if(recovering){const [base]=resolveManturhubBase(),cli=cliVersionInfo();if(inspectProjectSite(base).status!=='current')throw new OnlineError('MANTURHUB_SITE_CONFLICT');authenticationProfile(runCli(['balance','--json'],{cli,base,readOnlyRetry:true}).payload);return;}
      const result=doctor(['--stage','clips']);if(result.ok!==true||result.connection_ready!==true||result.contract_ready!==true||result.workflow_ready!==true||result.contract_profile!=='openapi_v1')throw doctorPreflightError(result);},
    refresh:async(id)=>refreshUiSnapshot(id?['--update-id',id]:[])};
}

async function videoOperationContext(){
  const {OnlineError,doctorPreflightError}=await import('./manturhub-online-transport.mjs');const auth=onlineAuthFactory();
  return {auth,
    preflight:async(recovering)=>{requireVideoPlatform(readJson(projectStatePath(),{object:true}).video?.model);
      await auth();if(recovering){const [base]=resolveManturhubBase(),cli=cliVersionInfo();if(inspectProjectSite(base).status!=='current')throw new OnlineError('MANTURHUB_SITE_CONFLICT');authenticationProfile(runCli(['balance','--json'],{cli,base,readOnlyRetry:true}).payload);return;}
      const result=doctor(['--stage','video']);if(result.ok!==true||result.connection_ready!==true||result.contract_ready!==true||result.workflow_ready!==true||result.contract_profile!=='openapi_v1')throw doctorPreflightError(result);},
    limits:async()=>{const {videoPlatformLimits}=await import('./video-generation-operation.mjs');return videoPlatformLimits(readJson(projectStatePath(),{object:true}).manturhub_base);},
    refresh:async(id)=>refreshUiSnapshot(id?['--update-id',id]:[])};
}

export const ACTIONS = {
  'resolve-manturhub-environment': (tokens) => {
    parseOptions(tokens,{positionals:0});
    try {
      const [manturhub_base,source]=resolveManturhubBase();
      return {ok:true,manturhub_base,source};
    } catch(error) {
      if(!['CLI_UNAVAILABLE','CLI_NOT_FOUND','CLI_VERSION_UNSUPPORTED','CLI_BASE_URL_UNAVAILABLE'].includes(error?.code))throw error;
      return {ok:false,error:{code:error.code,message:'ManturHub CLI setup needs attention.'},next_action:'follow_cli_onboarding',instruction:'references/cli-onboarding.md',repair:repairFor(error.code)};
    }
  },
  'query-account-balance': async (tokens) => {
    parseOptions(tokens, {positionals:0});
    const checked_at = new Date().toISOString();
    let site;
    try {
      try {
        [site] = resolveManturhubBase();
        if (inspectProjectSite(site).status === 'conflict_remote_lineage') {
          const result={ok:false, checked_at, error:{code:'MANTURHUB_SITE_CONFLICT'}};
          await writeAccountBalanceCache(projectRoot(),{ok:false,checked_at,site,error_code:result.error.code}).catch(()=>undefined);
          return result;
        }
      } catch (error) {
        const result={ok:false, checked_at, error:{code:error?.code==='MANTURHUB_SITE_CONFLICT'?'MANTURHUB_SITE_CONFLICT':error?.code==='MANTURHUB_ENVIRONMENT_INVALID'?'MANTURHUB_ENVIRONMENT_INVALID':'CLI_BASE_URL_UNAVAILABLE'}};
        await writeAccountBalanceCache(projectRoot(),{ok:false,checked_at,error_code:result.error.code}).catch(()=>undefined);
        return result;
      }
      const cli = cliVersionInfo();
      const {payload} = runCli(['balance', '--json'], {cli, base:site, readOnlyRetry:true});
      const result={ok:true, site, checked_at:new Date().toISOString(), balance_points:accountBalancePoints(payload), unit:'points'};
      await writeAccountBalanceCache(projectRoot(),result).catch(()=>undefined);
      return result;
    } catch (error) {
      const code = /^(?:MANTURHUB_[A-Z_]+|CLI_[A-Z_]+)$/.test(error.code ?? '') ? error.code : 'MANTURHUB_BALANCE_UNAVAILABLE';
      const result={ok:false, ...(site ? {site} : {}), checked_at, error:{code}};
      await writeAccountBalanceCache(projectRoot(),{ok:false,checked_at,site,error_code:code}).catch(()=>undefined);
      return result;
    }
  },
  'prepare-asset-revision':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});const m=await import('./asset-revision.mjs');return m.prepareAssetRevision(projectRoot(),options.input??'');},
  'apply-asset-revision':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['revision-id','approval']});const m=await import('./asset-revision.mjs');return m.applyAssetRevision(projectRoot(),options['revision-id']??'',options.approval??'',async()=>refreshUiSnapshot([]));},
  'apply-clip-review':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});const m=await import('./video-generation-operation.mjs');return m.applyClipReview(projectRoot(),options.input??'',async()=>refreshUiSnapshot([]));},
  'prepare-video-generation':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});await ensureProjectSiteForRemotePrepare();const m=await import('./video-generation-operation.mjs');return m.prepareVideoGeneration(projectRoot(),options.input??'',await videoOperationContext());},
  'submit-video-generation':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['operation-id','approval','batch-authorization']});if(options.approval&&options['batch-authorization'])throw new Error('VIDEO_APPROVAL_AMBIGUOUS');requireCurrentProjectSiteForRemoteAction();const m=await import('./video-generation-operation.mjs');return m.runVideoGeneration(projectRoot(),options['operation-id']??'','submit',await videoOperationContext(),options.approval,options['batch-authorization']);},
  'resume-video-generation':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['operation-id'],booleans:['local-only','no-write']});const m=await import('./video-generation-operation.mjs');if(options['no-write']&&!options['local-only'])throw new Error('--no-write requires --local-only');if(options['local-only'])return m.resumeVideoLocally(projectRoot(),options['operation-id']??'',{noWrite:!!options['no-write'],refresh:async()=>refreshUiSnapshot([])});requireCurrentProjectSiteForRemoteAction();return m.runVideoGeneration(projectRoot(),options['operation-id']??'','resume',await videoOperationContext());},
  'prepare-video-batch':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});await ensureProjectSiteForRemotePrepare();const m=await import('./video-generation-operation.mjs');return m.prepareVideoBatch(projectRoot(),options.input??'',await videoOperationContext());},
  'approve-video-batch':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['no-write']});const m=await import('./video-generation-operation.mjs');return m.approveVideoBatch(projectRoot(),options.input??'',options['no-write']===true);},
  'video-batch-status':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['batch-id']});const m=await import('./video-generation-operation.mjs');return m.videoBatchStatus(projectRoot(),options['batch-id']??'');},
  'plan-video-batch':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['no-write']});const m=await import('./video-generation-operation.mjs');return m.planVideoBatch(projectRoot(),options.input??'',options['no-write']===true);},
  'plan-video-export':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['no-write']});const m=await import('./video-generation-operation.mjs');return m.planVideoExport(projectRoot(),options.input??'',options['no-write']===true);},
  'select-video-results':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['no-write']});const m=await import('./video-generation-operation.mjs');return m.selectVideoResults(projectRoot(),options.input??'',options['no-write']===true);},
  'adopt-video-run':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});const m=await import('./video-generation-operation.mjs');return m.adoptVideoRun(projectRoot(),options.input??'',async()=>refreshUiSnapshot([]));},
  'video-generation-status':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['operation-id']});const m=await import('./video-generation-operation.mjs');return m.videoGenerationStatus(projectRoot(),options['operation-id']??'');},
  'import-video-result':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['no-write']});const m=await import('./video-generation-operation.mjs');return m.importVideoResult(projectRoot(),options.input??'',{write:!options['no-write'],refresh:async()=>refreshUiSnapshot([])});},
  'apply-video-review':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});const m=await import('./video-generation-operation.mjs');return m.applyVideoReview(projectRoot(),options.input??'',async()=>refreshUiSnapshot([]));},
  'inspect-video-resolution-change':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['resolution','clips']});const m=await import('./video-resolution.mjs');return m.inspectVideoResolutionChange(projectRoot(),options.resolution,options.clips?.split(',')??[]);},
  'apply-video-resolution-change':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['no-write']});const m=await import('./video-resolution.mjs');return m.applyVideoResolutionChange(projectRoot(),options.input??'',{write:!options['no-write'],refresh:async()=>refreshUiSnapshot([])});},
  'inspect-creative-style-change':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});const m=await import('./creative-style.mjs');return m.inspectCreativeStyleChange(projectRoot(),options.input??'');},
  'apply-creative-style-change':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['no-write']});const m=await import('./creative-style.mjs');return m.applyCreativeStyleChange(projectRoot(),options.input??'',{write:!options['no-write'],refresh:async()=>refreshUiSnapshot([])});},
  'seal-project-episode-scope':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['no-write']});if(!options.input)throw Object.assign(new Error('Provide a project-local --input episode evidence file.'),{code:'PROJECT_EPISODE_EVIDENCE_INVALID'});const m=await import('./project-episode-scope.mjs');return m.sealProjectEpisodeScope(projectRoot(),options.input,{write:!options['no-write']});},
  'inspect-clip-compilation-revision':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['revision-id','episodes']});const m=await import('./clip-compilation-revision.mjs');return m.inspectClipCompilationRevision(projectRoot(),options['revision-id'],options.episodes?.split(',').map(Number));},
  'activate-clip-compilation-revision':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['no-write']});const m=await import('./clip-compilation-revision.mjs');return m.activateClipCompilationRevision(projectRoot(),options.input??'',{write:!options['no-write'],refresh:async()=>refreshUiSnapshot([])});},
  'prepare-clip-compilation':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input','manifest-review'],booleans:['no-write']});if(!options['no-write'])await ensureProjectSiteForRemotePrepare();const m=await import('./clip-compilation-operation.mjs');return m.prepareClipCompilation(projectRoot(),options.input??'',await clipOperationContext(),options['manifest-review'],{write:!options['no-write']});},
  'submit-clip-compilation':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['operation-id','approval']});requireCurrentProjectSiteForRemoteAction();const m=await import('./clip-compilation-operation.mjs');return m.runClipCompilation(projectRoot(),options['operation-id']??'','submit',await clipOperationContext(),options.approval);},
  'resume-clip-compilation':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['operation-id','manifest-review']});requireCurrentProjectSiteForRemoteAction();const m=await import('./clip-compilation-operation.mjs');return m.runClipCompilation(projectRoot(),options['operation-id']??'','resume',await clipOperationContext(),options['manifest-review']);},
  'clip-compilation-status':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['operation-id']});const m=await import('./clip-compilation-operation.mjs');return m.clipCompilationStatus(projectRoot(),options['operation-id']??'');},
  'inspect-wan-asset-table':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});const {inspectWanAssetTable}=await import('./clip-compilation-import.mjs');return inspectWanAssetTable(projectRoot(),options.input??'');},
  'import-clip-compilation':async(tokens)=>{
    const {options}=parseOptions(tokens,{positionals:0,booleans:['no-write'],values:['input']});
    const {importClipCompilation}=await import('./clip-compilation-import.mjs');
    return importClipCompilation(projectRoot(),options.input??'',{write:!options['no-write'],refresh:async(id)=>refreshUiSnapshot(id?['--update-id',id]:[])});
  },
  'prepare-asset-batch':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});await ensureProjectSiteForRemotePrepare();const m=await import('./asset-operation.mjs');return m.prepareAssetBatch(projectRoot(),options.input??'',await assetOperationContext());},
  'prepare-asset-operation':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});await ensureProjectSiteForRemotePrepare();const m=await import('./asset-operation.mjs');return m.prepareAssetOperation(projectRoot(),options.input??'',await assetOperationContext());},
  'submit-asset-operation':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['operation-id','approval']});requireCurrentProjectSiteForRemoteAction();const m=await import('./asset-operation.mjs');return m.runAssetOperation(projectRoot(),options['operation-id']??'','submit',await assetOperationContext(),options.approval);},
  'resume-asset-operation':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['operation-id']});requireCurrentProjectSiteForRemoteAction();const m=await import('./asset-operation.mjs');return m.runAssetOperation(projectRoot(),options['operation-id']??'','resume',await assetOperationContext());},
  'asset-operation-status':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['operation-id']});const m=await import('./asset-operation.mjs');return m.assetOperationStatus(projectRoot(),options['operation-id']??'');},
  'asset-operation-queue-status':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});const m=await import('./asset-operation-queue.mjs');return m.assetQueueStatus(projectRoot(),options.input??'');},
  'step-asset-operation-queue':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input'],booleans:['retry-blocked']});requireCurrentProjectSiteForRemoteAction();const m=await import('./asset-operation-queue.mjs');return m.stepAssetQueue(projectRoot(),options.input??'',await assetOperationContext(),undefined,options['retry-blocked']===true);},
  'inspect-project-lock':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['lock']});const path=String(options.lock??'').replace(/\\/g,'/');if(!/^\.pipeline-state\/runtime\/(?:[a-zA-Z0-9_-]+\/)*[a-zA-Z0-9_.-]+\.lock$/.test(path))throw Object.assign(new Error('Expected a project runtime lock path.'),{code:'PROJECT_LOCK_PATH_INVALID'});const m=await import('./project-lock.mjs');const absolute=assertProjectWritePath(resolve(projectRoot(),path));return {ok:true,primary:await m.inspectProjectLock(absolute),reaper:await m.inspectProjectLock(absolute+'.reap')};},
  'apply-asset-review':async(tokens)=>{const {options}=parseOptions(tokens,{positionals:0,values:['input']});const m=await import('./asset-operation.mjs');return m.applyAssetReview(projectRoot(),options.input??'',await assetOperationContext());},
  "prepare-asset-extraction": async(tokens)=>{
    const {options}=parseOptions(tokens,{positionals:0,values:['input']});
    if(!options.input)throw Object.assign(new Error('Provide a project-local --input descriptor.'),{code:'ONLINE_DESCRIPTOR_INVALID'});
    await ensureProjectSiteForRemotePrepare();
    const {prepareAssetExtraction}=await import('./asset-extraction-operation.mjs');
    return prepareAssetExtraction(projectRoot(),options.input,await onlineAssetContext());
  },
  "submit-asset-extraction": async(tokens)=>{
    const {options}=parseOptions(tokens,{positionals:0,values:['operation-id','approval']});
    if(!options['operation-id']||!options.approval)throw Object.assign(new Error('Provide --operation-id and --approval.'),{code:'ONLINE_ARGUMENT_INVALID'});
    requireCurrentProjectSiteForRemoteAction();
    const {submitAssetExtraction}=await import('./asset-extraction-operation.mjs');
    return submitAssetExtraction(projectRoot(),options['operation-id'],options.approval,await onlineAssetContext());
  },
  "resume-asset-extraction": async(tokens)=>{
    const {options}=parseOptions(tokens,{positionals:0,values:['operation-id']});
    requireCurrentProjectSiteForRemoteAction();
    const {resumeAssetExtraction}=await import('./asset-extraction-operation.mjs');
    return resumeAssetExtraction(projectRoot(),options['operation-id']??'',await onlineAssetContext());
  },
  "asset-extraction-status": async(tokens)=>{
    const {options}=parseOptions(tokens,{positionals:0,values:['operation-id']});
    const {assetExtractionStatus}=await import('./asset-extraction-operation.mjs');
    return assetExtractionStatus(projectRoot(),options['operation-id']??'');
  },
  "import-asset-extraction": async (tokens) => {
    const {options}=parseOptions(tokens,{positionals:0,booleans:['no-write'],values:['input']});
    if(!options.input) throw Object.assign(new Error('Provide --input with the project-local intake descriptor.'),{code:'ASSET_IMPORT_DESCRIPTOR_INVALID'});
    const {importAssetExtraction}=await import('./asset-extraction-import.mjs');
    return importAssetExtraction(projectRoot(),options.input,{write:!options['no-write'],refresh:async(updateId)=>refreshUiSnapshot(['--update-id',updateId])});
  },
  doctor,
  run: runWorkflow,
  "inspect-image-provider-options": inspectImageProviderOptions,
  "select-image-provider": selectImageProvider,
  "migrate-image-provider": migrateImageProvider,
  "validate-references": validateReferences,
  "validate-clip-assets": validateClipAssets,
  "match-voice": matchVoice,
  "local-media-contract": localMediaContract,
  "storyboard-status-contract": storyboardStatusContract,
  "normalize-storyboard-statuses": normalizeStoryboardStatuses,
  "refresh-ui-snapshot": refreshUiSnapshot,
  "begin-snapshot-batch": beginSnapshotBatch,
  "snapshot-batch-heartbeat": snapshotBatchHeartbeat,
  "commit-snapshot-batch": commitSnapshotBatch,
  "abort-snapshot-batch": abortSnapshotBatch,
  "start-readonly-service": startReadonlyService,
  "open-workbench": openWorkbench,
  "readonly-service-status": readonlyServiceStatus,
  "stop-readonly-service": stopReadonlyService,
  "plan-scenes": planScenes,
  "materialize-video": materializeVideo,
  "materialize-video-params": materializeVideoParams,
  "poll-checkpoint": pollCheckpoint,
  "export-episodes": exportEpisodes,
  "export-jianying-drafts": exportJianyingDrafts,
  "import-jianying-draft": importJianyingDraft,
};
