import { randomUUID } from 'node:crypto';
import { existsSync, readFileSync, rmSync } from 'node:fs';
import { resolve } from 'node:path';
import { assertProjectWritePath, parseOptions, plainObject, projectRoot, writeJson } from './common.mjs';
import { withProjectLock } from './project-lock.mjs';
import { refreshUiSnapshot } from './studio.mjs';

const DEFAULT_LEASE_SECONDS = 90;
const MIN_LEASE_SECONDS = 15;
const MAX_LEASE_SECONDS = 900;
const statePath = () => assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/snapshot-batch.json'));
const lockPath = () => assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/snapshot-batch.lock'));

function readBatch() {
  const path = statePath();
  if (!existsSync(path)) return null;
  try {
    const value = JSON.parse(readFileSync(path, 'utf8'));
    if (!plainObject(value) || value.schema_version !== 1 || typeof value.update_id !== 'string'
      || typeof value.started_at !== 'string' || typeof value.expires_at !== 'string') return null;
    return value;
  } catch { return null; }
}
function activeBatch() { const value=readBatch(); return value && Date.parse(value.expires_at)>Date.now() ? value : null; }
function leaseSeconds(value) {
  const parsed=value===undefined?DEFAULT_LEASE_SECONDS:Number(value);
  if(!Number.isInteger(parsed)||parsed<MIN_LEASE_SECONDS||parsed>MAX_LEASE_SECONDS)
    throw Object.assign(new Error(`--lease-seconds must be ${MIN_LEASE_SECONDS}-${MAX_LEASE_SECONDS}`),{code:'INVALID_BATCH_LEASE'});
  return parsed;
}
function requireOwner(updateId) {
  const current=activeBatch();
  if(!current||current.update_id!==updateId) throw Object.assign(new Error('The snapshot batch lease is missing, expired, or belongs to another update.'),{code:'SNAPSHOT_BATCH_NOT_OWNED'});
  return current;
}

export async function beginSnapshotBatch(tokens) {
  const {options}=parseOptions(tokens,{positionals:0,values:['lease-seconds']});
  const seconds=leaseSeconds(options['lease-seconds']);
  return withProjectLock(lockPath(),async()=>{
    if(activeBatch()) throw Object.assign(new Error('A coordinated project update is already in progress.'),{code:'PROJECT_UPDATE_IN_PROGRESS',retryable:true});
    const now=new Date(),updateId=randomUUID();
    const record={schema_version:1,update_id:updateId,started_at:now.toISOString(),renewed_at:now.toISOString(),lease_seconds:seconds,expires_at:new Date(now.getTime()+seconds*1000).toISOString()};
    writeJson(statePath(),record);
    return {ok:true,action:'begin-snapshot-batch',update_id:updateId,expires_at:record.expires_at,lease_seconds:seconds};
  });
}

export async function snapshotBatchHeartbeat(tokens) {
  const {options}=parseOptions(tokens,{positionals:0,values:['update-id']});
  return withProjectLock(lockPath(),async()=>{
    const current=requireOwner(options['update-id']);
    const seconds=leaseSeconds(current.lease_seconds),now=new Date();
    const record={...current,renewed_at:now.toISOString(),expires_at:new Date(now.getTime()+seconds*1000).toISOString()};
    writeJson(statePath(),record);
    return {ok:true,action:'snapshot-batch-heartbeat',update_id:current.update_id,expires_at:record.expires_at};
  });
}

export async function commitSnapshotBatch(tokens) {
  const {options}=parseOptions(tokens,{positionals:0,values:['update-id']});
  return withProjectLock(lockPath(),async()=>{
    const current=requireOwner(options['update-id']);
    const refreshed=refreshUiSnapshot(['--update-id',current.update_id]);
    if(readBatch()?.update_id===current.update_id) rmSync(statePath(),{force:true});
    return {ok:true,action:'commit-snapshot-batch',update_id:current.update_id,snapshot_refresh:refreshed};
  });
}

export async function abortSnapshotBatch(tokens) {
  const {options}=parseOptions(tokens,{positionals:0,values:['update-id']});
  return withProjectLock(lockPath(),async()=>{
    const current=requireOwner(options['update-id']);
    if(readBatch()?.update_id===current.update_id) rmSync(statePath(),{force:true});
    return {ok:true,action:'abort-snapshot-batch',update_id:current.update_id,rolled_back:false};
  });
}
