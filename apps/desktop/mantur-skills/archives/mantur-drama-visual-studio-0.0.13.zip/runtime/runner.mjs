#!/usr/bin/env node
import { assertNodeVersion } from './node-version.mjs';

const [action, ...args] = process.argv.slice(2);

function safeErrorDiagnostics(error) {
  if (['CLIP_SOURCE_HASH_MISMATCH','CLIP_REFERENCE_BINDING_INVALID','CLIP_MANIFEST_BINDING_INVALID','CLIP_MANIFEST_MEDIA_CONFLICT','CLIP_VOICE_BINDING_CONFLICT','CLIP_VOICE_INHERITANCE_INVALID','CLIP_VOICE_MAPPING_CONFLICT'].includes(error?.code)) {
    const rules=new Set(['restoreOriginalUploadedBytesDoNotRecompile','explicitOrSameBaseVoiceFileAndHashRequired','exactAssetVoiceFileAndHashRequired','exactAssetImageFileAndHashRequired','uniqueAssetIdentity','validExplicitMediaBinding','voiceOnlyForCharacters','voicePolicyDisallowsBinding','uniqueDirectBaseCharacterRequired','consistentBaseVoicePolicy','sameFileRoleAndHashRequired','oneExclusiveVoiceWithinSameBaseCharacter','oneLocalVoiceSelectionPerBaseCharacter']);
    const paths=/^(?:\/(?:角色资产|场景资产|道具资产)\/\d+(?:\/(?:音色媒体|图片媒体|基础资产ID|音色策略))?|\/requests\/\d+\/references\/\d+|\/media_mapping\/items\/\d+|\/project\/source_script\/sha256|\/(?:production_asset_table\/|primary_json\/)?sourceScriptSha256|\/primary_json\/sourceProductionManifestSha256)$/;
    return Array.isArray(error.diagnostics)?error.diagnostics.filter(d=>typeof d?.path==='string'&&paths.test(d.path)&&rules.has(d.rule)).slice(0,20).map(d=>({path:d.path,rule:d.rule})):undefined;
  }
  if (['PROJECT_BUSY','ONLINE_LOCK_UNAVAILABLE','PROJECT_LOCK_INVALID','PROJECT_LOCK_OWNER_UNKNOWN','PROJECT_LOCK_ACCESS_DENIED','PROJECT_LOCK_FILESYSTEM_UNSUPPORTED','PROJECT_LOCK_RELEASE_FAILED'].includes(error?.code)) {
    const rules = new Set(['owner_live','owner_dead','owner_unknown','reaper_live','reaper_dead','reaper_unknown','reaper_writing','record_invalid','access_denied','release_failed','PROJECT_LOCK_INVALID','PROJECT_LOCK_OWNER_UNKNOWN','PROJECT_LOCK_ACCESS_DENIED','PROJECT_LOCK_FILESYSTEM_UNSUPPORTED','PROJECT_LOCK_RELEASE_FAILED']);
    return Array.isArray(error.diagnostics) ? error.diagnostics.filter(d=>d?.path==='/lock'&&rules.has(d.rule)).slice(0,2).map(d=>({path:'/lock',rule:d.rule})) : undefined;
  }
  if (error?.code !== 'REFERENCE_BINDING_MISMATCH' || !Array.isArray(error?.diagnostics)) return undefined;
  const hasReferenceBindingDiagnostic = error.diagnostics.some((diagnostic) => (
    diagnostic !== null
    && typeof diagnostic === 'object'
    && diagnostic.path === '/references'
    && diagnostic.rule === 'mustMatchReferenceRoutingBaseFirst'
  ));
  return hasReferenceBindingDiagnostic
    ? [{path:'/references', rule:'mustMatchReferenceRoutingBaseFirst'}]
    : undefined;
}

async function main() {
  assertNodeVersion();
  if (action === 'serve-readonly-service') {
    const { serveReadonlyService } = await import('./readonly-service.mjs');
    await serveReadonlyService(args);
    return;
  }
  const { ACTIONS } = await import('./actions.mjs');
  const { refreshUiSnapshot } = await import('./studio.mjs');
  if (!action || !Object.hasOwn(ACTIONS, action)) throw new Error(`action is not allowlisted: ${action || "(empty)"}`);
  const payload = await ACTIONS[action](args);
  if (payload === null || typeof payload !== "object" || Array.isArray(payload)) {
    throw new Error(`action ${action} returned an invalid result`);
  }
  if (['migrate-image-provider', 'normalize-storyboard-statuses', 'match-voice', 'plan-scenes', 'materialize-video', 'materialize-video-params', 'poll-checkpoint', 'export-episodes', 'export-jianying-drafts'].includes(action)) {
    try { payload.snapshot_refresh = {ok:true, ...refreshUiSnapshot([])}; }
    catch (error) {
      payload.snapshot_refresh = error?.code === 'PROJECT_UPDATE_IN_PROGRESS'
        ? {ok:true,deferred:true,reason:'snapshot_batch_active',production_result_preserved:true}
        : {ok:false, error:{code:'SNAPSHOT_REFRESH_FAILED',message:error.message}, retry_action:'refresh-ui-snapshot', production_result_preserved:true};
    }
  }
  process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
  if (payload.ok === false || payload.failed === true) process.exitCode = 1;
}

main().catch((error) => {
  const diagnostics = safeErrorDiagnostics(error);
  process.stdout.write(`${JSON.stringify({
    ok: false,
    error: {
      code: error.code || "SKILL_ACTION_FAILED",
      retryable: error.retryable === true,
      message: error instanceof Error ? error.message : String(error),
      ...(diagnostics ? {diagnostics} : {}),
    },
  }, null, 2)}\n`);
  process.exitCode = 1;
});
