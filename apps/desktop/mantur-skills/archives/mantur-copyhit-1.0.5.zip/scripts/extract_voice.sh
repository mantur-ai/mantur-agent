#!/usr/bin/env bash
# 抽人物说话的 N 秒音色样本（44.1k 单声道 wav，供出片 ref_audios 用）
# ⚠️ 这是回退脚本：默认走算子 op.audio.extract（至少 5s、自动 AI 分离人声）；中台不可用时才用本脚本
# 用法: extract_voice.sh <input> <start_sec> [dur=5] [out=voice_5s.wav]
set -e
IN="$1"; START="$2"; DUR="${3:-5}"; OUT="${4:-voice_5s.wav}"
[ -z "$IN" ] || [ -z "$START" ] && { echo "用法: extract_voice.sh <input> <start_sec> [dur=3] [out=voice_3s.wav]"; exit 1; }
ffmpeg -y -ss "$START" -t "$DUR" -i "$IN" -vn -ac 1 -ar 44100 -c:a pcm_s16le "$OUT" 2>/dev/null
echo "→ $OUT (${START}s 起 ${DUR}s，44100Hz 单声道)"
