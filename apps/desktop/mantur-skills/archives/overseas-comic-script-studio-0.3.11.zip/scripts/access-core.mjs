// Environment-aware adapter. Reuse the frozen v2 CLI primitives; never implement authenticated HTTP.
import assert from 'node:assert/strict';
import { readFileSync, realpathSync } from 'node:fs';
import { basename, dirname, isAbsolute, resolve } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as base from './access-base.mjs';
import { selectEnvironment, environmentIdentity, environmentDigest, projectEnvironment } from './test-mode.mjs';
export { child, hostSource, isSkillId, isSupportedCliVersion, locateCli, packageEntry, registrationEntryCode, validateExec, checkCliUpdate } from './access-base.mjs';
export function validateJobStatusUrl(value, profile) {
  assert(typeof base.validateJobStatusUrl === 'function', 'This adapter does not support job status URLs');
  return base.validateJobStatusUrl(value, profile);
}

export function validateProfile(profile) {
  base.validateProfile(profile);
  assert(profile.environmentPolicy === 'explicit-test-v1' && base.isSupportedCliVersion(profile.cliMinimumVersion, '1.2.9'), 'Unsupported environment policy/CLI version');
  return profile;
}
export function parseAccessArgs(argv) {
  const forwarded = [], seen = new Map(); let index = 0, project, environmentBinding;
  const names = ['--source', '--business-code', '--existing-cli', '--config-dir', '--project', '--environment-binding'];
  while (names.includes(argv[index]?.split('=')[0])) {
    const token = argv[index], name = token.split('=')[0], equal = token.indexOf('=');
    const value = equal < 0 ? argv[index + 1] : token.slice(equal + 1);
    assert(typeof value === 'string' && value.length, `Missing ${name} value`);
    if (seen.has(name)) {
      assert(seen.get(name) === value, `Conflicting repeated access option: ${name}`);
      index += equal < 0 ? 2 : 1; continue;
    }
    seen.set(name, value);
    if (name === '--project') { assert(project === undefined && isAbsolute(value), 'Use one absolute --project path'); project = value; }
    else if (name === '--environment-binding') {
      assert(environmentBinding === undefined && /^[a-f0-9]{64}$/.test(value), 'Invalid or repeated environment binding'); environmentBinding = value;
    } else forwarded.push(name, value);
    index += equal < 0 ? 2 : 1;
  }
  return { ...base.parseAccessArgs([...forwarded, ...argv.slice(index)]), project, environmentBinding };
}
export function context(profile, env = process.env, home = homedir(), binding, source, businessCode) {
  const p = validateProfile(profile), selected = selectEnvironment(p, env, home, binding);
  let validationProfile = p, validationHome = home;
  if (selected.mode === 'test' && p.channel === 'connector') {
    assert(/^\.manturhub-workbuddy(?:-[a-z0-9-]+)?$/.test(basename(selected.configDir)), 'Test connector requires a host-managed .manturhub-workbuddy directory');
    validationProfile = { ...p, configDir: basename(selected.configDir) }; validationHome = dirname(selected.configDir);
  }
  const ctx = base.context(validationProfile,
    selected.mode === 'test' ? { ...env, MANTURHUB_BASE: p.baseUrl } : env, validationHome, binding, source, businessCode);
  const bindingEnv = { MANTURHUB_SKILL_ENV: selected.mode, MANTURHUB_BASE: selected.baseUrl, MANTURHUB_CONFIG_DIR: ctx.configDir };
  // Production checks retain the legacy behavior that detects a stale stored non-production base.
  return { ...ctx, ...selected, configDir: ctx.configDir, bindingEnv,
    env: selected.mode === 'test' ? { ...ctx.env, ...bindingEnv } : ctx.env };
}
export function registrationContext(p, source, ctx) {
  return base.registrationContext({ ...p, baseUrl: ctx?.baseUrl ?? p.baseUrl }, source);
}
export async function status(entry, ctx, run = base.child) {
  const result = await run(entry, ['auth', 'status', '--json'], ctx.env, { capture: true, timeout: 10_000 });
  let value; try { value = JSON.parse(result.stdout); } catch { throw new Error('Invalid CLI auth status; no business call was made'); }
  assert(typeof value.authenticated === 'boolean' && typeof value.operatorReady === 'boolean', 'Invalid auth status contract');
  assert(value.baseUrl === ctx.baseUrl, 'CLI_SITE_MISMATCH: CLI does not match the explicitly selected environment');
  if (ctx.mode === 'test' && value.authenticated) assert(['account', 'api-key'].includes(value.mode), 'CLI_IDENTITY_MISMATCH: test mode requires the selected standalone CLI identity');
  return { code: result.code, authenticated: value.authenticated, operatorReady: value.operatorReady, baseUrl: value.baseUrl,
    ready: result.code === 0 && value.authenticated && value.operatorReady };
}
function report(p, entry, ctx, state, source, home, project) {
  const from = p.schemaVersion === 2 ? ctx.env.MANTURHUB_SOURCE : source;
  const registration = registrationContext(p, from, ctx);
  const businessArgs = p.schemaVersion === 2 ? ['--business-code', ctx.env.MANTURHUB_BUSINESS_CODE] : [];
  const bindingArgs = [...(p.channel === 'connector' ? businessArgs : [ ...(from ? ['--source', from] : []), ...businessArgs,
    '--existing-cli', entry, '--config-dir', ctx.configDir ]), '--environment-binding', environmentDigest(environmentIdentity(p, ctx)),
    ...(project ? ['--project', project] : [])];
  const loginInstructions = p.channel === 'standalone' && !state.authenticated
    ? { command: process.execPath, args: [entry, 'auth', 'login', ...(p.schemaVersion === 2 ? ['--from', registration.from, '--business-code', registration.businessCode] : [])],
      env: { ...ctx.bindingEnv, MANTURHUB_IDENTITY_MODE: 'standalone' } } : undefined;
  const quickLoginInstructions = loginInstructions && ctx.mode === 'production' && !ctx.existingCli && ctx.configDir === resolve(home, '.manturhub')
    ? { command: process.platform === 'win32' ? 'manturhub.cmd' : 'manturhub', args: loginInstructions.args.slice(1), scope: 'same-command-environment' } : undefined;
  return { channel: p.channel, product: p.product, accessMode: p.channel === 'connector' ? 'connector' : 'existing-cli',
    cliPath: entry, configDir: ctx.configDir, environment: ctx.mode, bindingArgs, bindingEnv: ctx.bindingEnv,
    ...(p.schemaVersion === 2 ? { invocationAttribution: { businessCode: ctx.env.MANTURHUB_BUSINESS_CODE, skillCode: p.skillCode,
      skillVersion: p.skillVersion, distributionTarget: p.distributionTarget, accessMode: p.accessMode } } : {}),
    ...(from ? { source: from } : {}), ...(loginInstructions ? { loginInstructions, ...registration } : {}),
    ...(quickLoginInstructions ? { quickLoginInstructions } : {}),
    cliVersion: JSON.parse(readFileSync(resolve(dirname(entry), '../package.json'), 'utf8')).version, cliMinimumVersion: p.cliMinimumVersion,
    status: state.ready ? 'READY' : !state.authenticated ? 'LOGIN_REQUIRED' : !state.operatorReady ? 'OPERATOR_AUTH_REQUIRED' : 'AUTH_CHECK_FAILED', ...state };
}
const packageRoot = fileURLToPath(new URL('../', import.meta.url));
export async function runAccess(p, argv, { env = process.env, home = homedir(), run = base.child, checkUpdates = base.checkCliUpdate,
  output = value => console.log(JSON.stringify(value)) } = {}) {
  assert(Number(process.versions.node.split('.')[0]) >= 20, 'Node >=20 required');
  const { binding, source, businessCode, project, environmentBinding, args: parsed } = parseAccessArgs(argv);
  const ctx = context(p, env, home, binding, source, businessCode), identity = environmentIdentity(p, ctx);
  if (environmentBinding) assert(environmentBinding === environmentDigest(identity), 'ENVIRONMENT_BINDING_CONFLICT: restore the environment returned by check; do not switch a confirmed or pending call');
  projectEnvironment(project, identity, { packageRoot });
  const [action, ...rest] = parsed;
  assert(['registration', 'check', 'authorize', 'exec'].includes(action), 'Use registration, check, authorize or exec; installation/login/logout remain user-managed');
  if (action === 'registration') {
    assert(!rest.length, 'registration accepts no flags'); output(registrationContext(p, source ?? ctx.env.MANTURHUB_SOURCE, ctx)); return 0;
  }
  if (p.schemaVersion === 2 && p.channel === 'standalone') assert(ctx.env.MANTURHUB_SOURCE, 'HOST_SOURCE_REQUIRED: explicitly pass the current --source');
  const entry = base.locateCli(p, ctx);
  const readiness = state => report(p, entry, ctx, state, source, home, project);
  if (action === 'check') {
    assert(!rest.length, 'check accepts no flags'); const state = await status(entry, ctx, run), result = readiness(state);
    if (p.cliInstallTag === 'latest') {
      result.cliUpdate = checkUpdates ? await checkUpdates(p, result.cliVersion, { home, env }) : { status: 'NOT_CHECKED' };
      result.upgradeInstructions = { requiresApproval: true, executor: p.channel === 'connector' ? 'connector-host' : 'user-agent',
        command: process.platform === 'win32' ? 'npm.cmd' : 'npm', args: ['install', '-g', '@manturhub/cli@latest', '--include=optional', '--engine-strict', '--registry=https://registry.npmjs.org'],
        cliPath: entry, configDir: ctx.configDir, verifyGlobalRoot: resolve(dirname(entry), '..'), explicitCliBinding: Boolean(ctx.existingCli), rerunCheckRequired: true };
    }
    output(result); return state.ready ? 0 : 1;
  }
  if (action === 'authorize') {
    assert(p.channel === 'standalone' && rest.length === 1 && rest[0] === '--approve-key', 'Use the host controls or explicit --approve-key approval');
    const state = await status(entry, ctx, run);
    if (state.ready) { output({ status: 'ALREADY_READY' }); return 0; }
    if (!state.authenticated) output(readiness(state));
    assert(state.authenticated && !state.operatorReady && [0, 1].includes(state.code), 'LOGIN_REQUIRED: use check and its complete login instructions before authorization');
    const probe = await run(entry, ['describe', p.probeOperator, '--json'], { ...ctx.env, MANTURHUB_BASE: ctx.baseUrl }, { capture: true, timeout: 60_000 });
    if (probe.code) return probe.code;
    const ready = await status(entry, ctx, run); output({ status: ready.ready ? 'OPERATOR_READY' : 'AUTHORIZATION_INCOMPLETE', ...ready }); return ready.ready ? 0 : 1;
  }
  assert(rest[0] === '--', 'Use exec -- <CLI arguments>'); const args = base.validateExec(rest.slice(1), { ...p, baseUrl: ctx.baseUrl });
  if (p.schemaVersion === 2) {
    const fixed = { 'business-code': ctx.env.MANTURHUB_BUSINESS_CODE, 'skill-code': p.skillCode, 'skill-version': p.skillVersion,
      'distribution-target': p.distributionTarget, 'access-mode': p.accessMode, source: ctx.env.MANTURHUB_SOURCE };
    for (let index = 1; index < args.length; index++) {
      const match = /^--([^=]+)(?:=(.*))?$/.exec(args[index]);
      if (match && Object.hasOwn(fixed, match[1])) assert((match[2] ?? args[++index]) === fixed[match[1]], `Conflicting product attribution: --${match[1]}`);
    }
  }
  if (!['doctor', '--version'].includes(args[0])) {
    const state = await status(entry, ctx, run); if (!state.ready) output(readiness(state));
    assert(state.ready, 'Authorization not ready; reuse check and its complete environment/login binding');
  }
  if (['run', 'quote'].includes(args[0])) projectEnvironment(project, identity, { commit: true, packageRoot });
  const result = await run(entry, args, ['doctor', '--version'].includes(args[0]) ? ctx.env : { ...ctx.env, MANTURHUB_BASE: ctx.baseUrl });
  // Legacy pending calls have no sidecar. The CLI first verifies their original origin/account receipt.
  if (args[0] === 'resume' && result.code === 0) projectEnvironment(project, identity, { commit: true, packageRoot });
  return result.code;
}
if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  try { process.exitCode = await runAccess(JSON.parse(readFileSync(new URL('./access-profile.json', import.meta.url), 'utf8')), process.argv.slice(2)); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
