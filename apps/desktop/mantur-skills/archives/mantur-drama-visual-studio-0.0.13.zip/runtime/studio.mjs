import { existsSync, lstatSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseOptions, plainObject, projectRoot, runInternalNode } from "./common.mjs";

const RUNTIME_ROOT = dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = resolve(RUNTIME_ROOT, "..");

function isSkillRoot(path) {
  try {
    return existsSync(resolve(path, "SKILL.md"))
      && lstatSync(resolve(path, "SKILL.md")).isFile()
      && existsSync(resolve(path, "runtime", "snapshot-compiler.mjs"))
      && lstatSync(resolve(path, "runtime", "snapshot-compiler.mjs")).isFile();
  } catch {
    return false;
  }
}

export function resolveSkillRoot(environ = process.env) {
  const configured = environ.MANTURHUB_SKILL_DIR && resolve(environ.MANTURHUB_SKILL_DIR);
  if (configured && isSkillRoot(configured)) return configured;
  if (isSkillRoot(PACKAGE_ROOT)) return PACKAGE_ROOT;
  throw new Error("installed Skill package is incomplete");
}

export function snapshotCompilerStatus(environ = process.env) {
  try {
    const skillRoot = resolveSkillRoot(environ);
    const entry = resolve(skillRoot, "runtime", "snapshot-compiler.mjs");
    for (const relativePath of [
      "schemas/manifest.schema.json",
      "schemas/snapshot-envelope.schema.json",
    ]) {
      const path = resolve(skillRoot, relativePath);
      if (!existsSync(path) || !lstatSync(path).isFile()) {
        return {
          ok: false,
          detail: `bundled snapshot schema is missing: ${relativePath}`,
          repair: "Reinstall mantur-drama-visual-studio@1.0.5",
        };
      }
    }
    return { ok: true, detail: "bundled snapshot compiler ready", skill_root: skillRoot, entry };
  } catch (error) {
    return {
      ok: false,
      detail: error instanceof Error ? error.message : String(error),
      repair: "Reinstall mantur-drama-visual-studio@1.0.5",
    };
  }
}

export function refreshUiSnapshot(tokens) {
  const { options } = parseOptions(tokens, { positionals: 0, booleans: ["no-write"], values: ["update-id"] });
  const compiler = snapshotCompilerStatus();
  if (!compiler.ok) throw new Error(`${compiler.detail}; ${compiler.repair}`);
  const root = projectRoot();
  const args = [compiler.entry, "--project-root", root];
  if (options["no-write"]) args.push("--no-write");
  if (options["update-id"]) args.push("--update-id", options["update-id"]);
  const result = runInternalNode(compiler.entry, args.slice(1));
  let payload = null;
  try {
    payload = JSON.parse(result.stdout);
  } catch {
    // A structured error is returned below.
  }
  if (result.status !== 0 || !plainObject(payload) || payload.ok !== true) {
    const detail = plainObject(payload) && payload.error
      ? payload.error
      : result.stderr.trim() || `snapshot compiler exited with ${result.status ?? "unknown"}`;
    throw Object.assign(new Error(`snapshot refresh failed: ${typeof detail==='object'?detail.message:detail}`),{code:detail?.code,retryable:detail?.retryable});
  }
  return {
    ...payload,
    action: "refresh-ui-snapshot",
    project_root: root,
    compiler: "bundled",
  };
}
