// Package-local project attribution only. No authentication, network or billing.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { closeSync, linkSync, lstatSync, openSync, readFileSync, realpathSync, unlinkSync, writeFileSync } from 'node:fs';
import { dirname, isAbsolute, join, parse, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const id = v => typeof v === 'string' && v.length <= 64 && !/[\x00-\x1f\x7f-\x9f]/.test(v) && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(v);
const runId = v => typeof v === 'string' && v.length === 32 && /^[a-f0-9]{32}$/.test(v);
const packageRoot = fileURLToPath(new URL('../', import.meta.url));
function noLinks(path) {
  let absolute = resolve(path);
  // macOS system aliases are not user-selected project links. Keep rejecting other links.
  if (process.platform === 'darwin') for (const prefix of ['/var', '/tmp']) {
    if ((absolute === prefix || absolute.startsWith(prefix + '/')) && realpathSync(prefix) === '/private' + prefix) absolute = '/private' + absolute;
  }
  let cursor = parse(absolute).root;
  for (const part of absolute.slice(cursor.length).split(/[\\/]/).filter(Boolean)) {
    cursor = join(cursor, part);
    assert(!lstatSync(cursor, { throwIfNoEntry: false })?.isSymbolicLink(), 'Unsafe project attribution path');
  }
  return absolute;
}
function read(path) {
  noLinks(path); const stat = lstatSync(path);
  assert(stat.isFile() && stat.size <= 32768, 'Unsafe project attribution file');
  return JSON.parse(readFileSync(path, 'utf8'));
}
function policy() {
  const profile = read(fileURLToPath(new URL('./access-profile.json', import.meta.url)));
  assert([1, 2].includes(profile.schemaVersion), 'Unsupported attribution profile');
  if (profile.schemaVersion === 1) return undefined;
  const p = read(fileURLToPath(new URL('./attribution-policy.json', import.meta.url)));
  assert(p.schemaVersion === 1 && p.product === profile.product && p.mode === 'workflow'
    && p.contextScope === 'project' && p.defaultBusinessCode === profile.businessCode && Array.isArray(p.steps), 'Invalid workflow attribution policy');
  return p;
}
function statePath(project) {
  const root = noLinks(project);
  assert(lstatSync(root).isDirectory(), 'Project directory is required');
  const relation = relative(realpathSync(packageRoot), realpathSync(root));
  assert(relation && (relation === '..' || relation.startsWith('..' + sep) || isAbsolute(relation)), 'Project must be outside the Skill installation');
  return join(root, 'skill-business-context.json');
}
function stored(path, p) {
  if (!lstatSync(path, { throwIfNoEntry: false })) return undefined;
  const s = read(path);
  assert(s.schemaVersion === 1 && s.product === p.product && id(s.businessCode) && runId(s.skillRunId)
    && Object.keys(s).every(k => ['schemaVersion', 'product', 'businessCode', 'skillRunId'].includes(k)), 'Invalid stored business attribution');
  return s;
}
export function readWorkflowContext(project) {
  const p = policy(); if (!p) return null;
  return stored(statePath(project), p) ?? null;
}
export function workflowContextArgs({ project, skillRunId, stepCode, operator, action, businessCode, env = process.env }) {
  const p = policy(); if (!p) return [];
  assert(runId(skillRunId), 'Invalid workflow ID');
  const step = p.steps.find(s => s.code === stepCode);
  assert(step && (operator === undefined || step.operator === operator) && (action === undefined || step.action === action), 'Undeclared attribution step or operator/action drift');
  const path = statePath(project), previous = stored(path, p);
  const selected = businessCode ?? env.MANTURHUB_BUSINESS_CODE ?? previous?.businessCode ?? p.defaultBusinessCode;
  assert(id(selected), 'Invalid business code');
  if (previous) assert(previous.businessCode === selected && previous.skillRunId === skillRunId, 'Project business/flow conflict; continue the original context or create a new project');
  else {
    const temporary = join(dirname(path), '.business-context-' + randomUUID() + '.tmp'); let fd, created = false;
    try {
      fd = openSync(temporary, 'wx', 0o600); created = true;
      writeFileSync(fd, JSON.stringify({ schemaVersion: 1, product: p.product, businessCode: selected, skillRunId }) + '\n');
      closeSync(fd); fd = undefined;
      try { linkSync(temporary, path); } catch (error) { if (error.code !== 'EEXIST') throw error; }
    } finally { if (fd !== undefined) closeSync(fd); if (created) unlinkSync(temporary); }
    const winner = stored(path, p);
    assert(winner.businessCode === selected && winner.skillRunId === skillRunId, 'Concurrent project business/flow conflict');
  }
  return ['--skill-run-id', skillRunId, '--step-code', stepCode, '--business-code', selected];
}
