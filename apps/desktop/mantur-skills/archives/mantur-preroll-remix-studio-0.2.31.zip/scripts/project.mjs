import {billingView} from './billing-view.mjs';
import fs from 'node:fs/promises';
import { createReadStream, constants } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import {inspectMedia} from './media-probe.mjs';

const skillRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const within = (root, target) => target === root || target.startsWith(root + path.sep);
async function resolvedPath(target) {
  try { return await fs.realpath(target); }
  catch (e) { if(e.code!=='ENOENT')throw e;const parent=path.dirname(target);if(parent===target)throw e;return path.join(await resolvedPath(parent),path.basename(target)); }
}
export async function assertProjectDirectory(dir) {
  const target=await resolvedPath(path.resolve(dir));
  check(!within(await resolvedPath(skillRoot),target),'PROJECT_DIRECTORY_RESERVED','项目必须放在独立目录，不能写入 Skill 安装目录。');
  for(let candidate=target;;candidate=path.dirname(candidate)){
    try{await fs.access(path.join(candidate,'SKILL.md'));fail('PROJECT_DIRECTORY_RESERVED','项目不能位于 Skill 源码或安装目录中。');}catch(e){if(e.code!=='ENOENT')throw e;}
    try{const pkg=JSON.parse(await fs.readFile(path.join(candidate,'package.json'),'utf8'));check(pkg.name!=='@manturhub/cli','PROJECT_DIRECTORY_RESERVED','项目不能位于 CLI 安装目录中。');}catch(e){if(e.code!=='ENOENT'&&!(e instanceof SyntaxError))throw e;}
    if(path.dirname(candidate)===candidate)break;
  }
  return target;
}
export async function projectFolder(dir,relative) {
  const root=await assertProjectDirectory(dir);await fs.mkdir(root,{recursive:true});
  const folder=path.resolve(root,relative);check(within(root,folder),'ASSET_PATH_INVALID');
  check(within(root,await resolvedPath(folder)),'ASSET_PATH_INVALID');
  await fs.mkdir(folder,{recursive:true});check(within(root,await fs.realpath(folder)),'ASSET_PATH_INVALID');return folder;
}
// Probe only disposable files on the actual state volume; never touch a real
// binding/lock. Import and local review can still work on unsupported volumes.
export async function projectStorageStatus(dir,{io=fs}={}) {
  let temporary,result,operation='state-directory';
  try {
    const folder=await projectFolder(dir,'.preroll');
    temporary=await io.mkdtemp(path.join(folder,'.storage-check-'));
    const source=path.join(temporary,'source'),target=path.join(temporary,'published');
    operation='exclusive-create';await io.writeFile(source,'probe',{flag:'wx',mode:0o600});
    try {await io.writeFile(source,'overwrite',{flag:'wx'});throw Object.assign(Error(),{code:'EXCLUSIVE_CREATE_UNSAFE'});}
    catch(error){if(error.code!=='EEXIST')throw error;}
    operation='hard-link';await io.link(source,target);
    operation='no-overwrite';
    try {await io.link(source,target);throw Object.assign(Error(),{code:'LINK_OVERWRITE_UNSAFE'});}
    catch(error){if(error.code!=='EEXIST')throw error;}
    operation='atomic-replace';const replacement=path.join(temporary,'replacement');
    await io.writeFile(replacement,'replacement',{flag:'wx',mode:0o600});await io.rename(replacement,target);
    operation='readback';
    if(await io.readFile(target,'utf8')!=='replacement'||await io.readFile(source,'utf8')!=='probe')throw Object.assign(Error(),{code:'READBACK_MISMATCH'});
    result={ready:true,requiredFor:'new_remote_actions'};
  }catch(error){
    const known=['EACCES','EPERM','ENOSPC','EROFS','ENOTSUP','EOPNOTSUPP','EXDEV','ENOENT','EXCLUSIVE_CREATE_UNSAFE','LINK_OVERWRITE_UNSAFE','READBACK_MISMATCH'];
    result={ready:false,requiredFor:'new_remote_actions',code:'PROJECT_STORAGE_UNSUPPORTED',failure:{operation,code:known.includes(error.code)?error.code:'IO_FAILED'},
      message:'项目状态目录未通过制作所需的文件能力检查。请核对目录权限或选择支持独占创建、硬链接和原子替换的位置；素材与已有记录保留，不会自动搬移或重新制作。'};
  }finally{if(temporary)try{await io.rm(temporary,{recursive:true,force:true});}catch{result={ready:false,requiredFor:'new_remote_actions',code:'PROJECT_STORAGE_UNSUPPORTED',failure:{operation:'cleanup',code:'IO_FAILED'},message:'项目目录的能力探测临时文件未能清理，请核对目录权限后再准备制作；已有项目和任务记录未改动。'};}}
  return result;
}
export async function assertProjectStorage(dir) {
  const result=await projectStorageStatus(dir);
  if(!result.ready)throw Object.assign(new Error(`${result.message} 检查项：${result.failure.operation}；原因码：${result.failure.code}。`),{code:result.code,storageFailure:result.failure});
  return result;
}
const safeTitle=title=>String(title).normalize('NFC').replace(/[<>:"/\\|?*\x00-\x1f]/g,'-').replace(/[. ]+$/g,'').slice(0,60)||'项目';
export async function createManagedProject(spec,{parentDirectory=path.join(os.homedir(),'Documents','ManturHub','projects')}={}) {
  const parent=await assertProjectDirectory(parentDirectory);
  const projectDir=path.join(parent,`${safeTitle(spec.title)}-${crypto.randomUUID()}`);
  await assertProjectDirectory(projectDir);
  const project=await initialize(projectDir,spec);return {projectDir,project};
}
function artifactManifest(p){
  const fields=(value,keys)=>Object.fromEntries(keys.filter(k=>value[k]!==undefined).map(k=>[k,value[k]]));
  const operations=p.operations.map(o=>{
    return {...fields(o,['id','stage','status','assetId','highlightId']),estimatedPoints:o.quote?.estimatedPoints,...billingView(o.status==='rejected'?undefined:o.billing)};
  });
  const selectedOperations=(p.highlightOperationIds||[]).map(id=>p.operations.find(o=>o.id===id)).filter(Boolean);
  const highlights=(p.highlights||[]).map(h=>{
    const op=selectedOperations.find(o=>o.highlightId===h.id);
    return {...fields(h,['id','episode','start','end']),...(op?.assetId?{assetId:op.assetId}:{}),...(op?{operationId:op.id,status:op.status}:{})};
  });
  return {schemaVersion:1,...fields(p,['id','title','revision','updatedAt']),assets:p.assets.map(a=>fields(a,['id','role','episode','name','relativePath','sha256','size','duration','width','height','displayWidth','displayHeight','displayGeometryKnown','hasAudio'])),operations,highlights};
}
export function fail(code, message = code) { throw Object.assign(new Error(message), { code }); }
export function check(ok, code, message) { if (!ok) fail(code, message); }
export function packagingOptions(value, base) {
  for (const options of [base,value]) {
    if(options===undefined)continue;
    check(options!==null&&typeof options==='object'&&(Object.getPrototypeOf(options)===Object.prototype||Object.getPrototypeOf(options)===null),'PACKAGING_INVALID','尾贴和水印选项必须为对象。');
    check(Reflect.ownKeys(options).every(key=>['ending','logo'].includes(key)&&typeof options[key]==='boolean'),'PACKAGING_INVALID','仅支持 ending、logo 布尔选项。');
  }
  return {ending:true,logo:true,...base,...value};
}
export function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(k => [k, canonical(value[k])]));
  return value;
}
export const digest = value => crypto.createHash('sha256').update(JSON.stringify(canonical(value))).digest('hex');
export const validId = id => typeof id === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/.test(id);
export const number = n => typeof n === 'number' && Number.isFinite(n);
export const episodeCount=p=>new Set((p.assets||[]).filter(a=>a.role==='episode').map(a=>a.episode).filter(n=>Number.isInteger(n)&&n>0)).size;
export function assertEpisodeMinimum(p){check(episodeCount(p)>=3,'EPISODES_INSUFFICIENT','至少需要 3 集不同集号的原始剧集；尾贴、参考视频和 PNG 不计入。请先补充素材。');}
export async function fileHash(file) {
  const hash = crypto.createHash('sha256'); let size = 0;
  for await (const chunk of createReadStream(file)) { hash.update(chunk); size += chunk.length; }
  return { sha256: hash.digest('hex'), size };
}
export async function atomicJson(file, data) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.${crypto.randomUUID()}.tmp`;
  await fs.writeFile(temporary, JSON.stringify(data, null, 2) + '\n', { mode: 0o600 });
  await fs.rename(temporary, file);
}
export async function loadProject(dir) {
  const p = JSON.parse(await fs.readFile(path.join(dir, '.preroll/project.json'), 'utf8'));
  check([1,2].includes(p.schemaVersion) && Array.isArray(p.assets) && Array.isArray(p.operations), 'PROJECT_INVALID');
  if(p.schemaVersion===1||p.legacyOrigin)Object.defineProperty(p,'legacyReadOnly',{value:true,enumerable:false});
  return p;
}
export async function saveProject(dir, p) {
  assertWritableProject(p);
  p.revision += 1; p.updatedAt = new Date().toISOString();
  const state=await projectFolder(dir,'.preroll');
  await atomicJson(path.join(state, 'project.json'), p);
  const records=await projectFolder(dir,'制作记录');
  await atomicJson(path.join(records,'产物清单.json'),artifactManifest(p));
}
export function assertWritableProject(p){
  check(p?.schemaVersion===2&&!p.legacyReadOnly&&!p.legacyOrigin,'LEGACY_PROJECT_READ_ONLY','历史项目仅供本地审阅；原未决调用留在原入口恢复，新制作请创建独立项目。');
}
export async function withLock(dir, action) {
  await projectFolder(dir,'.preroll');
  const lock = path.join(dir, '.preroll/write.lock'); const token = crypto.randomUUID();
  for (let i = 0; i < 2; i++) {
    try { await fs.writeFile(lock, JSON.stringify({ pid: process.pid, token }), { flag: 'wx', mode: 0o600 }); break; }
    catch (e) {
      if (e.code !== 'EEXIST') throw e;
      if (i === 1) fail('PROJECT_LOCKED');
      // Serialise stale-lock recovery so two rescuers cannot remove a new writer's lock.
      const recovery=`${lock}.recovery`;
      let handle;try{handle=await fs.open(recovery,'wx',0o600);}catch{fail('PROJECT_LOCKED');}
      try{
        let owner;try{owner=JSON.parse(await fs.readFile(lock,'utf8'));}catch(read){if(read.code==='ENOENT')continue;fail('PROJECT_LOCKED');}
        check(Number.isInteger(owner.pid)&&owner.pid>0,'PROJECT_LOCKED');
        try{process.kill(owner.pid,0);fail('PROJECT_LOCKED','另一个进程正在更新项目');}catch(probe){if(probe.code!=='ESRCH')throw probe;}
        await fs.unlink(lock);
      }finally{await handle.close();await fs.unlink(recovery);}
    }
  }
  try { return await action(); }
  finally {
    try { const owner = JSON.parse(await fs.readFile(lock, 'utf8')); if (owner.token === token) await fs.unlink(lock); } catch { /* Preserve other owners. */ }
  }
}
export async function assetPath(dir, asset) {
  return (await inspectAssetPath(dir,asset)).file;
}
// Resolve the project root once; every media component inside it must be real.
export async function inspectAssetPath(dir,asset){
  const root=await fs.realpath(dir);
  check(typeof asset.relativePath==='string'&&asset.relativePath&&!path.isAbsolute(asset.relativePath),'ASSET_PATH_INVALID');
  const file=path.resolve(root,asset.relativePath);
  check(file.startsWith(root+path.sep),'ASSET_PATH_INVALID');
  const parts=path.relative(root,file).split(path.sep),entries=[];
  let current=root;
  for(let index=-1;index<parts.length;index++){
    if(index>=0)current=path.join(current,parts[index]);
    const info=await fs.lstat(current);
    check(!info.isSymbolicLink()&&(index===parts.length-1?info.isFile():info.isDirectory()),'ASSET_PATH_INVALID');
    entries.push({path:current,dev:info.dev,ino:info.ino});
  }
  check(await fs.realpath(file)===file,'ASSET_PATH_INVALID');
  return {file,entries};
}
// Serve only the checked descriptor, never reopen a checked media pathname.
export async function openAsset(dir,asset){
  const before=await inspectAssetPath(dir,asset);
  let handle;
  try{
    handle=await fs.open(before.file,constants.O_RDONLY|(constants.O_NOFOLLOW||0)|(constants.O_NONBLOCK||0));
    const info=await handle.stat(),expected=before.entries.at(-1);
    check(info.isFile()&&info.dev===expected.dev&&info.ino===expected.ino,'ASSET_PATH_INVALID');
    const after=await inspectAssetPath(dir,asset);
    check(after.file===before.file&&after.entries.length===before.entries.length&&after.entries.every((entry,index)=>entry.dev===before.entries[index].dev&&entry.ino===before.entries[index].ino),'ASSET_PATH_INVALID');
    return {file:before.file,info,handle};
  }catch(error){
    if(handle)await handle.close();
    if(error.code==='ELOOP')fail('ASSET_PATH_INVALID');
    throw error;
  }
}
export async function verifyAsset(dir, asset) {
  const file = await assetPath(dir, asset); const h = await fileHash(file);
  check(h.sha256 === asset.sha256 && h.size === asset.size, 'ASSET_CHANGED', `素材已改变：${asset.name}`);
  return file;
}
export function displayGeometry(video) {
  const sar=video.sample_aspect_ratio;
  const ratio=/^(\d+):(\d+)$/.exec(sar||'');
  if(sar&&sar!=='N/A'&&(!ratio||Number(ratio[1])<=0||Number(ratio[1])!==Number(ratio[2])))return {displayGeometryKnown:false};
  const rotationData=video.side_data_list?.find(s=>s.rotation!==undefined||s.side_data_type==='Display Matrix');
  const rawRotation=rotationData ? rotationData.rotation : video.tags?.rotate??0;
  if(typeof rawRotation!=='number'&&(typeof rawRotation!=='string'||!rawRotation.trim()))return {displayGeometryKnown:false};
  const rotation=Number(rawRotation);
  const normalized=((rotation%360)+360)%360;
  if(!Number.isFinite(normalized)||![0,90,180,270].includes(normalized))return {displayGeometryKnown:false};
  const swapped=normalized===90||normalized===270;
  return {displayGeometryKnown:true,displayWidth:swapped?video.height:video.width,displayHeight:swapped?video.width:video.height};
}
export async function probe(file, decode = false) {
  // Retain the internal legacy signature, but never execute a system media tool.
  // The returned evidence explicitly says full decoding was not performed.
  return inspectMedia(file);
}
export async function addAsset(dir, project, item, {stage,inspection}={}) {
  assertWritableProject(project);
  await assertProjectDirectory(dir);
  check(stage===undefined||['fronts','highlights','compose'].includes(stage),'STAGE_INVALID');
  check(validId(item.id) && ['episode','ending','logo','reference','front','result'].includes(item.role), 'ASSET_INVALID');
  check(typeof item.path === 'string', 'ASSET_PATH_REQUIRED');
  if (item.role === 'episode') check(Number.isInteger(item.episode) && item.episode > 0, 'EPISODE_INVALID');
  const source = await fs.realpath(item.path); const h = await fileHash(source);
  check(h.size > 0, 'EMPTY_ASSET');
  const old = project.assets.find(a => a.id === item.id);
  if (old) {
    check(old.sha256 === h.sha256 && old.role === item.role && old.episode === item.episode, 'ASSET_ID_CONFLICT');
    try { await verifyAsset(dir,old); }
    catch(e){
      if(!['ENOENT','ASSET_CHANGED'].includes(e.code))throw e;
      const dest=path.resolve(dir,old.relativePath);const root=await fs.realpath(dir);
      const parent=await projectFolder(dir,path.dirname(old.relativePath));check(parent.startsWith(root+path.sep),'ASSET_PATH_INVALID');
      const temporary=`${dest}.${crypto.randomUUID()}.repair`;
      await fs.copyFile(source,temporary);check((await fileHash(temporary)).sha256===old.sha256,'ASSET_CHANGED_DURING_COPY');
      await fs.rename(temporary,dest);await verifyAsset(dir,old);
    }
    return old;
  }
  if (item.role === 'episode') check(!project.assets.some(a => a.episode === item.episode && a.role === 'episode'), 'EPISODE_DUPLICATE');
  if(inspection)check(inspection.sha256===h.sha256&&inspection.size===h.size&&inspection.facts?.validation?.container===true&&inspection.facts.validation.decode==='not_performed','MEDIA_METADATA_BINDING_MISMATCH','媒体核验记录与当前文件不一致，请恢复原产物。');
  const media = inspection?structuredClone(inspection.facts):await probe(source);
  if (item.role === 'logo') check(media.codec === 'png', 'LOGO_MUST_BE_PNG');
  else check(media.duration > 0 && number(media.duration), 'DURATION_INVALID');
  const extension=item.role==='logo'?'.png':path.extname(source).toLowerCase();
  check(['.png','.mp4','.mov','.webm'].includes(extension),'MEDIA_CONTAINER_UNSUPPORTED');
  const folders={episode:'素材/剧集',ending:'素材/尾贴',logo:'素材/水印',reference:'素材/参考视频',front:'素材/已有前贴',result:'最终成片'};
  const outputFolders={fronts:'中间产物/生成前贴',highlights:'中间产物/高光片段',compose:'最终成片'};
  const folder=await projectFolder(dir,outputFolders[stage]||folders[item.role]);
  let dest=path.join(folder,`${item.id}-${h.sha256.slice(0,12)}${extension}`);
  for(;;){try{await fs.copyFile(source,dest,constants.COPYFILE_EXCL);break;}catch(e){if(e.code!=='EEXIST')throw e;dest=path.join(folder,`${item.id}-${crypto.randomUUID()}${extension}`);}}
  const relativePath=path.relative(await fs.realpath(dir),dest);
  check((await fileHash(dest)).sha256 === h.sha256 && (await fileHash(source)).sha256 === h.sha256, 'ASSET_CHANGED_DURING_COPY');
  const asset = { id:item.id, role:item.role, ...(item.episode ? {episode:item.episode}:{}), name: typeof item.name === 'string' ? item.name : path.basename(source), relativePath, ...h, ...media };
  project.assets.push(asset); return asset;
}
export async function initialize(dir, spec) {
  await assertProjectDirectory(dir);
  check(typeof spec.title === 'string' && spec.title.trim(), 'TITLE_REQUIRED');
  check(spec.apiBase===undefined&&spec.environment===undefined,'PROJECT_CONNECTION_OVERRIDE_REJECTED','接入环境由公共工具合同管理，不在业务项目中覆盖。');
  try { await fs.access(path.join(dir,'.preroll/project.json')); fail('PROJECT_EXISTS'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  const p = {schemaVersion:2,id:crypto.randomUUID(),title:spec.title,packaging:packagingOptions(spec.packaging),modeDecision:null,revision:0,assets:[],operations:[],analysis:null,highlights:[],plans:[],planHistory:[],approvals:[]};
  check(Array.isArray(spec.assets), 'ASSETS_REQUIRED');
  for (const item of spec.assets) await addAsset(dir,p,item);
  await saveProject(dir,p); return p;
}
