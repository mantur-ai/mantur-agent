#!/usr/bin/env python3
# 把 op.image.generate 算子返回的 base64 图片解码存盘（op.image.generate 返回 base64 不是 URL）
# 用法: save_image_b64.py <raw.json|-> <out.png>    （- = 从 stdin 读取算子返回）
import json, base64, sys

if len(sys.argv) < 3:
    sys.exit("用法: save_image_b64.py <raw.json|-> <out.png>")
src, out = sys.argv[1], sys.argv[2]
raw = sys.stdin.read() if src == "-" else open(src, encoding="utf-8").read()
s = raw.find("{")
obj = json.loads(raw[s:]) if s >= 0 else {}
r = obj.get("result") or {}
b64 = r.get("value") or obj.get("result_b64_json") or r.get("b64_json")
if not b64:
    sys.exit("未找到 base64 图片数据（期望在 result.value）；返回 keys: %s" % list(obj.keys()))
if b64.startswith("data:"):
    b64 = b64.split(",")[-1]
with open(out, "wb") as f:
    f.write(base64.b64decode(b64))
print("→", out)
