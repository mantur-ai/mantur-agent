# 素材操作合同：图片、理解、音色与参考音频

每次平台费用确认前执行 `query-account-balance`，按 [报价与余额展示](quote-and-balance.md) 同时展示报价、刚查的余额与预计余量；查询失败明确说明，批次按本次精确报价总额计算。原生路径不因此调用平台余额或付费算子。

资产服装/外观等需求修改先走 [prepare/apply-asset-revision](asset-revisions.md)。修订后图片审核必须携带当前 requirement_revision、新证据和原选择 SHA；有合法修订时可在保留分镜/历史的条件下复核或替换目标图片。既有文件不自动验收，音色不因服装修订失效。

适用 `mantur-drama-visual-studio@1.0.5`，私有记录 `asset-operations/v1`。公开 Manifest、快照与 API 仍为 v1。新合同只按实际路径开放；分镜、视频和固定 voice_id 合成不因此开放。代码/隔离验证不等于真实付费验收。

图片、理解、音色设计和参考音频没有资产提取／分镜那样的第二套 import 血缘层；`prepare/submit/resume` 中的 operation、Job ID、算子、输出 Schema、首个成功结果和媒体检查就是唯一验证，不属于本次取消的重复接入复算。后续审核继续核对当前候选、需求 revision、媒体摘要和并发选择基线。

## 入口及授权

通过 `studio.mjs --project <PROJECT_DIR>` 调用：

| 动作 | 参数 | 行为 |
|---|---|---|
| prepare-asset-batch | `--input <项目内批次描述文件>` | 图片／定制音色按配置分组询价、汇总数量与总价；不提交 |
| prepare-asset-operation | `--input <项目内描述文件>` | 检查目标、原字节归档、必要上传确认、实时 Schema 与非扣费 precharge；不提交 |
| submit-asset-operation | `--operation-id <本地ID> --approval <项目内批准记录>` | 重新试算，批准仍一致才提交 |
| resume-asset-operation | `--operation-id <本地ID>` | 有界恢复原上传、原提交、原 Job、下载或发布；不创建替代任务 |
| asset-operation-status | `--operation-id <本地ID>` | 仅本地读取，不联网、不迁移、不写文件 |
| apply-asset-review | `--input <项目内审核记录>` | 保存明确候选的关联和验收，原子更新库存及匹配指针、刷新一次 |

`prepare` 会上传输入并试算，不能当成只读诊断。描述文件只允许下列字段，不接受任意算子、URL 请求入口或费用开关：

在任何上传前，Runtime 先检查实时算子身份、状态、同源路由和可编译 Schema，不比较打包指纹、平台业务版本或 checker 版本。准备和提交各保存一份不可变私有合同收据；提交前若 Schema 变化，只有原请求仍通过实时 inputSchema 且重新试算摘要不变才继续，否则按合同或报价错误阻断。结果继续使用提交时保存的 outputSchema 与本地资产解析器双重校验。

```json
{
  "schema_version": 1,
  "kind": "image",
  "asset_id": "CHAR-001-V01",
  "provider": "manturhub:op.image.generate",
  "parameters": {"prompt": "本资产的完整生成提示词"},
  "references": [],
  "reference_manifest": "input/reference-routing.json"
}
```

这是本地结构示例，不是官方请求或真实任务。`kind` 只接受 `image/understanding/voice-design/audio`。音色和音频目标必须是提取报告中的基础角色 ID；普通服装变体不另建音色。`attempt_key` 仅在用户明确要求新的生产操作时指定；不能为修复下载或快照换键。`audio` 还须 `purpose: "voice_reference"`，不扩展音乐、音效业务。

旧描述中的 `user_confirmation_required` 仅保留手动审核兼容语义。图片正常采用走 `review_origin: automatic_image_analysis` 和完整视觉证据，不靠将该旧字段设为 `false` 绕过检查，也不要求用户确认。

`references` 每项为 `{path, kind, remote_url?}`，`path` 必须写成相对于 `PROJECT_DIR` 的项目相对路径，并使用 `/` 分隔；不得保存绝对路径、项目目录名或 `..`。`reference_manifest`、审核文件中的 `local_file` 及参考清单的 `local_path` 同样遵守该规则。`kind` 为 image/audio/video。参数中禁止重复传任何媒体别名、fileId 或 URL。图片引用上传获得 `AVAILABLE` 后由 Runtime 写入唯一 `referenceImages:[{fileId}]`；理解只允许一个 image/video；音频至多一个 audio。理解和音频需要已知 HTTPS `remote_url`，匿名下载核对与本地 SHA 一致后使用。缺少地址时返回 `FILE_URL_UNAVAILABLE`，不把 fileId 填到 URL 字段，不猜取链接口。

角色变体不能只在参考清单中填写 `base_asset_reference`。准备 V02+ 图片时，操作描述文件的 `references` 还必须把同一张已验收 V01 基座图作为第一项；即使没有其他用户参考图，数组也不能是空。以下两个项目内文件必须配套：

`input/reference-routing-v4.json`：

```json
{
  "version": "reference-routing-v4",
  "references": [],
  "bindings": [{
    "asset_id": "CHAR-001-V02",
    "selected_reference_ids": [],
    "reference_uses": [],
    "base_asset_reference": {
      "asset_id": "CHAR-001-V01",
      "local_path": ".pipeline-state/media/assets/CHAR-001-V01.png",
      "checksum": "基座图的64位小写SHA-256"
    },
    "status": "ready"
  }]
}
```

`input/CHAR-001-V02-image.json`：

```json
{
  "schema_version": 1,
  "kind": "image",
  "asset_id": "CHAR-001-V02",
  "provider": "manturhub:op.image.generate",
  "parameters": {"prompt": "本变体的完整生成提示词"},
  "references": [{
    "path": ".pipeline-state/media/assets/CHAR-001-V01.png",
    "kind": "image"
  }],
  "reference_manifest": "input/reference-routing-v4.json"
}
```

精确不变量为：描述文件 `references[].path` 依次等于 `[binding.base_asset_reference.local_path（若有）, ...binding.selected_reference_ids 对应的 references[].local_path]`，按此顺序去重后逐项一致；每项均为项目相对路径且 `kind=image`。基座图还必须与当前匹配报告中该基础角色唯一、已验收图片的首个 `local_files` 路径一致。路径正确但漏项、重复、乱序或指向另一文件，均不得 prepare。

违反该顺序时，CLI 返回 `REFERENCE_BINDING_MISMATCH`，并仅附带固定的安全诊断 `[{"path":"/references","rule":"mustMatchReferenceRoutingBaseFirst"}]`；不得在诊断中回显本机路径、文件内容、远端标识或完整描述文件。

批准文件由 Agent 在取得用户明确费用批准后保存：复制 status 的 `approval_binding`，添加 `approved:true`、`approved_at` ISO 时间。绑定项目、锁站、操作、精确请求摘要与报价摘要。首次提交前重新试算；价格/规则变化返回 `ONLINE_QUOTE_CHANGED`，需要重新批准，不虚构平台报价 Token。

### 平台批量生图的 Agent 并发

Agent 使用 [标准图片队列](lock-and-queue-recovery.md#标准图片队列) 的 `asset-operation-queue-status`／`step-asset-operation-queue` 维护以下规则，不临时重写状态分类或清锁扫描器。队列描述保持批准顺序；错误、下载、审核和远端占用分开处理。

平台生图并发上限为 5 个独立操作。批量开始前，Agent 对所有依赖已满足的目标使用下方批量准备入口，保留各自资产、提示词、操作 ID 和幂等键；展示分组单价、数量、当前余额、总价和完整范围，取得用户一次明确费用批准后，再按每个 status 的 `approval_binding` 保存对应批准文件。批准只覆盖这组精确请求，不能追加资产；任一请求或报价变化时，仅受影响操作退出原批准范围并重新确认。

这 5 个槽位由 Agent 控制，不新增 Runtime 全局锁、跨项目额度池或后台调度器。`submission_unknown`、已被平台接受后排队及运行中的图片操作占用槽位；明确成功、失败、取消或超时终态立即释放远端槽位，本地下载、媒体校验、Agent 视觉检查和采用发布继续按原操作完成。Agent 按用户已批准的批次顺序稳定补位，不按资产 ID、文件名或相似度重排。准备完成、等待批准、依赖未满足和平台明确未受理的操作不占活动槽。

HTTP 429 或平台并发限制明确表示本次未受理时，不创建新操作、不更换幂等键或 provider；保存原操作，遵守 `Retry-After`／`next_poll_seconds`，到期后恢复同一提交。提交结果不明仍记为 `submission_unknown` 并占槽，先恢复原受理，不能当作 429 拒绝后补交第六项。单项明确失败只停止该操作，其他独立且已批准操作继续；重新付费生成仍须新的明确批准。

每个不同资产必须是独立操作。`n` 只表示同一提示词的一次请求返回多少候选，`n=5` 不是五个资产并发；默认仍为 `n=1`，多候选逐张保存，由 Agent 实际查看全部返回候选后择优采用一张，无法明确选择时才询问。V02+ 等依赖基础图的目标，必须等 V01 已验收且参考清单重新校验后才可 prepare／submit。当前 Agent 只统计自己可见的项目操作；多 Agent、其他设备或账号其他任务的合计不作本地绝对保证，平台响应是最终限制。宿主无法真正并行调用时使用更低并发并如实说明，不伪报五路运行。

## 图片与定制音色的批量计价

平台图片与定制音色使用 `prepare-asset-batch --input input/asset-batch.json`。先保存每个目标原有的操作描述文件，再列出本次完整范围：

```json
{
  "schema_version": 1,
  "items": [
    {"input": "input/image-01.json"},
    {"input": "input/image-02.json"},
    {"input": "input/voice-01.json"}
  ]
}
```

每项 `input` 为项目相对路径；只接受 `image` 和 `voice-design`，同类资产不能重复。音色按基础角色去重，预制音色免费复用不进入此批次；参考音频合成 `audio`、素材理解、视频和其他阶段不套用此计价规则。V02+ 等依赖未满足的目标仍先等待，不为凑全批次跳过基础图门禁。

Runtime 先逐项检查来源、引用、实时 Schema，完成必要上传并保存独立实际请求，整批准备成功后才集中询价。新计价收据按 `asset_quantity_v2` 分组：图片排除 `prompt`、整个 `referenceImages` 和已知同价的 `mode=generate/edit` 差异，参考图有无、数量、身份不拆组；定制音色只排除 `description`、`preview_text`。模型、尺寸、单次候选数 `n`、格式、语言及其他全部参数保留在分组键中；未知模式不按 generate/edit 合并，站点、项目、认证身份、报价地址与输入 Schema 不同也不共用。每组只取首个真实完整请求的有效实时报价，按同配置请求数量相乘后累加。`n=1` 时就是单张价格乘图片数量；`n>1` 时接口已报价该请求的候选数，只乘请求数量，不能再次乘 `n`。历史 `asset_quantity_v1` 收据按原分组规则校验，不迁移或改写历史请求。

Agent 对批量目标直接调用本入口，不先单独试算一张、不循环单项 prepare 来报价。先读取实时 Schema 构造合法请求，不能靠逐张试错探测参数。正常准备、上传和校验无需逐项播报；只在整批报价或需要用户处理的异常时集中反馈。

结果的 `pricing_groups` 给出 `points_per_request`、`request_count`、`image_count` 与组总价；`total_points` 是整批报价，`items` 保留各自完整批准绑定。只有 `approval_ready=true` 才能请求整批批准；单项失败、缺依赖、已提交项混入或准备期间来源变化时总价为 null，不能把成功部分冒充整批。处理失败项后重跑原批次会重新核价；明确缩小范围也须重新展示范围与总价。金额仍来自本次实时接口，不能用公开详情、历史单价或本地默认值。

批量准备的报价复用仅限本次调用，每组固定一次结果，不因上传、逐项保存或超过 60 秒重复询价；组报价失败也不对其余成员逐个重试。重跑批次或新会话重新核价，不使用跨调用价格缓存。提交阶段仍在每轮队列 step 内按组复核当前报价，复用最多 60 秒；金额、profileVersion 或 ruleDigest 变化时返回 `ONLINE_QUOTE_CHANGED`，受影响项须重新批准。逐项请求／来源、身份、Schema 与批准校验仍执行；恢复已受理任务不报价、不生成新幂等键。单项旧入口与历史批准继续兼容，单独提交仍单独复核。

私有 `asset-batches` 保存完整批次结果；每个操作的 `pricing` 收据明确记录代表请求、原始报价响应与分组规则，不伪装为每项都调用了报价 API。收据和完整提示词不进入快照、HTTP API 或看板。获批后图片及定制音色均使用标准队列，混合队列保守共享最多 5 个在途槽位；这不是对平台音色并发额度的承诺，平台限流仍按原操作恢复。

## 参考图、模型与原生路径

图片生成方式由用户而非能力探测决定。先盘点、匹配和审核用户已有图片；用户上传或接入已有图片时不询问生成方式、不调用图片生成，也不产生图片生成费用。只有仍缺少必需图片且用户明确要求生成时才询问路线。对于新的独立生图请求，用户没有说明方式时，Agent 主动让用户在“Agent 内置生图”和“ManturHub 平台生图”之间二选一，并分别说明前者使用当前 Agent 自带的图片生成能力，后者通过 ManturHub 图片生成服务制作、可能涉及平台额度和费用且以实际报价为准。用户明确说“继续本批”或“沿用刚才的方式”才沿用最近选择；用户明确选择另一种方式时确认本次切换后记录。普通用户无需看到算子名、内部路线值或选择命令。用户选择 Agent 内置生图而当前会话无法实际调用时，如实说明本次无法执行并等待重新选择，绝不自动改走平台，也不据此断言宿主或本机没有生图功能。平台生图仍必须完成实时报价和费用批准。该规则只约束图片生成，不改变音色优先级、用户素材匹配或绑定流程。

### Agent 内部执行（不得复述给普通用户）

普通生图流程不运行 `inspect-image-provider-options`，也不以模型、宿主名称或未传入的能力标记决定用户选项。用户的每次有效选择使用 `select-image-provider --user-selected` 记录；原生路线只有在 Agent 已能实际调用其内置生图能力时才加 `--confirm-native-imagegen`，真实改道同时加 `--confirm-provider-change`。`inspect-image-provider-options` 与 `--only-available` 仅用于历史项目兼容或技术排障，不得用于新的普通生图请求。选择 Agent 内置生图后，实际调用失败时不写入虚假的成功或改走平台；保留当前项目状态，等待用户明确改选。图片生成路线只影响新生成产物，不能阻止 `source=user_uploaded` 的已有本地图片进入匹配、审核和绑定。

图片始终提供 `reference-routing-v4` 清单。用 `validate-references <path> --local-only` 校验本地参考（不要求只供远端使用的 public_url）。目标必须唯一，selected 引用的路径、顺序、SHA 与角色用途一致；`base_asset_reference` 存在时，它不是 immutable `references` catalog 的一项，但必须作为操作描述文件 `references` 数组的第一项，其余项再按 selected 顺序去重。V02+ 角色第一项必须是已验收 V01，但不继承其画幅。Runtime 将 `mandatory_prompt_constraints` 从原始提示词构建进本次请求，并在其后追加当前结构化创作风格的私有后缀；操作保存风格 revision 与提示词摘要，恢复不重复追加。风格规则见 [视频创作风格合同](creative-style.md)。

不指定模型时保留平台合同默认分支，默认 n=1、size=auto；指定模型时不替换。数量、size、format 按实时完整 Schema 条件判断。图片输出逐张保存为候选；按画面是否符合目标、变体、参考用途及清晰度择优，不能按返回顺序默认取第一张通过验收。

用户素材优先。原生图片/视觉能力不需要平台对应算子；原生图片通过 `apply-asset-review` 本地路径接入，需要项目 native provider、参考清单、包含强制约束及当前私有风格后缀的 `generation_prompt`、风格 binding 和真实视觉审核。Runtime 将 binding 写入私有审核记录；旧项目未指定风格时保持兼容。原生理解证据同样绑定实际媒体 SHA，不需要调用平台理解。

项目后续切换为平台图片 provider 时，已接入的原生候选仍可继续审核：当前唯一选择、同项目不可变原审核的内容摘要、资产身份、媒体 SHA、需求修订、原参考清单与提示词必须一致，并重新通过参考、视觉与并发基线检查。仅兼容这类历史候选，不允许在平台 provider 下首次接入其他原生图片，不修改 provider 或伪装来源。

## 结果、音色与恢复

报价、提交、查询使用 [公共双域名路由](manturhub-preflight.md#openapi-双域名路由) 校验后的平台地址，并保存至私有操作记录；旧记录缺少地址时沿用原 BASE 路径，不切站重提。上传申请/确认仍使用 BASE；对象存储传输不携带平台 Key。

每个私有操作同时绑定 `credential_scheme` 与 `credential_sha256`。旧记录缺少 scheme 时按 `legacy-key-v1` 解释；使用原 `MANTURHUB_KEY` 可恢复。CLI 浏览器身份使用 `cli-identity-v1`，不与旧 Key 摘要推断等价；认证方式或身份摘要变化返回 `ONLINE_CREDENTIAL_CHANGED`，保留原批准、Job、请求与幂等键。

- 同步只识别已知 `code:0/data.output`，异步只识别绑定 apiCode/jobId 的封闭状态。未知结构阻断。HTTP 成功、Job 状态、输出可下载、分析、验收和就绪分开。
- 图片解析 `images[]`；理解仅依赖非空 summary，完整分析留在私有文件，绝不据 summary 自动写 passed。
- 音色解析 `voiceProfile` 与 `previewAudio`，身份/地址新旧别名矛盾时拒绝。已有合规试听音频直接进入质量分析和审核，不强制追加音频生成。只有 ID 无音频或只有预览无有效音色身份仍待处理。
- `voice-design` 返回的顶层 `previewUrl/result_url=null`，仅在已保存 Schema 声明它们为可选 string/uri 时，在本地校验副本中视为省略；完整原输出与 Schema 不变。必填空值、其他字段空值、错误类型、未知字段及有效链接冲突不放宽。通过 `previewAudio` 继续执行身份、下载与媒体校验；没有可用 URL 仍阻断下载。原 Job 远端成功但本地校验失败时，更新 Skill 后恢复原操作，不重新 prepare、报价或生成。下载成功后立即发布为可播放的 `pending/review_required`；续跑取得可靠、绑定当前 SHA 的质量分析时可按下文自动升级，否则由用户在看板试听后通过聊天确认。
- 音频使用 text_prompt/reference_audio_url/format 等声明字段。不接受 voice_id、voiceId 或 metadata 绕过固定音色合同；固定身份合成继续阻断。追加音频另建获批操作，不自动跟随设计任务。
- PNG/JPEG/WebP、MP3/WAV/M4A 先验证真实文件结构、MIME/扩展名、尺寸或时长，再原子保存。单文件首版上限 32 MiB；音频文件至少 1.8 秒。有效说话段、单人、无背景音乐／叠声／不可接受噪声或削波必须由可靠音频分析或用户实际试听确认，不能由文件名、时长或“未发现问题”推断。平台 SHA 存在则比对，否则记录本地 SHA 来源。
- 仅有 fileId 或同步结果 URL 失效：保存远端成功、下载未完成；缺取链合同则停止。已知 Job 可重查原任务更新下载地址；无 Job 不重新 invoke 来获取地址。
- 上传槽位申请收到明确 HTTP 非成功响应时保持 `not_started`，按错误修复或退避后使用同一操作 resume；请求已发出但无法确认是否创建槽位时立即写入 `application_unknown`，返回不可重试的 `UPLOAD_APPLICATION_UNKNOWN`，`polling.state=blocked`、`next_action=inspect_upload_application`，不得再次申请。四类素材与资产提取、分镜、视频共用该边界。
- 提交响应丢失：每次 resume 至多一次原键、完全相同请求恢复；不重新报价、改参数或更换键。明确失败/取消/超时终态不再生产。首份成功输出固定，续期响应另外归档。
- `.pipeline-state/runtime/asset-operations/<id>/` 保存输入、精确请求、批准、输出、候选、分析和阶段。真实远端身份、临时 URL、请求及费用仅留私有目录，不进入快照。

## 关联及审核写回

### 生成图片后的看板查看提醒

Agent 内置生图和 ManturHub 平台生图在完成检查、自动采用、快照刷新及回读后，必须主动提醒用户到看板查看并确认画面效果，并给出按只读服务合同取得的实际 Markdown 看板链接。可以说：“图片已生成并同步到看板，请到看板查看，确认画面效果是否符合预期；如需调整，直接在对话中告诉我具体图片和修改要求。无需回复‘确认’，我会继续已获授权的流程。”

这里的“确认”指用户自行查看主观效果，不是新的审核动作或生产门禁：不改回待确认、不写入用户确认记录、不新增页面按钮，也不因提醒暂停已经授权且满足门禁的工作。没有后续授权时只汇报当前结果，不承诺自动继续视频或付费生成。批量可合并本轮新增图片的提醒，已提醒的相同结果不因轮询或恢复重复发送。仅远端成功、候选下载完成或只在聊天中生成图片不算已同步；接入或刷新失败先说明真实状态并恢复本地发布，看板不可访问时如实说明，不编造链接或要求用户确认看不到的图片。

### 图片自动采用与提交前核对

按[视觉匹配](visual-matching.md)在用户允许采用的素材范围内形成唯一映射。Agent 必须查看真实像素、核对当前角色/变体、群像、道具或场景要求；生成图还要核对参考用途和风格约束。正常图片检查通过后自动采用，汇总已采用映射、备用图及异常，不请求整份图片清单确认。多张合格图择优采用一张，记录比较依据，不制造评分；用户可自行看图并在对话中提出修改。没有可靠视觉能力、身份矛盾或无法明确择优时，记录具体问题再询问，不编造检查结论。

每条审核文件提交前核对唯一资产、媒体种类和 SHA、`schema_version`、`asset_id`、`media_kind`、`review_status`、非空 `evidence`、`expected_previous_sha256`，以及当前需求有修订时的 `requirement_revision`。本地文件须同时填写项目相对 `local_file` 与真实 `source`；用户图片为 `user_uploaded`，内置生图为 `generated`，后者仍提供参考清单、生成正文和风格依据。自动通过的图片使用 `unique_match:true`、`review_origin:automatic_image_analysis` 和下述结构化 `image_quality_analysis`，不得包含 `user_confirmed`（即使 false 也不填）；生成图仍要求 `visual_validation:passed` 与 `reference_compliance:passed`。旧的真实人工确认审核继续兼容，不能借兼容字段绕过自动检查。

平台图片下载并通过媒体校验后保持内部 `awaiting_review`，候选暂不写入匹配/库存，也不发布正常图片的待确认快照。Agent 从 `asset-operation-status` 的私有 `candidates[].local_file` 读取图片，按返回顺序检查候选并准备审核；`selection_sha256` 是当前匹配行完整摘要，无旧选择时才为 null。`ok=false` 或 `selection_conflict` 时不得将 null 当作空基线。采用前保留原资产展示状态；自动采用成功才一次发布 `matched/passed`。`polling.state=complete` 只表示远端查询结束，仍必须执行 next_action 的本地检查与采用。

`image_quality_analysis` 使用数字版本 1、`method=agent_visual_inspection`、与外层一致的资产 ID/媒体 SHA、当前 `requirement_revision`（无修订时显式 null）、非空观察证据与选择理由。四项 checks 全部为 true 才通过；Runtime 只验证证据结构和绑定，不声称能自行理解像素。平台 `candidate_sha256` 须与原操作全部候选的 SHA 按顺序完全一致；本地图片只填写本次接入图片的 SHA，其他拟选图的比较依据写入 selection_reason。通过记录及文件均受当前选择基线保护，媒体或需求变化必须重新检查。

升级安装、查询状态和打开看板不改业务状态。用户继续素材处理时，可重新检查旧 pending 图片并追加自动审核；不改原操作描述、批准或历史审核。已驳回图片返回 `ASSET_IMAGE_PREVIOUSLY_REJECTED`，不能自动重新采用；既有 passed 图片的新自动采用必须有已批准且不同于旧选择的需求修订，否则返回 `ASSET_IMAGE_REPLACEMENT_REQUIRED`。相同审核的幂等重放继续可用。替换需求、下游影响或用户明确要求恢复驳回项仍走对应显式处理，不自动重做分镜或视频。

检查无法完成时，对媒体合规且身份明确的候选可用 pending 审核保存原因；明确不符合要求可保存 rejected。真正身份冲突不强行写入某个资产的匹配行，保留原候选和项目问题证据，在聊天集中报告；损坏图片不接入。异常不得填写自动通过证据。已记录的异常与正常自动采用分开汇报，必要时由用户解决。

现有入口每次只处理一条审核并刷新一次快照。可先集中准备和核对记录，再按当前选择基线逐条调用 `apply-asset-review`，检查每次返回的保存和 `snapshot_refresh` 结果；失败只处理受影响项，刷新失败只恢复本地快照，不重做已保存审核。不要把 `begin-snapshot-batch` 解释为该入口的批量写回或单次刷新。面向普通用户只汇报盘点结论、需要选择的冲突、审核结果和剩余缺口；命令、Schema 与逐项调试留在 Agent 内部，用户要求技术排障时再解释。

自动图片审核的结构示例（占位值必须替换为真实观察和摘要，不得直接复制为验收证据）：

```json
{
  "schema_version": 1,
  "asset_id": "CHAR-001-V01",
  "operation_id": "从动作返回的本地操作ID",
  "candidate_index": 0,
  "media_kind": "image",
  "media_sha256": "被检查候选的SHA256",
  "review_status": "passed",
  "unique_match": true,
  "review_origin": "automatic_image_analysis",
  "image_quality_analysis": {
    "schema_version": 1,
    "status": "passed",
    "method": "agent_visual_inspection",
    "asset_id": "CHAR-001-V01",
    "media_sha256": "被检查候选的SHA256",
    "requirement_revision": null,
    "candidate_sha256": ["本操作第1张候选的SHA256"],
    "checks": {"identity_matches": true, "requirements_met": true, "visual_quality_acceptable": true, "reference_compliant": true},
    "evidence": ["实际观察到的身份、服装、构图及参考用途依据"],
    "selection_reason": "为何采用这张图；多候选时写明比较理由"
  },
  "visual_validation": "passed",
  "reference_compliance": "passed",
  "evidence": ["实际身份、服装、用途及画幅的审核依据"],
  "expected_previous_sha256": "status返回的selection_sha256"
}
```

### 本地用户音频的审核与绑定

用户已提供音色时，不创建平台素材操作。先从当前制作角色的相关候选中检查项目内普通文件、真实音频结构、MIME、非空、时长至少 1.8 秒，并完成唯一基础角色映射。用户明确映射优先；canonical name／alias、文件名和目录只能构成辅助证据，不能替代唯一身份判断。普通视觉变体使用基础角色 ID，不逐变体重复绑定。识别到准备采用的音频后必须先调用 `apply-asset-review` 接入项目，再处理生图方式等其他问题；不得只把音频附件放在聊天中等待用户回复。

自动通过只用于当前宿主能可靠分析音频，且有效说话内容、单一说话人、无背景音乐、无多人叠声、噪声可接受、无削波六项全部通过的情况。审核记录不填 `operation_id`，不写 `user_confirmed`，并将结构化分析与当前媒体 SHA 绑定：

```json
{
  "schema_version": 1,
  "asset_id": "CHAR-001-V01",
  "local_file": "音频/角色名.mp3",
  "source": "user_uploaded",
  "media_kind": "audio",
  "media_sha256": "实际候选的64位小写SHA-256",
  "review_status": "passed",
  "unique_match": true,
  "candidate_count": 1,
  "listening_validation": "passed",
  "review_origin": "automatic_quality_analysis",
  "audio_quality_analysis": {
    "schema_version": 1,
    "status": "passed",
    "method": "agent_audio_analysis",
    "media_sha256": "与外层完全相同的SHA-256",
    "checks": {
      "speech_present": true,
      "single_speaker": true,
      "background_music_absent": true,
      "overlapping_speech_absent": true,
      "noise_acceptable": true,
      "clipping_absent": true
    },
    "evidence": ["实际音频分析方法和可复核观察"]
  },
  "evidence": ["角色声明、别名与可听内容共同支持唯一基础角色绑定"],
  "expected_previous_sha256": null
}
```

Runtime 会独立复核媒体可解码、MIME、时长、SHA、唯一映射、`candidate_count=1` 和六项布尔检查；平台操作还要求实际候选数组恰好只有一项。缺少分析、重复候选、分析方法不受支持、任一检查不是 `true`、分析 SHA 不等于媒体 SHA，或自动记录包含 `user_confirmed`，都会拒绝自动通过。仅文件名匹配、仅时长合格或只有笼统自然语言证据不能通过。

分析异常、不确定或当前宿主无法可靠分析时，仍用同一媒体和当前选择基线提交 `review_status=pending`；不写自动通过字段。Runtime 将合规音频复制到不可变内容寻址目录，发布 `review_required` 和 `local_audio`，看板显示“待试听 / 确认”并可播放。用户试听后通过聊天确认时，可用 `review_origin=user_confirmed`、`user_confirmed=true`、`listening_validation=passed` 和新的当前选择摘要升级。损坏、不可解码或时长不合规的文件在接入前失败，不能冒充待试听素材。

准备采用的用户音频仍应尽快按现有质量门禁接入，不等待图片盘点和检查全部完成。需要用户试听的候选集中说明角色和播放入口；图片已全部匹配而仍有必需音色 pending 时，只报告“图片匹配完成、音色待确认”，不得宣布整个素材阶段就绪或进入依赖音色的后续制作。

首次没有旧选择时基线为 `null`；已有选择必须先只读取得当前完整选择摘要。自动通过后回读库存及 `voices` 行，核对基础角色 `base_asset_id`、`status=matched`、`review_status=passed`、`local_audio` 和 `review_id`；自动通过只汇报结果，不列入用户必答问题。身份冲突保持 `unresolved`；质量问题或分析能力缺失保持 `pending/review_required`，不得静默跳到预制、定制或 AI 直出。

只审核当前角色准备采用的候选。无关、备用或未选中的 `voice_directories` 文件可以留在原目录；本合同不要求对目录中每个文件做全量入库或逐一拒绝，也不新增这种阶段门禁。

无旧记录时 `expected_previous_sha256:null`；已有记录使用最终完整 JSON 的 `sha256Json`（对象键排序）摘要，包括 `reference_base_asset_id`、`requirement_revision` 和所有实际保存字段，不是文件原字节摘要。首次发布、审核返回和私有 publication 使用同一摘要；status 先只读核对当前选择，再返回可使用的基线。后续更换必须重新读取当前受控匹配记录，不使用旧基线。已有下游时，可显式补齐从未验收的缺失/待审核素材，继续检查身份、媒体、证据与 expected_previous_sha256；生成结果仅留候选等待审核。替换已验收图片须走需求修订，已采用音色/直出策略的替换仍阻断。不自动修改 Clip、批准、历史 Run 或交付；补齐后重新编译使用新生成意图。重复相同审核仅在完整记录及媒体仍一致时复用，不能只凭 review_id 跳过并发检查。

### 旧摘要恢复与真实冲突

更新完整 Skill 包后，旧操作先执行 `asset-operation-status`。status 与本地 resume 返回共用只读校验：唯一选择、操作/不可变审核归属、候选媒体 SHA、基础角色和当前需求必须一致。只有精确符合旧写入器遗漏两个附加字段的摘要，才返回完整 `selection_sha256` 和 `selection_digest_corrected:true`；不遍历字段组合，不写回缓存或迁移项目，也不调用网络。无可验证归属的其他选择不能借此取得自动认可的审核基线。

Agent 使用核实后的摘要重新准备审核记录；校正不代表新的用户批准或验收，不需要重新生成图片。直接向审核入口提交旧错误摘要仍返回 `ASSET_SELECTION_CHANGED`。记录缺失/重复、其他审核替换、媒体/需求变化或非已知缺陷时，返回 `selection_sha256:null`、`selection_conflict` 及 `reread_current_selection_and_prepare_review`；不要把此 null 当成“没有旧记录”提交。先读取受控选择及变化原因，再按实际证据重新审核。远端任务状态保持不变，不能为修复本地摘要重新调用算子。

已有本地素材不填 operation_id，改填 local_file/source；source 为 user_uploaded、generated（原生图片）或 preset（音频）。预制必须提供 voice_id 且本地 SHA 与包内启用目录一致，继续遵守 match-voice 和角色占用。定制平台结果通过 operation_id 接入。用户音频、预制和定制音色的 passed 都需 `listening_validation=passed`，并且只能由 `user_confirmed` 或上述 `automatic_quality_analysis` 二者之一支持；文件时长不代替有效说话段检查。旧版不含 `review_origin` 的 `user_confirmed=true` 记录继续兼容。

`review_status` 为 pending/passed/rejected。未经检查的图片只在私有操作中保持 pending，正常图片通过明确关联、媒体复核和真实视觉证据后直接发布 matched/passed；音频仍可先发布待试听候选。理解分析本身不是验收。审核证据与媒体 SHA 绑定，素材变化旧证据失效；音色匹配记录增加私有/权威可选 base_asset_id，Compiler 优先按基础 ID 关联、兼容唯一旧角色名，快照不增加字段。质量分析只保留在私有审核记录，不进入 Manifest、Snapshot Envelope 或 HTTP API。

版本化库存/匹配报告写入 `.pipeline-state/results/asset-selections/`，一次原子切换两指针；候选/采用文件保留。批次保护及项目发布锁只覆盖本地发布，不跨网络等待。快照失败返回生产事实已保存和独立 snapshot_refresh 错误，resume/refresh 只恢复发布；看板继续使用 media_id，不把远端 URL/fileId 当 img src。

## 预检及已知缺口

`doctor --stage asset-production --asset-operation image|understanding|voice-design|audio` 检查所选平台路径；普通项目路由继续识别原生能力、已有/预制音色，不强制依赖音频算子。`asset_capabilities` 区分包内代码能力与实际 connection/contract/workflow_ready；现场合同读取失败仍阻断提交，不能手工在项目 JSON 开启。

2026-09-15 本轮 CLI describe 四项均返回 NOT_FOUND；已知 public detail 可读，但图片投影缺 `$defs/$ref`。没有将这个不完整投影替换已核验指纹。部署恢复完整合同后再安排获批线上验收；第 3 步及本轮真实上传/付费验收均未完成。
