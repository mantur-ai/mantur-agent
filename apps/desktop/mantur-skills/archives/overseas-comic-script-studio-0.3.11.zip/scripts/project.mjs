#!/usr/bin/env node
// Local project journal only. Authentication, transport, quotes and billing belong to the tool adapter.
import { createHash, randomUUID } from 'node:crypto';
import { closeSync, existsSync, fsyncSync, lstatSync, mkdirSync, openSync, readFileSync, realpathSync, renameSync, unlinkSync, writeFileSync } from 'node:fs';
import { basename, dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { publicStandardError, summarizeBilling, unconfirmedOutcome } from './receipts.mjs';
import { renderData, renderEpisode, renderNext, renderReview, plain } from './readable.mjs';
import { checkNewOutput, checkCharacterIdentities } from './contracts.mjs';
import { evidenceChecks } from './presentation.mjs';
import { inspectSource, checkSelection } from './source.mjs';
import { parseSourceFacts, verifySourceFacts, sourceFactsConfig, checkFactReview, upstreamTopics, checkUpstreamReview, blueprintConflictProof } from './source-facts.mjs';
import { issueContext, triageReport, decideIssue, revisionPlan, startContinuityCheck, continuityContext, continuityReport } from './issues.mjs';

const VERSION = 8;
const RUNTIME = Object.freeze({ runtimeVersion: '0.5.13' });
const REPORT_ONLY_ISSUES = new Set(['PROGRAM_REPORT_LANGUAGE', 'PROGRAM_REPORT_COMPLETENESS']);
// Local workflow scheduling ceiling, NOT a copy of server/model token admission policy.
// Leave extra headroom for server prompts, schemas, expanded recipes and output reservation.
const REVIEW_REQUEST_BYTES = 144 * 1024;
const PREFIX = 'op.script.';
const workflowContextUrl = new URL('./workflow-context.mjs', import.meta.url);
const workflowContext = existsSync(workflowContextUrl) ? await import(workflowContextUrl.href) : null;
const projectEnvironmentUrl = new URL('./project-environment.mjs', import.meta.url);
const projectEnvironment = existsSync(projectEnvironmentUrl) ? await import(projectEnvironmentUrl.href) : null;
if (existsSync(new URL('./access-profile.json', import.meta.url))
  && JSON.parse(readFileSync(new URL('./access-profile.json', import.meta.url))).environmentPolicy && !projectEnvironment)
  throw new Error('Incomplete environment package: missing project environment helper');
if (existsSync(new URL('./attribution-policy.json', import.meta.url)) && !workflowContext) throw new Error('Incomplete attribution package: missing workflow context helper');

export function workflowAttributionArgs(state, stepCode, enabled = false) {
  if (!enabled) return [];
  need(typeof stepCode === 'string' && stepCode.length <= 64 && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(stepCode), 'Invalid attribution step');
  state.skillRunId ||= randomUUID().replaceAll('-', '');
  need(/^[a-f0-9]{32}$/.test(state.skillRunId), 'Invalid attribution workflow');
  return ['--skill-run-id', state.skillRunId, '--step-code', stepCode];
}
function attributionEnabled() {
  const file = new URL('./access-profile.json', import.meta.url);
  return existsSync(file) && JSON.parse(readFileSync(file, 'utf8')).schemaVersion === 2;
}
const kinds = ['source-analyze', 'concept', 'assets', 'blueprint', 'episode', 'review'];
const activeStates = ['CREATED', 'QUEUED', 'RUNNING', 'PENDING', 'PROCESSING', 'IN_PROGRESS'];
const failedStates = ['FAILED', 'ERROR', 'CANCELED', 'CANCELLED', 'EXPIRED', 'TIMEOUT'];
const now = () => new Date().toISOString();
const json = value => JSON.stringify(value, null, 2) + '\n';
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const clone = value => structuredClone(value);
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const need = (condition, message) => { if (!condition) throw new Error(message); };
const text = value => typeof value === 'string' && value.trim().length > 0;
const id = value => typeof value === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(value);
const pick = (value, keys) => Object.fromEntries(keys.filter(key => value[key] !== undefined).map(key => [key, value[key]]));
const eq = (a, b) => hash(a) === hash(b);
const canonical = value => Array.isArray(value) ? value.map(canonical) : object(value) ? Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])])) : value;
const readJSON = file => { need(lstatSync(file).size <= 32 * 1024 * 1024, 'JSON file exceeds 32 MiB'); return JSON.parse(readFileSync(file, 'utf8')); };

// Read only CLI receipt markers. Raw stderr can contain quote tokens and is never persisted.
function recoveryMarkers(file) {
  if (file === undefined) return {};
  need(lstatSync(file).isFile() && lstatSync(file).size <= 2 * 1024 * 1024, 'CLI stderr must be a file of at most 2 MiB');
  const stderr = readFileSync(file, 'utf8');
  const ids = [...new Set([...stderr.matchAll(/^调用恢复 ID: ([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})\r?$/gmi)].map(m => m[1]))];
  const jobs = [...new Set([...stderr.matchAll(/^⏳ 异步任务 ([a-zA-Z0-9_-]{1,128}) 已提交，轮询结果中…\r?$/gm)].map(m => m[1]))];
  need(ids.length <= 1 && jobs.length <= 1, 'Mixed CLI receipts: use stderr from this single invocation');
  return { recoveryId: ids[0], jobId: jobs[0] };
}

// Never persist credentials or signed download/upload links in the project or generated documents.
function safeData(value) {
  if (Array.isArray(value)) { value.forEach(safeData); return; }
  if (object(value)) {
    for (const [key, child] of Object.entries(value)) {
      need(!/^(?:api_?key|access_?token|refresh_?token|authorization|password|secret|confirmation_?token|providerCode|modelCode|providerAccountOrTenant|__proto__|constructor|prototype)$/i.test(key), `Forbidden project field: ${key}`);
      safeData(child);
    }
  } else if (typeof value === 'string') {
    need(!/mtak_[A-Za-z0-9]{8,}|-----BEGIN .*PRIVATE KEY-----|Bearer\s+[A-Za-z0-9._-]{12,}|https?:\/\/\S*[?&](?:x-amz-|x-oss-|signature=|token=|access_token=)/i.test(value), 'Credential or signed URL must not be stored in the project');
  }
}

// Refuse linked project paths, including linked output folders. Never trust names from model output as paths.
function safePath(root, name = '') {
  const path = resolve(root, name);
  const rel = relative(root, path);
  need(!isAbsolute(rel) && rel !== '..' && !rel.startsWith('../'), 'Path escapes project');
  let current = root;
  need(!existsSync(current) || !lstatSync(current).isSymbolicLink(), 'Project must not be a symlink');
  for (const segment of rel.split(/[\\/]/).filter(Boolean)) {
    current = join(current, segment);
    need(!existsSync(current) || !lstatSync(current).isSymbolicLink(), 'Project resource must not be a symlink');
  }
  return path;
}

function atomic(root, name, content) {
  const file = safePath(root, name);
  mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
  const temp = `${file}.${randomUUID()}.tmp`;
  let fd;
  try {
    fd = openSync(temp, 'wx', 0o600);
    writeFileSync(fd, content);
    fsyncSync(fd);
    closeSync(fd); fd = undefined;
    renameSync(temp, file);
  } finally {
    if (fd !== undefined) closeSync(fd);
    if (existsSync(temp)) unlinkSync(temp);
  }
  return file;
}

function store(root, value) {
  safeData(value);
  const digest = hash(value);
  const file = `objects/${digest}.json`;
  if (!existsSync(safePath(root, file))) atomic(root, file, json(value));
  return { file, digest };
}
function load(root, ref) {
  need(ref && /^objects\/[a-f0-9]{64}\.json$/.test(ref.file), 'Invalid object reference');
  const value = readJSON(safePath(root, ref.file));
  need(hash(value) === ref.digest, 'Project object digest mismatch; do not edit recorded output');
  return value;
}
function save(root, state, event) {
  state.schemaVersion = VERSION;
  state.runtimeVersion = RUNTIME.runtimeVersion;
  state.revision++;
  state.updatedAt = now();
  state.events.push({ revision: state.revision, at: state.updatedAt, ...event });
  safeData(state);
  // state.json is the commit point. Orphaned objects after a crash are harmless; no network action occurs here.
  atomic(root, 'state.json', json(state));
}
function cleanQuality() { return { qualityAccepted: false, manual: null, acceptance: null }; }
function invalidateQuality(quality) {
  return { ...cleanQuality(), manual: quality?.manual ? { ...clone(quality.manual), checked: false, needsRecheck: true } : null };
}
function emptyView() {
  return { stage: 'INTAKE', awaiting: null, source: null, sourceManualRisks: [], sourceDecisions: [], concepts: null, selectedConceptId: null, assets: null, blueprint: null, episodes: {}, reviews: [], checkpointsPassed: [], quality: cleanQuality(), fix: null, afterFix: null, stop: null };
}
// Local scope is passed using the existing brief contract, never a made-up server field.
export function scopedBrief(config) {
  if (config.mode !== 'ADAPT') return config.brief;
  const scope = config.sourceScope;
  const coverage = scope ? `${scope.kind}: ${scope.label}\nLocation: ${scope.location}\nLimitations: ${scope.limitations.join('; ') || 'None declared by the user; completeness is not independently verified.'}`
    : 'Legacy project: original analysis scope was not recorded; whole-work coverage is unverified.';
  return `${config.brief}\n\n[Source scope / 源稿范围]\n${coverage}\nOnly the supplied material is analyzed. Do not invent missing source facts or claim whole-work verification. / 仅分析已提供材料，不补写缺失原作事实，不宣称全剧核验。`;
}
function checkAdaptationGoal(c) {
  need(['PRESERVE_CORE', 'REIMAGINE_STRUCTURE', 'LOCALIZE_OVERSEAS'].includes(c.source?.adaptationGoal),
    'source.adaptationGoal must be PRESERVE_CORE | REIMAGINE_STRUCTURE | LOCALIZE_OVERSEAS; explain and confirm the intended goal before a new call');
}
function checkConfig(c, { allowLegacyGoal = false } = {}) {
  need(object(c), 'Config must be an object'); safeData(c);
  const allowed = ['name', 'mode', 'brief', 'targetMarket', 'outputLanguage', 'languagePlan', 'deliveryWordsMin', 'deliveryWordsMax', 'carrier', 'episodeCount', 'targetWordsMin', 'targetWordsMax', 'recipeBindings', 'operatorRecipeBindings', 'source', 'sourceScope', 'concept', 'assets', 'episode'];
  need(Object.keys(c).every(key => allowed.includes(key)), 'Unknown config field');
  need(['CREATE', 'ADAPT'].includes(c.mode), 'mode must be CREATE or ADAPT');
  for (const key of ['name', 'brief', 'targetMarket', 'carrier']) need(text(c[key]), `Missing ${key}`);
  if (c.languagePlan !== undefined) {
    need(object(c.languagePlan) && Object.keys(c.languagePlan).length === 2 &&
      ['zh', 'en'].includes(c.languagePlan.workingLanguage) && ['zh', 'en'].includes(c.languagePlan.targetLanguage),
    'languagePlan requires explicit workingLanguage and targetLanguage, zh/en only');
    need(c.outputLanguage === undefined, 'Use languagePlan or legacy outputLanguage, never both');
    need(Number.isInteger(c.deliveryWordsMin) && Number.isInteger(c.deliveryWordsMax) && c.deliveryWordsMin >= 100 && c.deliveryWordsMax <= 5000 && c.deliveryWordsMin <= c.deliveryWordsMax, 'Specify deliveryWordsMin/Max within 100..5000');
    if (c.languagePlan.workingLanguage === c.languagePlan.targetLanguage) need(c.deliveryWordsMin === c.targetWordsMin && c.deliveryWordsMax === c.targetWordsMax, 'Same-language copy requires the same word budget; a rewrite is not automatic localization');
  } else {
    need(text(c.outputLanguage), 'Missing outputLanguage (legacy) or languagePlan');
    need(c.deliveryWordsMin === undefined && c.deliveryWordsMax === undefined, 'Delivery budget requires languagePlan');
  }
  need(c.brief.length <= 12000, 'brief exceeds 12000 characters');
  need(['VERTICAL_COMIC', 'MOTION_COMIC', 'SHORT_DRAMA'].includes(c.carrier), 'Invalid carrier');
  need(Number.isInteger(c.episodeCount) && c.episodeCount >= 1 && c.episodeCount <= 60, 'episodeCount must be 1..60');
  need(Number.isInteger(c.targetWordsMin) && Number.isInteger(c.targetWordsMax) && c.targetWordsMin >= 100 && c.targetWordsMax <= 5000 && c.targetWordsMin <= c.targetWordsMax, 'Specify targetWordsMin/Max within 100..5000');
  need(Array.isArray(c.recipeBindings), 'Specify recipeBindings explicitly (may be empty)');
  need(c.operatorRecipeBindings === undefined || object(c.operatorRecipeBindings), 'operatorRecipeBindings must be an object');
  need(Object.keys(c.operatorRecipeBindings || {}).every(code => kinds.some(kind => code === PREFIX + kind)), 'Unknown operator recipe target');
  const bindingsByCode = new Map();
  for (const kind of kinds) {
    const extra = c.operatorRecipeBindings?.[PREFIX + kind] || [];
    need(Array.isArray(extra), 'Operator recipes must be an array');
    const codes = new Set();
    for (const binding of [...c.recipeBindings, ...extra]) {
      need(object(binding) && text(binding.code) && /^[a-f0-9]{64}$/.test(binding.contentDigest) && !codes.has(binding.code), 'Invalid or duplicate recipe binding');
      need(Object.keys(binding).every(key => ['code', 'contentDigest', 'parameters'].includes(key)), 'Unexpected recipe field');
      codes.add(binding.code);
      // A recipe may legitimately target several operators, but its identity and parameters
      // must remain locked across the project. Per-request duplicate codes are still rejected.
      const previous = bindingsByCode.get(binding.code);
      need(!previous || eq(canonical(previous), canonical(binding)), 'Conflicting recipe binding across operators');
      bindingsByCode.set(binding.code, binding);
    }
  }
  for (const [field, keys] of Object.entries({ source: ['sourceLanguage', 'adaptationGoal', 'protectedElements', 'allowedChanges'], concept: ['genre', 'audience'], assets: ['namingConstraints'], episode: ['contentConstraints'] })) {
    if (c[field] !== undefined) need(object(c[field]) && Object.keys(c[field]).every(key => keys.includes(key)), `Invalid ${field} options`);
  }
  if (c.mode === 'ADAPT') need(text(c.source?.adaptationGoal), 'ADAPT requires source.adaptationGoal');
  if (c.mode === 'ADAPT' && !allowLegacyGoal) checkAdaptationGoal(c);
  if (c.sourceScope !== undefined) {
    const s = c.sourceScope;
    need(c.mode === 'ADAPT' && object(s) && Object.keys(s).length === 4 && ['FULL', 'EXCERPT'].includes(s.kind), 'sourceScope requires kind FULL/EXCERPT, label, location and limitations for ADAPT');
    need(text(s.label) && s.label.length <= 200 && text(s.location) && s.location.length <= 500, 'sourceScope needs a label and original chapter/line location');
    need(Array.isArray(s.limitations) && s.limitations.length <= 10 && s.limitations.every(v => text(v) && v.length <= 500)
      && (s.kind !== 'EXCERPT' || s.limitations.length > 0), 'EXCERPT requires explicit missing-context limitations');
  }
  for (const [items, limit] of [[c.assets?.namingConstraints, 300], [c.episode?.contentConstraints, 500], [c.source?.protectedElements, 500], [c.source?.allowedChanges, 500]]) {
    if (items !== undefined) need(Array.isArray(items) && items.length <= 100 && items.every(v => text(v) && v.length <= limit), 'Invalid naming/content/adaptation constraints');
  }
  need(!parseSourceFacts(c.episode?.contentConstraints).length || c.mode === 'ADAPT', 'Source facts are only for ADAPT');
}

function frozenSource(root, state) {
  const ref = state.view.source;
  const call = Object.values(state.calls).find(c => c.operator === PREFIX + 'source-analyze' && c.status === 'SUCCEEDED' && c.result?.digest === ref?.digest);
  const info = call?.sourceInspection;
  need(info?.status === 'READY' && /^source-files\/[a-f0-9]{64}\.(txt|md|json)$/.test(info.file || ''), 'Current source has no verified frozen text; do not claim original-text evidence from an analysis summary or a remote fileId');
  const inspected = inspectSource(safePath(root, info.file));
  need(inspected.report.sha256 === info.sha256, 'Frozen source digest changed');
  return inspected;
}

function verifyProjectFacts(root, state, config = state.config) {
  const facts = parseSourceFacts(config.episode?.contentConstraints);
  if (facts.length) verifySourceFacts(facts, frozenSource(root, state), config.episodeCount);
  return facts;
}

function reviewedSource(root, view, manual = view.sourceManualRisks || []) {
  const analysis = clone(output(root, view.source));
  need(Array.isArray(manual) && manual.length <= 100, 'source-risks must be an array of at most 100 items');
  const ids = new Set(analysis.risks.map(risk => risk.id));
  for (const risk of manual) {
    need(object(risk) && Object.keys(risk).length === 4 && /^MANUAL_SOURCE_[a-zA-Z0-9_-]{1,100}$/.test(risk.id), 'Manual source risk requires a MANUAL_SOURCE_ id, description, evidence and question');
    for (const field of ['description', 'evidence', 'question']) need(text(risk[field]) && risk[field].length <= 2000, `Manual source risk ${field} must contain 1..2000 characters`);
    need(!ids.has(risk.id), 'Duplicate or conflicting manual source risk id'); ids.add(risk.id);
    analysis.risks.push({ ...clone(risk), requiresConfirmation: true, origin: 'CALLER_REVIEW' });
  }
  safeData(manual);
  return analysis;
}

function checkSourceDecisions(analysis, decisions) {
  need(Array.isArray(decisions) && decisions.length <= 100, 'sourceDecisions must be an array of at most 100 decisions');
  const risks = analysis.risks, ids = new Set();
  need(Array.isArray(risks), 'Missing source risks');
  for (const item of decisions) {
    need(object(item) && Object.keys(item).length === 2 && text(item.riskId) && item.riskId.length <= 120 && text(item.decision) && item.decision.length <= 2000, 'Each source decision needs riskId and decision');
    need(!ids.has(item.riskId) && risks.some(risk => risk.id === item.riskId), 'Unknown or duplicate source riskId');
    ids.add(item.riskId);
  }
  for (const risk of risks) if (risk.requiresConfirmation === true) {
    need(text(risk.id) && ids.has(risk.id), `Source risk ${risk.id || '(missing id)'} needs an explicit user decision; use --source-decisions at source confirmation`);
  }
  safeData(decisions);
}

function output(root, ref) { return load(root, ref).output; }
function sourceDecisionConflicts(blueprint) {
  const checks = blueprint.readthroughReport?.sourceDecisionChecks;
  if (checks === undefined) return []; // Old results still need manual review; absence is not verification.
  need(Array.isArray(checks), 'Invalid blueprint sourceDecisionChecks');
  need(checks.every(check => object(check) && text(check.riskId) && text(check.decision) && text(check.explanation)
    && ['APPLIED', 'CONFLICT'].includes(check.status) && Array.isArray(check.beatIds)), 'Invalid blueprint sourceDecisionChecks entry');
  return checks.filter(check => check?.status === 'CONFLICT');
}

function upstreamContext(root, state, callId) {
  const v = state.view;
  need(state.config.mode === 'ADAPT' && v.source, 'Use the current ADAPT project with source analysis');
  const call = state.calls[callId], stage = call?.operator?.slice(PREFIX.length);
  need(['assets', 'blueprint'].includes(stage) && call.status === 'SUCCEEDED'
    && call.result?.digest === v[stage]?.digest, 'Use the current successful assets or blueprint call, not historical output');
  const input = load(root, call.input), result = output(root, call.result), facts = verifyProjectFacts(root, state);
  const decisions = v.sourceDecisions || [];
  need(eq(facts, parseSourceFacts(input.requirements?.contentConstraints)), 'Current upstream input must contain the same source facts');
  need(eq(decisions, input.requirements?.sourceDecisions || []), 'Current upstream input must retain the approved source decisions');
  const authority = { requirements: input.requirements || {}, sourceAnalysis: output(root, v.source), facts, sourceDecisions: decisions,
    selectedConcept: input.selectedConcept, ...(stage === 'blueprint' ? { assets: input.assets } : {}) };
  const binding = { projectId: state.projectId, callId: call.id, configDigest: state.configDigest,
    inputDigest: call.input.digest, outputDigest: hash(result), authorityDigest: hash(authority) };
  return { binding, stage, authority, output: result, facts, decisions };
}
function conflictScope(state) {
  return hash({ projectId: state.projectId, configDigest: state.configDigest,
    ...pick(state.view, ['source', 'sourceManualRisks', 'sourceDecisions', 'concepts', 'selectedConceptId', 'assets', 'blueprint']) });
}
function blueprintConflictState(root, state) {
  if (!state.view.blueprint) return { unresolved: [], resolutions: [] };
  const conflicts = sourceDecisionConflicts(output(root, state.view.blueprint)), scopeDigest = conflictScope(state);
  const resolutions = (state.view.blueprintConflictResolutions || []).map(ref => {
    const record = load(root, ref);
    const current = record.scopeDigest === scopeDigest && conflicts.some(c => c.riskId === record.riskId && eq(c, record.proof.serverCheck));
    return { ref, riskId: record.riskId, current, note: record.note, reason: record.proof.reason, snapshotId: record.snapshotId };
  });
  return { unresolved: conflicts.filter(c => !resolutions.some(r => r.current && r.riskId === c.riskId)), resolutions };
}
function validateConceptArcs(concepts, episodeCount) {
  need(Array.isArray(concepts) && concepts.length > 0, 'Missing concepts');
  concepts.forEach((concept, index) => {
    const path = `concepts[${index}].episodeArc`, arc = concept?.episodeArc;
    need(Array.isArray(arc) && arc.length > 0, `${path} must be a non-empty array`);
    need(arc.length === episodeCount, `${path} must cover 1..episodeCount=${episodeCount}`);
    const episodes = new Set();
    arc.forEach((beat, itemIndex) => {
      const itemPath = `${path}[${itemIndex}]`;
      need(object(beat), `${itemPath} must be an object`);
      const n = Object.hasOwn(beat, 'episode') ? beat.episode : beat.episodeNumber;
      need(Number.isInteger(n) && n >= 1 && n <= episodeCount && !episodes.has(n), `${itemPath}.episode must be a unique integer in 1..${episodeCount}`);
      if (Object.hasOwn(beat, 'episode') && Object.hasOwn(beat, 'episodeNumber')) {
        need(Number.isInteger(beat.episodeNumber) && beat.episodeNumber === n, `${itemPath}.episodeNumber conflicts with episode`);
      }
      episodes.add(n);
      for (const field of ['protagonistAction', 'visibleConsequence', 'emotionalTurn']) {
        need(text(beat[field]), `${itemPath}.${field} must be a non-empty string`);
        need(!/^(?:episode\s*\d+|ep[. ]*\d+|第\s*[0-9一二三四五六七八九十]+\s*集|TBD|TODO|N\/A|emotionalTurn|protagonistAction|visibleConsequence)$/i.test(beat[field].trim()), `${itemPath}.${field} must contain narrative content, not a placeholder`);
      }
    });
  });
}
function selected(root, state, checkNames = true) {
  const concept = output(root, state.view.concepts).concepts.find(item => item.id === state.view.selectedConceptId);
  need(concept, 'Selected concept no longer exists');
  if (checkNames) validateConceptNames(root, state, concept);
  return concept;
}
function validateConceptNames(root, state, concept) {
  if (state.config.mode !== 'ADAPT') return;
  const names = output(root, state.view.source).bannedSourceNames || [];
  const prose = ['title', 'logline', 'synopsis', 'coreHook', 'episodeArc'].map(k => concept[k]);
  const strings = value => typeof value === 'string' ? [value] : value && typeof value === 'object' ? Object.values(value).flatMap(strings) : [];
  for (const name of names) {
    if (!text(name)) continue;
    const escaped = name.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const pattern = new RegExp(/\p{Script=Han}/u.test(name) ? escaped : `(?<![\\p{L}\\p{N}_])${escaped}(?![\\p{L}\\p{N}_])`, 'iu');
    need(!strings(prose).some(value => pattern.test(value)), 'Selected concept contains a banned source name; inspect another candidate or request an authorized revision, never silently rename');
  }
}
function episodeNumbers(state) { return Object.keys(state.view.episodes).map(Number).sort((a, b) => a - b); }
function delivery(state) { return Boolean(state.config.languagePlan && state.view.workingDraft); }
function language(state) { return state.config.languagePlan?.[delivery(state) ? 'targetLanguage' : 'workingLanguage'] || state.config.outputLanguage; }
function wordBudget(state) {
  return delivery(state) ? { targetWordsMin: state.config.deliveryWordsMin, targetWordsMax: state.config.deliveryWordsMax }
    : pick(state.config, ['targetWordsMin', 'targetWordsMax']);
}
function reviewPlan(state, root, numbers = episodeNumbers(state)) {
  const result = [];
  if (!numbers.length) return { batches: result, blocked: null };
  const envelope = assembleInput(root, state, { operator: PREFIX + 'review', action: 'SCAN', numbers: [] }, {});
  const baseBytes = Buffer.byteLength(JSON.stringify(envelope));
  const paired = Array.isArray(envelope.sourceEpisodes);
  const costs = new Map(numbers.map(n => [n, Buffer.byteLength(JSON.stringify(output(root, state.view.episodes[n])))
    + (paired ? Buffer.byteLength(JSON.stringify(output(root, state.view.workingDraft.episodes[n]))) : 0)]));
  for (let i = 0; i < numbers.length;) {
    let end = i, bytes = baseBytes;
    while (end < numbers.length && end - i < 20) {
      const nextBytes = bytes + costs.get(numbers[end]) + (end > i ? (paired ? 2 : 1) : 0);
      if (nextBytes > REVIEW_REQUEST_BYTES) break;
      bytes = nextBytes; end++;
    }
    if (end === i || (end === i + 1 && numbers.length > 1)) {
      return { batches: [], blocked: 'REVIEW_CAPACITY: one episode or its adjacent boundary plus shared context exceeds the local scheduling budget. Do not truncate, hide an unchecked boundary, or retry a paid call; wait for server long-document support or discuss a smaller delivery scope.' };
    }
    result.push(numbers.slice(i, end));
    if (end === numbers.length) break;
    i = end - 1;
  }
  return { batches: result, blocked: null };
}
function batches(state, root) { return reviewPlan(state, root).batches; }
function signature(state, numbers) { return hash(numbers.map(n => [n, state.view.episodes[n]?.digest])); }
function reviewSignature(state, numbers) {
  // Any earlier manuscript may establish a fact used here; never reuse a downstream PASS after FIX.
  return hash({ version: 2, batch: signature(state, numbers), preceding: signature(state, episodeNumbers(state).filter(n => n < numbers[0])) });
}
function currentReviews(state, root) {
  return batches(state, root).map(numbers => state.view.reviews.findLast(r => currentReview(state, r, numbers))).filter(Boolean);
}
function validReviews(state) {
  const latest = new Map();
  for (const r of state.view.reviews) if (currentReview(state, r, r.numbers)) latest.set(hash(r.numbers), r);
  return [...latest.values()];
}
function reviewCoverage(state, root) {
  const plan = reviewPlan(state, root), numbers = episodeNumbers(state);
  const complete = numbers.length > 0 && !plan.blocked && currentReviews(state, root).length === plan.batches.length;
  return { status: complete ? 'SCANNED' : state.view.reviewSkipped?.signature === signature(state, numbers) ? 'SKIPPED'
    : validReviews(state).length ? 'PARTIAL' : 'NOT_REVIEWED', complete,
  availableEpisodes: numbers, reviewedBatches: validReviews(state).map(r => r.numbers), capacityWarning: plan.blocked };
}
function reviewChoice(state, root, reason) {
  return { kind: 'review-choice', optional: true, draftKind: delivery(state) ? 'DELIVERY' : 'WORKING',
    localCheck: writingGate(root, state),
    options: ['review', 'skip-review'], reviewCoverage: reviewCoverage(state, root), reason,
    instruction: 'Optional paid review. Show scope, batch count and live prices first. No explicit approval means no SCAN/FIX; skip or export without claiming review or quality acceptance.' };
}
function skipReview(state, note, { preserveQuality = false } = {}) {
  const v = state.view;
  if (v.afterFix || v.fix) {
    const round = state.rounds.find(r => r.snapshotId === (v.afterFix || v.fix).snapshotId);
    if (round) round.followupWithdrawn = { note, at: now() };
  }
  v.reviewRequest = null; v.fix = null; v.afterFix = null;
  v.reviewSkipped = { signature: signature(state, episodeNumbers(state)), note, at: now() };
  if (!preserveQuality) v.quality = invalidateQuality(v.quality);
  v.deliveryReceipt = null;
}
function repairPlan(root, state, reviewId, ids) {
  const review = validReviews(state).find(r => r.callId === reviewId); need(review, '--review must identify a current SCAN call');
  const issueIds = ids?.split(',');
  need(issueIds?.length && new Set(issueIds).size === issueIds.length && issueIds.every(issueId => output(root, review.ref).issues.some(i => i.id === issueId)), 'Confirm existing issue IDs only');
  const confirmedIssues = output(root, review.ref).issues.filter(issue => issueIds.includes(issue.id));
  need(!issueIds.some(id => REPORT_ONLY_ISSUES.has(id)), 'Report-only issues cannot authorize manuscript FIX; verify the report manually or separately authorize SCAN');
  const affected = new Set(confirmedIssues.flatMap(issue => issue.episodeNumber == null ? review.numbers : [issue.episodeNumber]));
  need([...affected].every(n => Number.isInteger(n) && n > 0 && review.numbers.includes(n)), 'Confirmed issue is outside its original review batch');
  need(affected.size <= 2, 'Confirm a small FIX affecting at most two episodes; batch-level issues cover the whole batch. Keep original issue IDs/scope and do not split the review evidence or auto-create extra paid calls.');
  const plan = reviewPlan(state, root); need(!plan.blocked, plan.blocked);
  const rescanBatches = [review.numbers, ...plan.batches.filter(ns => ns.at(-1) >= Math.min(...affected) && !eq(ns, review.numbers))];
  return { review, issueIds, rescanBatches, maxScanCalls: rescanBatches.length };
}
function executionPlan(state, root) {
  const c = state.config, crossLanguage = c.languagePlan && c.languagePlan.workingLanguage !== c.languagePlan.targetLanguage;
  const steps = [
    { operator: PREFIX + 'source-analyze', count: c.mode === 'ADAPT' ? 1 : 0 },
    { operator: PREFIX + 'concept', count: 1 }, { operator: PREFIX + 'assets', count: 1 }, { operator: PREFIX + 'blueprint', count: 1 },
    { operator: PREFIX + 'episode', action: 'WRITE', count: c.episodeCount },
    { operator: PREFIX + 'review', action: 'SCAN', draftKind: 'WORKING', optional: true, defaultCount: 0 },
    { action: 'confirm-working', operator: null, count: c.languagePlan ? 1 : 0 },
    { operator: PREFIX + 'episode', action: 'LOCALIZE', count: crossLanguage ? c.episodeCount : 0 },
    { operator: PREFIX + 'review', action: 'SCAN', draftKind: 'DELIVERY', optional: true, defaultCount: 0, reuseSameLanguage: !crossLanguage },
    { action: 'export/deliver', operator: null, qualityAcceptance: 'Separate explicit decision, never inferred from continue' },
  ];
  return { languagePlan: c.languagePlan ? clone(c.languagePlan) : null,
    localization: { operator: PREFIX + 'episode', generationMode: 'LOCALIZE',
      additionalCalls: crossLanguage ? c.episodeCount : 0, additionalCostCredits: crossLanguage ? null : 0,
      quoteStatus: crossLanguage ? 'AWAITING_LIVE_QUOTES' : 'NOT_REQUIRED',
      pricing: crossLanguage ? '每集一次独立本地化调用，额外费用为各集实时报价之和；输入未生成时不能提供精确总价，也不能默认与WRITE同价。语言选择不等于费用授权。'
        : c.languagePlan ? '两项语言相同，本地复用正文并独立导出；不调用LOCALIZE，额外转换费用为0。' : '旧项目保持单稿，不自动增加成品或本地化调用。' },
    scope: '完整配置项目的基础计划，不是剩余待扣次数；仅执行用户本次授权范围，不包含可选审校、改稿或重试。',
    steps, baseOperatorCalls: 3 + (c.mode === 'ADAPT' ? 1 : 0) + c.episodeCount * (crossLanguage ? 2 : 1),
    review: { optional: true, ...reviewPlan(state, root), coverage: reviewCoverage(state, root) },
    pricing: 'No fixed prices in this plan. Obtain live CLI quotes only for approved operations; later inputs are not yet available. Disclose FIX and estimated affected rescan costs together, but allow FIX-only. Rescans need their own explicit approval or an explicitly approved combined scope/budget; re-quote revised input and stop if the approved budget or scope is exceeded.' };
}
function currentReview(state, review, numbers) {
  return (review.reviewEpoch || 0) === (state.view.reviewEpoch || 0)
    && eq(review.numbers, numbers) && review.signature === reviewSignature(state, numbers);
}

export function next(state, root) {
  const step = nextStep(state, root), issues = localIssues(root, state);
  const uncertain = step.kind === 'operator' && Object.values(state.calls)
    .find(call => unconfirmedOutcome(call) && !call.unconfirmedRetryAuthorization);
  if (uncertain) return { ...pendingNext(uncertain), kind: 'blocked', reason: 'Original outcome remains unconfirmed' };
  const countAdvisories = wordCountAdvisories(root, state);
  if (!issues.signals.length && !issues.issues.length && !countAdvisories.length) return step;
  return { ...step, qualityAdvisories: {
    signalCount: issues.signals.length, untriagedSignalIds: issues.untriaged, countAdvisories,
    uncertainIssueIds: issues.issues.filter(i => i.severity === 'UNCERTAIN' && !['dismiss', 'resolved'].includes(i.decision?.action)).map(i => i.id),
    recheckIssueIds: issues.recheckIssueIds, unresolvedIssueIds: issues.blockers.map(i => i.id),
    instruction: 'Warnings and unverified quality suggestions remain visible and do not require per-episode decisions. Continue authorized generation; use issues for optional evidence-based assessment. Explicit pauses and confirmed core contradictions still hold. This is not quality acceptance or authorization for review/FIX.' } };
}

function nextStep(state, root) {
  const v = state.view;
  if (state.pending) return pendingNext(state.calls[state.pending]);
  if (v.stop) return { kind: 'blocked', reason: v.stop };
  if (v.repairDecision) return { kind: 'repair-decision', ...v.repairDecision, options: ['keep-revision', 'rollback-revision'], instruction: 'Compare original and revised text plus both scans. Newly reported issues are not proof of regression. Explicitly keep or roll back; neither choice accepts quality or authorizes another paid FIX.' };
  if (v.awaiting && v.awaiting.type !== 'mid-review') return { kind: 'pause', ...v.awaiting, ...(v.awaiting.type === 'blueprint' ? {
    conflicts: blueprintConflictState(root, state).unresolved, falsePositiveResolutions: blueprintConflictState(root, state).resolutions,
  } : {}), ...(v.awaiting.type === 'source' ? {
    namingBoundary: { bannedSourceNames: clone(output(root, v.source).bannedSourceNames || []),
      namingConstraints: clone(state.config.assets?.namingConstraints || []),
      instruction: 'Compare the actual user naming choice against banned names before confirmation. A note, source decision or same-language draft cannot override a hard name ban. If they conflict, stop before paid downstream generation; do not rebuild projects or promise to rename everything at delivery.' },
  } : {}) };
  if (state.config.mode === 'ADAPT' && !v.source) return { kind: 'operator', operator: PREFIX + 'source-analyze' };
  if (!v.concepts) return { kind: 'operator', operator: PREFIX + 'concept' };
  if (!v.assets) return { kind: 'operator', operator: PREFIX + 'assets' };
  if (!v.blueprint) return { kind: 'operator', operator: PREFIX + 'blueprint' };
  const count = episodeNumbers(state).length;
  const repair = v.fix || v.afterFix;
  if (repair && !repair.approval) return reviewChoice(state, root, 'Legacy repair has no combined FIX/rescan approval; retain existing results, reconfirm follow-up review or skip.');
  if (v.fix) return { kind: 'operator', operator: PREFIX + 'review', action: 'FIX', numbers: v.fix.numbers, repairApproval: v.fix.approval };
  if (v.afterFix && v.afterFix.approval.followupReview !== 'confirmed') return reviewChoice(state, root, 'FIX completed, but follow-up review is not authorized. Show the revised draft and ask once; no approval means no paid rescan.');
  if (v.afterFix) {
    const step = { kind: 'operator', operator: PREFIX + 'review', action: 'SCAN', numbers: v.afterFix.numbers, repairApproval: v.afterFix.approval };
    if (Buffer.byteLength(JSON.stringify(assembleInput(root, state, step, {}))) > REVIEW_REQUEST_BYTES) {
      return reviewChoice(state, root, 'REVIEW_CAPACITY: the revised original batch exceeds the scheduling budget. Retain the revision and skip review, or discuss a new review scope; do not silently split or submit another paid call.');
    }
    return step;
  }
  if (v.reviewRequest) {
    const plan = reviewPlan(state, root, v.reviewRequest.numbers);
    if (plan.blocked) return reviewChoice(state, root, plan.blocked);
    for (const numbers of plan.batches) {
      if (!v.reviews.some(r => currentReview(state, r, numbers))) {
        if (v.reviewRequest.approval && !v.reviewRequest.approval.rescanBatches.some(ns => eq(ns, numbers))) return reviewChoice(state, root, 'Review batches changed after FIX; obtain a new scope/price approval or skip.');
        return { kind: 'operator', operator: PREFIX + 'review', action: 'SCAN', numbers, ...(v.reviewRequest.approval ? { repairApproval: v.reviewRequest.approval } : {}) };
      }
    }
    if (count < state.config.episodeCount) return { kind: 'quality', partial: true, options: ['continue-writing', 'fix', 'export'], instruction: 'Requested interim review is complete. Show findings; do not automatically FIX. Continue writing only within the original scope.' };
  }
  if (count < state.config.episodeCount) return writingGate(root, state) || { kind: 'operator', operator: PREFIX + 'episode', episodeNumber: count + 1 };
  const localCheck = writingGate(root, state);
  if (v.quality.qualityAccepted) return { kind: 'done', qualityAccepted: true, localCheck, reviewCoverage: reviewCoverage(state, root) };
  if (v.deliveryReceipt?.signature === signature(state, episodeNumbers(state))) return { kind: 'done', qualityAccepted: false, delivered: true, localCheck, reviewCoverage: reviewCoverage(state, root) };
  if (!reviewCoverage(state, root).complete && v.reviewSkipped?.signature !== signature(state, episodeNumbers(state))) return reviewChoice(state, root);
  return { kind: 'quality', qualityAccepted: false, localCheck, draftKind: delivery(state) ? 'DELIVERY' : 'WORKING',
    instruction: 'Review is optional. Show existing findings and unchecked scope. Confirm working manuscript for delivery, or deliver without quality acceptance. Final acceptance needs an explicit decision; continue is not acceptance.' };
}

function localIssues(root, state) { return issueContext(state, ref => output(root, ref)); }
function localContinuity(root, state) { return continuityContext(state, ref => output(root, ref)); }
function invalidateLocalQuality(view) {
  view.quality = invalidateQuality(view.quality);
  if (view.stage === 'QUALITY_ACCEPTED') view.stage = view.deliveryReceipt ? 'DELIVERED_UNACCEPTED' : 'EPISODES_WRITTEN';
}
function writingGate(root, state) {
  const check = localContinuity(root, state);
  if (check && !check.complete) return { kind: 'continuity-check', numbers: check.numbers,
    instruction: 'Read revised and preserved downstream bodies/snapshots locally through check-continuity. No paid SCAN or rewrite is implied; export remains available.' };
  const issues = localIssues(root, state);
  const holds = issues.blockers.filter(i => i.decision?.action === 'pause'
    || i.severity === 'CORE' || i.requiresDecision === true);
  if (holds.length) return { kind: 'issue-decision', issueIds: holds.map(i => i.id),
    instruction: 'An explicit pause or an evidence-confirmed core/edited-continuity concern needs a decision. Model warnings and unverified suggestions alone do not stop authorized writing. Continue-known is not a correction, paid approval or quality acceptance.' };
  return null;
}

function buildInput(root, state, step, extra) {
  const c = state.config, v = state.view, kind = step.operator.slice(PREFIX.length);
  if (c.mode === 'ADAPT' && kind === 'source-analyze') checkAdaptationGoal(c);
  need(scopedBrief(c).length <= 12000, 'brief plus source scope exceeds 12000 characters; preview a shorter user-confirmed brief through reopen --config');
  // Old journals remain readable; never silently propagate an incomplete legacy concept into a new call.
  if (v.assets) checkCharacterIdentities(output(root, v.assets));
  if (v.concepts) validateConceptArcs(output(root, v.concepts).concepts, c.episodeCount);
  if (v.blueprint) need(!blueprintConflictState(root, state).unresolved.length, 'Blueprint has unresolved source decision conflicts; do not generate downstream episodes');
  if (c.mode === 'ADAPT' && kind !== 'source-analyze') checkSourceDecisions(reviewedSource(root, v), v.sourceDecisions || []);
  if (kind !== 'source-analyze') verifyProjectFacts(root, state);
  return assembleInput(root, state, step, extra);
}

// Read-only planning must not revalidate legacy upstream contracts or prevent inspecting old drafts.
// Only buildInput, used by prepare, admits a new call; this assembler has no side effects.
function assembleInput(root, state, step, extra) {
  const c = state.config, v = state.view, kind = step.operator.slice(PREFIX.length);
  const common = { ...pick(c, ['targetMarket', 'carrier']), outputLanguage: language(state) };
  let input;
  if (kind === 'source-analyze') input = { ...c.source, targetMarket: c.targetMarket, targetLanguage: c.languagePlan?.targetLanguage || c.outputLanguage, episodeCount: c.episodeCount };
  if (kind === 'concept') input = { ...common, ...c.concept, mode: c.mode, brief: scopedBrief(c), episodeCount: c.episodeCount, conceptCount: 3 };
  if (kind === 'assets') input = { ...common, ...c.assets, mode: c.mode, episodeCount: c.episodeCount, selectedConcept: selected(root, state) };
  if (kind === 'blueprint') input = { ...common, action: 'BUILD', selectedConcept: selected(root, state), assets: output(root, v.assets), targetEpisodeCount: c.episodeCount };
  if (kind === 'episode') {
    const blueprint = output(root, v.blueprint), n = step.episodeNumber;
    input = { ...c.episode, generationMode: delivery(state) ? 'LOCALIZE' : 'WRITE', episodeNumber: n, episodeBeat: blueprint.episodes.find(e => e.episodeNumber === n), selectedConcept: selected(root, state), assets: output(root, v.assets), blueprintDigest: blueprint.blueprintDigest, outputLanguage: language(state), ...wordBudget(state) };
    if (delivery(state)) input.sourceEpisode = output(root, v.workingDraft.episodes[n]);
    need(input.episodeBeat, 'Blueprint does not contain requested episode');
    if (n > 1) {
      input.previousEpisode = output(root, v.episodes[n - 1]);
      input.continuitySnapshot = input.previousEpisode.continuitySnapshot;
    }
  }
  if (kind === 'review') {
    input = { action: step.action, episodes: step.numbers.map(n => output(root, v.episodes[n])), blueprint: output(root, v.blueprint), assets: output(root, v.assets) };
    if (delivery(state) && c.languagePlan.workingLanguage !== c.languagePlan.targetLanguage) input.sourceEpisodes = step.numbers.map(n => output(root, v.workingDraft.episodes[n]));
    if (step.action === 'FIX') {
      need(!v.fix.issueIds.some(id => REPORT_ONLY_ISSUES.has(id)), 'Report-only issues cannot authorize manuscript FIX; verify the report manually or separately authorize SCAN');
      Object.assign(input, { confirmedIssueIds: v.fix.issueIds, revisionInstruction: v.fix.instruction, priorReview: output(root, v.fix.reviewRef) });
    }
  }
  if (c.mode === 'ADAPT' && ['concept', 'assets', 'review'].includes(kind)) input.sourceAnalysis = reviewedSource(root, v);
  if (kind !== 'source-analyze') {
    const sourceDecisions = v.sourceDecisions || [];
    input.requirements = { brief: scopedBrief(c), namingConstraints: c.assets?.namingConstraints || [],
      contentConstraints: c.episode?.contentConstraints || [], protectedElements: c.source?.protectedElements || [],
      allowedChanges: c.source?.allowedChanges || [], ...wordBudget(state), sourceDecisions: clone(sourceDecisions) };
  }
  if (c.languagePlan) {
    input.languagePlan = clone(c.languagePlan);
    if (['episode', 'review'].includes(kind)) input.draftKind = delivery(state) ? 'DELIVERY' : 'WORKING';
  }
  input.recipeBindings = [...c.recipeBindings, ...(c.operatorRecipeBindings?.[step.operator] || [])];
  // Only source file IDs are caller-supplied at prepare time. All upstream objects come from the journal.
  need(object(extra) && Object.keys(extra).every(key => kind === 'source-analyze' && key === 'sourceFileId'), 'Only sourceFileId may be supplied to prepare; use reopen for supported requirement changes, not input or state edits');
  if (extra.sourceFileId !== undefined) need(text(extra.sourceFileId), 'Invalid sourceFileId');
  return { ...input, ...extra };
}

function requireCompleteOutput(value) {
  need(value !== '<truncated>' && !(object(value) && value._truncated === true), 'Output contains a truncated result marker; fetch the original full result, never fabricate evidence');
  if (value && typeof value === 'object') Object.values(value).forEach(requireCompleteOutput);
}

function episodeCounts(episode) {
  let wordCount = 0, dialogueCount = 0;
  for (const line of episode.scriptLines) {
    if (line.type === 'SCENE') continue;
    if (line.type === 'DIALOGUE') dialogueCount++;
    const rest = line.text.replace(/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/gu, () => { wordCount++; return ' '; });
    wordCount += (rest.match(/[\p{L}\p{N}]+(?:['’\-][\p{L}\p{N}]+)*/gu) || []).length;
  }
  return { wordCount, sceneCount: episode.scenes.length, dialogueCount };
}

function terminalInvalidForRetry(call, receipt) {
  return call.operator === PREFIX + 'episode' && call.status === 'OUTPUT_INVALID' && Boolean(call.jobId) && receipt?.status?.toUpperCase() === 'SUCCEEDED' && !receipt._timeout;
}

function manuscriptProgress(state, root) {
  const numbers = Array.from({ length: state.config.episodeCount }, (_, i) => i + 1);
  const activeDelivery = delivery(state);
  const working = Object.keys(state.view.workingDraft?.episodes || (!activeDelivery ? state.view.episodes : {})).map(Number).sort((a,b) => a-b);
  const target = activeDelivery ? episodeNumbers(state) : [];
  const summary = completed => ({ completed, missing: numbers.filter(n => !completed.includes(n)), complete: completed.length === numbers.length });
  const pending = state.pending ? state.calls[state.pending] : null;
  return { working: summary(working), delivery: state.config.languagePlan ? summary(target) : null,
    activeDraft: activeDelivery ? 'DELIVERY' : 'WORKING',
    blockedEpisode: pending?.operator === PREFIX + 'episode' ? load(root, pending.input).episodeNumber ?? null : null,
    complete: (state.config.languagePlan ? target : working).length === numbers.length,
    instruction: 'Report each manuscript separately. Complete working episodes do not imply complete delivery. Preserve successful episodes and original receipts; follow next for recovery before any separately authorized new quote. An unconfirmed upstream outcome needs investigation even if refunded.' };
}

function validateOutput(kind, o, input, state, contractVersion = 0) {
  need(object(o), 'Missing successful output object');
  requireCompleteOutput(o);
  const schema = kind === 'source-analyze' ? 'source-analysis' : kind;
  need(o.schemaVersion === `script.${schema}.v1`, 'Unsupported output schemaVersion; stop and check online describe');
  const arr = key => need(Array.isArray(o[key]), `Output missing array ${key}`);
  const obj = key => need(object(o[key]), `Output missing object ${key}`);
  const str = key => need(text(o[key]), `Output missing text ${key}`);
  if (kind === 'source-analyze') {
    obj('sourceBible'); str('reportMarkdown'); ['protectedElements', 'flexibleElements', 'bannedSourceNames', 'plotSkeleton', 'risks'].forEach(arr);
    const ids = new Set();
    for (const risk of o.risks) {
      need(object(risk), 'Source risks must be objects');
      if (Object.hasOwn(risk, 'requiresConfirmation')) need(typeof risk.requiresConfirmation === 'boolean', 'Invalid source risk requiresConfirmation');
      if (Object.hasOwn(risk, 'id')) { need(text(risk.id) && risk.id.length <= 120 && !ids.has(risk.id), 'Invalid or duplicate source risk ID'); ids.add(risk.id); }
      if (risk.requiresConfirmation === true) need(text(risk.id) && text(risk.evidence) && text(risk.question), 'Confirmation risk needs id, evidence and question');
    }
  }
  if (kind === 'concept') {
    arr('concepts'); need(o.mode === state.config.mode && o.concepts.length === 3, 'Concept mode/count mismatch');
    const ids = o.concepts.map(item => item.id); need(ids.every(text) && new Set(ids).size === ids.length, 'Invalid concept IDs');
    validateConceptArcs(o.concepts, input.episodeCount);
  }
  if (kind === 'assets') {
    ['characters', 'locations', 'props', 'relationships', 'namingLedger', 'continuityRules'].forEach(arr);
    need(o.mode === state.config.mode && o.characters.length > 0, 'Assets mode/characters invalid'); str('storyBibleMarkdown');
    need(/^[a-f0-9]{64}$/.test(o.assetsDigest), 'Missing assetsDigest');
  }
  if (kind === 'blueprint') {
    arr('episodes'); arr('units'); obj('globalArc'); str('title');
    sourceDecisionConflicts(o);
    need(o.action === 'BUILD' && /^[a-f0-9]{64}$/.test(o.blueprintDigest), 'Invalid blueprint action/digest');
    need(eq(o.episodes.map(e => e.episodeNumber).sort((a,b) => a-b), Array.from({ length: state.config.episodeCount }, (_, i) => i+1)), 'Blueprint episode coverage mismatch');
  }
  if (kind === 'episode') {
    need(o.episodeNumber === input.episodeNumber, 'Episode number mismatch'); str('title'); str('markdown');
    arr('scenes'); arr('scriptLines'); obj('continuitySnapshot'); obj('continuityDelta'); arr('warnings'); obj('statistics');
    need(o.warnings.every(text), 'Output warnings must be non-empty strings');
    need(['wordCount', 'sceneCount', 'dialogueCount'].every(key => Number.isSafeInteger(o.statistics[key]) && o.statistics[key] >= 0)
      && o.statistics.wordCount > 0, 'Output statistics must contain valid server counts');
    need(o.scenes.length && o.scriptLines.length, 'Empty episode');
    need(o.scriptLines.every(line => object(line) && ['SCENE', 'ACTION', 'DIALOGUE', 'CAPTION', 'SFX'].includes(line.type)
      && text(line.text) && (line.type !== 'DIALOGUE' || text(line.character))), 'Invalid episode line type, text or speaker');
    const actual = episodeCounts(o);
    // Unicode property tables differ across server Java and supported Node versions.
    // Word count is advisory; structural counts and completeness remain hard checks.
    need(['sceneCount', 'dialogueCount'].every(key => actual[key] === o.statistics[key]), 'Output statistics do not match complete episode lines/scenes');
    if (input.languagePlan) need(o.generationMode === input.generationMode, 'Episode generationMode mismatch');
    if (input.generationMode === 'LOCALIZE') {
      need(eq(o.scenes.map(s => s.id), input.sourceEpisode.scenes.map(s => s.id)), 'LOCALIZE scene identity/order changed');
      need(eq(o.scriptLines.map(l => pick(l, ['type', 'sceneId', 'character'])), input.sourceEpisode.scriptLines.map(l => pick(l, ['type', 'sceneId', 'character']))), 'LOCALIZE line structure/speaker changed');
    }
  }
  if (kind === 'review') {
    need(o.action === input.action && ['PASS', 'REVIEW_REQUIRED'].includes(o.status), 'Review action/status invalid');
    obj('summary'); const key = input.action === 'FIX' ? 'unresolvedIssues' : 'issues'; arr(key);
    need(o[key].every(issue => object(issue) && text(issue.id) && text(issue.severity)), 'Invalid review issue');
    need(new Set(o[key].map(issue => issue.id)).size === o[key].length, 'Duplicate review issue ID');
    need((o.status === 'PASS') === (o[key].length === 0), 'Review status and issue count disagree');
    if (input.action === 'FIX') {
      arr('revisedEpisodes'); arr('resolvedIssueIds'); arr('changeSummary');
      need(o.revisedEpisodes.length > 0, 'Empty FIX result');
      const numbers = o.revisedEpisodes.map(e => e.episodeNumber);
      need(new Set(numbers).size === numbers.length, 'Duplicate fixed episode');
      const confirmed = input.priorReview.issues.filter(issue => input.confirmedIssueIds.includes(issue.id));
      for (const ep of o.revisedEpisodes) {
        need(input.episodes.some(before => before.episodeNumber === ep.episodeNumber), 'FIX episode out of batch');
        need(confirmed.some(issue => !issue.episodeNumber || issue.episodeNumber === ep.episodeNumber), 'FIX episode outside approved scope');
        validateOutput('episode', ep, { episodeNumber: ep.episodeNumber }, state);
      }
      need(o.resolvedIssueIds.every(item => input.confirmedIssueIds.includes(item)), 'FIX resolved unconfirmed issue');
    }
  }
  if (contractVersion >= 1) checkNewOutput(kind, o, input);
}

function pause(v, type, options) { v.awaiting = { type, options, createdAt: now() }; }
function preparedCli(root, call) {
  return { command: process.platform === 'win32' ? 'manturhub.cmd' : 'manturhub',
    ...(call.accessArgs?.length ? { accessArgs: call.accessArgs } : {}),
    args: ['run', call.operator, '--json-file', safePath(root, call.inputFile), ...(call.attributionArgs || [])] };
}
function projectBilling(root, state) {
  return summarizeBilling(Object.values(state.calls).flatMap(call => {
    const refs = receiptRefs(call);
    return (refs.length ? refs.map(ref => load(root, ref)) : [{}])
      .map(receipt => ({ callId: call.id, jobId: call.jobId, receipt }));
  }));
}
function receiptRefs(call) {
  return [...new Map([...(call.result ? [call.result] : []), ...(call.receiptHistory || [])]
    .map(ref => [ref.digest, ref])).values()];
}
function retainReceipt(root, call, result) {
  const ref = store(root, result);
  call.receiptHistory = receiptRefs(call);
  if (!call.receiptHistory.some(saved => eq(saved, ref))) call.receiptHistory.push(ref);
  return ref;
}
function pendingNext(call) {
  if (call.sourceBindingVersion === 1 && !call.sourceUpload) return { kind: 'pending', callId: call.id,
    operator: call.operator, status: call.status, sourceUploadRequired: true, accessArgs: call.accessArgs,
    sourceInspection: call.sourceInspection,
    instruction: 'Upload the frozen project source once through ACCESS, then bind-source-upload with this callId and its AVAILABLE receipt before requesting a quote. Do not run with --file or use shared upload-cache IDs. An interrupted upload is not an operator submission; locate its upload receipt before repeating it.' };

  const hints = {
    PREPARED: 'No submission receipt recorded. If not executed, or a quote error proves no submission, use abandon with submission evidence; otherwise locate the original CLI receipt.',
    WAITING_CONFIRMATION: 'Show quote; confirm the original input or cancel-quote. This is not a generated result.',
    OUTPUT_INVALID: 'Server result is retained but invalid locally. Inspect the validation error and original task. A terminal SUCCEEDED result with jobId may be explicitly abandoned; a fresh call can cost again.',
    NEEDS_RESULT_FETCH: 'Fetch the full result through resume using the original recovery ID; do not run again.',
    NOT_SUBMITTED: 'Quote-stage non-submission is recorded; check submissionEvidenceOrigin for manual verification versus a CLI receipt. Correct the cause; explicitly abandon or authorize retry. Do not automatically call again.',
    REJECTED: 'Server explicitly rejected admission. No task to poll for this attempt; preserve this receipt. Correct the cause and obtain explicit retry or abandon; this is not a refund promise for historical calls.',
  };
  return { kind: 'pending', callId: call.id, ...pick(call, ['operator', 'status', 'recoveryId', 'jobId', 'errorCode', 'errorMessage', 'standardError', 'validationError', 'billing', 'submissionEvidenceOrigin', 'accessArgs']),
    instruction: unconfirmedOutcome(call)
      ? 'The upstream outcome is UNCONFIRMED. WAIT_CONFIRMATION: query the original job/recovery ID or contact support with supportId; do not automatically run again. A refund is a billing fact, not proof that upstream execution never occurred. Preserve/export completed work; abandon only stops local work. Only after explaining duplicate execution and possible new charges, and the user explicitly chooses a new attempt, record answer --decision retry-unconfirmed --call <callId> --note <actual user authorization>. A fresh quote still requires separate fee approval.'
      : hints[call.status] || (failedStates.includes(call.status)
      ? 'Inspect the original terminal receipt and billing; a client wait timeout is still uncertain. A verified server terminal failure with jobId may be explicitly abandoned to stop or replan locally. Existing outputs stay intact; this does not authorize a new call or guarantee a refund. Separately authorized retry permits a new quote/call.'
      : 'Outcome unknown or active: resume original CLI receipt. Missing IDs alone do not prove no submission. Never create a second call; verified pre-submission failure requires explicit abandon evidence.') };
}
function checkSnapshot(root, state, snapshotId) {
  need(id(snapshotId) && state.snapshots[snapshotId], 'Unknown checkpoint');
  return load(root, state.snapshots[snapshotId]);
}
function checkpoint(root, state, label) {
  need(text(label), 'Checkpoint needs a label');
  const snapshotId = randomUUID();
  state.snapshots[snapshotId] = store(root, { label, at: now(), config: state.config, configDigest: state.configDigest, view: state.view });
  return snapshotId;
}
function restoreSnapshot(root, state, snapshot) {
  // v1-v5 checkpoints only contained a view. Freeze their shared config before the first amendment.
  const config = snapshot.config || (state.legacySnapshotConfig ? load(root, state.legacySnapshotConfig) : state.config);
  checkConfig(config, { allowLegacyGoal: true });
  need(!snapshot.config || snapshot.configDigest === hash(config), 'Checkpoint config digest mismatch');
  state.config = clone(config); state.configDigest = hash(config); state.view = clone(snapshot.view);
}

// Reopen a dependency boundary, never edit an operator receipt or infer paid retry authorization.
function reopenPlan(root, state, options) {
  const v = state.view, from = options.from;
  need(['source', 'concept', 'assets', 'blueprint'].includes(from), 'reopen requires --from source|concept|assets|blueprint');
  need(!state.pending && !v.stop && !v.fix && !v.afterFix && !v.repairDecision && !v.reviewRequest,
    'Resolve the pending call, stop, review or repair before reopening upstream');
  if (from === 'source') need(state.config.mode === 'ADAPT' && v.source, 'Reopening source requires an existing successful ADAPT analysis');
  if (from !== 'source' && state.config.mode === 'ADAPT') {
    need(v.source && v.awaiting?.type !== 'source', 'Confirm source decisions before reopening downstream');
    checkSourceDecisions(reviewedSource(root, v), v.sourceDecisions || []);
  }
  if (['assets', 'blueprint'].includes(from)) {
    need(v.concepts && v.selectedConceptId && v.awaiting?.type !== 'concept', 'A confirmed concept is required');
    selected(root, state);
  }
  if (from === 'blueprint') need(v.assets && v.awaiting?.type !== 'assets', 'Confirmed assets are required');
  const config = options.config ? readJSON(options.config) : clone(state.config);
  checkConfig(config); need(scopedBrief(config).length <= 12000, 'Scoped brief exceeds 12000 characters');
  const changed = [...new Set([...Object.keys(state.config), ...Object.keys(config)])]
    .filter(key => !eq(canonical(state.config[key] ?? null), canonical(config[key] ?? null)));
  need(changed.every(key => ['brief', 'concept', 'assets', 'episode'].includes(key)),
    'Only brief/concept/assets/episode may be amended; source, scope, languages, recipes and other locked configuration require separate planning');
  need(!changed.length || ['source', 'concept'].includes(from), 'Changed requirements must reopen source or concept because they affect all downstream stages');
  const view = emptyView();
  view.quality = invalidateQuality(v.quality);
  for (const key of ['source', 'sourceManualRisks', 'sourceDecisions']) if (v[key] !== undefined) view[key] = clone(v[key]);
  if (from === 'source') {
    view.stage = 'SOURCE_ANALYZED'; pause(view, 'source', ['confirm']);
    view.awaiting.requiredRisks = reviewedSource(root, view).risks.filter(risk => risk.requiresConfirmation === true);
  } else if (['assets', 'blueprint'].includes(from)) {
    view.concepts = clone(v.concepts); view.selectedConceptId = v.selectedConceptId; view.stage = 'CONCEPT_SELECTED';
    if (from === 'blueprint') { view.assets = clone(v.assets); view.stage = 'ASSETS_CONFIRMED'; }
  } else if (v.source) view.stage = 'SOURCE_ANALYZED';
  const invalidated = ['concepts', 'assets', 'blueprint'].filter(key => v[key] && !view[key]);
  return { config, view, report: {
    from, revision: state.revision, planDigest: hash(canonical({ projectId: state.projectId, revision: state.revision, from, config })), changedConfigFields: changed,
    configChanges: Object.fromEntries(changed.map(key => [key, { before: state.config[key] ?? null, after: config[key] ?? null }])),
    retained: ['source', 'concepts', 'assets'].filter(key => view[key]), invalidated,
    manuscripts: { workingEpisodes: Object.keys(v.workingDraft?.episodes || (!delivery(state) ? v.episodes : {})).map(Number),
      deliveryEpisodes: delivery(state) ? Object.keys(v.episodes).map(Number) : [] },
    sourceDecisions: clone(view.sourceDecisions), sourceManualRisks: clone(view.sourceManualRisks),
    bannedSourceNames: view.source ? clone(output(root, view.source).bannedSourceNames || []) : [],
    localOnly: true, newCalls: 0, qualityAccepted: false,
    instruction: 'Preview is read-only. Confirm the affected boundary and config diff before applying at this revision. Original receipts, files and charges remain; superseded manuscripts/reviews lose current status. This is not permission to generate or review again. Source decisions do not override protected elements or banned names; resolve any such contract conflict before paying for a new call.',
  } };
}
function applyOutput(root, state, call, ref) {
  const v = state.view, kind = call.operator.slice(PREFIX.length), result = output(root, ref);
  if (kind === 'source-analyze') {
    v.source = ref; v.sourceManualRisks = []; v.sourceDecisions = []; v.stage = 'SOURCE_ANALYZED'; pause(v, 'source', ['confirm']);
    v.awaiting.requiredRisks = result.risks.filter(risk => risk.requiresConfirmation === true);
  }
  if (kind === 'concept') { v.concepts = ref; pause(v, 'concept', result.concepts.map(c => c.id)); }
  if (kind === 'assets') { v.assets = ref; pause(v, 'assets', ['confirm']); }
  if (kind === 'blueprint') {
    v.blueprint = ref; v.blueprintConflictResolutions = []; pause(v, 'blueprint', ['confirm']);
    const conflicts = sourceDecisionConflicts(result);
    if (conflicts.length) v.awaiting.conflicts = conflicts;
  }
  if (kind === 'episode') {
    if (v.awaiting?.type === 'mid-review') v.awaiting = null; // Legacy five-episode progress stop is now advisory.
    v.episodes[result.episodeNumber] = ref;
    const count = episodeNumbers(state).length;
    if (count === state.config.episodeCount) v.stage = 'EPISODES_WRITTEN';
    else if (count % 5 === 0 && !v.checkpointsPassed.includes(count)) v.checkpointsPassed.push(count);
  }
  if (kind === 'review' && result.action === 'FIX') {
    const before = clone(v.episodes);
    for (const ep of result.revisedEpisodes) {
      v.episodes[ep.episodeNumber] = store(root, { status: 'SUCCEEDED', output: ep, provenance: { reviewCallId: call.id, jobId: call.jobId } });
    }
    const changed = result.revisedEpisodes.filter(ep => !eq(output(root, before[ep.episodeNumber]), ep)).map(ep => ep.episodeNumber);
    if (changed.length) startContinuityCheck(state, before, changed, 'Operator FIX changed an earlier manuscript; retained downstream episodes need local recheck.');
    v.quality = invalidateQuality(v.quality);
    v.afterFix = { ...v.fix, fixCallId: call.id }; v.fix = null;
    if (v.afterFix.approval?.followupReview === 'skip') skipReview(state, 'User explicitly declined follow-up review when approving FIX; revised manuscript retained, not quality-accepted.');
    v.stage = 'EPISODES_WRITTEN';
  }
  if (kind === 'review' && result.action === 'SCAN') {
    const numbers = load(root, call.input).episodes.map(e => e.episodeNumber);
    v.reviews.push({ callId: call.id, ref, numbers, signature: reviewSignature(state, numbers), reviewEpoch: call.reviewEpoch || 0 });
    if (v.afterFix && eq(v.afterFix.numbers, numbers)) {
      const fix = v.afterFix, before = output(root, fix.reviewRef);
      const beforeIds = new Set(before.issues.map(i => i.id)), afterIds = new Set(result.issues.map(i => i.id));
      const comparison = { snapshotId: fix.snapshotId, fixCallId: fix.fixCallId, rescanCallId: call.id,
        stillReported: fix.issueIds.filter(id => afterIds.has(id)),
        noLongerReported: fix.issueIds.filter(id => !afterIds.has(id)),
        newlyReported: result.issues.filter(i => !beforeIds.has(i.id)) };
      Object.assign(state.rounds.find(r => r.snapshotId === fix.snapshotId), { comparison });
      if (result.issues.length) v.repairDecision = comparison;
      v.afterFix = null;
    }
    if (currentReviews(state, root).length === batches(state, root).length) v.stage = 'REVIEW_SCANNED';
  }
}

function publicResult(raw) {
  need(object(raw), 'CLI stdout must be a public task object, not a gateway envelope');
  need(!Object.hasOwn(raw, 'data'), 'Import unwrapped CLI stdout, not HTTP Result.data');
  const result = pick(raw, ['schemaVersion', 'inputDigest', 'submission', 'recoveryId', 'reason', 'jobId', 'job_id', 'operatorCode', 'apiCode', 'requestId', 'invocationId', 'traceId', 'status', 'progress', 'output', 'errorCode', 'errorMessage', '_billing', 'billing', 'settlement', '_timeout', 'createdAt', 'updatedAt', 'terminalAt']);
  const standardError = publicStandardError(raw.standardError);
  if (standardError) result.standardError = standardError;
  safeData(result); return result;
}

function wordCountAdvisories(root, state) {
  const issues = [];
  for (const n of episodeNumbers(state)) {
    const ep = output(root, state.view.episodes[n]);
    // Historical receipts may predate line validation. Advisories never make them unreadable.
    if (!Array.isArray(ep.scenes) || !Array.isArray(ep.scriptLines)
      || !ep.scriptLines.every(line => object(line) && typeof line.text === 'string')) continue;
    const localWordCount = episodeCounts(ep).wordCount;
    const { targetWordsMin: min, targetWordsMax: max } = wordBudget(state);
    const actual = Number.isSafeInteger(ep.statistics?.wordCount) && ep.statistics.wordCount >= 0 ? ep.statistics.wordCount : localWordCount;
    if (Number.isFinite(min) && Number.isFinite(max) && (actual < min || actual > max)) {
      const draftKind = delivery(state) ? 'DELIVERY' : 'WORKING';
      issues.push({ id: `LOCAL_WORD_BUDGET_${draftKind}_${n}`, episodeNumber: n, severity: 'SUGGESTION', advisoryOnly: true,
        draftKind, actual, min, max, countBasis: actual === ep.statistics?.wordCount ? 'SERVER_STATISTICS' : 'LOCAL_UNICODE',
        description: `第${n}集${draftKind === 'DELIVERY' ? '成品稿' : '工作稿'}约 ${actual} 字/词，${actual > max ? '高于' : '低于'}目标 ${min}–${max}。仅为篇幅提醒，不代表成片时长或质量不合格；正文完整保留，可直接交付，是否精简或扩写由用户决定，不自动重生成或扣费。` });
    }
    if (Number.isSafeInteger(ep.statistics?.wordCount) && localWordCount !== ep.statistics.wordCount) {
      issues.push({ id: `LOCAL_WORD_COUNT_${n}`, episodeNumber: n, severity: 'SUGGESTION',
        description: `Word-count basis differs: server=${ep.statistics.wordCount}, local=${localWordCount}. Unicode versions may differ; original receipt and complete manuscript are retained. Check the text if needed; this alone does not require regeneration.` });
    }
  }
  return issues;
}

function diagnostics(root, state) {
  const issues = wordCountAdvisories(root, state);
  for (const n of episodeNumbers(state)) {
    const ep = output(root, state.view.episodes[n]);
    if (ep.scenes.length !== ep.scriptLines.filter(line => line.type === 'SCENE').length) issues.push({ id: `LOCAL_SCENE_COUNT_${n}`, episodeNumber: n, description: 'scenes and SCENE line counts differ' });
    if (!Array.isArray(ep.warnings) || !ep.warnings.every(text)) {
      issues.push({ id: `LOCAL_WARNINGS_UNCHECKED_${n}`, episodeNumber: n, description: 'Historical episode warnings are missing or malformed; not evidence of a clean review.' });
    } else for (const [index, warning] of ep.warnings.entries()) issues.push({ id: `LOCAL_WARNING_${n}_${index}`, episodeNumber: n, description: warning });
  }
  return issues;
}

function reviewEvidence(root, state, review) {
  const report = output(root, review.ref), call = state.calls[review.callId];
  return call?.input ? evidenceChecks(load(root, call.input), report.issues) : report.summary?.evidenceChecks || [];
}

function softLengthAdvisory(issue) {
  return issue.advisoryOnly === true && /^(?:WORKING:)?LOCAL_WORD_BUDGET_(?:WORKING|DELIVERY)_\d+$/.test(issue.id);
}

function qualityIssues(root, state) {
  const workingFindings = delivery(state) ? state.view.workingDraft.findings.map(issue => ({ ...issue, id: `WORKING:${issue.id}`, origin: 'CONFIRMED_WORKING_DRAFT' })) : [];
  const local = localIssues(root, state).issues.filter(i => !['dismiss', 'resolved'].includes(i.decision?.action))
    .map(i => ({ id: `LOCAL_ISSUE:${i.id}`, severity: i.severity, description: i.title, evidence: i.evidence, decision: i.decision || null }));
  return [...workingFindings, ...validReviews(state).flatMap(r => {
    const checks = reviewEvidence(root, state, r);
    return output(root, r.ref).issues.map(issue => ({ ...issue, id: `${r.callId}:${issue.id}`,
      ...(checks.some(c => c.issueId === issue.id) ? { evidenceCheck: checks.find(c => c.issueId === issue.id) } : {}) }));
  }), ...diagnostics(root, state), ...local, ...(state.view.quality.manual?.findings || [])];
}

const render = renderData;
function sourceCoverage(state) {
  if (state.config.mode !== 'ADAPT') return null;
  return { sourceScope: state.config.sourceScope || { kind: 'LEGACY_UNRECORDED', limitations: ['历史项目未记录分析范围，不表示全稿已分析。'] },
    note: '范围由用户确认；本地检查不等于模型全文理解或全季一致性核验。',
    calls: Object.values(state.calls).filter(c => c.operator === PREFIX + 'source-analyze').map(c => ({ callId: c.id, status: c.status, sourceInspection: c.sourceInspection || { status: 'LEGACY_UNCHECKED' } })) };
}
function exportProject(root, state) {
  const v = state.view, parts = [], paths = [];
  // Issues are consolidated once with stable call-prefixed IDs; keep the rest of
  // each SCAN report here. Complete, unmodified reports remain in data/.
  const reviewDetails = (reviews, includeIssues = false) => reviews.map(r => {
    const report = output(root, r.ref);
    return (includeIssues ? render({ callId: r.callId, issues: report.issues }) + '\n\n' : '') + renderReview(report, r.numbers, reviewEvidence(root, state, r));
  }).join('\n\n');
  const activePrefix = state.config.languagePlan ? (delivery(state) ? 'delivery/' : 'working/') : '';
  const base = `exports/revision-${state.revision}`;
  const add = (name, title, body) => { paths.push({ title, path: atomic(root, `${base}/${name}`, body + '\n') }); };
  const assets = v.assets ? output(root, v.assets) : {};
  const presentation = { assets, characters: state.presentation && state.presentation.assetsDigest === v.assets?.digest ? state.presentation.characters : [] };
  if (state.presentation) add('显示名映射.md', '角色显示名映射', '# 角色显示名映射\n\n仅改变阅读标签，原始身份键、正文和回执保留。资产已变化时旧覆盖不生效；缺少映射回退原名，不阻断导出。\n\n'
    + render({ ...state.presentation, active: state.presentation.assetsDigest === v.assets?.digest }));
  const reviewed = reviewCoverage(state, root);
  const reviewLabel = reviewed.complete ? '当前稿件已有算子审校报告（不等于质量通过）' : `未完成全部算子审校（${reviewed.status}）；空问题清单不表示无问题`;
  const label = (v.quality.qualityAccepted ? '用户已明确质量验收' : v.deliveryReceipt ? '已交付／尚未质量验收' : '草稿／尚未质量验收') + '；' + reviewLabel;
  add('稿件进度.md', '工作稿与成品稿进度', '# 工作稿与成品稿进度\n\n' + render(manuscriptProgress(state, root)));
  const coverage = sourceCoverage(state);
  if (coverage) add('源稿范围.md', '源稿范围与检查', '# 源稿范围与检查\n\n' + render(coverage));
  const episodeBody = (ep, n, lang, coverageStatus = reviewed, ref = v.episodes[n]) => {
    const note = /^en(?:[-_]|$)/i.test(lang)
      ? coverageStatus.complete ? 'Operator review reports exist; not a guarantee of quality acceptance.' : 'Operator review is incomplete or skipped. This is not a reviewed/PASS manuscript.'
      : coverageStatus.complete ? '已有算子审校报告，不代表质量自动通过。' : '未完成或已跳过算子审校；不是审校通过稿。';
    const localNote = load(root, ref).provenance?.kind === 'LOCAL_REVISION' ? /^en(?:[-_]|$)/i.test(lang)
      ? ' User-approved local revision, not a new operator result. Counts are locally derived; inherited warnings are tracked separately.'
      : ' 用户确认的本地修订，非新算子产物；统计为本地重算，继承警告的处理见创作问题台账。' : '';
    const body = renderEpisode(ep, n, lang, presentation).replace('\n\n', `\n\n> ${note}${localNote}\n\n`);
    if (!coverage) return body;
    const scope = state.config.sourceScope;
    const scopeNote = /^en(?:[-_]|$)/i.test(lang)
      ? `Adaptation scope: ${scope ? `${scope.kind} / ${scope.label} / ${scope.location}` : 'legacy scope unrecorded'}. Not whole-source verification.`
      : `改编范围：${scope ? `${scope.kind} / ${scope.label} / ${scope.location}` : '历史范围未记录'}；不表示原作全文已核验。`;
    return body.replace('\n\n', () => `\n\n> ${plain(scopeNote).replace(/\n/g, ' ')}\n\n`);
  };
  const manuscriptLabel = language(state) === 'en' ? (v.quality.qualityAccepted ? 'Accepted by the user' : 'Draft / not yet accepted') : label;
  add('执行计划.md', '执行计划与可选费用', '# 执行计划与可选费用\n\n默认先写完本次范围全部集数；审校是可选项，未确认不调用、不扣费。确认创作或回复“继续”不是审校、FIX或质量验收授权。下列次数不是报价，金额以每次CLI实时确认及最终账务为准。FIX须将修复和可选复扫范围、预估费用一起说明；允许只批准FIX，只有明确一起批准才共用总上限。复扫报价超出授权或金额未知就停止。\n\n' + render(executionPlan(state, root)));
  add('项目摘要.md', '项目摘要', `# ${plain(state.config.name)}\n\n状态：${label}\n\n阶段：${v.stage}\n\n${render(state.config)}\n\n## 当前停点与恢复\n\n${renderNext(next(state, root))}\n\n任务、恢复 ID 和实际账务见[运行记录](运行记录.md)。\n\n## 人工补充的源稿风险（非模型检测）\n\n${render(v.sourceManualRisks || [])}\n\n## 已确认的源稿澄清\n\n${render(v.sourceDecisions || [])}\n\n## 已知问题\n\n${render(qualityIssues(root, state))}`);
  const blueprintTitle = v.awaiting?.type === 'blueprint' ? '蓝图待确认稿' : '蓝图确认稿';
  for (const [ref, file, title, field] of [[v.source, '源稿分析.md', '源稿分析', 'reportMarkdown'], [v.concepts, '三个方案.md', '三个方案'], [v.assets, '资产.md', '资产', 'storyBibleMarkdown'], [v.blueprint, `${blueprintTitle}.md`, blueprintTitle]]) {
    if (ref) { const o = output(root, ref); add(file, title, `# ${title}\n\n${label}\n\n${coverage ? '仅适用于本项目已确认材料范围，参见[源稿范围与检查](源稿范围.md)；不代表原作全文已核验。\n\n' : ''}${field ? o[field] + '\n\n## 结构化明细\n\n' + render(Object.fromEntries(Object.entries(o).filter(([key]) => key !== field))) : render(o)}`); }
  }
  if (v.selectedConceptId) add('已选方案.md', '已选方案', render(selected(root, state, false)));
  const activeResolutions = blueprintConflictState(root, state).resolutions;
  const resolutionHistory = state.events.filter(event => event.action === 'resolve-blueprint-conflict').map(event => ({
    revision: event.revision, ...load(root, event.resolution),
    current: activeResolutions.some(r => r.ref.digest === event.resolution.digest && r.current),
  }));
  if (resolutionHistory.length) {
    add('蓝图误报解除记录.md', '蓝图误报解除记录', '# 蓝图误报解除记录\n\n用户明确确认的本地误报判断，不是模型重新审校或质量验收。原 CONFLICT、蓝图及账务未改写；历史已失效的解除不能放行当前蓝图。报告引用校验不等于自动证明语义正确。完整报告、摘要绑定和快照见 data/blueprint-conflict-resolutions.json。\n\n' + render(resolutionHistory.map(r => ({
      风险: r.riskId, 当前有效: r.current, 时间: r.at, 已批准改编: r.proof.serverCheck.decision,
      原模型解释: r.proof.serverCheck.explanation, 解除理由: r.proof.reason, 用户明确答复: r.note,
      实际拍点: r.proof.coveredBeats, 保留轻微项: r.proof.review.minorTopics,
    }))));
    add('data/blueprint-conflict-resolutions.json', '蓝图误报解除证据', json(resolutionHistory).trimEnd());
  }
  for (const n of episodeNumbers(state)) {
    const ep = output(root, v.episodes[n]);
    const body = episodeBody(ep, n, language(state));
    parts.push(body.replace(/^#{1,2} /gm, heading => '#' + heading)); add(`${activePrefix}episodes/ep${String(n).padStart(2, '0')}.md`, `${activePrefix ? (delivery(state) ? '成品稿' : '工作稿') + ' · ' : ''}第 ${n} 集`, body);
  }
  add(`${activePrefix}正文合集.md`, activePrefix ? (delivery(state) ? '成品稿合集' : '工作稿合集') : '正文合集', `# ${state.config.languagePlan && language(state) === 'en' ? (delivery(state) ? 'Delivery manuscript' : 'Working manuscript') : plain(state.config.name).replace(/\n/g, ' ')}\n\n${state.config.languagePlan ? manuscriptLabel : label}\n\n${parts.join('\n\n---\n\n')}`);
  if (delivery(state)) {
    const workingParts = [];
    for (const n of Object.keys(v.workingDraft.episodes).map(Number).sort((a,b) => a-b)) {
      const ep = output(root, v.workingDraft.episodes[n]), body = episodeBody(ep, n, state.config.languagePlan.workingLanguage, v.workingDraft.reviewCoverage || { complete: false }, v.workingDraft.episodes[n]);
      workingParts.push(body.replace(/^#{1,2} /gm, heading => '#' + heading)); add(`working/episodes/ep${String(n).padStart(2, '0')}.md`, `工作稿 · 第 ${n} 集`, body);
    }
    add('working/正文合集.md', '工作稿合集', `${state.config.languagePlan.workingLanguage === 'en' ? '# Working manuscript\n\nConfirmed for delivery preparation; not final acceptance' : `# ${plain(state.config.name).replace(/\n/g, ' ')}\n\n已确认用于成品制作；不代表终审通过`}\n\n${workingParts.join('\n\n---\n\n')}`);
    add('working/审校报告.md', '工作稿审校', '# 工作稿审校\n\n未做审校时仅记录覆盖状态，不冒充通过报告。\n\n' + render({ reviewCoverage: v.workingDraft.reviewCoverage || { status: 'LEGACY_UNVERIFIED' }, quality: v.workingDraft.quality, findings: v.workingDraft.findings }) + '\n\n' + reviewDetails(v.workingDraft.reviews));
  }
  add('审校报告.md', '审校报告', `# 审校报告\n\n${label}\n\n${render({ reviewCoverage: reviewed, reviewEpoch: v.reviewEpoch || 0, quality: v.quality, issues: qualityIssues(root, state), stop: v.stop, repairDecision: v.repairDecision })}\n\n${reviewDetails(validReviews(state))}`);
  const issueLog = localIssues(root, state), continuity = localContinuity(root, state);
  add('创作问题台账.md', '创作问题与局部修订', '# 创作问题与局部修订\n\n本地核对，不是付费审校或自动语义认证。同一警告按根因归并；原始warnings保留为历史证据，不代表每次都是新缺陷。明确保留问题不等于解决、批准费用或最终验收。\n\n'
    + render({ untriaged: issueLog.untriaged, recheckIssueIds: issueLog.recheckIssueIds, signals: issueLog.signals, issues: issueLog.issues,
      historicalAssessments: (v.issueLedger || []).filter(i => i.scopeDigest !== issueLog.binding.scopeDigest),
      continuityCheck: continuity && { numbers: continuity.numbers, complete: continuity.complete, report: continuity.report },
      localRevisions: v.localRevisions || [] }));
  for (const n of episodeNumbers(state)) {
    const record = load(root, v.episodes[n]);
    if (record.provenance?.kind === 'LOCAL_REVISION') add(`data/local-episode-${n}.json`, `本地修订证据 · 第${n}集`, json(record).trimEnd());
  }
  for (const [i, revision] of (v.localRevisions || []).entries()) add(`data/local-revision-${i + 1}.json`, `本地修订替换依据 · ${i + 1}`,
    json({ ...revision, proposal: load(root, revision.proposal) }).trimEnd());
  const historicalReviews = v.reviews.filter(r => !validReviews(state).some(c => c.callId === r.callId));
  if (v.reviewEpoch || historicalReviews.length) add('审校历史.md', '审校历史', '# 审校历史索引\n\n复扫是新调用，费用单独确认。以下保留当前稿别的旧报告；是否属于当前审校覆盖见标记，不代表旧问题已修复。改稿后未复扫时，旧问题是待核实历史发现，不冒充修订稿已通过。完整原回执位于data/，旧阅读稿仍在其原导出版本。\n\n' + render(v.reviews.map(r => ({ callId: r.callId, numbers: r.numbers, reviewEpoch: r.reviewEpoch || 0, currentReview: validReviews(state).some(c => c.callId === r.callId) }))) + '\n\n## 历史报告（不计入当前覆盖）\n\n' + reviewDetails(historicalReviews, true));
  // Keep complete task evidence separate from the reading view, including failed calls.
  for (const call of Object.values(state.calls)) {
    if (call.result) add(`data/${call.id}.json`, `调用证据 · ${call.operator}`, json(load(root, call.result)).trimEnd());
    for (const [index, ref] of receiptRefs(call).entries()) {
      if (!eq(ref, call.result)) add(`data/${call.id}.receipt-${index + 1}.json`, `后续查询证据 · ${call.operator}`, json(load(root, ref)).trimEnd());
    }
    if (call.submissionEvidence) add(`data/${call.id}.submission-evidence.json`, `人工未提交核对 · ${call.operator}`, json(load(root, call.submissionEvidence)).trimEnd());
  }
  add('运行记录.md', '运行记录', `# 运行记录\n\n此页用于排查与费用核对，不属于剧本正文。账务缺省表示未知，报价不等于实际扣费；本地解除或撤回不代表退款。完整证据在 data/，未决任务只恢复原调用。\n\n## 当前调用指引\n\n${render(next(state, root))}\n\n## 费用汇总\n\n${render(projectBilling(root, state))}\n\n## 调用历史\n\n${render(Object.values(state.calls).map(call => ({ callId: call.id, ...pick(call, ['operator', 'status', 'jobId', 'recoveryId', 'errorCode', 'errorMessage', 'standardError', 'validationError', 'billing']) })))}`);
  add('阅读索引.md', '阅读索引', `# ${plain(state.config.name)} · 阅读索引\n\n${label}\n\n先阅读项目摘要，再看方案、资产、蓝图与当前稿别；审校报告列出未解决问题。运行记录用于任务与账务核对；data/ 是原始调用证据，不是阅读稿。\n\n${paths.filter(p => !p.path.endsWith('.json')).map(p => `- [${plain(p.title)}](${relative(safePath(root, base), p.path).split('/').map(encodeURIComponent).join('/')})`).join('\n')}\n\n## 下一步\n\n${renderNext(next(state, root))}`);
  const index = { projectId: state.projectId, revision: state.revision, qualityAccepted: v.quality.qualityAccepted, generatedAt: now(), files: paths.map(p => ({ ...p, sha256: createHash('sha256').update(readFileSync(p.path)).digest('hex') })) };
  atomic(root, `${base}/index.json`, json(index));
  atomic(root, 'artifacts.json', json(index));
  return { artifacts: paths, index: safePath(root, `${base}/index.json`), qualityAccepted: v.quality.qualityAccepted };
}

export function execute(action, options) {
  need(options['business-code'] === undefined || action === 'prepare', 'Business code is only valid for prepare');
  need(text(options.project), '--project is required');
  const root = resolve(options.project);
  const rootStat = lstatSync(root, { throwIfNoEntry: false });
  need(!rootStat?.isSymbolicLink(), 'Project must not be a symlink; select the actual project directory');
  need(!rootStat || rootStat.isDirectory(), 'Project path is a file, not a directory');
  if (action === 'init') mkdirSync(root, { recursive: true, mode: 0o700 });
  need(rootStat || action === 'init', 'Project directory does not exist');
  const lock = safePath(root, '.project.lock');
  let fd;
  try { fd = openSync(lock, 'wx', 0o600); }
  catch (error) { if (error.code === 'EEXIST') throw new Error('Project is locked; wait for the writer. If it crashed, inspect .project.lock and confirm no writer before removing that exact lock file.'); throw error; }
  try {
    writeFileSync(fd, json({ pid: process.pid, action, at: now() }));
    const statePath = safePath(root, 'state.json');
    if (action === 'init') {
      need(!existsSync(statePath), 'Project already exists; use status/next, never reinitialize');
      const config = readJSON(options.config); checkConfig(config);
      need(config.mode !== 'ADAPT' || config.sourceScope, 'New ADAPT projects require user-confirmed sourceScope; see references/adaptation.md');
      need(scopedBrief(config).length <= 12000, 'brief plus source scope exceeds 12000 characters');
      const state = { schemaVersion: VERSION, runtimeVersion: RUNTIME.runtimeVersion, projectId: randomUUID(), config, configDigest: hash(config), revision: 0, createdAt: now(), pending: null, calls: {}, snapshots: {}, rounds: [], view: emptyView(), events: [] };
      save(root, state, { action }); return { project: root, next: next(state, root) };
    }
    const state = readJSON(statePath);
    need([1, 2, 3, 4, 5, 6, 7, VERSION].includes(state.schemaVersion), 'Unsupported project state version');
    checkConfig(state.config, { allowLegacyGoal: true });
    need(hash(state.config) === state.configDigest, 'Project config digest mismatch; do not change locked requirements or recipes in place');
    if (options.revision !== undefined) need(Number(options.revision) === state.revision, 'Stale project revision; reload status before writing');
    const v = state.view;
    // Reserve a new export revision when the renderer/runtime changes; preserve prior reading files.
    // v8 fences writers that ignore scoped, user-confirmed blueprint false-positive releases.
    if (action === 'export' && (state.schemaVersion !== VERSION || state.runtimeVersion !== RUNTIME.runtimeVersion)) {
      save(root, state, { action: 'upgrade-runtime', fromSchemaVersion: state.schemaVersion, fromRuntimeVersion: state.runtimeVersion || 'unknown' });
    }
    // Old accepted journals with non-overlapping scans cannot export a current all-season acceptance.
    // This read-time projection does not resubmit or rewrite historical receipts.
    if (v.quality.qualityAccepted && (((!v.quality.acceptance?.reviewCoverage || v.quality.acceptance.reviewCoverage.complete) && !reviewCoverage(state, root).complete)
      || qualityIssues(root, state).some(issue => !softLengthAdvisory(issue) && !v.quality.acceptance?.acceptedIssueIds?.includes(issue.id)))) {
      v.quality = invalidateQuality(v.quality);
      if (v.stage === 'QUALITY_ACCEPTED') v.stage = 'REVIEW_SCANNED';
      if (action === 'export') save(root, state, { action: 'invalidate-legacy-review-acceptance' });
    }
    if (action === 'attribution-context') return { invocationContext: workflowContext?.readWorkflowContext(root) ?? null };
    if (action === 'status' || action === 'next') return { projectId: state.projectId, revision: state.revision, stage: v.stage, reviewEpoch: v.reviewEpoch || 0, reviewCoverage: reviewCoverage(state, root), deliveryReceipt: v.deliveryReceipt || null, sourceCoverage: sourceCoverage(state), ...(state.config.languagePlan ? { languagePlan: clone(state.config.languagePlan), draftKind: delivery(state) ? 'DELIVERY' : 'WORKING', workingEpisodes: Object.keys(v.workingDraft?.episodes || (!delivery(state) ? v.episodes : {})).map(Number) } : {}), episodes: episodeNumbers(state), manuscripts: manuscriptProgress(state, root), next: next(state, root), quality: v.quality, findings: qualityIssues(root, state), billingSummary: projectBilling(root, state), rounds: state.rounds, snapshots: state.snapshots, pending: state.pending ? state.calls[state.pending] : null };
    if (action === 'display-names') {
      const assets = v.assets ? output(root, v.assets) : {};
      if (!options.names) return { localOnly: true, assetsDigest: v.assets?.digest || null,
        characters: assets.characters || [], presentation: state.presentation || null,
        instruction: 'Optional reading labels only. Use exact canonicalName with displayNames.zh/en and a provenance note; unknown names keep their original label. No paid call or identity change.' };
      need(v.assets && text(options.note), 'Display mapping requires current assets and a provenance note');
      const names = readJSON(options.names); safeData(names);
      need(object(names) && Object.keys(names).length === 1 && Array.isArray(names.characters), 'Expected {characters:[{canonicalName,displayNames:{zh?,en?}}]}');
      const seen = new Set();
      for (const row of names.characters) {
        need(object(row) && Object.keys(row).length === 2 && text(row.canonicalName)
          && !seen.has(row.canonicalName) && (assets.characters || []).filter(c => c.canonicalName === row.canonicalName).length === 1,
        'Use each unambiguous, existing canonicalName once; no identity renaming');
        seen.add(row.canonicalName);
        need(object(row.displayNames) && Object.keys(row.displayNames).length > 0
          && Object.entries(row.displayNames).every(([key, value]) => ['zh', 'en'].includes(key) && text(value)
            && value.length <= 300 && !/[\u0000-\u001f\u007f-\u009f]/u.test(value)), 'Display labels must be nonempty single-line zh/en strings, at most 300 characters');
      }
      state.presentation = { assetsDigest: v.assets.digest, characters: clone(names.characters), note: options.note, at: now() };
      save(root, state, { action, note: options.note });
      return { localOnly: true, newCalls: 0, presentation: state.presentation, next: next(state, root) };
    }
    if (action === 'plan') {
      const plan = executionPlan(state, root);
      if (options.review || options.issues) {
        const repair = repairPlan(root, state, options.review, options.issues);
        plan.repair = { reviewCallId: repair.review.callId, issueIds: repair.issueIds, rescanBatches: repair.rescanBatches,
          maxScanCalls: repair.maxScanCalls, fixCalls: 1, price: 'Obtain live FIX quote and a separately labeled optional rescan estimate; confirm FIX-only maximum or an explicitly chosen combined maximum before execution.' };
      }
      return plan;
    }
    if (action === 'issues') {
      const { episodes, ...report } = localIssues(root, state);
      return { ...report, revision: state.revision, localOnly: true, newCalls: 0, semanticVerification: 'CALLER_REVIEW_ONLY' };
    }
    if (['triage', 'issue-decision', 'revise-local', 'check-continuity'].includes(action)) {
      need(!state.pending, 'Resolve the original pending task before local assessment or revision');
      const context = localIssues(root, state);
      const report = options.report ? readJSON(options.report) : undefined;
      if (report) safeData(report);
      if (action === 'triage') {
        const current = triageReport(context, report);
        v.issueLedger = [...(v.issueLedger || []).filter(i => i.scopeDigest !== context.binding.scopeDigest), ...current];
        invalidateLocalQuality(v);
        save(root, state, { action, report: store(root, report) });
      } else if (action === 'issue-decision') {
        need(options.revision !== undefined, 'Issue decision requires the reviewed --revision');
        const item = decideIssue(context, options.issue, options.decision, options.note, report);
        v.issueLedger = v.issueLedger.map(old => old.id === item.id && old.scopeDigest === item.scopeDigest ? item : old);
        invalidateLocalQuality(v);
        save(root, state, { action, issueId: item.id, decision: item.decision });
      } else if (action === 'check-continuity') {
        const check = localContinuity(root, state);
        need(check, 'No manuscript revision requires continuity recheck');
        if (!report) return { ...check, localOnly: true, newCalls: 0, semanticVerification: 'CALLER_REVIEW_ONLY' };
        const checked = continuityReport(check, report);
        // Conflicts remain actionable even if the manuscript itself contained no warnings.
        const findings = checked.checks.filter(row => row.status !== 'CONSISTENT').map(row => ({
          id: `continuity_${check.binding.revisionDigest.slice(0, 12)}_${row.episodeNumber}`, signalIds: [], requiresDecision: true, severity: row.status === 'CONFLICT' ? 'CORE' : 'UNCERTAIN',
          category: 'CONTINUITY', title: `Revision impact on episode ${row.episodeNumber}`, explanation: row.explanation,
          evidence: row.evidence, scopeDigest: context.binding.scopeDigest,
        }));
        need(!check.complete, 'Continuity assessment already recorded; resolve its findings with issue-decision or make a new authorized revision');
        v.issueLedger = [...(v.issueLedger || []), ...findings]; v.continuityCheck.report = checked;
        invalidateLocalQuality(v);
        save(root, state, { action, report: store(root, report) });
      } else {
        const requested = v.reviewRequest && reviewPlan(state, root, v.reviewRequest.numbers);
        const completedReview = requested && !requested.blocked && requested.batches.length > 0
          && requested.batches.every(numbers => v.reviews.some(r => currentReview(state, r, numbers)));
        need(!v.stop && !v.fix && !v.afterFix && !v.repairDecision && (!v.reviewRequest || completedReview)
          && (!v.awaiting || v.awaiting.type === 'mid-review'), 'Finish or explicitly withdraw active review/repair before local correction');
        const plan = revisionPlan(context, report, language(state));
        for (const [n, ep] of Object.entries(plan.changed)) validateOutput('episode', ep, { episodeNumber: Number(n) }, state);
        const changedEpisodes = Object.keys(plan.changed).map(Number), retainedEpisodes = episodeNumbers(state).filter(n => !changedEpisodes.includes(n));
        if (options.decision === undefined) return { preview: true, revision: state.revision, planDigest: plan.planDigest,
          changedEpisodes, retainedEpisodes, continuityCheckEpisodes: episodeNumbers(state).filter(n => n >= Math.min(...changedEpisodes)),
          edits: plan.proposal.edits, localOnly: true, newCalls: 0 };
        need(options.decision === 'confirm' && text(options.note) && !/^(继续|好的?|continue|ok)[.!！。\s]*$/i.test(options.note.trim()), 'Local revision requires explicit approval of the exact edits');
        need(options.revision !== undefined && options['plan-digest'] === plan.planDigest, 'Local revision needs matching preview revision and plan digest');
        const snapshotId = checkpoint(root, state, 'Before approved local manuscript correction'), before = clone(v.episodes);
        const proposal = store(root, plan.proposal);
        for (const [n, ep] of Object.entries(plan.changed)) v.episodes[n] = store(root, { output: ep, provenance: {
          kind: 'LOCAL_REVISION', basedOn: before[n], proposal, note: options.note,
          statisticsBasis: 'LOCAL_DERIVED', warningsBasis: 'INHERITED_EVIDENCE_NOT_RESCANNED',
        } });
        (v.localRevisions ||= []).push({ snapshotId, changedEpisodes, retainedEpisodes, proposal, note: options.note });
        startContinuityCheck(state, before, changedEpisodes, plan.proposal.reason);
        v.quality = invalidateQuality(v.quality); v.deliveryReceipt = null; v.reviewSkipped = null;
        // A fulfilled review request cannot authorize another paid SCAN after this local edit.
        if (completedReview) v.reviewRequest = null;
        v.stage = episodeNumbers(state).length === state.config.episodeCount ? 'EPISODES_WRITTEN' : 'WRITING';
        save(root, state, { action, snapshotId, proposal, changedEpisodes, note: options.note });
        return { preview: false, revision: state.revision, snapshotId, changedEpisodes, retainedEpisodes, next: next(state, root), localOnly: true, newCalls: 0 };
      }
      return { revision: state.revision, next: next(state, root), localOnly: true, newCalls: 0 };
    }
    if (action === 'source-facts') {
      need(options.facts && options.out, 'source-facts requires --facts and --out');
      const config = sourceFactsConfig(state.config, readJSON(options.facts), frozenSource(root, state));
      checkConfig(config);
      const requested = resolve(options.out), target = join(realpathSync(dirname(requested)), basename(requested));
      const rel = relative(realpathSync(root), target);
      need(isAbsolute(rel) || rel === '..' || rel.startsWith('../') || rel.startsWith('..\\'), 'Write the proposed config outside the managed project directory');
      need(target.endsWith('.json'), 'Proposed config must be a new .json file');
      writeFileSync(target, json(config), { flag: 'wx', mode: 0o600 });
      return { configFile: target, facts: parseSourceFacts(config.episode.contentConstraints), localOnly: true, newCalls: 0,
        instruction: 'Proposed full config only; project unchanged. Review evidence, interpretation, mapping and the complete replacement ledger with the user. Apply through reopen --from source|concept --config, then inspect prepared requirements. This does not authorize a paid call.' };
    }
    if (action === 'check-facts') {
      need(v.concepts && !state.pending, 'A completed current concept result with no pending call is required');
      const call = state.calls[options.call];
      need(call?.operator === PREFIX + 'concept' && call.status === 'SUCCEEDED' && call.result?.digest === v.concepts.digest, 'Use the current successful concept call, not a historical candidate');
      const facts = verifyProjectFacts(root, state), input = load(root, call.input), result = output(root, call.result);
      need(facts.length && eq(facts, parseSourceFacts(input.requirements?.contentConstraints)), 'Current concept input must contain the same verified source facts');
      const binding = { projectId: state.projectId, callId: call.id, configDigest: state.configDigest, inputDigest: call.input.digest, outputDigest: hash(result), sourceDecisionsDigest: hash(v.sourceDecisions || []) };
      if (!options.report) return { binding, facts, conceptIds: result.concepts.map(c => c.id), localOnly: true, newCalls: 0,
        instruction: 'Read source evidence and actual candidates. Prepare one check per fact/candidate; see references/source-facts.md. No checks have been performed yet.' };
      const report = readJSON(options.report); safeData(report);
      return { ...checkFactReview({ binding, facts, output: result, decisions: v.sourceDecisions || [] }, report), localOnly: true, newCalls: 0 };
    }
    if (action === 'check-upstream') {
      need(!state.pending, 'Use a project with no pending call');
      const context = upstreamContext(root, state, options.call), { binding, stage, facts, decisions, authority } = context;
      if (!options.report) return { binding, stage, topics: upstreamTopics(facts, decisions), authority, localOnly: true, newCalls: 0,
        instruction: 'Read authoritative evidence and actual assets/beats, including actions outside the key-fact list. Write the local report described in references/source-facts.md; no semantic checks have been performed.' };
      const report = readJSON(options.report); safeData(report);
      const review = checkUpstreamReview(context, report);
      const conflicts = stage === 'blueprint' ? blueprintConflictState(root, state) : { unresolved: [], resolutions: [] };
      return { ...review, readyForConfirmation: !review.blockedTopics.length && !conflicts.unresolved.length,
        unresolvedServerConflicts: conflicts.unresolved.map(c => c.riskId), falsePositiveResolutions: conflicts.resolutions, localOnly: true, newCalls: 0 };
    }
    if (action === 'resolve-blueprint-conflict') {
      need(!state.pending && !v.stop && !v.fix && !v.afterFix && !v.repairDecision && !v.reviewRequest,
        'Resolve the pending call, stop, review or repair before a false-positive release');
      need(v.awaiting?.type === 'blueprint', 'False-positive release requires the blueprint confirmation stop');
      need(options.report, 'Provide the complete upstream evidence report');
      const context = upstreamContext(root, state, options.call), report = readJSON(options.report); safeData(report);
      const proof = blueprintConflictProof(context, report, options.risk, options.reason);
      need(blueprintConflictState(root, state).unresolved.some(c => c.riskId === options.risk), 'This conflict already has a current resolution');
      const scopeDigest = conflictScope(state);
      const planDigest = hash(canonical({ revision: state.revision, scopeDigest, report, proof }));
      if (options.decision === undefined) {
        need(options.note === undefined, 'Preview takes no user approval note');
        return { preview: true, revision: state.revision, planDigest, proof, localOnly: true, newCalls: 0 };
      }
      need(options.decision === 'confirm-false-positive' && text(options.note) && options.note.trim().length >= 10 && options.note.length <= 2000
        && !/^(继续|开始|下一步|好的?|同意|continue|next|ok|okay|yes|confirm)[.!！。\s]*$/i.test(options.note.trim()),
      'Explicit user approval of this exact false positive is required, not continue or general stage delegation');
      need(options.revision !== undefined && options['plan-digest'] === planDigest, 'False-positive release requires the matching preview revision and plan digest');
      safeData(options.note); safeData(proof);
      const snapshotId = checkpoint(root, state, `Before false-positive release: ${options.risk}`);
      const resolution = store(root, { kind: 'USER_CONFIRMED_FALSE_POSITIVE', scopeDigest, riskId: options.risk,
        report, proof, planDigest, note: options.note, at: now(), snapshotId });
      (v.blueprintConflictResolutions ||= []).push(resolution);
      v.awaiting.conflicts = blueprintConflictState(root, state).unresolved;
      v.awaiting.falsePositiveResolutions = blueprintConflictState(root, state).resolutions;
      v.quality = invalidateQuality(v.quality);
      save(root, state, { action, riskId: options.risk, resolution, snapshotId, note: options.note });
      return { preview: false, revision: state.revision, snapshotId, resolution, next: next(state, root), localOnly: true, newCalls: 0,
        instruction: 'Original CONFLICT and all artifacts retained. Only this bound local blocker is released; blueprint still needs confirmation. No new requirement, paid review/retry or final quality acceptance is authorized. Export the evidence record.' };
    }
    if (action === 'export') return exportProject(root, state);
    if (action === 'reopen') {
      const plan = reopenPlan(root, state, options);
      verifyProjectFacts(root, state, plan.config);
      if (options.decision === undefined) {
        need(options.note === undefined, 'Preview takes no decision note; use --decision confirm to apply');
        return { preview: true, ...plan.report };
      }
      need(options.decision === 'confirm' && text(options.note), 'Reopen requires explicit --decision confirm and a real user --note');
      need(options.revision !== undefined, 'Reopen requires --revision from the reviewed preview');
      need(options['plan-digest'] === plan.report.planDigest, 'Reopen plan changed; preview the exact config and use its --plan-digest');
      safeData(options.note);
      const snapshotId = checkpoint(root, state, `Before upstream reopening: ${options.from}`);
      if (plan.report.changedConfigFields.length && !state.legacySnapshotConfig) state.legacySnapshotConfig = store(root, state.config);
      state.config = plan.config; state.configDigest = hash(plan.config); state.view = plan.view;
      save(root, state, { action, from: options.from, snapshotId, note: options.note, changedConfigFields: plan.report.changedConfigFields });
      return { ...plan.report, preview: false, revision: state.revision, snapshotId, next: next(state, root),
        instruction: 'Local boundary reopened and prior view/config checkpointed. Export a fresh revision. Confirm source decisions when prompted; any new operator call needs a fresh quote and authorization. Undo restores this snapshot without erasing history or refunding charges.' };
    }
    if (action === 'bind-source-upload') {
      need(id(options.call) && state.pending === options.call, 'Upload must bind the current pending call');
      const call = state.calls[options.call];
      need(call.sourceBindingVersion === 1 && call.operator === PREFIX + 'source-analyze', 'Call has no local source upload to bind');
      const raw = readJSON(options['upload-result']);
      need(object(raw) && raw.status === 'AVAILABLE' && id(raw.fileId) && /^[a-f0-9]{64}$/.test(raw.sha256)
        && Number.isSafeInteger(raw.sizeBytes) && raw.sizeBytes > 0, 'Expected an AVAILABLE CLI upload receipt with fileId, sha256 and sizeBytes');
      const upload = pick(raw, ['fileId', 'status', 'sha256', 'sizeBytes']);
      if (call.sourceUpload) {
        need(eq(call.sourceUpload, upload), 'Source upload is already bound; fileId cannot change after binding or quote');
        need(eq(readJSON(safePath(root, call.inputFile)), load(root, call.input)), 'Prepared source input changed');
        const canQuote = ['PREPARED', 'WAITING_CONFIRMATION'].includes(call.status) && !call.jobId && !call.recoveryId && !call.observedActive;
        return { duplicate: true, callId: call.id, ...(canQuote ? { cli: preparedCli(root, call) } : { next: next(state, root) }) };
      }
      need(call.status === 'PREPARED' && !call.jobId && !call.recoveryId && !call.observedActive && !call.result,
        'Bind the source upload before any quote, submission or recovery');
      const sourcePath = safePath(root, call.sourceInspection.file);
      const inspected = inspectSource(sourcePath);
      need(inspected.report.sha256 === call.sourceInspection.sha256 && inspected.report.bytes === call.sourceInspection.bytes,
        'Frozen source changed; do not bind or submit it');
      need(upload.sha256 === inspected.report.sha256 && upload.sizeBytes === inspected.report.bytes, 'Upload receipt does not match frozen source bytes');
      const input = load(root, call.input);
      need(eq(readJSON(safePath(root, call.inputFile)), input) && !input.sourceFileId, 'Prepared source input changed');
      input.sourceFileId = upload.fileId;
      call.input = store(root, input); atomic(root, call.inputFile, json(input)); call.sourceUpload = upload;
      save(root, state, { action, callId: call.id });
      return { callId: call.id, operator: call.operator, inputFile: safePath(root, call.inputFile), cli: preparedCli(root, call),
        sourceUpload: upload, sourceUploadRequired: false,
        instruction: 'Use the returned fixed-input CLI arguments through ACCESS for quote and confirmation. Never append --file, re-upload or substitute a cached fileId. Upload is not authorization for a paid call.' };
    }
    if (action === 'prepare') {
      const step = next(state, root); need(step.kind === 'operator', `Cannot prepare: ${step.kind}${step.reason ? `; ${step.reason}. ${step.instruction || ''}` : ''}`);
      const input = buildInput(root, state, step, options.params ? readJSON(options.params) : {});
      const sourceCall = step.operator === PREFIX + 'source-analyze';
      let sourceInspection, sourceFile;
      if (sourceCall) {
        need(state.config.sourceScope, 'Legacy source scope is unknown; preserve existing calls and use a new scoped project for a new source analysis');
        if (options['source-file']) {
          need(!input.sourceFileId && !options['source-unchecked-note'], 'Use a local source-file OR an existing sourceFileId, never both');
          const inspected = inspectSource(options['source-file']);
          need(inspected.report.status === 'READY', `Source preflight: ${inspected.report.status}; select a smaller complete chapter/scene range or extract verified UTF-8 text first`);
          sourceInspection = inspected.report;
          if (options['source-selection']) {
            sourceInspection.selection = checkSelection(readJSON(options['source-selection']), inspected.report);
            const { original, selected } = sourceInspection.selection;
            need(original.sha256 === selected.sha256 || state.config.sourceScope.kind === 'EXCERPT', 'A selected excerpt must use sourceScope.kind EXCERPT');
          }
          sourceInspection.file = `source-files/${inspected.report.sha256}${inspected.report.extension}`;
          sourceFile = atomic(root, sourceInspection.file, inspected.bytes);
        } else {
          need(input.sourceFileId && !options['source-selection'] && text(options['source-unchecked-note']) && options['source-unchecked-note'].length <= 1000,
            'Source analysis requires --source-file, or authorized sourceFileId plus --source-unchecked-note explaining unverified local capacity');
          sourceInspection = { status: 'REMOTE_UNCHECKED', note: options['source-unchecked-note'] };
        }
        safeData(sourceInspection);
      } else need(!['source-file', 'source-selection', 'source-unchecked-note'].some(key => options[key] !== undefined), 'Source options only apply to source-analyze');
      const enabled = attributionEnabled(), bound = workflowContext?.readWorkflowContext(root);
      if (bound && !state.skillRunId) state.skillRunId = bound.skillRunId;
      need(options['business-code'] === undefined || (enabled && workflowContext), 'Business context requires a complete attribution-enabled package');
      if (enabled && workflowContext && !bound && Object.keys(state.calls).length) need(options['business-code'], 'Legacy project: confirm --business-code for subsequent new calls; preserve historical receipts');
      const stepCode = step.operator.slice(PREFIX.length) + (step.action ? '-' + step.action.toLowerCase().replaceAll('_', '-') : '');
      let attribution = workflowAttributionArgs(state, stepCode, enabled);
      if (enabled && workflowContext) attribution = workflowContext.workflowContextArgs({ project: root, skillRunId: state.skillRunId, stepCode, operator: step.operator, action: step.action, businessCode: options['business-code'] });
      const accessArgs = [...(attribution.includes('--business-code') ? ['--business-code', attribution[attribution.indexOf('--business-code') + 1]] : []),
        ...(projectEnvironment ? projectEnvironment.prepareProjectAccess(root) : [])];
      const callId = randomUUID(), inputRef = store(root, input);
      const inputFile = atomic(root, `calls/${callId}/input.json`, json(input));
      state.calls[callId] = { id: callId, ...(projectEnvironment ? { accessArgs } : {}), outputContractVersion: 1, operator: step.operator, input: inputRef, inputFile: `calls/${callId}/input.json`, ...(step.episodeNumber ? { episodeNumber: step.episodeNumber } : {}), ...(sourceInspection ? { sourceInspection } : {}), ...(sourceFile ? { sourceBindingVersion: 1 } : {}), attributionArgs: attribution, ...(step.action === 'SCAN' ? { reviewEpoch: v.reviewEpoch || 0 } : {}), status: 'PREPARED', createdAt: now() };
      state.pending = callId;
      save(root, state, { action, callId });
      const cli = preparedCli(root, state.calls[callId]);
      return { callId, operator: step.operator, inputFile, ...(step.repairApproval ? { repairApproval: step.repairApproval } : {}),
        ...(sourceInspection ? { sourceInspection } : {}), ...(sourceFile ? { sourceUpload: { cli: { ...cli, args: ['upload', sourceFile, '--json'] } } } : { cli }),
        sourceUploadRequired: Boolean(sourceFile),
        instruction: sourceFile ? 'Upload the frozen source using sourceUpload.cli through ACCESS, then bind-source-upload before any quote. Keep the original upload receipt outside exports; only fileId/hash/size are saved. Do not run with --file.'
          : 'Check the current operator contract, execute cli.args unchanged through the tool adapter in references/cli.md. Record stdout/exit code and receipt. Cost confirmation remains separate user authorization. For repairApproval, compare live quotes and prior repair charges against the combined maximum before each confirmation; no hidden follow-up charges.' };
    }
    if (action === 'record') {
      need(id(options.call) && state.calls[options.call], 'Unknown call ID');
      const call = state.calls[options.call];
      need(call.sourceBindingVersion !== 1 || call.sourceUpload, 'Bind the source upload before recording an operator call');
      const exitCode = Number(options['exit-code']);
      need(Number.isInteger(exitCode) && exitCode >= 0 && exitCode <= 255, '--exit-code required');
      if (options['submission-evidence'] !== undefined) {
        // Separate human-verified evidence from unmodified CLI stdout; never synthesize a CLI receipt.
        need(exitCode === 1 && options.result === undefined && options['recovery-id'] === undefined && options.stderr === undefined && options['repair-recovery'] === undefined,
          'Manual quote evidence requires exit-code 1 and no result/recovery-id');
        need(state.pending === call.id && !call.jobId && !call.recoveryId && !call.observedActive && call.billing === undefined,
          'Manual quote evidence cannot downgrade accepted or uncertain work with a recovery ID');
        need(eq(readJSON(safePath(root, call.inputFile)), load(root, call.input)), 'Prepared input changed; do not alter a quoted or submitted call');
        const proof = readJSON(options['submission-evidence']);
        need(object(proof) && Object.keys(proof).every(key => ['callId', 'operatorCode', 'inputDigest', 'phase', 'outcome', 'evidence'].includes(key))
          && proof.callId === call.id && proof.operatorCode === call.operator
          && proof.inputDigest === hash(canonical(load(root, call.input)))
          && proof.phase === 'QUOTE' && proof.outcome === 'NOT_SUBMITTED' && text(proof.evidence) && proof.evidence.length <= 4000,
        'Manual quote evidence must bind this call, operator and original canonical input digest; verify the actual pre-submit phase, not merely missing IDs');
        safeData(proof);
        if (call.status === 'NOT_SUBMITTED' && call.submissionEvidenceOrigin === 'MANUAL_PRE_SUBMIT') {
          need(eq(load(root, call.submissionEvidence), proof), 'Recorded manual evidence cannot be overwritten');
          return { duplicate: true, next: next(state, root) };
        }
        need(['PREPARED', 'UNKNOWN', 'WAITING_CONFIRMATION'].includes(call.status), 'Manual quote evidence cannot downgrade accepted or uncertain work in another status');
        call.submissionEvidence = store(root, proof); call.submissionEvidenceOrigin = 'MANUAL_PRE_SUBMIT';
        call.status = 'NOT_SUBMITTED';
        // Keep any previous raw result and the pending call. Only an explicit user decision may clear it.
        save(root, state, { action: 'record-unsubmitted', callId: call.id, status: call.status, exitCode });
        return { callId: call.id, status: call.status, next: next(state, root) };
      }
      const raw = options.result ? readJSON(options.result) : {};
      const result = publicResult(raw), status = typeof result.status === 'string' ? result.status.toUpperCase() : '';
      need(!result.jobId || !result.job_id || result.jobId === result.job_id, 'Conflicting job IDs');
      const jobId = result.jobId || result.job_id;
      const previousRecoveryId = call.recoveryId, previousJobId = call.jobId;
      const markers = recoveryMarkers(options.stderr);
      if (markers.jobId && (jobId || call.jobId)) need(markers.jobId === (jobId || call.jobId), 'CLI stderr job ID mismatch');
      if (jobId !== undefined) { need(id(jobId), 'Invalid job ID'); need(!call.jobId || call.jobId === jobId, 'Job ID changed'); call.jobId = jobId; }
      if (result.operatorCode !== undefined) need(result.operatorCode === call.operator, 'Operator mismatch');
      if (result.apiCode !== undefined) need(result.apiCode === call.operator, 'Operator mismatch');
      const mistakenCallId = options['recovery-id'] === call.id;
      const explicitRecoveryId = mistakenCallId ? undefined : options['recovery-id'];
      if (markers.recoveryId && explicitRecoveryId) need(markers.recoveryId === explicitRecoveryId, 'CLI stderr recovery ID mismatch');
      const recoveryId = markers.recoveryId || explicitRecoveryId;
      const recoveryNotice = mistakenCallId ? 'Local callId is not a CLI recovery ID; ignored. Use original run stderr or the original CLI recovery ID; never re-submit unknown work.' : undefined;
      const repairRecovery = options['repair-recovery'] !== undefined;
      if (repairRecovery) {
        need(options['repair-recovery'] === 'confirmed' && (previousRecoveryId === call.id || previousRecoveryId === markers.recoveryId)
          && markers.recoveryId && markers.recoveryId !== call.id && previousJobId && jobId === previousJobId
          && markers.jobId === previousJobId && call.status === 'SUCCEEDED',
        'Recovery repair requires a completed call with the mistaken local callId, original CLI stderr and identical job receipt');
      }
      if (recoveryId) {
        need(id(recoveryId) && recoveryId !== call.id, 'Invalid CLI recovery ID');
        need(!call.recoveryId || call.recoveryId === recoveryId || repairRecovery, 'Recovery ID changed');
        call.recoveryId = recoveryId;
      }
      const recoveryUpdated = previousRecoveryId !== call.recoveryId;
      const original = call.result ? load(root, call.result) : null;
      const originalStatus = original?.status?.toUpperCase();
      const terminalSaved = original && !original._timeout && (call.status === 'SUCCEEDED'
        || (previousJobId && failedStates.includes(originalStatus)) || (call.status === 'ABANDONED' && originalStatus === 'SUCCEEDED'));
      if (terminalSaved) {
        const identical = eq(original, result);
        need(originalStatus !== 'SUCCEEDED' || status !== 'SUCCEEDED' || exitCode === 0, 'Successful terminal receipt requires exit-code 0');
        need(identical || (previousJobId && jobId === previousJobId), 'Terminal receipt refresh requires the identical original job ID');
        need(identical || ((status === originalStatus || activeStates.includes(status))
          && !result._timeout && [0, 1].includes(exitCode)), 'Terminal result cannot be overwritten with a conflicting or unknown status');
        need(identical || result.output == null || (original.output !== undefined && eq(original.output, result.output)), 'Completed call cannot be overwritten with a different result output');
        if (recoveryUpdated) {
          need(markers.recoveryId && markers.jobId === previousJobId, 'Completed recovery binding requires original CLI stderr matching the saved job');
        }
        const duplicate = receiptRefs(call).some(ref => eq(load(root, ref), result));
        if (!duplicate || recoveryUpdated) {
          retainReceipt(root, call, result);
          // Later queries may add the first public uncertainty diagnosis. Never lose it to a sparse query.
          if (unconfirmedOutcome(result)) {
            const priorError = call.standardError;
            Object.assign(call, pick(result, ['errorCode', 'errorMessage', 'standardError']));
            if (priorError && result.standardError) call.standardError = { ...priorError, ...result.standardError,
              suggestedActions: [...new Set([...(priorError.suggestedActions || []), ...(result.standardError.suggestedActions || [])])] };
          }
          save(root, state, { action: repairRecovery ? 'repair-recovery' : 'record-receipt-query', callId: call.id,
            observedStatus: status, preservedStatus: call.status, recoveryId: call.recoveryId, jobId: previousJobId });
        }
        return { duplicate, receiptOnly: true, callId: call.id, status: call.status,
          ...(recoveryUpdated ? { recoveryUpdated: true, recoveryId: call.recoveryId } : {}), ...(recoveryNotice ? { recoveryNotice } : {}),
          billingSummary: projectBilling(root, state), next: next(state, root) };
      }
      need(state.pending === call.id, 'Call is not the current pending call');
      need(eq(readJSON(safePath(root, call.inputFile)), load(root, call.input)), 'Prepared input changed; do not alter a quoted or submitted call');
      if (['REJECTED', 'NOT_SUBMITTED'].includes(status)) {
        need(exitCode === 1 && result.schemaVersion === 'mantur.cli.submission.v1'
          && Object.keys(raw).every(key => ['schemaVersion', 'operatorCode', 'inputDigest', 'status', 'submission',
            'errorCode', 'errorMessage', 'reason', 'traceId', 'recoveryId'].includes(key))
          && text(result.errorCode) && text(result.errorMessage)
          && result.operatorCode === call.operator && result.inputDigest === hash(canonical(load(root, call.input)))
          && !call.jobId && !call.observedActive && !result.invocationId && result.output === undefined
          && !result.billing && !result._billing && !result._timeout,
        'Rejection must match the original input and cannot downgrade an accepted or active task');
        const proof = result.submission;
        need(object(proof) && Object.keys(proof).every(key => ['phase', 'outcome', 'evidence', 'httpStatus'].includes(key))
          && proof.outcome === status && Number.isInteger(proof.httpStatus), 'Invalid rejection evidence');
        if (status === 'NOT_SUBMITTED') {
          need(proof.phase === 'QUOTE' && proof.evidence === 'CLI_PRE_SUBMIT' && proof.httpStatus >= 400 && proof.httpStatus <= 599
            && !call.recoveryId && !result.recoveryId, 'Quote failure cannot clear a prior uncertain submission');
        } else {
          need(proof.phase === 'INVOKE' && proof.evidence === 'SERVER_ADMISSION' && proof.httpStatus === 422
            && result.errorCode === 'AGENT_INPUT_SCHEMA_INVALID' && id(result.recoveryId)
            && call.recoveryId === result.recoveryId, 'Missing server admission rejection or matching recovery ID');
        }
        call.status = status; call.result = store(root, result);
        Object.assign(call, pick(result, ['errorCode', 'errorMessage', 'reason']));
        save(root, state, { action, callId: call.id, status, exitCode });
        return { callId: call.id, status, next: next(state, root) };
      }
      Object.assign(call, pick(result, ['errorCode', 'errorMessage', 'standardError']));
      retainReceipt(root, call, result);
      if (result.billing || result._billing) call.billing = clone(result.billing || result._billing);
      if (activeStates.includes(status)) call.observedActive = true;
      // CLI --no-wait may return a terminal submission receipt without the result.
      // Recognize only the CLI's canonical job route; never persist or follow a supplied URL.
      const needsResultFetch = status === 'SUCCEEDED' && exitCode === 0 && !result._timeout
        && result.output == null && jobId && raw.pollUrl === `/api/openapi/v1/jobs/${encodeURIComponent(jobId)}`;
      if (needsResultFetch) {
        call.status = 'NEEDS_RESULT_FETCH'; call.result = store(root, result);
      } else if (status === 'SUCCEEDED' && exitCode === 0 && !result._timeout) {
        try { validateOutput(call.operator.slice(PREFIX.length), result.output, load(root, call.input), state, call.outputContractVersion); }
        catch (error) {
          call.status = 'OUTPUT_INVALID'; call.result = store(root, result); call.validationError = error.message;
          save(root, state, { action, callId: call.id, status: call.status, exitCode });
          throw error;
        }
        call.status = 'SUCCEEDED'; call.result = store(root, result); state.pending = null;
        applyOutput(root, state, call, call.result);
      } else {
        call.result = store(root, result);
        call.status = result._timeout ? 'UNKNOWN' : exitCode === 3 && !jobId && !call.jobId && !call.recoveryId ? 'WAITING_CONFIRMATION' : failedStates.includes(status) ? status : activeStates.includes(status) ? status : 'UNKNOWN';
        // Even definite failure pauses; a new billable attempt requires a separately recorded decision.
      }
      save(root, state, { action, callId: call.id, status: call.status, exitCode });
      return { callId: call.id, status: call.status, ...(recoveryNotice ? { recoveryNotice } : {}), next: next(state, root) };
    }
    if (action === 'answer') {
      need(text(options.note), '--note must record the user decision (not an inferred approval)'); safeData(options.note);
      for (const option of ['source-decisions', 'source-risks']) if (options[option] !== undefined) need(!state.pending && v.awaiting?.type === 'source', `--${option} is only allowed at source confirmation`);
      const decision = options.decision;
      need(options.call === undefined || decision === 'retry-unconfirmed', '--call is only allowed for retry-unconfirmed');
      if (options['submission-evidence'] !== undefined) need(state.pending && decision === 'abandon', '--submission-evidence is only allowed when abandoning a verified unsubmitted call');
      if (decision === 'retry-unconfirmed') {
        const call = state.calls[options.call];
        const receipt = call?.result ? load(root, call.result) : null;
        need(call && unconfirmedOutcome(call) && call.jobId && !receipt?._timeout
          && failedStates.includes(receipt?.status?.toUpperCase())
          && (state.pending === call.id || (!state.pending && ['ABANDONED', ...failedStates].includes(call.status))),
        'Unconfirmed retry authorization must name the original terminal failed call; active/unknown submissions must resume');
        call.unconfirmedRetryAuthorization = { note: options.note, at: now(), jobId: call.jobId };
        call.retryDecision = { note: options.note, at: now() };
        if (state.pending === call.id) state.pending = null;
        save(root, state, { action, decision, callId: call.id, note: options.note });
        return { next: next(state, root), instruction: 'Only informed authorization for a new attempt was recorded; the original upstream outcome remains unconfirmed. This is not fee approval or permission to resubmit the old command. Obtain a fresh quote for a new call.' };
      }
      if (state.pending) {
        const call = state.calls[state.pending];
        const receipt = call.result ? load(root, call.result) : null;
        if (decision === 'cancel-quote') {
          need(call.status === 'WAITING_CONFIRMATION' && !call.jobId && !call.recoveryId, 'Only a confirmed unsubmitted quote may be canceled');
          call.status = 'QUOTE_DECLINED'; v.stop = 'User declined the quote; explicitly continue before preparing a fresh quote.';
          if (call.operator === PREFIX + 'review') skipReview(state, options.note);
        } else if (decision === 'abandon') {
          const admissionRejected = ['NOT_SUBMITTED', 'REJECTED'].includes(call.status);
          const terminalInvalid = call.status === 'OUTPUT_INVALID' && call.jobId && !receipt?._timeout && receipt?.status?.toUpperCase() === 'SUCCEEDED';
          const terminalFailure = call.jobId
            && failedStates.includes(call.status) && !receipt?._timeout && receipt?.status?.toUpperCase() === call.status;
          if (!terminalInvalid && !admissionRejected && !terminalFailure) {
            need(['PREPARED', 'UNKNOWN', 'WAITING_CONFIRMATION'].includes(call.status) && !call.jobId && !call.recoveryId && !call.observedActive, `Cannot abandon status=${call.status}; resume the original task`);
            const proof = options['submission-evidence'] ? readJSON(options['submission-evidence']) : null;
            need(object(proof) && Object.keys(proof).every(k => ['phase', 'outcome', 'evidence'].includes(k)) && ['NOT_STARTED', 'QUOTE'].includes(proof.phase) && proof.outcome === 'NOT_SUBMITTED' && text(proof.evidence), 'abandon requires verified pre-submission evidence (phase NOT_STARTED/QUOTE, outcome NOT_SUBMITTED, evidence); missing IDs alone are insufficient');
            safeData(proof); call.submissionEvidence = store(root, proof);
          }
          call.abandonedFrom = call.status; call.status = 'ABANDONED';
          v.stop = 'User abandoned local call; history retained. This does not cancel a server task or refund. Explicitly continue before a new quote/call.';
          if (call.operator === PREFIX + 'review') skipReview(state, options.note);
        } else need(decision === 'retry' && !unconfirmedOutcome(call) && !receipt?._timeout && ([...failedStates, 'NOT_SUBMITTED', 'REJECTED'].includes(call.status) || terminalInvalidForRetry(call, receipt)), `Pending/unknown submission cannot be discarded; status=${call.status}. ${pendingNext(call).instruction}`);
        call.retryDecision = { note: options.note, at: now() }; state.pending = null;
      } else if (['review', 'skip-review', 'continue-writing'].includes(decision)
        || (decision === 'continue' && next(state, root).kind === 'review-choice')) {
        need(episodeNumbers(state).length && (!v.awaiting || v.awaiting.type === 'mid-review') && !v.repairDecision, 'Finish the current stage/repair decision before choosing optional review');
        need(!v.stop || v.stop.startsWith('User declined') || v.stop.startsWith('User abandoned'), 'Resolve the stopped call first');
        if (decision === 'review') {
          const deferredFix = v.afterFix && (!v.afterFix.approval || v.afterFix.approval.followupReview === 'later');
          need(!v.stop && !v.fix && (!v.afterFix || deferredFix) && (!v.reviewRequest || deferredFix), 'Resolve or skip the existing review/repair before requesting another');
          need(deferredFix || !reviewCoverage(state, root).complete, 'Current manuscript is already scanned; a repeated paid scan requires explicit rescan');
          v.reviewRequest = { numbers: episodeNumbers(state), note: options.note, at: now() };
          if (deferredFix) v.afterFix.approval = { followupReview: 'confirmed', note: options.note, at: now(), pricing: 'Separately requested review: confirm each live quote, not charged against the old FIX-only approval.' };
          v.reviewSkipped = null; v.deliveryReceipt = null; v.quality = invalidateQuality(v.quality);
        } else if (decision === 'continue-writing') {
          need(episodeNumbers(state).length < state.config.episodeCount && v.reviewRequest
            && next(state, root).kind === 'quality', 'Complete or explicitly skip the requested interim review first');
          v.reviewRequest = null;
        } else {
          skipReview(state, options.note); v.stop = null;
        }
        if (v.awaiting?.type === 'mid-review') { v.checkpointsPassed.push(episodeNumbers(state).length); v.awaiting = null; }
      } else if (v.awaiting) {
        need(v.awaiting.options.includes(decision), 'Decision not in current options');
        const type = v.awaiting.type;
        if (type === 'source') {
          const decisions = options['source-decisions'] ? readJSON(options['source-decisions']) : v.sourceDecisions || [];
          const manual = options['source-risks'] ? readJSON(options['source-risks']) : v.sourceManualRisks || [];
          need(Array.isArray(manual), 'source-risks must be an array');
          const retainedRiskIds = new Set(manual.map(risk => risk.id));
          need((v.sourceManualRisks || []).every(risk => retainedRiskIds.has(risk.id)), 'Previously confirmed manual source risks cannot be silently removed');
          checkSourceDecisions(reviewedSource(root, v, manual), decisions);
          v.sourceManualRisks = clone(manual);
          v.sourceDecisions = clone(decisions);
        }
        if (type === 'concept') {
          validateConceptArcs(output(root, v.concepts).concepts, state.config.episodeCount);
          validateConceptNames(root, state, output(root, v.concepts).concepts.find(c => c.id === decision));
          v.selectedConceptId = decision; v.stage = 'CONCEPT_SELECTED';
        }
        if (type === 'assets') v.stage = 'ASSETS_CONFIRMED';
        if (type === 'blueprint') {
          need(!blueprintConflictState(root, state).unresolved.length, 'Blueprint has unresolved source decision conflicts; revise or explicitly resolve an evidenced false positive before confirmation');
          v.stage = 'BLUEPRINT_CONFIRMED';
        }
        if (type === 'mid-review') v.checkpointsPassed.push(episodeNumbers(state).length);
        v.awaiting = null;
      } else if (v.repairDecision && ['keep-revision', 'rollback-revision'].includes(decision)) {
        const comparison = v.repairDecision;
        const round = state.rounds.find(r => r.snapshotId === comparison.snapshotId);
        round.decision = { decision, note: options.note, at: now() };
        if (decision === 'rollback-revision') {
          restoreSnapshot(root, state, checkSnapshot(root, state, comparison.snapshotId));
          state.view.fix = null; state.view.afterFix = null; state.view.repairDecision = null;
          state.view.quality = invalidateQuality(state.view.quality); round.rolledBack = true;
        } else v.repairDecision = null;
      } else if (decision === 'continue' && (v.stop?.startsWith('User declined') || v.stop?.startsWith('User abandoned'))) {
        v.stop = null;
      } else if (decision === 'continue' && !v.awaiting && v.checkpointsPassed.includes(episodeNumbers(state).length)) {
        // Compatibility for callers acknowledging an already recorded five-episode progress update.
      } else if (decision === 'rescan') {
        need(options.review === undefined && options.issues === undefined && options.instruction === undefined,
          'rescan covers all current draft batches; do not select old issue IDs or a partial batch');
        need(!v.stop && !v.fix && !v.afterFix && !v.repairDecision && reviewCoverage(state, root).complete
          && ['quality', 'done'].includes(next(state, root).kind), 'Complete current SCAN batches and resolve any pending call or repair before requesting rescan');
        // Change only local review eligibility, never manuscript signatures or old report/call objects.
        const snapshotId = checkpoint(root, state, 'Before explicitly requested unchanged-manuscript SCAN');
        v.reviewEpoch = (v.reviewEpoch || 0) + 1;
        v.reviewRequest = { numbers: episodeNumbers(state), note: options.note, at: now() }; v.reviewSkipped = null; v.deliveryReceipt = null;
        v.quality = invalidateQuality(v.quality); v.stage = 'RESCAN_REQUESTED';
        save(root, state, { action, decision, note: options.note, snapshotId, reviewEpoch: v.reviewEpoch });
        return { snapshotId, reviewEpoch: v.reviewEpoch, next: next(state, root), stage: v.stage };
      } else if (decision === 'confirm-working') {
        need(!writingGate(root, state), 'Complete local warning decisions and revision continuity checks before confirming the working source; no paid review is required');
        need(state.config.languagePlan && !delivery(state) && !v.stop && !v.fix && !v.afterFix
          && episodeNumbers(state).length === state.config.episodeCount && ['quality', 'review-choice'].includes(next(state, root).kind), 'Complete working episodes; finish or skip any requested current SCAN before confirm-working');
        if (!reviewCoverage(state, root).complete) skipReview(state, options.note);
        const snapshotId = checkpoint(root, state, 'Before confirmed working-to-delivery transition');
        v.workingDraft = { episodes: clone(v.episodes), reviews: clone(validReviews(state)), reviewCoverage: reviewCoverage(state, root), quality: clone(v.quality), findings: qualityIssues(root, state), snapshotId, note: options.note, at: now() };
        v.workingDraft.continuityCheck = clone(v.continuityCheck || null); v.continuityCheck = null;
        v.reviewRequest = null; v.deliveryReceipt = null;
        if (state.config.languagePlan.workingLanguage !== state.config.languagePlan.targetLanguage) {
          v.episodes = {}; v.reviews = []; v.checkpointsPassed = []; v.reviewSkipped = null;
        }
        v.quality = cleanQuality(); v.stage = 'WORKING_CONFIRMED';
      } else if (decision === 'fix') {
        need(!v.stop && !v.fix && !v.afterFix && ['quality', 'done'].includes(next(state, root).kind), 'Complete SCAN batches first; repair is paused or already active');
        need(state.rounds.length < 3, 'Maximum three FIX rounds reached; stop automatic repair');
        const { review, issueIds, rescanBatches, maxScanCalls } = repairPlan(root, state, options.review, options.issues);
        need(text(options.instruction), '--instruction required');
        need(['confirmed', 'later', 'skip'].includes(options['with-rescan']) && text(String(options['repair-budget'] ?? ''))
          && Number.isFinite(Number(options['repair-budget'])) && Number(options['repair-budget']) >= 0,
        'FIX requires explicit follow-up choice: --with-rescan confirmed|later|skip --repair-budget <maximum credits>; disclose FIX and optional follow-up costs together, never infer rescan approval');
        const approval = { followupReview: options['with-rescan'], maxTotalCredits: Number(options['repair-budget']), rescanBatches, maxScanCalls, note: options.note, at: now() };
        const snapshotId = checkpoint(root, state, 'Before confirmed FIX');
        v.fix = { numbers: review.numbers, issueIds, instruction: options.instruction, reviewRef: review.ref, snapshotId, note: options.note, approval };
        v.reviewRequest = { numbers: episodeNumbers(state), approval, note: options.note, at: now() }; v.reviewSkipped = null; v.deliveryReceipt = null;
        v.quality = invalidateQuality(v.quality);
        state.rounds.push({ snapshotId, reviewCallId: review.callId, issueIds, approval, at: now() });
      } else if (decision === 'deliver') {
        need((!state.config.languagePlan || delivery(state)) && episodeNumbers(state).length === state.config.episodeCount
          && !v.stop && !v.fix && !v.afterFix && ['quality', 'review-choice', 'done'].includes(next(state, root).kind), 'Complete the delivery manuscript and finish or skip requested review before delivery');
        if (!reviewCoverage(state, root).complete) skipReview(state, options.note, { preserveQuality: true });
        v.deliveryReceipt = { signature: signature(state, episodeNumbers(state)), note: options.note, at: now(), reviewCoverage: reviewCoverage(state, root) };
        v.stage = v.quality.qualityAccepted ? 'QUALITY_ACCEPTED' : 'DELIVERED_UNACCEPTED';
      } else if (decision === 'accept') {
        need(!state.config.languagePlan || delivery(state), 'Confirm working manuscript and complete delivery before final acceptance');
        need(!v.stop && !v.fix && !v.afterFix && episodeNumbers(state).length === state.config.episodeCount
          && ['quality', 'review-choice', 'done'].includes(next(state, root).kind), 'Finish or skip requested current SCAN before final acceptance');
        need(!writingGate(root, state), 'Resolve local warning decisions and revision continuity checks before quality acceptance; export remains available');
        need(v.quality.manual?.checked === true && v.quality.manual.signature === signature(state, episodeNumbers(state)), 'Record manual quality checks for current episodes first');
        need(options['accept-quality'] === 'confirmed' && !/^(继续|开始|下一步|好的?|continue|next|ok|okay)[.!！。\s]*$/i.test(options.note.trim()), 'Explicit final quality acceptance is required; continue is not acceptance');
        const coverage = reviewCoverage(state, root);
        const separateWorkingDraft = state.config.languagePlan && state.config.languagePlan.workingLanguage !== state.config.languagePlan.targetLanguage;
        if (!coverage.complete || (separateWorkingDraft && v.workingDraft && !v.workingDraft.reviewCoverage?.complete)) need(options.unreviewed === 'acknowledged', 'Acknowledge unreviewed scope with --unreviewed acknowledged; do not claim model review passed');
        const issues = qualityIssues(root, state);
        const acceptedIds = options.issues ? options.issues.split(',') : [];
        need(acceptedIds.every(id => issues.some(i => i.id === id)) && issues.filter(i => !softLengthAdvisory(i)).every(i => acceptedIds.includes(i.id)), 'Explicitly acknowledge every remaining issue ID, or repair and rescan');
        v.quality.qualityAccepted = true; v.quality.acceptance = { note: options.note, acceptedIssueIds: acceptedIds, reviewCoverage: coverage, at: now() }; v.stage = 'QUALITY_ACCEPTED';
      } else throw new Error('No matching user decision is pending');
      save(root, state, { action, decision, note: options.note }); return { next: next(state, root), stage: state.view.stage };
    }
    if (action === 'quality') {
      need(!state.pending && ['quality', 'review-choice', 'done'].includes(next(state, root).kind), 'Finish or skip requested SCAN batches before manual quality assessment');
      const report = readJSON(options.report); safeData(report);
      need(object(report) && report.checked === true && text(report.notes) && Array.isArray(report.findings), 'Quality report needs checked=true, notes and findings[]');
      need(report.findings.every(f => object(f) && /^MANUAL_[a-zA-Z0-9_-]+$/.test(f.id) && text(f.description)), 'Manual findings require MANUAL_ IDs and description');
      need(new Set(report.findings.map(f => f.id)).size === report.findings.length, 'Duplicate manual issue IDs');
      v.quality.manual = { ...report, signature: signature(state, episodeNumbers(state)), at: now() };
      save(root, state, { action }); return { findings: qualityIssues(root, state), next: next(state, root) };
    }
    if (action === 'checkpoint') {
      need(!state.pending && !v.fix && !v.afterFix && !v.repairDecision, 'Cannot checkpoint an active call or repair');
      const snapshotId = checkpoint(root, state, options.label);
      save(root, state, { action, snapshotId }); return { snapshotId };
    }
    if (action === 'undo') {
      need(!state.pending, 'Cannot undo while a submission is pending');
      need(text(options.note), 'Undo needs explicit user --note');
      const snapshot = checkSnapshot(root, state, options.snapshot);
      restoreSnapshot(root, state, snapshot); state.view.quality = invalidateQuality(state.view.quality); state.view.fix = null; state.view.afterFix = null; state.view.repairDecision = null;
      state.view.reviewRequest = null; state.view.deliveryReceipt = null;
      if (state.view.stage === 'QUALITY_ACCEPTED') state.view.stage = 'REVIEW_SCANNED';
      save(root, state, { action, snapshotId: options.snapshot, note: options.note });
      return { next: next(state, root), instruction: 'Local view restored; task history, charges and previous exports are retained. Export a new revision; this is not a refund.' };
    }
    throw new Error('Unknown command');
  } finally { closeSync(fd); unlinkSync(lock); }
}

const flags = {
  'bind-source-upload': ['call', 'upload-result'],
  'resolve-blueprint-conflict': ['call', 'report', 'risk', 'reason', 'decision', 'note', 'plan-digest'],
  issues: [], triage: ['report'], 'issue-decision': ['issue', 'decision', 'note', 'report'],
  'revise-local': ['report', 'decision', 'note', 'plan-digest'], 'check-continuity': ['report'],
  'attribution-context': [], init: ['config'], status: [], next: [], 'display-names': ['names', 'note'], plan: ['review', 'issues'], prepare: ['business-code', 'params', 'source-file', 'source-selection', 'source-unchecked-note'], record: ['call', 'result', 'exit-code', 'recovery-id', 'stderr', 'repair-recovery', 'submission-evidence'],
  answer: ['decision', 'call', 'note', 'review', 'issues', 'instruction', 'source-decisions', 'source-risks', 'submission-evidence', 'with-rescan', 'repair-budget', 'accept-quality', 'unreviewed'], quality: ['report'], checkpoint: ['label'], undo: ['snapshot', 'note'], reopen: ['from', 'config', 'decision', 'note', 'plan-digest'], 'source-facts': ['facts', 'out'], 'check-facts': ['call', 'report'], 'check-upstream': ['call', 'report'], export: [],
};
if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  try {
    const [action, ...args] = process.argv.slice(2);
    if (!action || action === '--help') {
      console.log('project.mjs init|status|next|plan|prepare|bind-source-upload|record|answer|quality|checkpoint|undo|reopen|source-facts|check-facts|check-upstream|resolve-blueprint-conflict|issues|triage|issue-decision|revise-local|check-continuity|display-names|export --project <directory> [options]. See references/runtime.md. Local-only; never submits paid calls.');
    } else {
      need(Object.hasOwn(flags, action), 'Unknown action'); const options = {};
      for (let i = 0; i < args.length; i += 2) {
        const key = args[i].slice(2);
        need(args[i].startsWith('--') && ['project', 'revision', ...flags[action]].includes(key) && !Object.hasOwn(options, key) && args[i+1] !== undefined, 'Unknown, repeated or incomplete argument');
        options[key] = args[i+1];
      }
      console.log(json({ ok: true, ...execute(action, options) }));
    }
  } catch (error) {
    console.error(json({ ok: false, error: error.message })); process.exitCode = 1;
  }
}
