import {parseHighlights,visibleHighlights} from './plan.mjs';

const finite=value=>typeof value==='number'&&Number.isFinite(value);
const episodeNumber=value=>Number.isInteger(value)&&value>0;
const pending=new Set(['prepared','unknown','running','remote_succeeded','artifact_pending']);

/** Read-only analysis metadata. The caller supplies its existing text/id sanitizer. */
export function buildAnalysisDetails(p,{label,id}) {
  const operations=(p.operations||[]).filter(op=>op.stage==='analysis');
  const currentIds=new Set(Array.isArray(p.analysis?.operationIds)?p.analysis.operationIds:[]);
  const scope=new Set(Array.isArray(p.analysis?.episodes)?p.analysis.episodes.filter(episodeNumber):operations.filter(op=>currentIds.has(op.id)).map(op=>op.episode).filter(episodeNumber));
  const assets=(p.assets||[]).filter(asset=>asset.role==='episode');
  const durations=[...scope].map(episode=>{
    const saved=operations.find(op=>currentIds.has(op.id)&&op.episode===episode)?.analysisSpec?.sourceDuration;
    return finite(saved)&&saved>0?saved:assets.find(asset=>asset.episode===episode)?.duration;
  }).filter(value=>finite(value)&&value>0);
  const scaleDuration=durations.length?Math.max(...durations):null;
  const selected=visibleHighlights(p);
  const result=new Map();
  for(const op of operations){
    if(!id(op.id))continue;
    const episode=episodeNumber(op.episode)?op.episode:null;
    const asset=assets.find(asset=>asset.episode===episode);
    const savedSpec=op.analysisSpec;
    const recorded=finite(savedSpec?.minDuration)&&savedSpec.minDuration>=0&&finite(savedSpec?.maxDuration)&&savedSpec.maxDuration>=savedSpec.minDuration;
    const sourceDuration=finite(savedSpec?.sourceDuration)&&savedSpec.sourceDuration>0?savedSpec.sourceDuration:finite(asset?.duration)&&asset.duration>0?asset.duration:null;
    const current=currentIds.has(op.id);
    const detail={episode,sourceDuration,scaleDuration:current?scaleDuration:sourceDuration,current,criteriaStatus:recorded?'recorded':'legacy_unrecorded',minDuration:recorded?savedSpec.minDuration:null,maxDuration:recorded?savedSpec.maxDuration:null,recordSource:'none',detailStatus:pending.has(op.status)?'pending':'unavailable',records:[],availableCount:null,selectedCount:null,excludedCount:0};
    result.set(op.id,detail);
    if(current&&Array.isArray(p.analysis?.candidateDiagnostics))detail.excludedCount=p.analysis.candidateDiagnostics.filter(item=>item.operationId===op.id).length;
    if(op.status!=='succeeded'||episode===null)continue;
    let records;
    if(Array.isArray(p.highlightPool)){
      const owned=p.highlightPool.filter(row=>row?.operationId===op.id);
      // A collected current pool can truthfully contain zero records for this episode.
      const currentPool=current&&p.highlightPool.every(row=>row&&currentIds.has(row.operationId));
      // An incremental pool may only contain untouched episodes. A completed new
      // episode still needs its own output parsed until it has been collected.
      if(owned.length||currentPool&&(op.output==null||sourceDuration===null)){records=owned;detail.recordSource='pool';}
    }
    try{
      if(records===undefined&&op.output!==undefined&&op.output!==null){
        detail.recordSource='output';
        if(sourceDuration===null)continue;
        // Current global choices are mutable. Historical criteria are only known
        // when saved on the operation; legacy output is shown as raw records.
        const minDuration=recorded?savedSpec.minDuration:0;
        const maxDuration=recorded?savedSpec.maxDuration:sourceDuration;
        const sourceProject={...p,assets:[...p.assets.filter(a=>a.role!=='episode'||a.episode!==episode),{...asset,role:'episode',episode,duration:sourceDuration}]};
        const diagnostics=[];
        records=parseHighlights(sourceProject,{episodes:[episode],minDuration,maxDuration},[{operationId:op.id,episode,output:op.output}],diagnostics);
        detail.excludedCount=diagnostics.length;
      }
      if(records===undefined){
        const saved=(p.highlights||[]).filter(row=>row?.operationId===op.id);
        if(saved.length){records=saved;detail.recordSource='legacy_saved';}
      }
      if(records===undefined)continue;
      const ids=new Set();
      const normalized=records.map(row=>{
        const recordId=id(row.id);
        if(!recordId||ids.has(recordId)||row.episode!==episode||!finite(row.start)||!finite(row.end)||row.start<0||row.end<=row.start||(sourceDuration!==null&&row.end>sourceDuration+0.000001)||row.score!==undefined&&row.score!==null&&!finite(row.score))throw Error('Invalid saved analysis record');
        ids.add(recordId);
        return {id:recordId,start:row.start,end:row.end,duration:row.end-row.start,reason:label(row.reason),score:finite(row.score)?row.score:null,
          selected:current&&selected.some(choice=>choice.operationId===op.id&&choice.id===row.id&&choice.episode===episode&&choice.start===row.start&&choice.end===row.end)};
      }).sort((a,b)=>a.start-b.start||a.end-b.end||a.id.localeCompare(b.id));
      detail.records=normalized.map((row,index)=>({...row,number:index+1}));
      detail.detailStatus='ready';detail.availableCount=detail.records.length;detail.selectedCount=detail.records.filter(row=>row.selected).length;
    }catch{
      detail.detailStatus='invalid';detail.records=[];detail.availableCount=null;detail.selectedCount=null;
    }
  }
  return result;
}
