import crypto from 'node:crypto';
import {check,validId,saveProject} from './project.mjs';

const labels=Object.freeze({viral:'爆款前贴智剪',highlight:'高光前贴智剪'});
const isMode=value=>Object.hasOwn(labels,value??'');
const evidence=value=>typeof value==='string'&&value.trim().length>0&&value.length<=2000;
function validDecision(value){
  return value?.confirmed===true&&isMode(value.mode)&&validId(value.id)&&evidence(value.note)
    &&typeof value.confirmedAt==='string'&&/T.*(?:Z|[+-]\d{2}:\d{2})$/.test(value.confirmedAt)&&Number.isFinite(Date.parse(value.confirmedAt));
}
export function modeView(p){
  const d=p.modeDecision;
  return validDecision(d)?{status:'confirmed',mode:d.mode,label:labels[d.mode],confirmedAt:d.confirmedAt}
    :{status:'unconfirmed',mode:null,label:'待选择制作模式'};
}
export function modeChoice(){
  return {status:'needs_mode_decision',nextAction:'select-mode',message:'请先选择爆款前贴智剪或高光前贴智剪。用户已经明确指定时，按真实决定记录并告知采用的模式，无需重复询问。',modes:[
    {mode:'viral',label:labels.viral,description:'按文案或参考视频生成前贴，也可明确复用已有前贴。'},
    {mode:'highlight',label:labels.highlight,description:'从原始剧集中分析并提取选定高光作为前贴。'}]};
}
export function requireMode(p,expected){
  check(validDecision(p.modeDecision),'MODE_CONFIRMATION_REQUIRED','开始新制作前，请先在聊天中明确制作模式并用 select-mode 保存用户决定；素材导入、看板和原任务恢复不受影响。');
  check(!expected||p.modeDecision.mode===expected,'MODE_MISMATCH','当前制作模式与这项操作不一致。请按用户明确要求选择正确模式，不能自动切换。');
  return p.modeDecision;
}
export function requireFrontMode(p,front){
  const d=requireMode(p);
  check(front&&Boolean(front.assetId)!==Boolean(front.highlightId),'FRONT_INVALID');
  requireMode(p,front.highlightId?'highlight':'viral');return d;
}
export function assertPlanMode(p,plan){
  const d=requireMode(p);
  check(plan?.modeDecisionId===d.id,'MODE_PLAN_STALE','剪辑计划不属于当前已确认模式，请沿用原素材重新编排计划后再准备合成。');
  requireFrontMode(p,plan.front);
}
export function assertPreparedMode(p,op){
  if(op.status!=='prepared')return;
  const expected=op.stage==='fronts'?'viral':['analysis','highlights'].includes(op.stage)?'highlight':op.productionMode;
  const d=requireMode(p);
  check(!op.modeInvalidated&&op.modeDecisionId===d.id&&op.productionMode===d.mode,'MODE_OPERATION_STALE','这项未提交操作没有当前模式的有效记录，或已因模式切换失效。请重新准备并核对报价与授权；原任务、素材和费用记录已保留。');
  requireMode(p,expected);
}
/** Called under the project write lock; the note is evidence supplied from the user's real choice. */
export async function selectMode(dir,p,spec){
  check(isMode(spec?.mode),'MODE_INVALID','制作模式仅支持 viral（爆款前贴智剪）或 highlight（高光前贴智剪）。');
  check(spec.confirmed===true&&evidence(spec.note),'MODE_CONFIRMATION_REQUIRED','请记录用户真实的模式决定；不能根据文件存在或模型建议伪造确认。');
  if(validDecision(p.modeDecision)&&p.modeDecision.mode===spec.mode)return {changed:false,productionMode:modeView(p)};
  const previous=p.modeDecision,switched=validDecision(previous);
  if(previous)(p.modeHistory??=[]).push({decision:structuredClone(previous),...(switched?{context:structuredClone({frontOperationIds:p.frontOperationIds,frontStyleDecision:p.frontStyleDecision,analysis:p.analysis,highlights:p.highlights,highlightPool:p.highlightPool,highlightOperationIds:p.highlightOperationIds,highlightCanvas:p.highlightCanvas,plans:p.plans,intent:p.intent})}:{})});
  // Never mutate requests, keys, jobs, quotes or paid recovery facts.
  for(const op of p.operations)if(op.status==='prepared')op.modeInvalidated=true;
  if(switched){
    if(p.plans.length)(p.planHistory??=[]).push({revision:p.revision,plans:structuredClone(p.plans),intent:p.intent});
    p.plans=[];p.highlights=[];p.analysis=null;
    for(const key of ['frontOperationIds','frontStyleDecision','highlightPool','highlightOperationIds','highlightCanvas','selectionDecision'])delete p[key];
  }
  p.modeDecision={id:crypto.randomUUID(),mode:spec.mode,confirmed:true,note:spec.note.trim(),confirmedAt:new Date().toISOString()};
  await saveProject(dir,p);
  return {changed:true,productionMode:modeView(p),message:`本次采用${labels[spec.mode]}。`,recoverableOperations:p.operations.filter(o=>['unknown','running','remote_succeeded','artifact_pending','qa_failed'].includes(o.status)).map(o=>({id:o.id,status:o.status}))};
}
