/** One read/recovery pass at a time; never authorizes or starts production. */
export function createSynchronizer(synchronize,{intervalMs=15000,now=Date.now}={}) {
  let pending,timer,closed=false,lastStart=-Infinity;
  let state={status:'idle',lastAttemptAt:null,lastSuccessAt:null,message:'尚未查询服务端'};
  function schedule(){
    if(timer)clearTimeout(timer);
    if(closed||!synchronize)return;
    const remaining=Number.isFinite(lastStart)?Math.max(0,intervalMs-(now()-lastStart)):intervalMs;
    timer=setTimeout(trigger,remaining);timer.unref?.();
  }
  function trigger(){
    if(closed||!synchronize||pending)return {...state};
    if(now()-lastStart<intervalMs){schedule();return {...state};}
    if(timer)clearTimeout(timer);
    lastStart=now();state={...state,status:'syncing',lastAttemptAt:new Date(lastStart).toISOString(),message:'正在同步已有任务及产物'};
    pending=Promise.resolve().then(synchronize).then(result=>{
      const incomplete=result.operations?.some(o=>o.error)||result.skipped?.length>0;
      if(!result.operations?.length&&!incomplete){state={...state,status:'idle',message:'本项目暂无待同步的已提交任务'};return;}
      state={...state,status:incomplete?'partial':'ok',lastSuccessAt:incomplete?state.lastSuccessAt:new Date(now()).toISOString(),message:incomplete?'部分任务待处理，请在聊天中查看原任务；不会自动重新制作。':'已有任务状态已核对'};
    }).catch(error=>{
      const busy=error.code==='PROJECT_LOCKED';
      state={...state,status:busy?'busy':'error',message:busy?'Agent正在更新项目，稍后自动同步。':'服务端同步未完成，请检查当前站点登录或在聊天中恢复原任务。'};
    }).finally(()=>{pending=undefined;schedule();});
    return {...state};
  }
  schedule();
  return {trigger,snapshot:()=>({...state}),close:async()=>{closed=true;if(timer)clearTimeout(timer);await pending;}};
}
