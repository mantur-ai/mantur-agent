# 公共接入检查与转发

ACCESS是本包`scripts/access.mjs`的绝对路径。默认使用生产站点、已安装CLI与现有登录态；最低CLI 1.2.10，回归基线1.2.10，安装/批准升级使用latest。包内不提供测试站地址。只有用户明确要求测试时，按[test-mode.md](test-mode.md)选择外部环境。

## 检查与固定环境

独立技能执行`node "ACCESS" --source HOST check`，HOST为当前workbuddy、codex、claude-code或unknown。连接器只使用宿主的CLI和注入环境。check不安装、登录、创建Key或执行算子；返回READY才继续实际调用。

后续调用保留check的`bindingArgs`和`bindingEnv`，业务planner也使用同一bindingEnv。bindingArgs包括CLI/配置目录、来源/业务码和环境指纹；不能只保留路径而丢掉环境指纹。显式`--existing-cli`和`--config-dir`仍成对使用，路径必须绝对，不自动切换CLI或账号。

有项目时传`--project`绝对路径；业务返回`cli.accessArgs`时与check.bindingArgs合并使用，相同选项相同值可去重、不同值停止。项目使用独立`skill-access-context.json`记录非敏感站点与配置目录；不存Key、Token或登录凭据。相同项目的新调用、确认和恢复使用原环境，切换环境请新建项目。纯本地阅读/导出不要求登录或联网。

## 登录、归因与授权

READY直接复用授权，不重复登录。LOGIN_REQUIRED时按返回的完整loginInstructions.command/args/env执行用户批准的登录；命令保留--from与注册businessCode，不能用调用businessCode替换。仅生产默认命令环境可能返回quickLoginInstructions；测试环境始终使用完整指引。同源registration动态链接只表达当前环境，不自动登录。

profile v2的调用businessCode可由前置--business-code指定，再取环境变量，最后使用产品默认值；Skill身份、版本、发行目标固定于包。注册businessCode独立为产品id加-skill/connector；旧profile保留原归因规则。内层CLI显式归因不得冲突，费用确认与恢复以CLI原快照为准。

仅缺算子Key时，独立入口获准后使用`authorize --approve-key`，由CLI准备；连接器通过宿主连接/重新连接。安装、登录、登出不由ACCESS执行，外部MANTURHUB_KEY拒绝，不读取、复制或改写凭据。

## 调用与恢复

支持describe、quote、run、resume、doctor --json及--version，按[cli.md](cli.md)转发真实cli.args。参数数组、stdout、stderr和退出码原样传递，退出3仍需费用确认，不自动confirm、重试或付费。白名单防误用，权限和计费以服务端为准。

新prepare保存项目接入参数；pending提示会返回同一accessArgs。旧项目没有环境sidecar或旧pending没有accessArgs时，先保留原输入、回执、恢复ID，在明确的原环境中resume；CLI核对原站点和账号，成功后才补充环境sidecar。失败不换环境重提、不回填旧call，不删除凭据或账务。环境指纹不取代CLI的账号/令牌/输入校验。

新版CLI提示只用于用户批准的升级，保留原安装方式和配置目录，升级后重新check；存在未决任务先恢复。运行时不安装另一套私有CLI，不追踪其他登录目录。连接器不接受外部CLI路径，测试也须由宿主注入配置并管理授权。


授权状态解析失败时会附退出码及脱敏、限长的错误摘要，业务调用不会继续。先排查 CLI/Node 和原生依赖；这不等同于未登录，不要重复登录。
