// Display projections of public CLI receipts only; never infer or change settlement.
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const amount = value => typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : null;
const actions = new Set(['EDIT_INPUT', 'RETRY_LATER', 'SWITCH_MODEL', 'CONTACT_SUPPORT', 'WAIT_CONFIRMATION']);
const sensitive = /mtak_[A-Za-z0-9]{8,}|Bearer\s+[A-Za-z0-9._-]{12,}|-----BEGIN .*PRIVATE KEY-----|https?:\/\/\S*[?&](?:x-amz-|x-oss-|signature=|token=|access_token=)/i;

export function publicStandardError(raw) {
  if (!object(raw)) return undefined;
  const result = {};
  if (raw.schemaVersion === 1) result.schemaVersion = 1;
  for (const [key, max] of Object.entries({ code: 96, category: 48, supportId: 128, locale: 24, message: 512, suggestion: 512, presentationSource: 48, overrideVersion: 128 })) {
    const value = raw[key];
    if (typeof value === 'string' && value.trim() && value.length <= max
      && !/[\x00-\x1f\x7f-\x9f]/.test(value) && !sensitive.test(value)) result[key] = value;
  }
  if (Number.isSafeInteger(raw.overrideVersion) && raw.overrideVersion >= 0) result.overrideVersion = raw.overrideVersion;
  if (Array.isArray(raw.suggestedActions)) result.suggestedActions = [...new Set(raw.suggestedActions.filter(value => actions.has(value)))];
  return Object.keys(result).length ? result : undefined;
}

export function billingView(receipt) {
  // Presence of public billing wins, even if incomplete; never fill its gaps with legacy fields.
  const current = Object.hasOwn(receipt, 'billing');
  const b = current ? receipt.billing : receipt._billing;
  const source = current ? 'billing' : Object.hasOwn(receipt, '_billing') ? '_billing' : 'missing';
  const status = object(b) ? current ? b.billingStatus : b.final === true ? 'FINAL' : 'PENDING' : 'UNKNOWN';
  const final = current ? ['COMPLETED', 'REFUNDED', 'FREE'].includes(status) : status === 'FINAL';
  return { source, status: typeof status === 'string' ? status : 'UNKNOWN', final,
    netPoints: final ? amount(current ? b.points : b.charged_dumplings) : null,
    refundedPoints: object(b) ? amount(current ? b.refundedPoints : b.refunded_dumplings) : null,
    reservedPoints: object(b) && !final ? amount(current ? status === 'DEDUCTED' ? b.reservedPoints : undefined : b.charged_dumplings) : null };
}

export function unconfirmedOutcome(receipt) {
  return receipt.errorCode === 'MODEL_SUBMIT_AMBIGUOUS'
    || receipt.standardError?.code === 'INVOKE_RESULT_UNCONFIRMED'
    || receipt.standardError?.category === 'UNCERTAIN'
    || receipt.standardError?.suggestedActions?.includes('WAIT_CONFIRMATION') === true;
}

export function summarizeBilling(calls) {
  const groups = new Map();
  for (const { callId, jobId, receipt } of calls) {
    const key = jobId ? `job:${jobId}` : `call:${callId}`;
    const rows = groups.get(key) || []; rows.push({ callId, jobId, ...billingView(receipt) }); groups.set(key, rows);
  }
  const rows = [...groups.values()].map(group => {
    // A later missing/pending query does not erase a known final settlement.
    // Public billing takes precedence across the entire job history as well.
    const source = group.some(row => row.source === 'billing') ? 'billing'
      : group.some(row => row.source === '_billing') ? '_billing' : 'missing';
    const evidence = group.filter(row => row.source === source);
    const final = evidence.filter(row => row.final && row.netPoints !== null);
    const net = new Set(final.map(row => row.netPoints));
    const refunds = new Set(final.map(row => row.refundedPoints).filter(value => value !== null));
    const chosen = final.at(-1) || evidence.at(-1);
    return { ...chosen, ...(final.length && refunds.size === 1 ? { refundedPoints: [...refunds][0] } : {}),
      callIds: [...new Set(group.map(row => row.callId))], ...(net.size > 1 || refunds.size > 1
      ? { status: 'CONFLICT', final: false, netPoints: null, refundedPoints: null, reservedPoints: null } : {}) };
  });
  const known = rows.filter(row => row.final && row.netPoints !== null);
  const knownNetPoints = known.reduce((sum, row) => sum + row.netPoints, 0);
  const unknownCallCount = rows.length - known.length;
  return { rows, knownNetPoints, totalNetPoints: unknownCallCount ? null : knownNetPoints, unknownCallCount,
    note: '公开最终 points（旧格式 charged_dumplings）已经是实际消耗；退款单独展示，不再次相减。同一 jobId 只计一次。报价和预扣不计最终费用，未知不按零处理。' };
}
