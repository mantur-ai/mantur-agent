import {check} from './project.mjs';

const text=value=>typeof value==='string'?value.trim().replace(/\s+/g,' '):'';

/** Skill-owned visual choices; names are open text, not a model style enum. */
export function normalizeFrontStyles(spec) {
  check(Array.isArray(spec?.items)&&spec.items.length>0,'FRONT_ITEMS_REQUIRED');
  const decision=spec?.styleDecision;
  check(decision&&decision.confirmed===true&&typeof decision.note==='string'&&decision.note.trim(),
    'FRONT_STYLE_CONFIRMATION_REQUIRED','请先向用户确认前贴风格，并记录本次真实决定。');
  check(['uniform','per_front'].includes(decision.mode),
    'FRONT_STYLE_MODE_INVALID','请选择全部前贴统一风格，或逐条指定风格。');
  const styles=spec.items.map(item=>{
    const name=text(item?.style?.name),prompt=text(item?.style?.prompt);
    check(name&&prompt,'FRONT_STYLE_REQUIRED','每条新生成的前贴都需要明确风格名称和风格约束。');
    return {name,prompt};
  });
  if(decision.mode==='uniform')check(styles.every(style=>style.name===styles[0].name&&style.prompt===styles[0].prompt),
    'FRONT_STYLE_UNIFORM_CONFLICT','已选择统一风格，但各条前贴的风格不一致，请先与用户确认。');
  return {decision:{confirmed:true,mode:decision.mode,note:decision.note.trim()},styles};
}

export function stylePrompt(originalPrompt,style) {
  return `${originalPrompt}\n\n【本次确认的前贴视觉风格】\n风格：${style.name}\n风格约束：${style.prompt}`;
}
