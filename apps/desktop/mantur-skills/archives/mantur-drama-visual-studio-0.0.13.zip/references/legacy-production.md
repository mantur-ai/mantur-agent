# Legacy 生产兼容参考

仅适用于 doctor 明确识别并放行的旧合同。本文不适用于 OpenAPI fileId/jobId/output；不能用旧动作绕过新合同门禁。以下迁移自原 Skill，作为旧项目恢复约定保留。

## 旧平台调用与上传

### 算子调用

仅在当前合同工作流适配就绪后调用。legacy 使用 `manturhub run <算子ID> --json '{...}'`；凡是异步任务均使用当前 CLI 支持的 `--no-wait`，随后由 Agent 循环查询原任务。OpenAPI 使用各阶段专属 submit/resume。直接调用 REST 时，以 `manturhub describe <算子ID>` 返回的实时 schema 和轮询说明为准。结算与退款以平台实际结果为准，不因失败就假定退款到账；Skill 不得自行实现重复扣费、伪造退款或因失败静默更换 provider。

资产提取、分镜编译和批量视频属于长任务：使用 `manturhub run <算子ID> --json-file <参数文件> --no-wait` 与稳定幂等键只提交一次，收到 `task_id/poll_url` 后立即原子写入 `.pipeline-state`，再通过原任务的 `status` 或 `poll-checkpoint` 恢复查询。不要让一个终端调用长期占住连接，也不得因 Agent 单轮等待结束而重新提交。

### 文件上传

本地文件必须先转换为当前站算子可匿名读取的公网 URL，不能把磁盘路径直接传给远端算子。



* CLI：`manturhub upload <本地文件>`，使用返回的公网 URL。

* REST：`POST /api/v1/uploads/presign` 获取 `put_url`，PUT 上传后使用 `access_url`。

上传前后都要校验文件位于项目目录、是普通非空文件、MIME 与内容签名一致并记录 SHA-256。签名 URL、上传凭据和远端任务标识只保存在 Runtime 权威文件中，不进入只读快照。

### 执行前自检



1. 运行 `manturhub describe <算子ID>` 获取当前站实时参数 schema，不根据历史示例猜参数。

2. 对调用所需的本地素材运行 `manturhub upload <本地文件>`。

3. 使用最终实际参数运行 `manturhub quote <算子ID>` 查询实时价格。

4. 执行 `query-account-balance`，按 [报价与余额展示](quote-and-balance.md) 用制作语言向用户说明本次要制作的内容、范围、预计费用、刚查的余额与预计余量（或余额暂不可用的原因）和失败边界，取得明确批准；不要求用户理解算子或命令名。旧响应没有已知余额字段时不猜值。

5. 使用 `manturhub run <算子ID> --json-file <参数文件>` 调用；长任务增加 `--no-wait` 并持久化任务检查点。

### 本 Skill 依赖算子



* `op.drama.asset-extract`：剧本资产提取，兼容版本不低于 v2.3.0。

* `op.drama.clip-seedance-compile`：剧本分镜与 Seedance 请求模板，兼容版本不低于 v2.3.3。

* `op.image.generate`：Agent 没有原生生图能力时的资产图片生成。

  仅在此 legacy 图片合同预检通过后，无参考使用 `mode=generate`，有参考使用 `mode=edit` 和 `images[]`，默认 `n=1`。上传当前目标相关参考后实时报价、获批调用；不把这些旧字段套到新 OpenAPI 的 `referenceImages:[{fileId}]` 合同。

* `op.video.understand-v2`：Agent 没有原生视觉理解能力时的图片 / 视频检查。

* `op.voice.design`：用户明确要求并批准时设计定制音色。

* `op.audio.generate`：用户明确要求并批准时生成可用参考音频。

* `op.video.generate`：默认 Seedance 视频生成算子。





## 旧资产提取

调用 `op.drama.asset-extract` v2.3.0 或兼容更高版本。传完整 `script_url` 或 `script_text`、项目风格、负面要求和全部 `reference_images`。Worker 必须把完整剧本作为单个 Responses `input_file`，以严格 JSON Schema 一次生成；禁止切批、摘要替代原文、改走 Chat Completions 或把在线对象地址交给上游自行抓取。

权威输出写入 `.pipeline-state/results/asset-extract-report.json`，任务检查点写入 `.pipeline-state/asset-extract.json`，由 `project.json.workflow_state` 指向结果。验收项目美术规范、角色、场景、道具四类结构；群众作为角色子类型。每项必须有稳定资产 ID、基础资产 ID、变体、适用集数 / 场景、证据、提示词、负面提示词和生成策略；V01 的基础 ID 为自身，V02+ 指向同实体 V01。

`reference_required` 在分镜前必须有唯一匹配或验收通过的参考图；`defer_to_video` 只允许一次使用、非变体、非关键且无需跨镜连续性的资产。V02+ 一律为 `reference_required`。提取阶段只产生文本事实，不伪造媒体、URL 或完成状态。

变体名表达真实差异（如晚礼服裙、泥污大衣、商务装），不以纯 `V01/V02` 代替描述；`Vxx` 仍保留在稳定资产 ID 中。用户已有素材唯一匹配后，在匹配记录保存原文件名去扩展名的 `display_name`；用户明确指定名称时以其指定为准。生成资产使用角色名与语义变体名。聊天列举资产优先使用展示名，重名或精确定位时附 ID；身份、音色共享和 Clip 引用仍按原有身份字段关联。兼容与回退规则见 [local-project-schema.md](local-project-schema.md#资产展示名称)。



## 旧分镜编译

资产验收后，合并资产提取报告、匹配结果与库存，将已上传图片和已绑定音色的公网 URL 写入完整资产清单 `complete-assets.json`（保存在项目 Runtime 私有目录）。对准备实际上传的这份文件执行：



```
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" validate-clip-assets "<完整资产清单路径>"
```

只有 `ok=true` 且退出码为 0，才上传这份清单、报价并提交分镜；清单变化后必须重新校验。失败时按 `issues` 返回具体资产及原因，补齐后重查，不跳过检查。命令只读取项目文件、检查结构和 HTTPS URL 格式，不上传、不联网、不改状态；公网匿名访问和 MIME 检查仍按输入提交规范执行。不能只重命名原始提取报告，或因项目允许 AI 直出而漏掉已绑定音色。匹配报告选择顺序为项目 `workflow_state.asset_matching_report`、Manifest 的 `authoritative_files.asset_matching.path`、标准 `results/asset-matching-report.json`；显式指针无效时停止，不回退。

随后调用 `op.drama.clip-seedance-compile` v2.3.3 或兼容更高版本。完整剧本作为 `complete-script.md`、完整资产清单作为 `complete-assets.json`，Worker 通过两个 `input_file.file_data` 在一次 Responses 请求中提交；禁止摘要、切批、把正文塞进普通提示词、按集多次调用或改走 Chat Completions。

权威输出写入 `.pipeline-state/results/clip-compile-report.json`；确定性后处理可以写 `clip-compile-enriched-report.json`，但必须由项目状态或 Manifest 显式选中。层级固定为剧集、场次组、Clip；一个 Clip 对应一条视频，不增加 Cut。

模型决定剧情拆分、资产选择和台词翻译；代码确定 Clip ID、引用编号、状态和请求体。每集 Clip 数是软目标。默认 60–90 秒时，同次输出优先规划到 70–85 秒；偏短只在现有 Clip 的单 Clip 硬上限内向上加秒，不缩短、不删剧情、不虚构剧情、不二次调用模型；超过软上界保留完整剧情。`quality_report.duration_planning` 保存原始、补足、最终时长和审核状态。

中文状态使用 `assets/storyboard-status-contract.json` 的封闭枚举；历史英文状态只能通过 `normalize-storyboard-statuses` 字段级迁移，未知非空值阻断。所有提示词精确以 `不要背景音乐，不要字幕。` 结尾。

每个已绑定用户、预制或定制音色的说话角色，都必须在对白处使用对应 `@AudioN`；`metadata.content` 按相同顺序包含同一公开 URL 的 `reference_audio`。图片和音频引用编号必须与 content 数组逐项一致。请求模板在 `metadata` 内包含 `content/resolution/ratio/generate_audio/seed/return_last_frame=true`。同场后续 Clip 只记录 `pending_previous_tail`，不能伪造尾帧 URL。

`missing_assets` 或 `missing_voice_assets` 非空时禁止进入视频；`deferred_assets` 和项目已批准的 `ai_direct_voices` 是允许的显式策略。

验收同时检查 `quality_report.missing_assets/missing_voice_assets` 与每个 Clip 的 `缺失资产`，合并报告没有顶层汇总也不能省略逐行检查。依赖未解决时，将业务 `workflow_state.clip_compile_state` 写为 `blocked`，保留真实远端任务的成功终态；运行快照刷新并回读分镜完成门禁，不把 “算子成功返回报告” 当成 “分镜验收完成”。Compiler 只发布派生状态，不反写权威文件。`validate-clip-assets` 是流程校验，不能阻止 Agent 绕过 Skill 直接调用通用 CLI。



## 旧视频请求与轮询

用户批准视频费用后才执行。先读取 [video-concurrency-policy.md](video-concurrency-policy.md) 并运行：



```
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" plan-scenes clip-rows.json --requested-concurrency "$REQUESTED_VIDEO_CONCURRENCY" --concurrency "$EFFECTIVE_VIDEO_CONCURRENCY" --output .pipeline-state/scene-chain-plan.json
```

项目并发单位是 `(episode, scene_group)` 场次链，默认 5、可配置 1–20；所有合法锁定站点采用同一本地调度策略，由 Agent 按已知在途数量协调、平台最终限制，不维护本机跨项目任务槽。平台额度是否另行核实不阻断提交，QPM 单独处理。同链一次只提交一个 Clip，前序采用 Run 验收及真实尾帧通过后继续；异链按现有 FIFO。未知提交计入 Agent 在途预算；远端终态不再计入该预算，但不绕过本地场次链门禁。详见需求修订合同的并发边界。

每个获批 Clip：



1. 按 `Clip ID` 从当前选中的分镜报告 `Seedance2.0请求体` 中读取 `请求体模板JSON`，复制为本次输入文件并校验所需资产、音色；模板缺失或无效则记录门禁，不回退读取 `请求体JSON` 或 `实际请求体JSON`。

2. 场次首镜直接物化；同场后续镜头等待前序完成和真实 `last_frame_url`。

3. 用 `materialize-video` 在本次模板副本中注入前序尾帧和连续性提示词；其中 `@ImageX` 由 Runtime 替换为尾帧在本次 `metadata.content` 中的真实 `@ImageN` 编号，注入全文固定为：“镜头连续性硬性限制：@ImageX 是上一片段的真实尾帧。本片段开场必须紧接 @ImageX，继承同一场景的空间布局、机位方向、景别、光线、人物位置、朝向、服装、表情与动作进度；只能按本段剧本继续动作。不得重新布置场景、不得让人物瞬移、不得无依据改变服装或外观。” 将输出的完整 JSON 保存到该 Clip 的 `实际请求体JSON`，其中 `prompt` 为本次最终实际提示词。保留本次独立请求文件，再用 `materialize-video-params` 转换该文件为 live `op.video.generate` 参数，固定 `return_last_frame=true`。

4. 重新校验 `@Image/@Audio` 顺序、URL、媒体上限、时长、画幅、分辨率、seed 和音频策略；对最终实际请求 describe/quote。

5. 用户批准后只提交一次，校验返回 poll URL 与项目站点同源，立即保存 task、poll、请求哈希、报价和提交状态。

6. 使用包内 `poll-checkpoint --stage video` 只轮询原任务，及时保存每次查询状态并刷新，不等下载完成或下一个 Clip 提交。入口校验 `task_id/job_id` 与原检查点一致，并适配 `result.value` 或直接 `result` 的视频结果；字段和诊断详见 [视频 Runtime 合同](runtime-and-export.md#manturhub-视频算子)。成功响应必须提供官方 `video_url` 与 `last_frame_url`；返回地址不代表下载完成。下载到 `.pipeline-state/results/videos/**`，校验项目内路径、普通文件、MIME、大小与 SHA-256。

7. 写入每 Clip 视频结果并刷新快照；本地视频和尾帧都被 Compiler 成功回读后，状态才能成为 `completed`。

如果上游没有返回尾帧，只有 live 算子明确支持本地提取且结果记录 provenance 时才可使用；不得伪造成功尾帧。动态请求、远端响应、task、poll 和签名 URL 留在 Runtime 权威文件中，不进入只读 API。

首次生成、用户批准的重试或再次生成，均重新读取 `请求体模板JSON` 构建请求；不得把上次 `实际请求体JSON` 或已注入尾帧的文件作为下一次模板，不得将注入内容写回 `请求体模板JSON`。若模板已含历史尾帧或重复连续性段落，先核对并恢复干净模板再继续。轮询恢复只查询原任务，不重新物化或提交。字段保存和历史请求保留规则见 [runtime-and-export.md](runtime-and-export.md#请求字段与再次生成)。

再次生成前如用户修改了提示词，先完成 [修改 Clip 提示词的写回流程](runtime-and-export.md#修改-clip-提示词的写回流程)。禁止覆盖模板是指禁止用注入尾帧后的实际请求覆盖它，不禁止用户授权修改基础模板。



## 旧视频 Runtime 细节

## ManturHub 视频算子

每次付费调用前检查 live schema。先把实际 Seedance 请求确定性转换为 `op.video.generate` 参数：

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" materialize-video-params actual-seedance-request.json --output .pipeline-state/requests/video-params.json
```

转换器必须原样映射模型、提示词、时长、分辨率、画幅、图片引用及角色、reference audio、seed、音频策略和 `return_last_frame=true`，不得发明媒体。对生成的精确参数文件执行 describe/quote；用户批准后提交该文件。

长任务使用 `--no-wait`。提交成功后立即保存当前站、请求 SHA-256、quote、task ID 和 poll URL；确认 poll URL 与项目锁定站点同源。提交状态未知时停止，不得创建第二个任务。

使用 allowlist 中的 `poll-checkpoint` 保存原任务进度：

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" poll-checkpoint <poll_url> --stage video --state-file .pipeline-state/runs/<clip-id>.json --output-dir .pipeline-state/runs/checkpoints
```

该动作接受当前 CLI 的活动、成功、失败和取消状态；缺失或未知状态失败关闭；只查询原任务，永远不提交或重新提交付费调用。

视频响应适配与落盘规则：

- 视频轮询前必须已有带任务身份的检查点。响应及检查点均接受非空字符串 `task_id` 或 `job_id`；双字段必须一致，响应身份必须与原检查点完全一致，规范身份保存为 `task_id`。已有 `poll_url` 必须与本次查询目标一致，仍遵守项目单站锁定。身份缺失、无效、冲突或任务/目标不符返回 `VIDEO_*` 脱敏错误码，检查点不变，不绑定新任务。
- 成功状态兼容 `done`。结果优先取对象 `result.value`，否则取对象 `result`；视频优先 `video_url` 再取 `result_url`，尾帧取 `last_frame_url`，嵌套字段缺失时兼容顶层字段。只接受 HTTP(S) 地址，拒绝带用户名或密码的地址，不执行 `hint/next_actions` 等响应内容。
- 检查点及动作结果返回 `video_url/last_frame_url`，`result_url` 保留为视频地址兼容别名。它们仅供 Runtime 后续下载，不能进入 UI 快照。未知响应字段不整包复制。视频响应未提供 `checkpoint_seq` 时保留已有序号，不把它重置为零。
- 已确认的远端成功即刻保存，不等待本地下载。缺少地址返回 `result_diagnostic.code=VIDEO_RESULT_INCOMPLETE`；非法地址不保存并返回 `VIDEO_RESULT_URL_INVALID`。诊断不把远端成功改为失败，只能查询原任务补齐结果，不能重新提交。未知状态仍记录为 `submission_unknown`，不猜测终态。
- 每次查询落盘后沿用主动快照刷新，保留 Run、Clip、attempt、请求哈希与关联。刷新失败仅重试本地刷新；不要等下一 Clip 开始才写状态。返回地址不是完成门禁证明，媒体下载、真实尾帧与回读规则不变。

成功结果必须包含有效 `video_url` 和 `last_frame_url`。下载二者后逐项验证项目内路径、普通文件、非空、扩展名与内容 MIME、一致的 SHA-256，并写入 `.pipeline-state/results/<clip-id>-video-result.json`。公开或签名 URL、完整响应和远端任务标识留在 Runtime 私有结果中。

随后运行 `refresh-ui-snapshot`。只有新 Manifest 和对应剧集快照以同一 revision 成功回读，且视频与尾帧均为 `availability=available`，Clip 才能成为 `completed`。


分辨率允许值、超限拒绝与历史兼容统一遵循[分辨率设置与持久化合同](video-resolution.md)。
