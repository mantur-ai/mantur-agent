import { inspectOpenApiOperator } from './operator-schema-compatibility.mjs';

export const VERIFIED_DEV_CLI = '0.9.10-dev.20260810.9';
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export const diagnostic = code => Object.assign(new Error(code), {code});

export function parseCliVersion(value) {
  const match = /^(?:@manturhub\/cli\s+|manturhub(?:\s+version)?\s+)?v?((0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?)$/.exec(String(value).trim());
  if (!match || (match[5]?.split('.').some(part => /^\d+$/.test(part) && part.length > 1 && part[0] === '0'))) throw diagnostic('CLI_VERSION_UNSUPPORTED');
  const version = match[1];
  const prerelease = match[5] ?? null;
  if (prerelease ? version !== VERIFIED_DEV_CLI : Number(match[2]) === 0 && Number(match[3]) < 10) throw diagnostic('CLI_VERSION_UNSUPPORTED');
  return {version, prerelease, channel: prerelease ? 'dev' : 'stable'};
}

export function responseError(payload) {
  if (!object(payload)) return null;
  const code = payload.http_status ?? payload.statusCode ?? (typeof payload.status === 'number' ? payload.status : undefined) ?? payload.error?.status ?? payload.error?.code ?? payload.code;
  const failed = payload.success === false || payload.ok === false || payload.error != null || (code != null && ![0,200,'0','200','SUCCESS','OK'].includes(code));
  if (!failed) return null;
  return classifyCliFailure(JSON.stringify({code, message:payload.message, error:payload.error}));
}

// Inspect diagnostics only to classify them; never return remote text, URLs or credentials.
export function classifyCliFailure(text, systemCode) {
  if (/\b(?:EACCES|EPERM|EBUSY|SQLITE_BUSY|SQLITE_CANTOPEN|SQLITE_CORRUPT|SQLITE_IOERR)\b/i.test(text)) return 'MANTURHUB_AUTH_STORE_UNAVAILABLE';
  if (systemCode === 'ETIMEDOUT' || /\b(?:ETIMEDOUT|TIMEOUT|TimeoutError|AbortError)\b|timed? out/i.test(text)) return 'MANTURHUB_TIMEOUT';
  if (/\b401\b|UNAUTHORIZED|未配置 API Key|未登录/i.test(text)) return 'MANTURHUB_AUTH_REQUIRED';
  if (/\b403\b|FORBIDDEN|PERMISSION_DENIED/i.test(text)) return 'MANTURHUB_FORBIDDEN';
  if (/\b429\b|RATE_LIMIT/i.test(text)) return 'MANTURHUB_RATE_LIMITED';
  if (/\b50[0234]\b|SERVICE_UNAVAILABLE/i.test(text)) return 'MANTURHUB_SERVICE_UNAVAILABLE';
  if (/\b404\b|NOT_FOUND/i.test(text)) return 'MANTURHUB_NOT_FOUND';
  if (/ECONN|ENOTFOUND|EAI_AGAIN|fetch failed|network/i.test(text)) return 'MANTURHUB_NETWORK_ERROR';
  return 'MANTURHUB_RESPONSE_INCOMPATIBLE';
}

export function unwrapResponse(payload) {
  const error = responseError(payload);
  if (error) throw diagnostic(error);
  const data = Object.hasOwn(payload ?? {}, 'data') ? payload.data : payload;
  if (!object(data)) throw diagnostic('MANTURHUB_RESPONSE_INCOMPATIBLE');
  const nestedError = responseError(data);
  if (nestedError) throw diagnostic(nestedError);
  return data;
}

export function authenticationProfile(payload) {
  const data = unwrapResponse(payload);
  if (Object.hasOwn(data, 'totalBalance')) {
    const value = data.totalBalance;
    if (!((typeof value === 'number' || typeof value === 'string' && value.trim() !== '') && Number.isFinite(Number(value)))) throw diagnostic('MANTURHUB_RESPONSE_INCOMPATIBLE');
    return 'openapi'; // Authentication diagnostics do not expose account facts.
  }
  if (typeof data.email === 'string' && data.email.trim()) return 'legacy';
  throw diagnostic('MANTURHUB_RESPONSE_INCOMPATIBLE');
}

// Explicit chat-only balance reads; never return the account response wholesale.
export function accountBalancePoints(payload) {
  const data = unwrapResponse(payload);
  const value = data.totalBalance;
  if (!((typeof value === 'number' || typeof value === 'string' && /^[+-]?\d+(?:\.\d+)?$/.test(value.trim())) && Number.isFinite(Number(value)))) {
    throw diagnostic('MANTURHUB_BALANCE_UNAVAILABLE');
  }
  return Number(value);
}

export function inspectOperator(raw, operatorId) {
  const payload = unwrapResponse(raw);
  const ids = ['id', 'apiCode', 'operatorCode'].filter(key => Object.hasOwn(payload, key)).map(key => payload[key]);
  if (!ids.length || ids.some(id => id !== operatorId)) throw diagnostic('OPERATOR_IDENTITY_MISMATCH');
  const modern = Object.hasOwn(payload, 'apiCode') || Object.hasOwn(payload, 'operatorCode') || Object.hasOwn(payload, 'inputSchema') || Object.hasOwn(payload, 'outputSchema');
  if (modern) {
    try {
      const inspected=inspectOpenApiOperator(payload,operatorId);
      return {ok:true,code:null,profile:'openapi_v1',verification:inspected.verification,
        input_sha256:inspected.input_sha256,output_sha256:inspected.output_sha256,input_verification:inspected.input_verification,
        output_verification:inspected.output_verification,receipt:inspected.receipt,receipt_sha256:inspected.receipt_sha256,payload};
    } catch (error) {
      if (error?.code === 'OPERATOR_IDENTITY_MISMATCH' || error?.code === 'OPERATOR_UNAVAILABLE') throw diagnostic(error.code);
      return {ok:false,code:'OPERATOR_CONTRACT_UNVERIFIED',profile:'openapi_unverified',payload};
    }
  }
  if (payload.status !== 'online') throw diagnostic('OPERATOR_UNAVAILABLE');
  return {ok:true, code:null, profile:'legacy', payload};
}

export function hasReferenceImages(payload, profile) {
  const schema = profile === 'legacy' ? payload?.params_schema : payload?.inputSchema;
  const name = profile === 'legacy' ? 'reference_images' : 'referenceImages';
  return schema?.properties?.[name]?.type === 'array' ||
    profile === 'legacy' && schema?.[name]?.type === 'array' ||
    profile === 'legacy' && Array.isArray(schema) && schema.some(field => field?.name === name && field.type === 'array');
}

export function repairFor(code) {
  if (code === 'CLI_UNAVAILABLE' || code === 'CLI_NOT_FOUND') return 'Follow references/cli-onboarding.md: locate an existing CLI entry and npm global installation first; if absent, show a verified version, source and install scope, then ask permission before installing. Installation does not approve login, uploads or paid generation.';
  if (code === 'MANTURHUB_AUTH_REQUIRED' || code === 'MANTURHUB_OPERATOR_KEY_NOT_READY') return 'Run manturhub auth login --workbuddy on the locked environment, or set MANTURHUB_KEY for explicit-key automation';
  if (code === 'MANTURHUB_AUTH_STORE_UNAVAILABLE') return 'Repair local CLI credential-store access, then rerun manturhub auth status --json; do not export or copy the stored key';
  if (code === 'CLI_AUTH_ADAPTER_UNAVAILABLE') return 'Use stable ManturHub CLI >=1.2.5 for browser-login reuse, or set MANTURHUB_KEY for the explicit-key compatibility path';
  if (code === 'MANTURHUB_DEV_CROSS_ORIGIN_KEY_REQUIRED') return 'Development cross-origin OpenAPI requests require an explicit MANTURHUB_KEY; CLI-managed credentials remain same-origin';
  if (code === 'MANTURHUB_FORBIDDEN') return 'Check permissions on the locked environment; do not switch accounts or sites automatically';
  if (code === 'CLI_VERSION_UNSUPPORTED') return `Follow references/cli-onboarding.md: verify the existing channel and request upgrade permission for stable ManturHub CLI >=0.10.0 or verified ${VERIFIED_DEV_CLI}; preserve configuration and project site locks`;
  if (code === 'CLI_BASE_URL_UNAVAILABLE') return 'Follow references/cli-onboarding.md: inspect the existing CLI entry, package version and lib/config.js getBaseUrl(); do not assume it is uninstalled or automatically reinstall';
  if (code === 'OPERATOR_CONTRACT_UNVERIFIED') return 'Obtain and review the current operator contract; do not submit';
  return 'Retry the read-only check or inspect the current contract; do not resubmit production tasks or change sites';
}
