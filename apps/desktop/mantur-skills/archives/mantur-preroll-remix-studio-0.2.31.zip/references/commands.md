# 命令与输入合同

业务入口为`node <SKILL_DIR>/scripts/studio.mjs --source <HOST> --project <PROJECT_DIR> ACTION`，输入JSON由Agent依据真实用户意图整理，不把技术字段交给普通用户。ID只用字母、数字、连字符及下划线。工具纳管的执行入口和运行条件按[工具调用合同](cli.md)，不依赖相邻源码或私有模块。

`HOST`按[工具调用合同](cli.md)取当前实际宿主，不从安装方式、安装目录、`--client`或项目旧值推断。Agent已知当前宿主时主动传入；无法确认才保留`unknown`，不为埋点强制登录或阻断本地查看。真正调用工具前执行公共检查，直接运行脚本时逐项沿用返回的`bindingArgs`和`bindingEnv`，包括来源、业务及所选CLI/配置；后续每个新命令、工作台启动和重开都保持这一上下文。纯本地查看不额外执行账户检查。

直接运行与工具纳管两种入口都携带当前来源，例如：

```bash
node "<SKILL_DIR>/scripts/studio.mjs" --source "<HOST>" --project "<PROJECT_DIR>" open-workbench
manturhub skill exec mantur-preroll-remix-studio open-workbench --client "<安装目标>" --source "<HOST>" --project "<PROJECT_DIR>"
```

纳管的`skill run/doctor`也使用外层`--source <HOST>`；`--client`仅选择已安装副本。外层来源放在动作参数分隔符`--`之前，不能把完整ACCESS参数机械塞入CLI外层，其他环境/绑定参数按公共合同保留。此处示例不授权重跑已有制作。

`doctor`及已取得工作台上下文的结果提供`hostAttribution.source`，`verificationScope=CALLER_DECLARED`仅说明本次调用方声明，不证明后端已记录或宿主身份已认证；检查失败或无此观测时不补造来源。`HOST_SOURCE_UNKNOWN`是独立非阻断提示：未明确选择`unknown`且已知当前宿主时纠正下一入口参数，不重复向用户索要已知信息。显式`unknown`仍允许；没有诊断字段不等于已正确申报。旧绑定文件中的source不代表当前有效来源，不手工改该文件；已确认或受理的操作继续原快照。

当前为候选交付版本，离线流程闭环已验证；真实生产制作与目标宿主现场仍需核验。原调用恢复、下载及旧项目边界见[恢复合同](recovery.md)。工作台启动后进行一次只读余额查询，并支持手动刷新，显示最近查询金额和时间；查询不代表实时账户监控，切换授权后应重新刷新。未知或查询失败不显示为0，失败不阻断制作与原任务恢复，接入规则按[工具调用合同](cli.md)。所有输入示例只说明结构，素材路径、决定、回执和结果必须来自实际用户与文件，不可作为真实制作证据。

常规动作的顶层`guidance`提供只读接续建议：`title/message/actor/question/choices`面向用户，`nextAction/nextActions`供Agent按真实授权执行。不要将复制回复、导引中的建议或预算记录视为收费确认；实际确认仍以当前工具响应为准。`create-project/open-workbench/status/add-assets`也返回下一步，失败时保留原错误和当前已保存事实，不能只转述错误码。`doctor`转交公开检查生成的接入指引，业务不重写登录参数。独立的`attribution-context`仍只返回归因上下文。展示与中断话术见[工作台合同](workbench.md#每次停点都给出接续方式)。

## 项目与素材

`create-project --file manifest.json [--parent-directory DIR]`在用户工作区创建唯一项目，返回真实`projectDir`；`init --file manifest.json`使用显式`--project`目录。新项目不接受环境或服务地址覆盖。可先用`assets:[]`建立项目、展示素材库，再`add-assets --file`逐批导入。

```json
{"title":"前贴混剪项目","assets":[{"id":"ep3","role":"episode","episode":3,"path":"<用户选择的第三集绝对路径>"},{"id":"ep4","role":"episode","episode":4,"path":"<用户选择的第四集绝对路径>"},{"id":"ep5","role":"episode","episode":5,"path":"<用户选择的第五集绝对路径>"},{"id":"ending","role":"ending","path":"<用户选择的尾贴绝对路径>"},{"id":"logo","role":"logo","path":"<用户选择的PNG绝对路径>"}]}
```

导入复制文件并保存SHA256、大小及真实容器信息，不静默转码或更改原件。支持MP4/MOV/WebM及PNG。现有ID不能改指其他内容；换尾贴/Logo时用新ID，在计划明确`endingAssetId`和`logo.assetId`，多个同类素材不能猜选。

已有前贴使用`role:"front"`，计划引用`front.assetId`；用于模仿生成的参考使用`role:"reference"`，二者不混用。误导入时用新ID按正确角色重导并更新计划，保留旧记录，不重新付费生成。

`status`读取本地摘要；`guide`提示下一步，不扩大用户本次范围；`doctor`检查实际运行条件，不安装、登录或提交制作。`capabilities`经公共工具读取三个算子当前合同，不把读取成功当作制作或质量验收。

`attribution-context`只读返回`invocationContext`（未绑定时为`null`），不创建项目或流程ID、不检查授权、不启动工作台。继续项目先读取该结果，再以同一业务执行公共检查。

项目继续新制作时先复用原业务上下文，同一项目不在不同业务间切换。已有操作却未绑定业务时，新prepare/quote/invoke需用`--business-code <用户明确的业务>`指定后续归属；明确冲突或损坏即停止，不修改历史回执。远端prepare在describe/上传前检查归属；纯本地导入和plan不调用工具或新建归因状态。原poll/resume不补归因，细节见[恢复合同](recovery.md)。

`open-workbench`返回同项目真实URL；`serve`为其兼容别名。`create-project/init/add-assets`默认展示工作台，普通项目动作复用或恢复同一服务。默认`--browser host`由宿主复用项目页面；仅用户明确选择外部浏览器时使用`--browser auto`，系统展示后不再要求宿主另开页面；只有实际观察页面才称已展示。`--headless true`用于用户明确无需界面或独立自动化。细节见[工作台](workbench.md)。

## 模式与生成前贴

`select-mode --file mode.json`使用真实决定，如`{"mode":"viral","confirmed":true,"note":"用户明确选择爆款前贴智剪"}`；高光为`highlight`。详情见[制作模式](production-mode.md)。

`prepare-fronts --file fronts.json`的结构示例：

```json
{"bodyEpisodes":[3,4,5],"styleDecision":{"confirmed":true,"mode":"uniform","note":"用户明确确认本次统一真人实拍"},"items":[{"id":"front-a","label":"前贴A","style":{"name":"真人实拍","prompt":"真实人物与摄影质感"},"input":{"model":"wan3.0-video","prompt":"用户确认的画面文案","duration":5}}]}
```

每item一条请求，先完整校验批次。风格决定及每条约束按[风格合同](front-styles.md)；尺寸省略时按本次`bodyEpisodes`派生，item范围优先，明确覆盖按[尺寸合同](front-size.md)。准备操作不提交生成，但可能上传用户已选参考文件。

参考条目加`referenceAssetIds:["ref1"]`，必须对应已导入reference或episode；真实上传回执组装`ref_videos`，不在业务输入手填URL。模型参数必须核对当前公开合同；默认模型未支持请求时停止，不能静默换模型。prompt保留用户已确认的剧情及声音要求并追加风格约束，不把旧已追加prompt再次作为原始文案。WAN声音处理见[生成调用卡](operators.md#生成前贴opvideogenerate)，不因省略音频开关而改模型。

## 高光分析、选择与裁片

`prepare-analysis --file analysis.json`：

```json
{"episodes":[3,4,5],"count":3,"minDuration":1,"maxDuration":12}
```

只分析指定集，项目需至少3集原始剧集，实际分析可以只取1集。`count`为跨集选定高光数。公开分析请求使用summary/scenes，不传不存在的highlights任务名。`collect-highlights`收集合法完整线索池并建议N条；逐项隔离时间、分数或时长错误并报告诊断，合法项继续保留；结构或跨集来源异常停止核对；不足明确shortage，不伪造、重复凑数或自动重新付费分析。

`highlight-options`返回候选和已选ID；`select-highlights --file selection.json`使用`{"ids":["实际候选ID1","实际候选ID2","实际候选ID3"]}`。数量改变须`countChangeReason`记录真实决定。工作台“记录几”按该集当前分析的start/end/id时间顺序编号，匹配时核对operationId、集号和区间，不能使用全池分数顺序。

`prepare-highlights [--file clip-canvas.json]`仅准备选定N条独立裁片。默认沿用源尺寸并将帧率取合法整数；无法可靠推断则请求明确画布，如`{"canvas":{"width":720,"height":1280,"fps":24}}`。显式画布持久保存，换片不变部分复用。裁片不加尾贴/Logo，真实文件验收后才可进入最终计划。

单集重分析用`{"episodes":[3],"updateMode":"merge","refreshId":"本次实际新分析的稳定ID"}`，数量和时长范围省略沿用。merge不允许悄改全局约束；改变整个范围需`scopeChangeReason`。仅补页面展示不产生新的付费refreshId。重新收集保留仍有效的手动选择和裁片，失效项返回`selectionRequired`，不自动以其他候选替代。

## 正片接续与包装

`plan --file plan.json`：

```json
{"intent":"用户要求第三集第五秒开始共三集并保留原音轨","canvas":{"width":720,"height":1280,"fps":30},"logo":{"assetId":"logo","x":620,"y":20,"width":64,"height":64,"opacity":0.5},"endingAssetId":"ending","outputs":[{"id":"cut-a","label":"成片A","front":{"assetId":"实际前贴资产ID"},"body":[{"episode":3,"start":5},{"episode":4},{"episode":5}]}]}
```

高光前贴改用`front:{"highlightId":"实际已选高光ID"}`。body起点默认0、终点默认该集片尾，区间为半开区间；输出按帧网格排列，不修改源时间。画布需正偶数宽高、正整数fps。保留原布局时先读旧plan的canvas、logo、endingAssetId、front/body，不用默认值覆盖。

默认添加尾贴和全程水印。用户明确不添加时输入`packaging:{"ending":false,"logo":false}`，也可只关一项；仅接受布尔值，省略沿用项目已有明确决定，重新启用须有相应素材。无包装仍走同一计划和合成流程。

先向用户展示实际plan中每条前贴、正片集数/区间、尺寸、尾贴及水印。沿用已确认内容，缺项或矛盾才补问；用户改变接集或包装时更新plan，复用未变前贴，只重新准备受影响合成并核对报价。

`prepare-compose`用实际上传回执编译计划。公开视频位置为`position:{x,y}`，尺寸为`transform:{width,height}`，水印opacity在图片元素顶层。计划变动会使旧高光计划失效，必须重建，不执行历史prepared请求。

## 阶段执行与本地复验

阶段为`fronts`、`analysis`、`highlights`、`compose`。`quote --stage STAGE`展示当前尚未提交项的实时报价；`approve --stage STAGE --file approval.json`记录已有用户预算决定，如`{"maxPoints":100,"note":"用户明确批准的范围与预算原话摘要"}`。不得编造批准。该本地记录不代替公共工具实际收费确认，完整规则只维护在[工具调用合同](cli.md)。

`BALANCE_INSUFFICIENT`表示本次报价明确不足，按[统一充值指引](balance-recharge.md)提示；`BALANCE_UNKNOWN`表示无法判断，停止新提交且不据此推荐充值。报价失败会清除该项旧金额与报价摘要，不能沿用失败前的报价批准；重新报价成功后，仍匹配的已有预算保留，变价则重新确认。看板的只读余额查询失败与制作报价校验分别处理，不能用前者绕过后者。

`run --stage STAGE`用于经授权的新提交；`resume --stage STAGE`或`resume --operation OP`只恢复已有原调用，不执行prepared的首次提交。原调用有恢复标识才恢复；`resume`可能长时间等待，不能当成工作台有界查询。`select-result --operation OP --index 0`记录多结果中明确选择，不能盲选第一条。`retry --operation OP --file retry.json`仅用于明确失败且用户决定新收费尝试的当前操作，如`{"authorizeNewCharge":true,"reason":"真实用户决定"}`，随后重新报价和确认。详细限制见[恢复合同](recovery.md)。

实际收费确认按单项继续：`run --operation OP --confirm <该项原令牌>`。`--confirm`只用于明确的一项run，不能给整阶段或resume复用；其余项仍保留各自待确认状态。令牌只临时传递，不写输入文件、项目或网页；本地approve预算不代替实际令牌确认。

`redownload --operation OP`只重置当前操作的下载检查点，不创建制作任务；随后经公共下载入口恢复原产物；地址、文件或网络校验失败如实保留，不能因此承诺必定下载完成。`verify-media --operation OP [--local-tools true] [--full-decode true]`只复验已保存文件，默认不调用外部媒体工具；详见[媒体合同](media-validation.md)。

`check-updates`只观察公开工具返回的纳管/平台版本状态，不自动安装。发现更新时返回更新/继续选择及updateTarget；先取得实际用户选择，再按返回目标继续，不能自动选择。公开结果未提供源码版本或更新摘要时保持未知，不补造；更新决定不能代替制作或费用授权。

## 项目状态与升级

新项目使用schema2；旧schema1默认本地只读。`upgrade-project`先返回预览，不写入；用户明确批准后`upgrade-project --apply true --confirmed true --source-sha256 <预览摘要>`备份原状态再升级；源完整字节变化即停止。升级返回`readOnly:true`，历史项目仍仅本地审阅，保存、导入和其他业务写入口拒绝，不允许远端准备、上传或接管，后续新制作另建项目。旧未决调用阻断升级，仍须由原入口处理，不伪造恢复标识。细节见[恢复与升级](recovery.md)。

`.preroll/project.json`保存业务决定、真实请求与恢复线索；`.preroll/downloads/`为恢复缓存。素材放`素材/`，阶段产物放`中间产物/生成前贴/`及`中间产物/高光片段/`，最终文件放`最终成片/`，`制作记录/产物清单.json`只作脱敏清单。旧media目录不强制搬迁。私有状态不向网页开放，不将用户项目、凭据或收费确认令牌装入发行包。
