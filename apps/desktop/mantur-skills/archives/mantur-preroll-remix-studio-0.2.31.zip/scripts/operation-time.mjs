// Display only verified calendar values; task preparation is not submission.
function calendar(value,offsetRequired){
  if(typeof value!=='string')return null;
  const match=/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?(Z|[+-]\d{2}:\d{2})?$/.exec(value);
  if(!match||(offsetRequired&&!match[8])||(!offsetRequired&&match[8]))return null;
  const [year,month,day,hour,minute,second]=match.slice(1,7).map(Number);
  if(year<1970||month<1||month>12||day<1||hour>23||minute>59||second>59)return null;
  const date=new Date(Date.UTC(year,month-1,day,hour,minute,second));
  if(date.getUTCFullYear()!==year||date.getUTCMonth()!==month-1||date.getUTCDate()!==day)return null;
  if(offsetRequired){const normalized=new Date(value.replace(' ','T'));return Number.isFinite(normalized.getTime())?normalized.toISOString():null;}
  return `${match[1]}-${match[2]}-${match[3]} ${match[4]}:${match[5]}:${match[6]}`;
}

export function operationSubmission(op){
  const preparedAt=calendar(op?.createdAt,true);
  const attempted=calendar(op?.submissionAttemptedAt,true);
  const remote=calendar(op?.job?.createdAt,true);
  const serverCreatedAt=calendar(op?.job?.createdAt,false);
  if(attempted)return {time:attempted,source:'local_attempt',preparedAt,serverCreatedAt};
  if(remote)return {time:remote,source:'remote_created',preparedAt,serverCreatedAt:null};
  return {time:null,source:op?.status==='prepared'&&!op?.job?'not_submitted':'missing',preparedAt,serverCreatedAt};
}
