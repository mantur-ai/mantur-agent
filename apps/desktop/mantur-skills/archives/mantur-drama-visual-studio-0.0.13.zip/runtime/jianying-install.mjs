import { existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, realpathSync, renameSync, rmSync, statSync, writeFileSync, copyFileSync, constants } from 'node:fs';
import { basename, dirname, isAbsolute, relative, resolve } from 'node:path';
import { homedir } from 'node:os';
import { createHash, randomUUID } from 'node:crypto';
import { assertProjectWritePath, projectRoot, readJson, writeJson } from './common.mjs';
import { withProjectLock } from './project-lock.mjs';
import { extractStoredZip } from './zip.mjs';
import { sha256Media } from './media.mjs';
import { JIANYING_PROFILES, validateDraftPackage } from './jianying-format.mjs';

export const JIANYING_DIRECTORY_NOT_FOUND_MESSAGE = '未找到本机剪映草稿目录。这通常表示尚未安装剪映，或安装后还没有打开过。请先从剪映官网下载安装，并至少打开一次剪映；完成后告诉我“继续导出剪映草稿”。';

function fail(code, message = code) { throw Object.assign(new Error(message), { code, retryable: true }); }
export function nativeDraftPlatform() { return process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'macos' : null; }
export function defaultDraftDirectory(platform = nativeDraftPlatform(), environment = process.env, userHome = homedir()) {
  if (platform === 'windows') {
    if (!environment.LOCALAPPDATA || !isAbsolute(environment.LOCALAPPDATA)) fail('JIANYING_DIRECTORY_NOT_FOUND', JIANYING_DIRECTORY_NOT_FOUND_MESSAGE);
    return resolve(environment.LOCALAPPDATA, 'JianyingPro', 'User Data', 'Projects', 'com.lveditor.draft');
  }
  if (platform === 'macos') return resolve(userHome, 'Movies', 'JianyingPro', 'User Data', 'Projects', 'com.lveditor.draft');
  fail('JIANYING_PLATFORM_UNSUPPORTED');
}

export function assertSafeDraftPath(path) {
  let cursor = resolve(path);
  for (;;) {
    if (existsSync(cursor) && lstatSync(cursor).isSymbolicLink()) fail('JIANYING_UNSAFE_PATH');
    const parent = dirname(cursor);
    if (parent === cursor) break;
    cursor = parent;
  }
  return resolve(path);
}

export function requireDraftDirectory({ draftsDir, platform = nativeDraftPlatform() } = {}) {
  const targetRoot = assertSafeDraftPath(draftsDir || defaultDraftDirectory(platform));
  if (!existsSync(targetRoot) || !lstatSync(targetRoot).isDirectory()) {
    fail('JIANYING_DIRECTORY_NOT_FOUND', JIANYING_DIRECTORY_NOT_FOUND_MESSAGE);
  }
  return realpathSync(targetRoot);
}

export function inspectDraftPackage(directory) {
  const entries = [];
  function visit(path) {
    for (const e of readdirSync(path, { withFileTypes: true })) {
      const file = resolve(path, e.name);
      if (e.isSymbolicLink()) fail('JIANYING_UNSAFE_PATH');
      if (e.isDirectory()) visit(file);
      else if (e.isFile()) {
        const bytes = statSync(file).size;
        entries.push({ name: relative(directory, file).replaceAll('\\', '/'), bytes, sha256: sha256Media(file),
          ...(e.name.endsWith('.json') && bytes <= 16 * 1024 * 1024 ? { content: readFileSync(file) } : {}) });
      } else fail('JIANYING_UNSAFE_PATH');
    }
  }
  visit(directory);
  return { manifest: validateDraftPackage(entries), entries };
}


// Reserve human-readable names across projects before packaging, without touching editor drafts.
export async function reserveDraftName(baseName, outputDir, {draftsDir, install=false}={}) {
  function nextName(names, reserved=-1) {
    let maximum=reserved;
    for(let name of names) {
      if(name.endsWith('.zip'))name=name.slice(0,-4);
      if(name===baseName)maximum=Math.max(maximum,0);
      else if(name.startsWith(baseName+'（')&&name.endsWith('）')) {
        const value=name.slice(baseName.length+1,-1);
        if(/^[1-9][0-9]*$/.test(value))maximum=Math.max(maximum,Number(value));
      }
    }
    if(!Number.isSafeInteger(maximum)||maximum>=999999999999999)fail('JIANYING_NAME_LIMIT');
    const number=maximum+1;
    return {number,name:baseName+(number?'（'+number+'）':'')};
  }
  let root;
  if(install)try {
    const candidate=assertSafeDraftPath(draftsDir||defaultDraftDirectory());
    if(existsSync(candidate)&&lstatSync(candidate).isDirectory())root=realpathSync(candidate);
  }catch {/* Preserve package-only fallback when the installation directory is unavailable/unsafe. */}
  if(!root)return nextName(readdirSync(outputDir)).name;
  return withProjectLock(resolve(root,'.mantur-jianying-install.lock'),async()=>{
    assertSafeDraftPath(root);
    const registry=assertSafeDraftPath(resolve(root,'.mantur-draft-names.json'));
    if(existsSync(registry)&&(!lstatSync(registry).isFile()||statSync(registry).size>1024*1024))fail('JIANYING_NAME_REGISTRY_INVALID');
    const data=existsSync(registry)?readJson(registry,{object:true}):{schema_version:1,counters:{}};
    if(data.schema_version!==1||!data.counters||typeof data.counters!=='object'||Array.isArray(data.counters))fail('JIANYING_NAME_REGISTRY_INVALID');
    const key=createHash('sha256').update(baseName.toLowerCase()).digest('hex');
    const old=data.counters[key]??-1;
    if(!Number.isSafeInteger(old)||old< -1)fail('JIANYING_NAME_REGISTRY_INVALID');
    const next=nextName([...readdirSync(root),...readdirSync(outputDir)],old);
    const temporary=resolve(root,'.mantur-draft-names-'+randomUUID()+'.tmp');
    try {
      writeFileSync(temporary,JSON.stringify({...data,counters:{...data.counters,[key]:next.number}}),{flag:'wx'});
      renameSync(temporary,assertSafeDraftPath(registry));
    }finally{rmSync(temporary,{force:true});}
    return next.name;
  });
}

// Both export and retry use this installer. ZIP stays project-local; the editor owns installed copies.
export async function installDraftPackage(archive, { draftsDir, expectedSha256, applicationVersion = null } = {}) {
  archive = assertProjectWritePath(archive);
  if (!existsSync(archive) || !lstatSync(archive).isFile()) fail('JIANYING_PACKAGE_NOT_FOUND');
  const packageHash = sha256Media(archive);
  if (expectedSha256 && packageHash !== expectedSha256) fail('JIANYING_PACKAGE_HASH_MISMATCH');
  const scratch = assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/jianying-import', randomUUID()));
  let staging;
  try {
    extractStoredZip(archive, scratch);
    const { manifest, entries } = inspectDraftPackage(scratch);
    if (manifest.target_profile === 'jianying-macos-5.9') fail('JIANYING_LEGACY_REEXPORT_REQUIRED');
    const platform = manifest.target_profile === JIANYING_PROFILES.windows ? 'windows' : 'macos';
    if (platform !== nativeDraftPlatform()) fail('JIANYING_PLATFORM_MISMATCH');
    const canonicalRoot = requireDraftDirectory({ draftsDir, platform });
    return await withProjectLock(resolve(canonicalRoot, '.mantur-jianying-install.lock'), async () => {
      assertSafeDraftPath(canonicalRoot);
      const destination = assertSafeDraftPath(resolve(canonicalRoot, manifest.draft_folder_name));
      if (dirname(destination) !== canonicalRoot) fail('JIANYING_UNSAFE_PATH');
      const rootKey = createHash('sha256').update(process.platform === 'win32' ? canonicalRoot.toLowerCase() : canonicalRoot).digest('hex');
      const receiptPath = assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/jianying-installs', `${rootKey}-${manifest.idempotency_key}.json`));
      const markerName = '.mantur-install.json';
      const prior = existsSync(receiptPath) ? readJson(receiptPath, { object: true }) : null;
      const result = (reused) => ({ status: 'installed', reused, target_platform: platform, installed_path: destination,
        draft_id: manifest.draft_id, installed_at: prior?.installed_at || new Date().toISOString(),
        generator_format: manifest.generator_format, serialization_version: '5.9.0', application_version: applicationVersion,
        app_acceptance: reused && ['passed','failed'].includes(prior?.app_acceptance) ? prior.app_acceptance : 'pending',
        message: '已安装，可刷新草稿列表或重新打开剪映。' });
      if (existsSync(destination)) {
        const markerPath = assertSafeDraftPath(resolve(destination, markerName));
        if (!prior || !existsSync(markerPath) || !lstatSync(markerPath).isFile()) fail('JIANYING_INSTALL_CONFLICT');
        const marker = readJson(markerPath, { object: true });
        if (prior.installed_path !== destination || prior.draft_id !== manifest.draft_id || prior.package_sha256 !== packageHash
          || marker.token !== prior.token || marker.idempotency_key !== manifest.idempotency_key || marker.draft_id !== manifest.draft_id) fail('JIANYING_INSTALL_CONFLICT');
        // Native saving can rewrite/encrypt JSON: never hash or restore an existing editor-owned draft.
        const installed = result(true);
        writeJson(receiptPath, { ...prior, ...installed });
        return installed;
      }
      staging = resolve(canonicalRoot, `.mantur-install-${randomUUID()}`);
      mkdirSync(staging);
      const sourceRoot = resolve(scratch, manifest.draft_folder_name);
      for (const entry of entries) {
        const local = entry.name.slice(manifest.draft_folder_name.length + 1);
        const target = resolve(staging, local);
        mkdirSync(dirname(target), { recursive: true });
        copyFileSync(resolve(sourceRoot, local), target, constants.COPYFILE_EXCL);
        if (statSync(target).size !== entry.bytes || sha256Media(target) !== entry.sha256) fail('JIANYING_COPY_INTEGRITY_MISMATCH');
      }
      const token = randomUUID();
      writeFileSync(resolve(staging, markerName), JSON.stringify({ token, draft_id: manifest.draft_id, idempotency_key: manifest.idempotency_key }), { flag: 'wx' });
      const installed = result(false);
      const receipt = { schema_version: 1, ...installed, token, package_sha256: packageHash, idempotency_key: manifest.idempotency_key };
      // Pending receipt makes a crash immediately after rename recoverable without modifying the draft.
      writeJson(receiptPath, { ...receipt, status: 'pending' });
      assertSafeDraftPath(destination);
      if (existsSync(destination)) fail('JIANYING_INSTALL_CONFLICT');
      renameSync(staging, destination);
      staging = undefined;
      writeJson(receiptPath, receipt);
      return installed;
    });
  } finally {
    if (staging && existsSync(staging)) rmSync(staging, { recursive: true, force: true });
    if (existsSync(scratch)) rmSync(scratch, { recursive: true, force: true });
  }
}
