const positive=value=>typeof value==='number'&&Number.isFinite(value)&&value>0;
const dimension=value=>Number.isInteger(value)&&value>0&&value<=8192;

/** Reuse only facts on the selected result, never aggregate usage of another item. */
export function reusePlatformFacts(inspected,media,output){
  const result={...inspected};
  if(output?.usage?.mediaMetadataSource!=='MATERIALIZED_FILE'||!media||typeof media!=='object')return result;
  const reused=[];let inconsistent=false;
  for(const field of ['width','height']){
    if(!dimension(media[field]))continue;
    if(media[field]===inspected[field]){result[field]=media[field];reused.push(field);}else inconsistent=true;
  }
  if(positive(media.durationSec)&&output.usage.videoSecondsVerified===true){
    const tolerance=Math.max(inspected.fps?2/inspected.fps:0,.1);
    if(Math.abs(media.durationSec-inspected.duration)<=tolerance){
      // Preserve exact native stream ticks when available instead of rounded seconds.
      if(inspected.durationSource!=='video-ticks')result.duration=media.durationSec;
      reused.push('duration');
    }else inconsistent=true;
  }
  if(reused.length){result.metadataSource='platform+container';result.platformFields=reused;}
  if(inconsistent)result.platformMetadataStatus='inconsistent';
  return result;
}
