// Display/log projection only. Original CLI receipts and confirmation responses
// stay with their existing owners; never sanitize those objects in place.
const sensitiveAssignment=/(?:^|[^\w-])(?:\\*["']?[\w-]*(?:token|secret|password|cookie|api[-_ ]?key|authorization)\\*["']?)\s*[:=]\s*/gi;
const placeholder='[凭据已隐藏]';

function valueEnd(text,start){
  const first=text[start];
  // A JSON body may itself be logged as a JSON string. Without unpacking the
  // original response, hide the remaining escaped value conservatively.
  if(/^\\+["']/.test(text.slice(start)))return text.length;
  if(first==='"'||first==="'"){
    for(let i=start+1;i<text.length;i++){
      if(text[i]==='\\'){i++;continue;}
      if(text[i]===first)return i+1;
    }
    return text.length;
  }
  if(first==='{'||first==='['){
    const stack=[first==='{'?'}':']'];let quote;
    for(let i=start+1;i<text.length;i++){
      const c=text[i];
      if(quote){if(c==='\\')i++;else if(c===quote)quote=undefined;continue;}
      if(c==='"'||c==="'"){quote=c;continue;}
      if(c==='{'||c==='[')stack.push(c==='{'?'}':']');
      else if(c===stack.at(-1)){stack.pop();if(!stack.length)return i+1;}
    }
    return text.length;
  }
  // An unquoted credential may contain spaces. Do not leave its trailing words.
  const delimiter=text.slice(start).search(/[,;\r\n}\]]/);
  return delimiter<0?text.length:start+delimiter;
}
function redactAssignments(text){
  const pattern=new RegExp(sensitiveAssignment);let output='',cursor=0,match;
  while((match=pattern.exec(text))){
    const start=pattern.lastIndex;
    // Cookie headers use semicolons inside their sensitive value. Once control
    // separators are removed, conservatively hide the remaining unquoted field.
    const cookie=/cookie["']?\s*[:=]/i.test(match[0]);
    const end=cookie&&!['"',"'",'{','['].includes(text[start])?text.length:valueEnd(text,start);
    output+=text.slice(cursor,start)+placeholder;cursor=end;pattern.lastIndex=end;
  }
  return output+text.slice(cursor);
}

export function sanitizeText(value,{maxLength=400,redactPaths=false}={}){
  // Remove controls before matching so they cannot split credential names or
  // prefixes. Values are redacted before the final display-length limit.
  let text=String(value??'').replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'')
    .replace(/[\x00-\x1f\x7f-\x9f]/g,'');
  // Hide URLs first so query fields do not consume unrelated following prose.
  // A neutral marker cannot be mistaken for a structured credential value.
  text=text.replace(/https?:\/\/[^\s<>"']+/gi,'\uE000');
  text=redactAssignments(text).replaceAll('\uE000','[地址已隐藏]')
    .replace(/\bBearer\s+[^\s,;"'<>]+/gi,`Bearer ${placeholder}`)
    .replace(/\b(?:mtak_|sk-)[A-Za-z0-9_.=-]+/g,placeholder)
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)?\b/g,placeholder);
  if(redactPaths)text=text.replace(/(?:\/(?:Users|private|home|tmp|var|etc|opt)\/|[A-Z]:\\)[^\s<>"']+/g,'[路径已隐藏]');
  return text.replace(/[\r\n\t]/g,' ').replace(/\s+/g,' ').trim().slice(0,maxLength);
}

export function safeErrorCode(value,fallback='LOCAL_ERROR'){
  return typeof value==='string'&&/^[A-Z][A-Z0-9_]{0,95}$/.test(value)?value:fallback;
}
export function errorView(error,{fallbackCode='LOCAL_ERROR'}={}){
  const code=safeErrorCode(error?.code,fallbackCode);
  const message=typeof error?.message==='string'?error.message:typeof error==='string'?error:code;
  return {code,message:sanitizeText(message)||'步骤失败'};
}
