#!/usr/bin/env node
import { ACTIONS } from "./actions.mjs";

const [action, ...args] = process.argv.slice(2);

async function main() {
  if (!action || !Object.hasOwn(ACTIONS, action)) throw new Error(`action is not allowlisted: ${action || "(empty)"}`);
  const payload = await ACTIONS[action](args);
  if (payload === null || typeof payload !== "object" || Array.isArray(payload)) {
    throw new Error(`action ${action} returned an invalid result`);
  }
  process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
  if (payload.ok === false || payload.failed === true) process.exitCode = 1;
}

main().catch((error) => {
  process.stdout.write(`${JSON.stringify({
    ok: false,
    error: {
      code: "SKILL_ACTION_FAILED",
      message: error instanceof Error ? error.message : String(error),
    },
  }, null, 2)}\n`);
  process.exitCode = 1;
});
