# CLI 调用合同

本页是业务唯一的工具接入入口，要求公共 CLI 1.2.10 及以上正式版，默认安装最新版正式 CLI（`@latest`），已验证的回归基线为 1.2.10。仅梳理需求或读取已有本地产物时无需安装、登录或联网；实际调用前按 [channel.md](channel.md) 准备运行条件和授权，按 [access.md](access.md) 使用固定环境与命令转发。具体版本、站点、凭据位置和宿主按钮只在接入/发行层维护，不写进业务流程。

## 调用入口

尚未有平台账号时，可按 [注册入口](registration.md) 选择当前宿主的引流链接；注册与 CLI 授权分别完成。当前宿主由每次ACCESS --source明确提供；调用businessCode来自当前调用方上下文，Skill身份/版本由包内接入层提供，业务 input 保持算子 Schema。支持归因的 profile v2 会把业务脚本的流程/步骤参数交给 CLI；确认与恢复沿用首次归因快照。新归因包的注册businessCode表示引流Skill及接入形态：独立技能为产品id加-skill，连接器加-connector。缺registrationBusinessCode的旧profile沿用原产品id，不能判成独立技能，不回填旧数据；不与调用业务自动合并。

ACCESS替换为本包`scripts/access.mjs`的绝对路径；参数逐项传递，不拼接shell字符串。业务脚本返回的`cli.args`原样传给ACCESS，不直接执行其`cli.command`。下面省略接入选项；独立入口按channel.md先check默认发现本地CLI，再在每次exec前带上返回的同一组bindingArgs（`--source`、`--business-code`、`--existing-cli`和`--config-dir`），包括报价、确认调用及resume。连接器复用check返回的业务码bindingArgs，其他身份/包元数据仍使用宿主环境，不能中途换入口。

```bash
node "ACCESS" exec -- describe <算子代码> --json
node "ACCESS" exec -- quote <算子代码> --json-file "参数文件" --json
node "ACCESS" exec -- run <算子代码> --json-file "参数文件"
node "ACCESS" exec -- resume <原恢复ID>
```

describe以当前身份的线上合同为准，不可发现即停止；本地算子说明不是上架证明。quote仅取报价，run仍会重新报价；通常直接按业务脚本返回的run参数执行，无需重复quote。run的stdout默认JSON，不加无值的`--json`；也支持`--json '<JSON>'`，本地项目统一使用`--json-file`。

## 费用与文件

- run不是纯报价：正额固定报价退出3，确认信息在stderr。展示实际价格、范围及返回的有效期，用户明确批准后以原参数追加CLI返回的`--confirm <confirmation_token>`。令牌只用于临时命令，不写项目或交付物；过期后重新取得报价和确认。
- 升级包或自动环境中的宿主、Skill版本、发行目标、接入方式变化，不改原确认快照；业务/Skill身份、流程/步骤冲突仍停止。显式改写快照字段继续拒绝，账号/站点/算子/输入/价格校验保持。
- 只有`billable=false`、金额0且`postExecutionSettlement`缺失/null才可直接免费受理，也需用户批准该业务操作。畸形报价、收费但金额0、任何非null后结算合同都停止，不换旧CLI或HTTP绕过。
- `--file "<Schema文件字段>=<本地路径>"`由CLI完成上传/确认并替换fileId。上传在报价前就可能发生，先确认用户选定文件及使用权；退出3不表示文件尚未上传。确认后复用相同文件和参数，不单独重复上传。
- 文件类型/大小按describe，不使用任意URL绕过。扫描PDF或复杂排版要人工核对分析效果。
- 报价不是最终扣费，失败也不等于已退款；以公开`billing/_billing`及平台记录为准。

## 回执、结果与恢复

stdout保存为单独JSON，stderr中的进度、确认信息和恢复ID分别处理，记录真实退出码。recoveryId、jobId、本地callId/stepId互不等同。

CLI stdout 是解包后的任务对象，不再包 HTTP `Result.data`。以下是字段位置示意，不是可导入的完整业务结果：

```json
{"jobId":"示意任务ID","operatorCode":"op.script.review","status":"SUCCEEDED","output":{"schemaVersion":"script.review.v1","action":"SCAN","status":"REVIEW_REQUIRED"}}
```

这里顶层 status 表示任务执行成功，output.status 表示仍有审校问题；数据算子的 output.outcome/status 也只表示业务结果。项目的 qualityAccepted 是另外的本地验收事实，不能从任一成功状态自动推导。输入只包含算子业务参数，不包含 jobId、任务 status、output 包装或本地项目 ID；下游只按业务引用取完整 output 或指定子对象，不能把整个 stdout 直接作为下游参数。

CLI 校验输入合同；本地业务脚本仅提供关键结构与流程护栏，并非完整输出 Schema 验证器。收到输出仍需核对当前合同的关键字段、业务状态与质量门禁；缺少字段就停止，不用示例或模型补齐。

| 实际结果 | 后续动作 |
| --- | --- |
| 退出3，未受理 | 记录待费用确认；批准后确认同一调用，不把报价当业务产物 |
| QUEUED/RUNNING/PENDING或提交结果未知 | 保存原恢复ID与jobId，resume查询；不新建调用 |
| `--no-wait`回执为SUCCEEDED、output缺失/null且带CLI作业pollUrl | 只是结果待获取；按原恢复ID查询，不再次run，不直接访问返回URL |
| 退出0、SUCCEEDED且完整output | 按算子Schema校验，才可导入并继续下游 |
| 恢复查询仍无output，或output为非法对象/缺少jobId等关键合同 | 停止排查，保留ID和原始响应；不无限轮询、不造结果 |
| 明确FAILED/CANCELED等终态 | 保存错误与账务；用户明确要求新尝试后，走业务脚本允许的重试入口及新的报价/调用 |

未知任务只恢复原调用；终态后的新尝试不是resume，不承诺免费，也不能一概复用已失败调用的幂等键。参数变更不能套用旧确认令牌。幂等与记录由CLI管理，不手工生成或替换。缺少恢复ID时核对CLI/平台记录，不据此推断未提交。

## 长任务与宿主执行预算

实际提交前核对当前宿主是否支持长进程或后台任务。当前CLI的run默认等待结果，resume也会持续轮询，默认轮询预算20分钟；宿主的命令执行预算可能更短。不要套用认证命令的超时作为业务执行超时。

- 宿主支持长进程：使用它提供的后台执行/继续读取输出机制，保存stdout、stderr和原恢复ID；等待同一进程，不重复run。
- 需要先取提交回执：可在业务脚本给出的run参数后追加`--no-wait`，其他业务参数与确认令牌不变；按原callId记录回执。它不是有界查询，随后resume仍可能长时间等待，不能宣称仅加此标志就适配了短超时宿主。
- 宿主既不支持长进程、也不能继续读取后台结果：在提交前说明限制并暂停；不要反复杀进程重跑。若任务已经受理，保留原ID，回到同一CLI、账号及配置目录恢复，不新建收费任务。

当前适配器没有单次有界查询接口；后续若需要，应先在CLI实现并回归，再更新公共合同，不能由Skill另写HTTP、直接访问pollUrl或猜造resume参数。

## 认证错误与凭据迁移

认证失效按channel的入口重新授权；403也可能是权限不足，先看错误信息，不反复登出/登录。不能通过换账号、目录或渠道重提未决任务。

当前 CLI 使用本机私有 SQLite 凭据库，进程崩溃由事务恢复，不再要求手工删除凭据锁。首次修改凭据时由 CLI 迁移旧文件；若检测到旧 `client-credentials.lock`，会隔离旧会话并提示重新登录，旧文件与锁保留。停止使用同目录的旧版 CLI；不要手工改库、删除新库或移走旧锁来恢复旧登录。凭据库只支持本机磁盘，含明文凭据，不可共享上传。迁移后不能降级到使用旧凭据文件的版本。

登出先提交本地退出，再限时处理远端撤销；失败会保留重试记录并提示到平台核对，本地退出不等于远端已撤销。公共安装锁和业务项目锁仍各有恢复规则，不与凭据迁移混用。


余额不足时遵守[余额与充值指引](balance-recharge.md)，单项和批次均适用；余额未知不误判，充值后不自动重提。


CLI 检查后必须在对话中展示结果及适用的升级命令，按[版本与升级提示](cli-upgrade.md)处理；不自动升级，不重复提示。


显式测试模式见[test-mode.md](test-mode.md)。本包默认生产；只有用户指定测试任务时才使用外部测试环境。check返回的bindingEnv与bindingArgs在后续业务脚本、调用、费用确认及恢复中保持一致；有cli.accessArgs时追加其项目绑定，不修改cli.args。旧pending保留原回执与输入，先在原环境resume。

## 本地工作流入口

本包的 `skill-runtime.json` 提供 CLI 纳管安装后的 `skill doctor/run/exec` 入口。doctor 检查本地安装，run 展示新项目所需信息或恢复已有项目状态；两者不登录、不上传、不调用算子。仅讨论需求时仍直接使用 Skill，无需先运行命令。

此入口继续使用上述 ACCESS 的检查、授权、归因与显式测试环境合同，不另建 CLI 或凭据目录。项目状态中的下一步由 Agent 在用户授权范围内执行，启动成功不表示生成完成。

## 授权文件上传

业务运行时返回独立上传步骤时，采用本节流程，不把上面的通用 `--file` 示例混入报价或确认；旧在途调用仍按原回执恢复，不改写原输入。

本包显式支持 `ACCESS exec -- upload <选定文件的绝对路径> --json`。仅在用户确认源文件及用途后上传，沿用 check 返回的 bindingArgs/bindingEnv 和项目 cli.accessArgs；保存 AVAILABLE 回执中的 fileId、SHA256、大小，不保存下载链接。通过本地绑定校验后再报价，报价及确认输入都固定该 fileId，不重新上传、不读取共享上传缓存。
