#!/usr/bin/env bash
# 各段统一分辨率+帧率后拼接成片（各段尺寸/帧率不一致会错位，必须先统一）
# 用法: concat_videos.sh <out.mp4> <W> <H> <part1.mp4> <part2.mp4> ...
set -e
OUT="$1"; W="$2"; H="$3"; shift 3
[ -z "$OUT" ] || [ -z "$3" ] && { echo "用法: concat_videos.sh <out.mp4> <W> <H> <part1.mp4> <part2.mp4> ..."; exit 1; }
INPUTS=(); FILTER=""; i=0
for f in "$@"; do
  INPUTS+=(-i "$f")
  FILTER+="[$i:v]scale=$W:$H:force_original_aspect_ratio=disable,setsar=1,fps=24[v$i];"
  i=$((i+1))
done
CC=""; for j in $(seq 0 $((i-1))); do CC+="[v$j][$j:a]"; done
ffmpeg -y "${INPUTS[@]}" -filter_complex "${FILTER}${CC}concat=n=$i:v=1:a=1[v][a]" \
  -map "[v]" -map "[a]" -c:v libx264 -pix_fmt yuv420p -c:a aac -movflags +faststart "$OUT" 2>/dev/null
echo "→ $OUT (${i} 段拼接，统一 ${W}x${H} @24fps)"
