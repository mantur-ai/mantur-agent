// Package implementation facts. Never read capability switches from a user project.
import {resolveVideoModel} from './video-models.mjs';
export function clipCapabilities(operatorContractReady,model='seedance-2.0') {
  const selected=resolveVideoModel(model);
  if(!selected.artifactReady)return {
    phase:'platform_contract_pending',operator_contract_ready:operatorContractReady===true,
    business_contract_ready:false,workflow_ready:false,production_manifest_ready:true,
    local_clip_intake_ready:false,activation_pending:true,simulated_workflow_verified:false,
    video_ready:false,deployment_verified:false,error_code:'WAN_PLATFORM_CONTRACT_NOT_READY',
    message:'平台分镜产物解析合同尚未就绪。',
    missing_contracts:['wan_primary_json_adapter'],
    supported_profile:'wan-file-video-v1',next_action:'obtain_platform_contract_and_artifacts',
  };
  return {
    phase: selected.id==='wan-3.0'?'wan_observed_artifact_verified':'5A_observed_profile_mock_verified',
    operator_contract_ready: operatorContractReady === true,
    business_contract_ready: true,
    workflow_ready: operatorContractReady === true,
    production_manifest_ready: true,
    local_clip_intake_ready: true,
    activation_pending: false,
    simulated_workflow_verified: true,
    video_ready: false,
    deployment_verified: false,
    error_code: operatorContractReady ? null : 'OPERATOR_CONTRACT_UNVERIFIED',
    missing_contracts: [],
    supported_profile: selected.id==='wan-3.0'?'wan-storyboard-v1-to-local-v2':'production-manifest-v2-restricted-overrides-file-refs-v1',
    unsupported_paths: ['numeric_row_overrides','protected_field_overrides','reference_only_reuse','unknown_business_version'],
    next_action: operatorContractReady ? 'prepare-clip-compilation' : 'review_operator_contract',
  };
}
