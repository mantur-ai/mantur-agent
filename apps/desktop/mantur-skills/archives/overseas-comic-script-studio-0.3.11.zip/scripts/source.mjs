#!/usr/bin/env node
// Local source preparation only; never upload, summarize, OCR or call an operator.
import { createHash } from 'node:crypto';
import { existsSync, lstatSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { extname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

export const SOURCE_LIMITS = Object.freeze({ readBytes: 32 * 1024 * 1024, uploadBytes: 5 * 1024 * 1024, textUnits: 30000 });
const need = (ok, message) => { if (!ok) throw new Error(message); };
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const textTypes = new Set(['.txt', '.md', '.json']);
// Treat CRLF as one boundary; a terminal newline does not create a fictitious extra line.
const lines = text => text.match(/[^\r\n]*(?:\r\n|\r|\n)|[^\r\n]+$/g) || [];

/** Byte-preserving inspection; the character ceiling is a local scheduling rule, not model capacity. */
export function inspectSource(file) {
  const stat = lstatSync(file), extension = extname(file).toLowerCase();
  need(stat.isFile() && !stat.isSymbolicLink(), 'Source must be a regular file, not a symlink');
  need(stat.size > 0 && stat.size <= SOURCE_LIMITS.readBytes, 'Source must contain 1 byte..32 MiB; select or extract a smaller text copy first');
  need(textTypes.has(extension) || ['.pdf', '.docx'].includes(extension), 'Use UTF-8 txt/md/json or extract a verified text copy from PDF/DOCX');
  const bytes = readFileSync(file);
  need(bytes.length > 0 && bytes.length <= SOURCE_LIMITS.readBytes, 'Source size changed beyond the reading limit');
  const report = { schemaVersion: 'script.source-inspection.v1', sha256: sha(bytes), bytes: bytes.length, extension, limits: SOURCE_LIMITS };
  if (!textTypes.has(extension)) return { report: { ...report, status: 'NEEDS_TEXT_EXTRACTION' } };
  let body;
  try { body = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes); }
  catch { throw new Error('Source is not valid UTF-8; convert a copy and verify it before analysis'); }
  need(!body.includes('\u0000') && body.trim().length > 0, 'Source is empty or contains binary NUL characters');
  return { bytes, body, report: { ...report, textUnits: body.length, lineCount: lines(body).length,
    status: bytes.length <= SOURCE_LIMITS.uploadBytes && body.length <= SOURCE_LIMITS.textUnits ? 'READY' : 'NEEDS_SELECTION' } };
}

/** Select exact contiguous lines chosen by the user; never silently truncate or overwrite a file. */
export function selectSource(file, start, end, out) {
  const inspected = inspectSource(file);
  need(inspected.body !== undefined, 'Extract and verify UTF-8 text before selecting lines');
  const all = lines(inspected.body);
  need(Number.isSafeInteger(start) && Number.isSafeInteger(end) && start >= 1 && start <= end && end <= all.length, 'Line range must be 1-based, inclusive and within the source');
  need(['.txt', '.md'].includes(extname(out).toLowerCase()), 'Selected source must use .txt or .md');
  const selected = all.slice(start - 1, end).join(''), bytes = Buffer.from(selected, 'utf8');
  need(selected.trim().length > 0 && selected.length <= SOURCE_LIMITS.textUnits && bytes.length <= SOURCE_LIMITS.uploadBytes, 'Selected range is empty or exceeds the local source limit; choose a smaller complete chapter/scene range');
  const receipt = { schemaVersion: 'script.source-selection.v1', original: { sha256: inspected.report.sha256, bytes: inspected.report.bytes, textUnits: inspected.report.textUnits, lineCount: all.length },
    selected: { sha256: sha(bytes), bytes: bytes.length, textUnits: selected.length }, range: { startLine: start, endLine: end } };
  const target = resolve(out), manifest = `${target}.scope.json`;
  need(!existsSync(target) && !existsSync(manifest), 'Selection output or receipt already exists; use a new path');
  // Exclusive writes retain evidence if the second write fails; never remove a path that could be another writer's.
  writeFileSync(target, bytes, { flag: 'wx', mode: 0o600 });
  writeFileSync(manifest, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  return { file: target, selection: manifest, ...receipt };
}

/** Bind a selection receipt to the exact file; provenance is a local record, not proof of user consent. */
export function checkSelection(receipt, report) {
  need(receipt?.schemaVersion === 'script.source-selection.v1', 'Invalid selection receipt');
  const a = receipt.original, b = receipt.selected, r = receipt.range;
  need(a && b && r && Object.keys(receipt).length === 4 && Object.keys(a).length === 4 && Object.keys(b).length === 3 && Object.keys(r).length === 2, 'Invalid selection receipt fields');
  need(/^[a-f0-9]{64}$/.test(a.sha256) && ['bytes', 'textUnits', 'lineCount'].every(k => Number.isSafeInteger(a[k]) && a[k] > 0)
    && a.bytes <= SOURCE_LIMITS.readBytes && a.textUnits <= a.bytes && a.lineCount <= a.textUnits, 'Invalid original source identity');
  need(b.sha256 === report.sha256 && b.bytes === report.bytes && b.textUnits === report.textUnits && a.bytes >= b.bytes && a.textUnits >= b.textUnits, 'Selection receipt does not match the selected file');
  need(Number.isSafeInteger(r.startLine) && Number.isSafeInteger(r.endLine) && r.startLine >= 1 && r.endLine >= r.startLine && r.endLine <= a.lineCount
    && r.endLine - r.startLine + 1 === report.lineCount, 'Invalid selection line range');
  return structuredClone(receipt);
}

if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  try {
    const [action, ...args] = process.argv.slice(2), opts = {};
    if (!action || action === '--help') console.log('source.mjs inspect --file <UTF-8 text or document> | select --file <UTF-8 text> --start-line N --end-line M --out <new .txt/.md>. Local-only; see references/adaptation.md.');
    else {
      need(['inspect', 'select'].includes(action), 'Unknown source action');
      const allowed = action === 'inspect' ? ['file'] : ['file', 'start-line', 'end-line', 'out'];
      for (let i = 0; i < args.length; i += 2) {
        const key = args[i].slice(2);
        need(args[i].startsWith('--') && allowed.includes(key) && !Object.hasOwn(opts, key) && args[i + 1] !== undefined, 'Unknown, repeated or incomplete argument');
        opts[key] = args[i + 1];
      }
      need(allowed.every(key => opts[key]), 'Missing source arguments');
      const result = action === 'inspect' ? inspectSource(opts.file).report : selectSource(opts.file, Number(opts['start-line']), Number(opts['end-line']), opts.out);
      console.log(JSON.stringify({ ok: true, ...result }, null, 2));
    }
  } catch (error) { console.error(JSON.stringify({ ok: false, error: error.message })); process.exitCode = 1; }
}
