import { lstat, rename, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { check, fileHash, loadProject, projectFolder, saveProject, withLock } from './project.mjs';
import { publicProjectClient } from './integration.mjs';
import { recordRemoteReceipt, selectedArtifact, syncExisting } from './workflow.mjs';
import {errorView,safeErrorCode} from './diagnostics.mjs';

const eligible=new Set(['unknown','running','remote_succeeded','artifact_pending']);
const stopErrors=new Set(['CLI_RECEIPT_INVALID','CLI_REJECTION_INVALID','CLI_RECOVERY_ID_CHANGED','CLI_REJECTION_MISMATCH','JOB_RECEIPT_INVALID','JOB_STATUS_INVALID','JOB_STATUS_REGRESSION','JOB_ID_MISMATCH','ANALYSIS_OUTPUT_INVALID','VIDEO_RESULT_MISSING','ARTIFACT_URL_UNAVAILABLE']);
const skipOperation=(id,reason)=>({operations:[],skipped:[{id,reason}]});
const currentOperation=(project,original)=>{
  const operation=project.operations.find(op=>op.id===original.id);
  return project.schemaVersion===2&&!project.legacyOrigin&&operation&&eligible.has(operation.status)
    &&operation.status===original.status&&operation.job?.jobId===original.job?.jobId&&operation.job?.status===original.job?.status
    &&operation.requestHash===original.requestHash&&operation.recoveryId===original.recoveryId
    &&operation.selectedResult===original.selectedResult?operation:null;
};

/** At most two original recovery processes, outside the write lock. No submission path. */
export function backgroundRecovery(projectDir,{signal,clientFactory=publicProjectClient}={}){
  let cursor=0;
  return async()=>{
    const snapshot=await loadProject(projectDir);
    if(snapshot.schemaVersion!==2||snapshot.legacyOrigin||signal?.aborted)return {operations:[],skipped:[],newPaidTask:false};
    const pending=snapshot.operations.filter(op=>eligible.has(op.status));
    const skipped=pending.filter(op=>!op.recoveryId||stopErrors.has(op.error?.code)).map(op=>({id:op.id,status:op.status,reason:safeErrorCode(op.error?.code,'CLI_RECOVERY_ID_REQUIRED')}));
    const candidates=pending.filter(op=>op.recoveryId&&!stopErrors.has(op.error?.code));
    if(!candidates.length)return {operations:[],skipped,newPaidTask:false};
    const selected=Array.from({length:Math.min(2,candidates.length)},(_,i)=>candidates[(cursor+i)%candidates.length]);
    cursor=(cursor+selected.length)%candidates.length;
    const results=await Promise.all(selected.map(async original=>{
      const client=clientFactory({project:snapshot,projectDir,signal});
      let staging,artifact,preparedOperation;
      try{
        const receipt=await client.poll(original.job,original.recoveryId,original);
        if(signal?.aborted)return {operations:[],skipped:[]};
        const prepared=await withLock(projectDir,async()=>{
          if(signal?.aborted)return {operations:[],skipped:[]};
          const current=await loadProject(projectDir),operation=currentOperation(current,original);
          if(!operation)return skipOperation(original.id,'PROJECT_CHANGED_DURING_RECOVERY');
          await recordRemoteReceipt(projectDir,current,operation,receipt,client);
          if(operation.stage==='analysis'||operation.status!=='remote_succeeded')
            return operation.status==='remote_succeeded'
              ?syncExisting(projectDir,current,{...client,poll:async()=>receipt},operation.id)
              :{operations:[{id:operation.id,status:operation.status,...(operation.error?{error:errorView(operation.error)}:{})}],skipped:[]};
          operation.status='artifact_pending';await saveProject(projectDir,current);
          return {operation:structuredClone(operation)};
        });
        if(!prepared.operation)return prepared;
        preparedOperation=prepared.operation;
        artifact=selectedArtifact(prepared.operation);
        const target=join(await projectFolder(projectDir,'.preroll/downloads'),artifact.fileName);
        let cached=false;
        if(prepared.operation.downloaded&&prepared.operation.downloadedFor===artifact.binding){
          try{
            const info=await lstat(target);check(info.isFile()&&!info.isSymbolicLink(),'DOWNLOAD_PATH_INVALID');
            const fact=await fileHash(target);check(fact.sha256===prepared.operation.downloaded.sha256&&fact.size===prepared.operation.downloaded.size,'DOWNLOAD_CHANGED');
            cached=true;
          }catch(error){if(error.code!=='ENOENT')throw error;}
        }
        let downloaded;
        if(!cached){
          if(signal?.aborted)return {operations:[],skipped:[]};
          staging=join(await projectFolder(projectDir,'.preroll/download-staging'),`${randomUUID()}.mp4`);
          downloaded=await client.download(artifact.url,staging);
          const fact=await fileHash(staging);check(fact.size>0&&fact.sha256===downloaded.sha256&&fact.size===downloaded.size,'DOWNLOAD_CHANGED');
        }
        if(signal?.aborted)return {operations:[],skipped:[]};
        return await withLock(projectDir,async()=>{
          const current=await loadProject(projectDir),operation=currentOperation(current,preparedOperation);
          if(signal?.aborted)return {operations:[],skipped:[]};
          if(!operation||selectedArtifact(operation).binding!==artifact.binding)return skipOperation(original.id,'PROJECT_CHANGED_DURING_RECOVERY');
          return syncExisting(projectDir,current,{...client,poll:async()=>receipt,
            download:async(url,destination)=>{
              check(!signal?.aborted&&staging&&url===artifact.url&&destination===target,'ARTIFACT_STAGING_CHANGED');
              try{const info=await lstat(destination);check(info.isFile()&&!info.isSymbolicLink(),'DOWNLOAD_PATH_INVALID');}catch(error){if(error.code!=='ENOENT')throw error;}
              await rename(staging,destination);staging=undefined;return downloaded;
            }},operation.id);
        });
      }catch(error){
        if(!signal?.aborted&&(preparedOperation||stopErrors.has(error.code))){
          try{await withLock(projectDir,async()=>{
            const current=await loadProject(projectDir),operation=currentOperation(current,preparedOperation||original);
            if(!operation||(artifact&&selectedArtifact(operation).binding!==artifact.binding))return;
            if(preparedOperation)operation.status='artifact_pending';
            operation.error=errorView(error,{fallbackCode:'ARTIFACT_RECOVERY_FAILED'});await saveProject(projectDir,current);
          });}catch{/* Keep remote-success evidence if the project is busy. */}
        }
        return {operations:[],skipped:signal?.aborted?[]:[{id:original.id,status:original.status,reason:safeErrorCode(error.code,'RECOVERY_INCOMPLETE')}]};
      }finally{if(staging)await rm(staging,{force:true});}
    }));
    return {operations:results.flatMap(result=>result.operations),skipped:[...skipped,...results.flatMap(result=>result.skipped||[])],newPaidTask:false};
  };
}
