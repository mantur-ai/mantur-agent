// Local evidence and revision bookkeeping. No model, transport, billing or semantic classifier.
import { createHash } from 'node:crypto';
import { renderEpisode } from './readable.mjs';

const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const need = (ok, message) => { if (!ok) throw new Error(message); };
const text = value => typeof value === 'string' && value.trim().length > 0;
const fields = (value, keys) => value && typeof value === 'object' && !Array.isArray(value)
  && Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const normalized = value => value.normalize('NFC').trim().replace(/\s+/gu, ' ');
const own = (value, key) => value != null && Object.hasOwn(value, key);
const identityField = key => /^(?:id|ids|name|names|canonicalName|character|speaker|gender|type|schemaVersion|generationMode|language|outputLanguage)$/i.test(key)
  || /(?:Id|Ids|Name|Names|Digest|Sha256)$/.test(key) || /(?:_id|_ids|_name|_names|_digest|_sha256)$/i.test(key);
const occurrencesDigest = (signals, issue) => hash(signals.filter(s => issue.signalIds.includes(s.id)).map(s => [s.id, s.occurrences]));

export function at(value, path) {
  need(typeof path === 'string' && path.startsWith('/'), 'Evidence requires a JSON pointer');
  for (const part of path.slice(1).split('/')) {
    need(!/~(?![01])/u.test(part), 'Invalid JSON pointer escape');
    const key = part.replace(/~1/g, '/').replace(/~0/g, '~');
    need(!['__proto__', 'prototype', 'constructor'].includes(key) && own(value, key), 'Unknown or unsafe evidence path');
    value = value[key];
  }
  return value;
}

export function checkEvidence(episodes, evidence) {
  need(Array.isArray(evidence) && evidence.length > 0 && evidence.length <= 30, 'Provide 1..30 literal evidence quotes');
  for (const row of evidence) {
    need(fields(row, ['episodeNumber', 'path', 'quote']) && Number.isInteger(row.episodeNumber)
      && episodes[row.episodeNumber] && text(row.quote) && row.quote.length <= 2000, 'Invalid episode evidence');
    const value = at(episodes[row.episodeNumber], row.path);
    need(typeof value === 'string' && value.includes(row.quote), 'Evidence quote does not match current manuscript');
  }
}

function issueScope(state) {
  const v = state.view;
  return hash([state.configDigest, v.source?.digest, v.sourceDecisions, v.concepts?.digest,
    v.selectedConceptId, v.assets?.digest, v.blueprint?.digest,
    Boolean(v.workingDraft && state.config.languagePlan?.workingLanguage !== state.config.languagePlan?.targetLanguage), v.issueEpoch || 0]);
}

export function issueContext(state, read) {
  const v = state.view, episodes = Object.fromEntries(Object.entries(v.episodes).map(([n, ref]) => [n, read(ref)]));
  const scopeDigest = issueScope(state);
  const signals = new Map();
  for (const [n, ep] of Object.entries(episodes)) {
    const warnings = Array.isArray(ep.warnings) && ep.warnings.every(text) ? ep.warnings
      : ['LOCAL_WARNINGS_UNCHECKED: historical warnings are missing or malformed.'];
    warnings.forEach((warning, index) => {
      const id = `w_${hash(normalized(warning)).slice(0, 24)}`;
      const signal = signals.get(id) || { id, warning, occurrences: [] };
      signal.occurrences.push({ episodeNumber: Number(n), outputDigest: v.episodes[n].digest, warningIndex: index });
      signals.set(id, signal);
    });
  }
  // Legacy post-revision UNKNOWN findings still require a decision; ordinary uncertain warnings do not.
  const check = v.continuityCheck?.report;
  const postRevision = new Set((check?.checks || []).filter(row => row.status === 'UNKNOWN')
    .map(row => `continuity_${check.binding.revisionDigest.slice(0, 12)}_${row.episodeNumber}`));
  const issues = (v.issueLedger || []).filter(item => item.scopeDigest === scopeDigest).map(item => {
    const reappeared = ['dismiss', 'resolved'].includes(item.decision?.action)
      && item.decision.occurrencesDigest !== occurrencesDigest([...signals.values()], item);
    return { ...item, ...(postRevision.has(item.id) && item.severity === 'UNCERTAIN' ? { requiresDecision: true } : {}),
      ...(reappeared ? { needsRecheck: true } : {}) };
  });
  const assigned = new Set(issues.flatMap(item => item.signalIds));
  const binding = { projectId: state.projectId, scopeDigest, manuscriptsDigest: hash(v.episodes), assessmentsDigest: hash(v.issueLedger || []) };
  return { binding, episodes, signals: [...signals.values()], issues,
    untriaged: [...signals.keys()].filter(id => !assigned.has(id)),
    recheckIssueIds: issues.filter(item => item.needsRecheck).map(item => item.id),
    blockers: issues.filter(item => item.decision?.action === 'pause'
      || ((item.severity === 'CORE' || item.requiresDecision === true) && !['continue-known', 'dismiss', 'resolved'].includes(item.decision?.action))) };
}

export function triageReport(context, report) {
  need(fields(report, ['binding', 'items']) && same(report.binding, context.binding), 'Stale issue report binding');
  need(Array.isArray(report.items) && report.items.length > 0 && report.items.length <= 100, 'Provide 1..100 triage items');
  const result = structuredClone(context.issues), ids = new Set();
  for (const row of report.items) {
    need(fields(row, ['id', 'signalIds', 'severity', 'category', 'title', 'explanation', 'evidence'])
      && /^[a-zA-Z][a-zA-Z0-9_-]{0,79}$/.test(row.id) && !ids.has(row.id), 'Invalid or duplicate root-cause id');
    ids.add(row.id);
    const old = result.find(item => item.id === row.id);
    need(['MINOR', 'CORE', 'UNCERTAIN'].includes(row.severity)
      && ['UPSTREAM', 'CONTINUITY', 'TEXT', 'TECHNICAL'].includes(row.category), 'Invalid issue severity/category');
    need(text(row.title) && row.title.length <= 200 && text(row.explanation) && row.explanation.length <= 2000, 'Explain the root cause and impact');
    need(Array.isArray(row.signalIds) && new Set(row.signalIds).size === row.signalIds.length
      && row.signalIds.every(id => context.signals.some(s => s.id === id) || old?.signalIds.includes(id)), 'Unknown or duplicate warning signal');
    checkEvidence(context.episodes, row.evidence);
    need(!old || old.signalIds.every(id => row.signalIds.includes(id)), 'Do not silently drop a grouped warning');
    need(!old || (old.severity !== 'CORE' && !old.requiresDecision) || row.severity === old.severity || row.severity === 'CORE' || old.decision?.action === 'dismiss', 'Core concerns need an explicit evidence-backed dismissal, not silent downgrading');
    need(!result.some(item => item.id !== row.id && item.signalIds.some(id => row.signalIds.includes(id))), 'Warning already assigned to another root cause');
    const item = { ...structuredClone(row), scopeDigest: context.binding.scopeDigest, ...(old?.requiresDecision && old.decision?.action !== 'dismiss' ? { requiresDecision: true } : {}) };
    // A changed assessment/new variant needs a fresh decision; an identical repeated warning does not.
    if (old && !old.needsRecheck && same(Object.fromEntries(Object.keys(row).map(k => [k, old[k]])), row)) item.decision = old.decision;
    if (old) result[result.indexOf(old)] = item; else result.push(item);
  }
  return result;
}

export function decideIssue(context, id, action, note, report) {
  const issue = context.issues.find(item => item.id === id);
  need(issue && ['continue-known', 'pause', 'dismiss', 'resolved'].includes(action), 'Unknown issue or decision');
  need(text(note) && !/^(继续|好的?|下一步|continue|ok|next)[.!！。\s]*$/i.test(note.trim()), 'Record the specific user decision, not generic continue');
  if (['dismiss', 'resolved'].includes(action)) {
    need(fields(report, ['binding', 'evidence', 'explanation']) && same(report.binding, context.binding)
      && text(report.explanation), 'Resolution/dismissal needs current evidence and an explanation');
    checkEvidence(context.episodes, report.evidence);
    need(report.evidence.some(e => !e.path.startsWith('/warnings/')), 'A warning alone does not prove resolution');
  } else need(report === undefined, 'Evidence report is only used for dismissal/resolution');
  return { ...issue, needsRecheck: false, decision: { action, note,
    occurrencesDigest: occurrencesDigest(context.signals, issue), ...(report ? { report } : {}) } };
}

export function startContinuityCheck(state, before, changed, reason) {
  const v = state.view, previous = v.continuityCheck;
  const oldScope = issueScope(state), carry = (v.issueLedger || []).filter(i => i.scopeDigest === oldScope);
  const allChanged = [...new Set([...(previous && !previous.report ? previous.changedEpisodes : []), ...changed])].sort((a, b) => a - b);
  const numbers = Object.keys(v.episodes).map(Number).filter(n => n >= allChanged[0]).sort((a, b) => a - b);
  v.continuityCheck = { reason, changedEpisodes: allChanged, numbers,
    before: previous && !previous.report ? { ...before, ...previous.before } : structuredClone(before) };
  v.issueEpoch = (v.issueEpoch || 0) + 1;
  // A correction must not erase a manually found concern just because no model warning carried it.
  v.issueLedger = [...(v.issueLedger || []), ...carry.map(item => ({ ...structuredClone(item),
    scopeDigest: issueScope(state), decision: undefined, needsRecheck: true }))];
}

export function continuityContext(state, read) {
  const check = state.view.continuityCheck;
  if (!check) return null;
  const current = Object.fromEntries(check.numbers.map(n => [n, state.view.episodes[n]]));
  const previousNumber = check.numbers[0] - 1, previousRef = state.view.episodes[previousNumber];
  const binding = { projectId: state.projectId, configDigest: state.configDigest,
    revisionDigest: hash([check.changedEpisodes, check.before, current, previousRef]) };
  return { binding, numbers: check.numbers, changedEpisodes: check.changedEpisodes,
    precedingEpisode: previousRef ? read(previousRef) : null,
    sourceEpisodes: state.view.workingDraft ? Object.fromEntries(check.numbers.map(n => [n, read(state.view.workingDraft.episodes[n])])) : null,
    before: Object.fromEntries(check.numbers.filter(n => check.before[n]).map(n => [n, read(check.before[n])])),
    current: Object.fromEntries(check.numbers.map(n => [n, read(current[n])])),
    complete: Boolean(check.report && same(check.report.binding, binding)), report: check.report || null };
}

export function continuityReport(context, report) {
  need(context && fields(report, ['binding', 'checks']) && same(report.binding, context.binding), 'Stale continuity report binding');
  need(Array.isArray(report.checks) && report.checks.length === context.numbers.length, 'Check every affected existing episode, including unchanged downstream episodes');
  const seen = new Set();
  for (const row of report.checks) {
    need(fields(row, ['episodeNumber', 'status', 'explanation', 'evidence'])
      && context.numbers.includes(row.episodeNumber) && !seen.has(row.episodeNumber), 'Unknown or duplicate continuity episode');
    seen.add(row.episodeNumber);
    need(['CONSISTENT', 'CONFLICT', 'UNKNOWN'].includes(row.status) && text(row.explanation), 'Invalid continuity conclusion');
    checkEvidence(context.current, row.evidence);
    need(row.evidence.every(e => e.episodeNumber === row.episodeNumber), 'Cite this episode separately');
    if (row.status === 'CONSISTENT') {
      need(row.evidence.some(e => /^\/scriptLines\/\d+\/text$/.test(e.path))
        && row.evidence.some(e => e.path.startsWith('/continuitySnapshot/')), 'Check both actual body and resulting snapshot, not only a synopsis');
    }
  }
  return structuredClone(report);
}

/** Bounded exact replacements, never an imported/synthetic operator success or an upstream edit. */
export function revisionPlan(context, proposal, language) {
  need(fields(proposal, ['binding', 'reason', 'edits']) && same(proposal.binding, context.binding)
    && text(proposal.reason), 'Local revision needs current binding and reason');
  need(Array.isArray(proposal.edits) && proposal.edits.length > 0 && proposal.edits.length <= 16, 'Local correction supports 1..16 exact replacements');
  const changed = {}, seen = new Set();
  for (const edit of proposal.edits) {
    need(fields(edit, ['episodeNumber', 'path', 'before', 'after']) && Number.isInteger(edit.episodeNumber)
      && context.episodes[edit.episodeNumber], 'Unknown local revision episode');
    need(text(edit.before) && text(edit.after) && edit.after.length <= 4000 && edit.before !== edit.after, 'Replacement must be nonempty and changed');
    const ep = changed[edit.episodeNumber] ||= structuredClone(context.episodes[edit.episodeNumber]);
    const key = `${edit.episodeNumber}:${edit.path}`;
    need(!seen.has(key), 'Duplicate replacement path'); seen.add(key);
    const body = /^\/scriptLines\/(\d+)\/text$/.exec(edit.path);
    need(body ? ep.scriptLines[Number(body[1])]?.type !== 'SCENE'
      : /^\/continuity(?:Snapshot|Delta)\//.test(edit.path), 'Only existing body text and continuity string leaves may be corrected');
    need(at(ep, edit.path) === edit.before, 'Replacement does not match the exact original value');
    const pieces = edit.path.split('/'), leaf = pieces.pop().replace(/~1/g, '/').replace(/~0/g, '~');
    need(body || !identityField(leaf), 'Continuity identity, schema and language fields cannot be locally revised');
    at(ep, pieces.join('/'))[leaf] = edit.after;
  }
  need(Object.keys(changed).length <= 2, 'Local correction affects at most two episodes; larger rewrites need separate planning');
  for (const ep of Object.values(changed)) {
    let wordCount = 0;
    for (const line of ep.scriptLines.filter(line => line.type !== 'SCENE')) {
      const remainder = line.text.replace(/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/gu, () => { wordCount++; return ' '; });
      wordCount += (remainder.match(/[\p{L}\p{N}]+(?:['’\-][\p{L}\p{N}]+)*/gu) || []).length;
    }
    ep.statistics = { wordCount, sceneCount: ep.scenes.length, dialogueCount: ep.scriptLines.filter(line => line.type === 'DIALOGUE').length };
    ep.markdown = renderEpisode(ep, ep.episodeNumber, language);
    // Keep original warnings as evidence; only a separate recorded assessment can dismiss/resolve them.
  }
  return { changed, planDigest: hash(proposal), proposal: structuredClone(proposal) };
}
