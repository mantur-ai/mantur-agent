#!/usr/bin/env node
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { statSync } from 'node:fs';
import { assertNodeVersion } from '../runtime/node-version.mjs';

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
try {
  assertNodeVersion();
  if (args[0] !== '--project' || !args[1] || !args[2]) throw new Error('Usage: studio.mjs --project <directory> <action> [arguments]');
  const root = resolve(args[1]);
  if (!statSync(root).isDirectory()) throw new Error('Project must be a directory');
  process.env.MANTURHUB_PROJECT = root;
  process.env.MANTURHUB_SKILL_DIR = packageRoot;
  try {
    const { hydrateManturhubBaseFromCli } = await import('../runtime/common.mjs');
    await hydrateManturhubBaseFromCli(process.env);
  } catch (error) {
    process.env.MANTURHUB_BASE_RESOLUTION_ERROR = error?.code || 'CLI_BASE_URL_UNAVAILABLE';
  }
  process.chdir(root);
  process.argv = [process.execPath, resolve(packageRoot, 'runtime/runner.mjs'), ...args.slice(2)];
  await import('../runtime/runner.mjs');
} catch (error) {
  process.stdout.write(JSON.stringify({ok:false,error:{code:error.code === 'NODE_VERSION_UNSUPPORTED' ? error.code : 'STUDIO_START_FAILED',message:error.message}})+'\n');
  process.exitCode = 1;
}
