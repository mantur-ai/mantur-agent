# 5B 新视频执行与本地接入

2026-09-22 画面比例：每次新视频准备同时复核项目固定比例与唯一请求模板的 `metadata.ratio`，二者必须一致；报价、批准和提交沿用这份精确请求，不允许用平台其他画幅或项目默认值覆盖模板。技术校验继续按实际请求比例核对输出尺寸。

适用 Skill 版本：1.0.5；内部 profile：`seedance-file-video-v1`。Manifest、Snapshot Envelope、HTTP v1 不变。本合同仅针对受控 fileId 分镜；legacy 仍使用原 Runtime。

## 当前开放范围

2026-09-16 已核验标准 Seedance 新增 1080p 的实时输入 Schema。当前 Runtime 不再保留或比较兼容指纹；实际请求按实时 inputSchema 校验，仅保留[分辨率合同](video-resolution.md)中的 Seedance 1080p 局部枚举例外；结果按提交时 outputSchema 和本地视频／尾帧解析器校验。通过合同校验不等于自动启用新能力，平台枚举中的 2k 仍不属于本地支持范围。

2026-09-21 已只读核验当前实时输入 Schema：模型字典公开包含 `wan3.0-video`。WAN 必须由实时原始 Schema 直接验证，不在本地副本中补模型枚举；历史摘要只作为带日期审计证据，不参与当前兼容判定。平台 WAN 分支禁止 `negative_prompt`、`seed`、`generate_audio`、`camera_fixed`；Runtime 可从统一本地模板读取并审计分镜产生的 seed/generate_audio，但转换后的报价与提交请求必须省略它们。同日单次真实付费调用已经返回一段视频及同 Job 的 `source=final_video` PNG 尾帧，下载后与视频末帧的 SSIM 为 1.0，据此确认该模型的尾帧返回合同；跨 Clip 注入与承接仍须独立做端到端验收。

Clip 的 `音色资产` 清单与在场角色分开。角色已有匹配、验收通过且库存摘要一致的音频，但未被本镜头音色清单选用时，不强制添加引用。被清单声明的角色（基础角色与变体统一判断）仍需有效引用或明确合法的直出/无需音色策略。未决定、缺失、待审核、冲突、损坏或被篡改的音频继续阻断；没有清单的旧报告保留对全部在场角色的检查，不根据台词字符串猜身份。审核时仍须核对清单是否覆盖实际对白。

以下动作已随包提供。所有合法锁定站点按公共路由规则调用，并统一采用项目内默认最多 5 条活动场次链；这是 Skill 调度策略，不是平台额度声明。Agent 按已知在途任务控制提交节奏，平台负责账号级最终限制；不维护本机跨项目额度池、不扫描旧项目。QPM 不与并发混用，未知 QPM 和未独立核实的平台额度均不关闭视频。项目内场次链串行、生成前技术校验及素材门禁继续由代码保护；跨 Agent/设备不承诺本地总量硬限制。完整语义见 [视频并发约定](video-concurrency-policy.md)。

测试站点的受限 video 路径在实时合同及原有门禁通过后可返回 workflow_ready=true；WAN 单次真实付费生成及同 Job 尾帧已验收，但这不等于其他上传、完整 Skill 付费链路、跨 Clip 连续性或平台部署均已验收。多结果尾帧关联、无下载地址等未知分支继续阻断。

## 动作与描述文件

每次请求费用批准前执行 `query-account-balance`，按 [报价与余额展示](quote-and-balance.md) 展示单次/本批精确报价、刚查的余额与预计余量或查询失败原因。已提交任务恢复不重新报价、不为查余额重新生成。

统一使用 `node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" <action>`。

| action | 参数 / 职责 |
|---|---|
| apply-clip-review | `--input`：兼容旧明确审核/驳回；正常生成不调用 |
| prepare-video-generation | `--input`：准备唯一生成意图、上传确认本地引用、构建实际请求、非扣费试算；不提交 |
| submit-video-generation | `--operation-id --approval`：复核精确请求、批准、依赖和槽位，再提交一次 |
| resume-video-generation | `--operation-id [--local-only [--no-write]]`：恢复原任务；local-only 仅检查技术证据、当前媒体与动态依赖或恢复已保存成功产物，不联网、不重放历史批准／请求／Job；no-write 不创建锁或写入 |
| video-generation-status | `--operation-id`：纯本地读取，不联网、不迁移 |
| import-video-result | `--input [--no-write]`：校验已有 Job 与本地媒体，仅进入预览，不补造批准 |
| apply-video-review | `--input`：兼容旧人工审核及明确驳回；正常生成无需调用 |
| adopt-video-run | `--input`：明确替换采用结果，复核技术证据与预期旧 Run，不要求人工成片验收 |

生成描述文件只接受以下字段，不接受 URL、算子 ID、任意平台参数或伪造的 limits：

```json
{"schema_version":1,"clip_id":"CLIP-EP01-001","generation_intent":"first-approved-attempt","attempt":1}
```

同分镜版本/同 Clip/同 generation_intent 恢复原操作；改变 intent 表示新的生产意图，须用户明确要求并独立批准费用。不得用新 intent 修复原任务下载、快照、超时或响应丢失。

仅在用户明确要求人工审核或处理历史驳回时，旧 Clip 审核记录需 `schema_version=1, clip_id, approved, binding, evidence, evidence_sha256, user_confirmed=true`，以及 `checks.dialogue/continuity/timing=true`。evidence 是明确的项目内非空观察记录，必须实际观察并遵守用户确认要求；不得用测试示例制造批准。

binding 含 template_sha256、references_sha256、structure_sha256 及 clip_id。包内模块 `runtime/video-generation-operation.mjs` 导出的只读 `videoSelection(PROJECT_DIR, clipId, false)` 返回 `reviewBinding`；Agent 只打印该摘要对象，仅在显式人工审核时再结合真实证据生成审核文件，不打印整个选择结果。审核动作重新校验摘要、素材与时长，不能用批准覆盖硬性缺失。模板、引用、制作参数变化会使旧审核失效。

未使用批次授权的单操作 prepare 返回 `approval_binding` 和 `estimated_points`，明确获批后复制 binding，增加 `approved=true, approved_at=<ISO时间>` 保存本地批准文件；提交前金额或规则摘要变化使该单操作批准失效。视频批次不复制逐操作人工批准，使用 --batch-authorization；每段实时试算由 Runtime 对照整批上限，额度内报价变化自动继续。底层 `points` 字段和完整计费信息留在私有操作记录，面向用户的数值单位统一显示为“馒头”。

## 模板与连续性

旧项目配置中的 `seedance-2.0` 与标准模型 ID `doubao-seedance-2-0-260128` 均精确映射为算子模型 `seedance`。该别名兼容不改项目或历史模板，不允许 Fast/Mini 混用，也不放行未知相似名称；准备、提交复核共用同一映射。

每次新生成读取唯一 `请求体模板JSON`。`请求体JSON` 与上次 `实际请求体JSON` 都不是输入回退。已有连续性硬性限制段落的模板被拒绝，不猜测剥离。

保留模板原引用顺序，使用已验收本地媒体核实 SHA。首版不能证明旧 fileId 的账号/站点/保留期时，重新走原字节 upload → PUT → confirm，而不盲目复用字符串；同一操作确认成功后不重复上传。确认响应丢失恢复原 uploadId。槽位申请收到明确 HTTP 非成功响应时保持 `not_started`，按错误修复或退避后恢复同一操作；请求已发出但无法确认是否创建槽位时立即写入 `application_unknown`，返回不可重试的 `UPLOAD_APPLICATION_UNKNOWN`，`polling.state=blocked`、`next_action=inspect_upload_application`，不重新申请。

场次首镜不追加尾帧。新批次同场后续读取批次固定的前序 Run（范围内必须是本次新结果）；旧操作恢复按其已保存合同读取前序，回验视频、真实尾帧和当前依赖，不等待人工成片验收。尾帧作为末尾普通 reference 图片，替换 `@ImageLastFrame`，编号取实际 @ImageN；不使用严格 first_frame/last_frame。连续性全文固定：

> 镜头连续性硬性限制：@ImageX 是上一片段的真实尾帧。本片段开场必须紧接 @ImageX，继承同一场景的空间布局、机位方向、景别、光线、人物位置、朝向、服装、表情与动作进度；只能按本段剧本继续动作。不得重新布置场景、不得让人物瞬移、不得无依据改变服装或外观。

最终仍以 `不要背景音乐，不要字幕。` 结尾。Seedance 最多 9 图片、3 音频；WAN 按实时合同最多 10 图片、5 音频。项目视频比例只允许已固化的 `9:16` 或 `16:9`；未知模型、4 秒或产品约束超限直接阻断；现有 Seedance 模型支持本地 1080p。标准模型映射 doubao-seedance-2-0-260128 → seedance；WAN 映射 wan-3.0 → wan3.0-video；mini 采用已有明确映射。不静默换 provider/模型/时长/比例/分辨率。

实际副本写到目标请求行的 `实际请求体JSON`，模板保持不变；单次平台 `{mode:"ASYNC",input}` 另存并绑定报价。锁内重新选择报告，只改目标 Clip，备份旧报告。提交前依赖变化使准备失效；已提交任务仍恢复原请求。

## 恢复、媒体与采用

私有目录：`.pipeline-state/runtime/video-operations/<id>/`，包括输入副本、template-row、binding、actual、request、批准版本、受理、first-success、响应、下载及本地事实。原成功 Job 不随 URL 续期被覆盖。审批和费用资料不进入快照。

视频操作以 `credential_scheme + credential_sha256` 绑定认证身份，旧记录缺 scheme 视为 `legacy-key-v1`。原 `MANTURHUB_KEY` 可恢复旧操作；CLI 托管身份使用 `cli-identity-v1`。二者或不同 CLI 身份之间不能证明等价时返回 `ONLINE_CREDENTIAL_CHANGED`，不重新提交、不更换幂等键，也不改写历史 Run、Job 或批准。

新下载的第一个视频在该操作的 `media` 目录中命名为 `EPxx-CLIPxx.mp4`，真实尾帧为 `EPxx-CLIPxx-last-frame.<原扩展名>`。`attempt > 1` 时在 Clip 后加全角轮次，例如 `EP01-CLIP05（2）.mp4`；单次响应内第 2 个起的视频另加 `-RESULT02`，不将候选序号写成生成轮次。命名只使用操作已固化的 episode、order 和 attempt，不扫描目录推测。已记录数字文件名的历史操作继续引用原路径；其中断恢复也保持同一旧命名方式，不搬移、不重命名已保存媒体。

提交前保存稳定 `video-<id>` 幂等键对应的请求。未知受理只用同键同请求恢复；有 Job 后只查询原任务，每次 resume 最多一次查询。FAILED/CANCELED/TIMED_OUT 保存终态，并将算子回执中的 `errorCode/errorMessage` 分别保存为私有操作状态的 `remote_error_code/remote_error_message`，发布检查点时映射到既有 `error_code/error_message`；缺失错误码使用稳定的本地终态码，原始错误文本仍以算子返回为准。网络错误、查询超时、限流和其他非终态恢复异常只保留为操作恢复错误，不写入远端终态字段、不伪造任务失败。不新增常驻付费调度器。

兼容旧检查点时，如果失败/取消记录缺少错误字段，但同一私有视频操作已经归档终态轮询回执，Compiler 可只读恢复该回执中的 `errorCode/errorMessage`。恢复必须同时匹配 operation、Clip、Job、算子和终态，并且只能接受唯一一致的错误内容；不满足条件时继续使用缺失错误的兼容路径，不联网查询、不重写私有操作，也不据此重新提交。

视频流式落盘和 SHA 校验，不整段读入内存；采用受控 MP4 探测器校验时长、尺寸及结构。图片通过现有 MIME/尺寸校验。无平台 SHA 标记 local，有平台 SHA 才标记 platform_verified；不能把本地摘要冒充平台保证。

单个视频与 lastFrame 必须同 Job，source=final_video、尺寸相符且本地哈希有效才可供连续链验收。Job 的 apiCode 与输出 operationCode 是不同字段；已观察 operationCode=VIDEO_GENERATE。缺尾帧/未知来源保留预览但阻断采用。多视频保留全部候选，不默认选第一项；当前尾帧与多结果没有唯一关联合同，因此多结果仍不能通过连续链验收，待补证，不伪造选择关联。

首次在线完成时，技术校验一次性覆盖原操作／请求／报价批准／受理／成功 Job、媒体结构／MIME／哈希／时长／画幅、同结果真实尾帧、当前分镜及前序依赖，并写入独立 `runtime/video-validations/<摘要>.json`。Run 保存 `technical_validation_path/technical_validation_sha256`、`validation_status=passed` 和 `status=succeeded`；历史 schema_version=1 与新批次 schema_version=2 原样兼容，不迁移。该证据是后续阶段的历史收据：Compiler、候选、采用和交付只验证证据摘要以及当前视频／尾帧、尺寸、时长、画幅、分镜 revision、素材绑定、人工驳回和前序链，不再打开 operation、descriptor、request、approval、accepted、first-success 或不可变批次计划。证据不包含伪造的 user_confirmed 或内容审核声明。

首次唯一合规结果自动采用，操作完成后返回 stage=completed；同场下一 Clip 在原范围及费用批准满足时继续。已有采用结果不自动替换。明确替换使用 adopt-video-run，输入 `{schema_version:1,run_id,video_sha256,tail_sha256,expected_selected_run}`；expected_selected_run 是原始 Run ID 或 null，不能使用 UI 脱敏 ID。该动作重新校验后切换，不授权重生成。旧合同的全局采用依赖仍按原规则失效；新批次按已记录的实际前序核验，不因全局采用切换而改写或失效。

旧 apply-video-review 记录和历史驳回保留兼容；已驳回不能由自动恢复放行。仅导入的外部样例缺少可信提交批准血缘，保持预览，不能借技术证据入口完成、采用或交付。旧 preview_ready 可通过 resume-video-generation --local-only --no-write 只读预检，再去掉 --no-write 恢复；尚无技术证据的原在线操作在本地恢复时执行一次完整校验并封存证据，已有证据则只检查当前动态事实。整个过程不上传、报价、查询或 invoke；快照失败只恢复发布，重复恢复不改已完成 Run。

媒体、审核和采用都有并发复核。旧合同的前序采用变化使后续旧依赖失效，即使尾帧 SHA 相同也比较 Run 身份；新批次独立校验已记录的前序 Run，来源损坏或需求过期仍阻断。历史视频不删除，不自动重生成。刷新失败保留事实，resume 只恢复发布。

## 并发和看板

槽位状态在 `runtime/video-chain-slots.json`，跨进程短锁保护。默认请求 5、用户范围 1–20，有效值须结合包内核实的平台限制。场次链 FIFO 按集数及场次首次序号，已持有链保留槽位到链结束或失败；同链只允许一个在途操作。submission_unknown/reserved 无时间租约，不因进程退出释放。此安全状态需要恢复原操作，不能清空文件以解除等待。

Run 发布到 `runs/VIDEO-<id>-<candidate>.json`，使用原有字段和 selected_runs。Compiler 区分新 profile 的预览、验收、采用与旧合同；新计费信息不假装成旧单位。视频覆盖仍按有本地可用视频的 Clip 去重，严格完成检查采用和真实尾帧。页面继续读取基础模板及本地 media_id，不展示 fileId/地址/动态请求，也不增加生产按钮。

## 视频结果的聊天展示

一个批次的首个新片段下载完成并通过本地媒体结构、MIME、时长及哈希校验后，Agent 必须在聊天中主动返回结果，标注 `EPxx`、Clip 编号与当前真实状态，并说明其余已批准片段会继续生成、此刻是否需要回复。优先使用宿主支持的可播放视频附件或内嵌预览，引用项目内已保存且校验通过的真实视频，不使用远端签名 URL、私有任务标识或完整请求。后续正常结果可按阶段合并展示，不要求逐 Clip 单独反馈。

宿主不支持视频展示或展示失败时，直接提供 `[打开生产进度看板](<实际看板 URL>)`，不补充“无法内嵌播放”等能力说明，不用裸文件路径或远端视频链接替代。复用已核实的当前项目看板入口；尚无有效入口时按 Skill 看板交接规则调用 `open-workbench --link-only` 获取实际 URL，不猜端口、不自动弹页或重启服务，尊重用户不启动服务的明确要求。确实无法取得入口时仅说明实际看板故障或未启动状态，不伪造可用链接。

媒体可预览不等于技术完成、已采用或已交付；缺失真实尾帧或其他技术证据时准确标注“可预览，技术校验未通过”，按实际阻塞处理。快照刷新失败时可展示已校验的视频，但不得声称看板已同步；只恢复发布，不重新生成。

批量生成可合并展示本轮新增片段；同一结果不因轮询或恢复而反复回传，用户明确要求重看时可再次展示。聊天展示不增加成片人工确认门禁、不暂停已批准的后续生成，不改变采用关系，不因展示失败重新付费生成。

失败或阻断只在状态具有实际变化时再次引导，并明确区分：恢复原远端任务、修复本地下载／校验／快照接入、需要用户选择，以及建立新生成意图并重新报价的付费重生成。不得把重新生成描述为免费重试，也不得因附件、看板或快照展示失败建议重新生成。受影响链单独说明；其他独立且已批准链继续时明确无需回复。整批进入终态后不在本节自行推进交付，转到[批次完成后的下一步选择](video-result-selection.md#批次完成后的下一步选择)。

## 分镜版本与参数扩展

新 Run 以 storyboard_revision 绑定当前分镜；跨版本同 Clip ID 不共享审核、采用、统计或真实尾帧。资产复核不能把旧版本 Run 转为新版本。历史切回及未受影响集保留各自采用关系，详见 [版本合同](clip-revisions.md)。

时长遵循当前模型合同；1080p 原值保留到 precharge/invoke。实际请求按实时 Schema 与本地产品范围共同校验，仅 Seedance 1080p 使用局部枚举兼容副本，不改写平台原始 Schema，也不比较指纹；WAN 不使用该例外。提交前请求或首次 invoke 明确 HTTP 400/422 拒绝才保存终止状态，不重复提交、不降级。Job 查询失败或未知提交重放收到同类错误，不证明原任务终止，不释放其占用；继续保留原身份与恢复路径。

分辨率支持范围、修改边界和历史兼容统一见 [分辨率合同](video-resolution.md)。
