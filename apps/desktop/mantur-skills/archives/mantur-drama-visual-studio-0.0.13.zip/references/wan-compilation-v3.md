# wan分镜：完整资产表 v3 调用

适用于新建 `op.drama.clip-wan-compile` 请求。本文件取代本包旧wan提交说明；Seedance 使用其独立实时契约。保留当前项目站点、模型、画幅、风格、分辨率及实际授权，不自动跨站或改用其他算子。

## 执行入口

新的wan分镜通过 `manturhub` CLI 直接提交，不调用包内 `doctor/run --stage clips` 或旧 prepare/submit/resume 分镜动作。成功产物使用包含 `production_asset_table` 的本地 `import-clip-compilation` 描述文件接入（见下文），导入器按字段结构识别路径，不按 `v2/v3` 标签路由。旧已受理任务仅查询原 Job，不重新提交；旧项目文件与历史状态不迁移。

1. 在项目锁定站点执行 `manturhub describe op.drama.clip-wan-compile --json`，核对实时输入和输出 Schema；站点与当前项目不一致时停止，不混用文件 ID。
2. 准备已确认剧本与用户最终确认的完整资产表 JSON；普通用户可查看表格，Agent 负责准备内部 JSON，不要求用户手写管理字段。当前算子不能直接接收 Excel 作为完整资产表。
3. 按 [变体音色检查](wan-asset-table-v3.md#上传前的变体音色检查) 执行 `inspect-wan-asset-table`，处理待展开项并保存输入原字节副本。两个文件分别执行 `manturhub upload <文件路径> --json`。确认返回 AVAILABLE，保存 fileId 与 SHA256。
4. 写入 params.json，调用 `manturhub quote op.drama.clip-wan-compile --json-file params.json`，按实时价格和现有用户授权执行。无固定价格；清单审核不代替费用授权。
5. 调用 `manturhub run op.drama.clip-wan-compile --json-file params.json --no-wait`。CLI 若返回费用确认信息，按下文真实 confirmation_token 与既有授权完成提交，不伪造令牌。保存恢复 ID、jobId、pollUrl 和请求。已受理后仅 `manturhub status <返回的pollUrl>` 或 `manturhub resume <恢复ID>`，不重复 run。

## CLI 费用确认

非交互 `run` 可能以退出码 3 返回待确认信息，这是尚未提交，不是 Job 失败。保存返回的真实 `confirmation_token`；核对站点、请求和报价仍属于已有费用授权后，执行：

```text
manturhub run op.drama.clip-wan-compile --json-file params.json --confirm <本次返回的confirmation_token> --no-wait
```

不要使用 `--confirmation-token`。令牌不是新的用户授权：已有有效授权不重复询问，授权不足才补充确认。参数或报价变化后重新报价并按实际授权处理，不复用旧令牌。响应不明确是否受理时，先检查 CLI 恢复记录；已存在 jobId/pollUrl 后只查询原任务。不能把网络超时当作安全重提依据。CLI 语法按本机 `manturhub help` 核实（本说明核对于 1.2.5）。

## 输入契约

仅两个文件字段必填：`scriptFileId`、`productionAssetManifestFileId`。不发送 `requirementsResultId`，不把旧提取结果 ID 填入完整资产表文件 ID。

以下为结构示例；替换上传所得 ID，按用户实际集数和项目选择填写可选参数，不把示例第 1 集、风格或分辨率当作用户默认选择。

```json
{
  "scriptFileId": "已确认剧本的fileId",
  "productionAssetManifestFileId": "已确认完整资产表的fileId",
  "episodeStart": 1,
  "episodeEnd": 1,
  "ratio": "9:16",
  "resolution": "720p",
  "targetRegion": "western",
  "dialogueLanguage": "en",
  "minimumClipSeconds": 4,
  "maximumClipSeconds": 30,
  "missingVoicePolicy": "ai_direct",
  "generateAudio": true
}
```

集数起止成对提供。wan Clip 范围为 4–30 秒；按对白字词和独立动作估时，不按片段数量或整集软目标机械补长。语言、音色直出策略及视觉风格遵循项目与用户选择；中国地区对白使用 zh，western 使用 en，最终以实时 Schema 为准。

## 集数范围

新编译未指定范围时，使用项目已封存全集，不主动询问集数。用户明确只要部分集数时，沿用 [集数范围默认策略](clip-compilation.md#集数范围默认策略) 的一次提醒与用户选择，实际金额只取本次精确请求的有效实时报价。恢复已有操作沿用原范围，不扩为全集、不重新提交。该链接仅复用范围决策，不授权使用 Seedance 的旧清单或 Runtime 调用。

## 完整资产表

先读 [资产表结构、Excel 转换与风格映射](wan-asset-table-v3.md)，配套完整示例为 [资产表 JSON](../examples/production-asset-table.example.json) 与 [对应虚构剧本](../examples/script.example.md)。样例不代表用户资产、审核或费用授权，不能直接代替真实输入。

必须包含实际完整角色、场景、道具和美术规范，保持原资产 ID 与变体 ID；不是只有以下管理字段的空壳，也不是差量清单。

- `schemaVersion` 保留平台产物原值用于归档；导入器不按该值放行或拒绝，完整表结构、审核、血缘和媒体绑定仍必须通过。
- `sourceScriptSha256` 为本次上传剧本原始字节的 SHA256。
- 用户实际确认后填写 `review.status=APPROVED`、`review.mode=HUMAN_CONFIRMED`；未确认不得自动填写。
- 保留完整 `角色资产`、`场景资产`、`道具资产`、`项目美术规范` 数据。将用户批准的行级修改落实到完整表，不发送顶层 `overrides` 或 `bindings`。
- 已确认素材放在对应资产行的 `图片媒体`／`音色媒体` 对象，保存同站点已确认文件的 `fileId`、`sha256`、实际适用的 `reusePolicy`；不猜复用授权。不要用非空 `图片URL`／`音色URL` 代替文件绑定。
- 来源提取结果 ID／哈希可作为已有来源元数据保留，但不是提交参数，也不需要重新读取原提取结果；不得编造旧来源信息。
- 未补齐媒体如实保留，编译成功不等于视频可生成。

## 独立记录与恢复

本地接入失败不等于远端编译失败。已成功任务优先复用原始输入、Job 与产物，按下方 [本地接入失败恢复](#本地接入失败恢复) 诊断；不要为了修复绑定去编辑上传原表，不把恢复接入变成新的报价或付费编译。

在项目私有 `.pipeline-state/wan-v3/<本次唯一操作目录>/` 保存 `params.json`、`contract.json`（本次 describe）、`uploads.json`（两个输入的 fileId/SHA256）、`quote.json`、`submission.json`（CLI 原始受理响应）和 `latest-status.json`。记录实际站点、集数范围和恢复 ID；未受理前不得伪造 jobId。这些原始记录不伪装为旧 Runtime operation；终态后通过下述本地导入动作发布看板。不得保存 Key、认证配置；含任务地址或签名 URL 的响应仅留项目私有目录。

恢复时按用户所指集数及本地操作记录定位原请求，核对站点、输入哈希与原标识；存在多个候选时先明确目标，不猜最近的一个。已受理任务只 `status`/`resume`。终态 Job 保存为 `final-job.json`，产物保存到该目录的 `artifacts/`，校验通过后给用户本地文件链接。目录和下载步骤由 Agent 执行；Runtime 导入器只读取描述文件中明确指定的文件，不扫描或猜选最近任务。

## 接收结果与页面边界

等待明确终态；百分比不能代替成功。成功后核对 `businessStatus`、`qualityReport`、`missingOrAmbiguous` 与 `nextAction`。`requirementsResultId` 可以为 null，不强制比对旧来源 ID／来源哈希。仍核对剧本与完整资产表原字节哈希、实际 Clip ID、资产 ID、引用、集数与时长。

从 `output.artifacts` 获取 PRIMARY_JSON、TABULAR_XLSX，下载时不携带平台 Key，验证返回 SHA256；保存请求、最终 Job 与原始产物。失败如实记录错误与最终退款；查询失败不当作远端失败，不自动创建付费重试。

## 本地导入与看板同步（1.0.5）

保存 `intake.json`。所有路径相对项目根目录，替换成这次请求实际保存位置，`episodes` 必须与实际请求及封存范围一致。`compilation_request` 指向原始 CLI `params.json`，不是旧 `mode/input` 包装体。

```json
{
  "schema_version": 2,
  "script": "inputs/script.md",
  "production_asset_table": "inputs/final-assets-approved.json",
  "primary_json": ".pipeline-state/wan-v3/operation/artifacts/storyboard.json",
  "tabular_xlsx": ".pipeline-state/wan-v3/operation/artifacts/storyboard.xlsx",
  "job": ".pipeline-state/wan-v3/operation/final-job.json",
  "episodes": [1],
  "compilation_request": ".pipeline-state/wan-v3/operation/params.json"
}
```

```text
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" import-clip-compilation --input "<本次intake.json相对路径>" --no-write
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" import-clip-compilation --input "<本次intake.json相对路径>"
```

- 不填 `requirements`、`requirementsResultId` 或旧 `production_manifest`，不补造原提取记录。完整 v3 表是这次资产依据，源 ID 允许 null。仍核对原剧本、完整表和两个产物的原字节哈希、成功 Job、算子身份、资产与 Clip ID 的唯一性。
- 已有本地媒体时可增加 `media_mapping` 文件路径；格式为 `{"schema_version":1,"items":[{"asset_id":"实际资产ID","role":"IMAGE","file_id":"实际fileId","sha256":"实际SHA256","path":"项目内实际图片路径"}]}`。音频 role 为 `VOICE`。只列可验证的媒体；没有本地副本可省略，不能为了导入编造文件。新接入的媒体仅提供预览、保持待验收，不把清单审核当作图片/音频质量通过。
- 原始文件归档到私有 Runtime 目录；派生资产报告和分镜报告由导入器写入，登记权威指针后主动刷新。不得手改 Snapshot，也不得把原始 WAN JSON 指定为本地派生报告。
- 首次结果自动作为活动版本；已有分镜时保留候选，按 [分镜版本合同](clip-revisions.md) 检查影响并显式切换。候选完整资产表随该版本切换，导入候选不覆盖当前资产表。
- `snapshot_refresh.ok=true` 且 `readback=true` 才说明看板已同步；`candidate=true` 时说明结果已保存为候选，当前页面仍显示原版本。刷新失败只执行 `refresh-ui-snapshot` 或恢复同一导入，不重新运行远端付费算子。
- 缺集、编号间隙、质量建议与缺素材不再阻止已返回行展示；保持原 ID，不补造缺失片段。单 Clip 缺请求模板保留分镜并标记该 Clip 不能生成，其他行继续展示。原始状态、交付建议及缺口保持可查。
- 看板可见不代表视频已就绪。继续生成前按视频合同检查实际参考素材、请求参数、真实前序尾帧和费用授权；不自动采用新视频、修改历史 Run 或绕过素材验收。

## 本地接入失败恢复

1. 先区分原 Job 失败、原 Job 成功但本地导入失败，以及导入成功但快照刷新失败。成功编译的费用和成果不因本地错误撤销，不据此要求重新付费。
2. 用已保存原输入、最终 Job、JSON/XLSX 与明确的接入描述执行 `import-clip-compilation --input <描述文件> --no-write`。它只核实本地资料一致性，不宣称实时查询平台成功。
3. `CLIP_SOURCE_HASH_MISMATCH` 的 `diagnostics.path` 指出剧本还是完整表摘要不一致；`restoreOriginalUploadedBytesDoNotRecompile` 表示找回上传时的原始字节。保留修改后工作文件，优先使用私有原件副本；副本缺失时通过当前站点正式文件读取能力取回原上传文件并核对完整 SHA，不能按 JSON 重排猜原件、改故事板摘要或跳过校验。没有可验证原件时报告本地恢复阻塞，不自动重跑。
4. `CLIP_REFERENCE_BINDING_INVALID` 的请求与引用下标定位不匹配项。音色规则 `explicitOrSameBaseVoiceFileAndHashRequired` 要求显式音色，或满足 [受控继承](wan-asset-table-v3.md#已有产物的受控继承) 的同基础角色音色；若文件身份／摘要不同，不能说“都是同一个人”就放行。`CLIP_VOICE_INHERITANCE_INVALID`、`CLIP_VOICE_BINDING_CONFLICT`、`CLIP_VOICE_MAPPING_CONFLICT` 分别说明基础关系／策略、共享绑定或本地映射有冲突，按已存资料核对，不重新生成音色。
5. 修复安装包兼容或接入描述后，重新 dry-run，再恢复同一产物的本地导入、刷新与回读；已有版本仍遵守显式切换合同。仅快照失败时只重试刷新。若用户确实要求改变作品再编译，应作为独立新意图重新报价批准，不能以恢复名义替代。
