2026-09-23 Agent 集标题证据：新项目收据使用 `project-episode-scope-v2`。Agent 完整读取已确认剧本并提交每集的集号、完整标题原文和 1-based 行号；Runtime 逐条对照 UTF-8 源文件，复核集号标记、原文、行号、顺序、SHA-256 与全部明显候选行覆盖，不再使用标题分隔符白名单取代 Agent 识别。标题原文不修改。旧 `project-episode-scope-v1` 收据按封存时的规则继续只读验证和幂等复用，不重写、不迁移。

2026-09-23 初始化选择：正常项目准备应明确取得 `project.json.video.model`、`video.ratio`、`video.resolution` 与 `creative_style`。比例只接受 `9:16 | 16:9`；若比例选择被绕过，Runtime 在首次封存时持久化 `9:16`。模型、分辨率或风格缺失仍阻断初始化；分辨率只接受 `480p | 720p | 1080p`。各项保存私有初始选择收据，模型与比例固定，分辨率仍可走现有变更动作。

2026-09-23 全集封存与交付配置精简：新项目不询问制作范围、交付目标或截止阶段。Agent 完整读取唯一 `source_script` 并提交集标题行证据，Runtime 通过 `seal-project-episode-scope` 重读原文、验证 SHA-256 和全部标题后封存 `production_scope.mode=full_series`。`project.json` 不再写 `deliverables`；ZIP 和剪映只有真实导出记录才进入公共 `project.deliverables` 兼容字段。旧项目不迁移。

2026-09-21 WAN 视频模型收据：`project.json.video.model` 继续保存稳定值 `wan-3.0`。新建项目的私有 `runtime/video-model-selection.json` 保存 `provider_model=wan3.0-video`；历史 WAN 收据的 `provider_model=null` 可原样读取和复核，不自动重写。模型变化仍返回 `PROJECT_VIDEO_MODEL_IMMUTABLE`，该兼容不迁移旧项目、不改变历史操作或批准。

# 本地项目数据协议

WAN 完整表的变体音色由导入适配器按 [受控继承](wan-asset-table-v3.md#已有产物的受控继承) 解析；原字节与哈希保持，派生请求保留变体身份，本地音色匹配和看板仍按基础角色归并。Compiler 不自行修复关联或制造验收，公共 Schema 与快照字段不变。

本地锁增加可选系统进程启动标识；图片队列私有状态保存于 `runtime/asset-queues/<queue_id>.json`，仅记录错误计数、下次执行时间与暂停状态，生产事实仍来自原 operation。两者不进入 Manifest、Snapshot 或 HTTP API，详细结构与恢复边界见 [锁与标准队列](lock-and-queue-recovery.md)。

2026-09-17 视频技术完成：新 Run 的 technical_validation_path/technical_validation_sha256 引用带版本的私有技术校验记录，成功后 validation_status=passed、status=succeeded，首次唯一结果自动写入 selected_runs。Compiler 回验完整原任务、媒体和当前依赖后才发布 completed，不依赖生成后的用户确认。旧人工审核记录仍校验兼容；已驳回、无血缘导入及多结果尾帧歧义不自动通过。采用切换保留比较预期旧 Run 与下游依赖失效；公开状态枚举不变。详见 [视频合同](video-generation.md)。

分镜版本：workflow_state.clip_revisions 保存私有按集索引、版本报告引用与采用历史；workflow_state.clip_compile_report 指向合成活动报告。Run 的 storyboard_revision 隔离同 ID 的不同分镜，公共 v1 不增加字段。详见 [版本合同](clip-revisions.md)。


需求修订增量：workflow_state.asset_revision 指向 Runtime 私有不可变修订；extraction_result 选择有效派生报告。报告 asset_revision 保存原字节摘要与累计 overrides，受影响行 requirement_revision 绑定新审核。匹配图片须具备同一 requirement_revision；视频 reviewBinding.asset_requirements 使未提交批准和旧验收失效。历史 Run 的 clip_binding_sha256 保持原值，明确复核后另记 current_review_binding_sha256。Compiler、尾帧及交付共用复核绑定。公开快照不暴露这些私有字段，见 [完整修订合同](asset-revisions.md)。

5B 增量：新视频私有操作在 runtime/video-operations，审核在 runtime/video-reviews，跨进程槽位在 runtime/video-chain-slots.json。Run 仍发布到 runs/，source_profile=seedance-file-video-v1；Compiler 对新记录另要求 production_lineage_verified 与 selected_runs 显式采用才能计严格完成。前序采用 Run 身份及尾帧摘要均必须匹配；保留旧视频预览与 legacy 规则。详见 [新视频合同](video-generation.md)，公开 v1 结构不变。

5A 分镜接入：原始清单/Job/产物私有归档；独立转换生成 `mantur.drama.clip-compilation/v1`，由 `workflow_state.clip_compile_report` 指定，`clip_compilation_import` 保存稳定接入身份。生成后的分镜按 [分镜接入合同](clip-compilation.md) 的技术校验默认采用，不再仅凭 COMPLETED 要求人工确认；REVIEW_REQUIRED 可保存展示，未解决依赖仍阻断受影响视频。WAN `basis=continuity` 组内无前态的变体问题在结构化决策和资产身份一致时仅是非阻断提醒；平台原始状态和证据不改写，旧派生报告不迁移、读取时完成分类。Compiler 仅对该受控版本启用 fileId/mediaRef/SHA 引用分支，按模板位置映射本地媒体与基础角色音色，不联网、不新增公开字段。实际视频请求/尾帧不覆盖模板。其他动作与冲突规则也以该合同为准。

Manifest 协议版本固定为 `mantur.drama.local/v1`，快照 Envelope 固定为 `mantur.drama.ui-snapshot/v1`。机器校验源位于 `schemas/manifest.schema.json` 和 `schemas/snapshot-envelope.schema.json`。

### 协议版本字段消歧

同名 `schema_version` 只在所属文件合同内解释，不能跨文件复制：

| 所属合同 | 合法示例 | 含义 |
|---|---|---|
| `.pipeline-state/project.json`、动作输入、批准和 Runtime 私有状态 | `1` | 数字结构版本；当前必须是 JSON number，不接受字符串 `"1"` 或命名版本 |
| `.pipeline-state/manifest.json` | `"mantur.drama.local/v1"` | Manifest 命名协议版本 |
| UI Snapshot Envelope | `"mantur.drama.ui-snapshot/v1"` | 快照封装命名协议版本 |
| 导入报告或平台业务产物 | 由对应合同定义，例如 `"asset_extract_model_result_v2"` 或平台业务标签 `"asset_extract_v2.0"` | 业务格式版本；同一主版本是否兼容由对应接入器完成完整语义校验，不能代替项目、动作、Manifest 或快照版本 |

因此，在线资产提取等动作输入必须写 `"schema_version": 1`，不能因为文档提到本地协议名称而改写为 `"mantur.drama.local/v1"`。Runtime 应按目标文件自己的 Schema 校验，不做版本类型猜测或隐式转换。

素材适配补充：操作私有状态在 `.pipeline-state/runtime/asset-operations/<id>/`，审核记录在 `runtime/asset-reviews/`；库存与匹配的不可变版本在 `.pipeline-state/results/asset-selections/`。一次原子项目指针更新选择同版本库存/匹配。声音匹配行可选 `base_asset_id` 优先于 legacy 唯一角色名；它不增加快照字段。唯一角色映射及绑定当前媒体 SHA 的可靠质量分析全部通过时沿用 `matched/passed`；`review_required` 的合规音频可携带已有 `local_audio` 供试听，但不变为 matched、不增加就绪数。自动质量证据只留在私有审核记录，不进入公开协议。详见 [素材操作合同](asset-operations.md)。

## 目录

```text
<project>/
└── .pipeline-state/
    ├── project.json
    ├── asset-extract.json
    ├── asset-inventory.json
    ├── results/
    │   ├── asset-extract-report.json
    │   ├── clip-compile-report.json
    │   ├── clip-compile-enriched-report.json
    │   └── videos/**/<clip>-video-result.json
    ├── runs/**
    ├── runtime/readonly-service.json
    ├── runtime/snapshot-sync.json
    ├── runtime/snapshot-source-receipt.json
    ├── manifest.json
    ├── deliveries.json
    └── ui/revisions/<revision>-<transaction-id>/
        ├── project.snapshot.json
        ├── assets.snapshot.json
        ├── episodes.index.snapshot.json
        ├── episodes/<episode_id>.snapshot.json
        ├── tasks.snapshot.json
        └── deliveries.snapshot.json
```

`project.json` 与 `results` 是业务事实。Manifest 是这些事实与只读快照的唯一权威索引。`ui` 目录中的文件是派生、脱敏、可重建的只读数据，不得反向成为生产输入。

## 已确认剧本与提取前看板

新项目在 project.json 保存 `source_script: {"path":"input/script.md","sha256":"<实际字节的64位小写SHA-256>"}`，path 相对项目根目录。Agent 在用户选定剧本后写入，提取描述中的 script 使用同一副本；修改剧本必须确认本次采用内容后更新摘要，不因校验失败自动重算覆盖。该字段只供本地来源校验，不进入公开快照，也不代表任何费用批准或提取完成。它是兼容的可选本地字段，仅新自动入口要求存在，不改变公共 Manifest、Envelope 或 API Schema。

新项目可保存私有 `local_media_sources`，记录用户已经确认纳入后续盘点的外部素材目录：

```json
{
  "confirmed": true,
  "roots": [
    {"path": "E:/project/人物", "kinds": ["image"]},
    {"path": "E:/project/音色", "kinds": ["audio"]}
  ]
}
```

`path` 是同一台机器上的规范化绝对目录；`kinds` 只接受 `image | audio`。用户明确不纳入自动发现的目录时保存 `{"confirmed":true,"roots":[]}`。该对象只记录用户确认的发现范围，不是库存、匹配、审核或生产授权；Compiler 和只读服务必须忽略它，不得发布到 Manifest、快照、HTTP API、看板或交付物。续跑时可直接复用仍可读取的目录；失效时要求用户重新指定，不按修改时间或相似目录猜选。真正采用的媒体仍复制到项目内并使用项目相对路径。

`open-workbench --on-project-ready` 校验该来源并发布初始看板；既有项目无需自动补字段，普通打开和 `--after-extraction` 保持原兼容行为。详见 [看板自动交接](readonly-http-api.md#项目准备完成后的自动交接)。

## 私有制作要求

`project.json.production_brief?: string` 保存用户面向整个项目的自由文本制作要求。它不是结构化制作参数：不再拆分 Clip 数、风格、语言或其他子字段。初次保存只去除整段首尾空白，保留内部原文和换行；空内容省略字段。后续补充保留旧内容，并以 `\n\n---\n\n补充要求：\n` 分隔后追加去除整段首尾空白的新原文，不替换旧内容。旧项目缺少该字段时保持原行为，不补写、不迁移、不报错。

Agent 在新建、续跑及准备资产提取、分镜或视频请求前读取完整备注，按当前阶段解释相关内容并转化为现有参数、提示词或决策，不机械复制全文。明确冲突以较新的补充为准；无法判断时在受影响阶段开始前询问。新补充只作用于尚未准备的新操作；历史分镜、视频、批准和已提交任务不变。与已准备或已报价但未提交操作冲突时，必须暂停复用并取得用户明确决定后才重新准备。

该字段属于项目私有创作偏好。Compiler 必须忽略它，不得写入 Manifest、Snapshot Envelope、只读快照、HTTP API 或看板；字段内容也不构成素材绑定／验收、模型选择、生成／重试／上传或费用批准，不能绕过实时 Schema、媒体门禁、安全边界和操作血缘。

## 私有视频创作风格

`project.json.creative_style` 是结构化且带修订号的项目风格选择，与自由文本 `production_brief` 分离：

```json
{"schema_version":1,"mode":"preset","preset_id":"fruit-drama-3d","preset_version":1,"revision":1}
```

或：

```json
{"schema_version":1,"mode":"custom","custom_text":"用户自定义风格原文","revision":1}
```

`mode=preset` 只接受 `fruit-drama-3d | ai-photoreal-live-action`，Runtime 根据稳定 ID 与 `preset_version=1` 解析私有文案；`mode=custom` 的文本整段只去除首尾空白、保留内部格式，长度为 1–12,000 字符。新项目 revision 必须从 1 开始；后续只能通过 `inspect-creative-style-change`／`apply-creative-style-change` 递增，不能直接编辑。初始选择收据保存在 `runtime/creative-style-selection.json`，每个不可变解析版本在 `runtime/creative-style-revisions/`，变更收据在 `runtime/creative-style-changes/`。

风格原文、解析提示词、摘要与操作 binding 都是私有生产状态。Compiler 必须忽略 `creative_style`，不得发布至 Manifest、Snapshot Envelope、HTTP API、看板或交付物。完整传播、旧项目兼容与修订失效规则见 [视频创作风格合同](creative-style.md)。

## 图片 provider 选择

`project.json.image_provider` 只接受 `native_agent_imagegen` 或 `manturhub:op.image.generate`；历史 `codex_imagegen` 仅作待规范的原生别名。新选择另存：

```json
{
  "image_provider": "native_agent_imagegen",
  "image_provider_selection": {
    "provider": "native_agent_imagegen",
    "mode": "user_selected"
  }
}
```

`mode` 只接受 `user_selected | only_available`。新生图请求只写 `user_selected`：用户对新的独立生图请求未指定方式时，Agent 主动询问；只有用户明确说继续当前批次或沿用刚才方式时复用最近选择。`only_available` 只兼容历史项目或技术排障，不能由新的普通生图请求写入。用户之后选择另一种方式时，保留显式改道确认与审计。该对象是避免重复询问的可选交互记录，不是生产授权：缺失时标为 `selection_unrecorded`，未知、无效或与 `image_provider` 不一致时标为 `selection_stale`，两者均不阻断 Runtime，实际生产只采用 `image_provider`。用户上传或接入已有图片不依赖此对象；既有项目不自动补写。

`provider_selection_audits` 保存单调 sequence、前后 provider、模式、是否真实改道及写入器；真实 provider 改变继续追加 `provider_migrations`。同一有效选择幂等，不新增审计。`select-image-provider` 改道时同步新选择；不带选择模式的旧迁移动作若真实改道则清除旧选择，历史审计保留。选择记录不进入公开快照，不改变音色状态、音色优先级或视频 provider。

## 资产展示名称

新资产保存产物由 `import-asset-extraction` 校验并转换，不直接将远端版本加入 Compiler allowlist。详细输入、限制和恢复规则见 [接入合同](asset-extraction-import.md)。派生报告版本为 `mantur.drama.asset-extraction/v1`，位于 `results/asset-extraction/<import_id>/report.json`；同目录 `state.json` 分别记录保存提取结果来源和本地接入成功，不能当作新建远端任务。

新项目的 `project.production_scope` 是 Runtime 封存的全集事实，包含 `mode=full_series`、连续集数、数量、剧本摘要和私有收据摘要。资产报告、Compiler、素材操作、音色门禁和 Production Manifest 采用该全集；分镜、视频、重试和导出仍可选择全集内的单次批次。全集不扩大费用批准。

`workflow_state.extraction_result/extraction_state/asset_extraction_import` 选中报告、状态和接入身份；原始 JSON/XLSX/Job/剧本字节与收据仅存 Runtime 私有归档。ID、基础 ID 的 `-V01` 和原集数文本保留；Compiler 支持 `第01集`。音色阶段按基础角色去重，与看板口径一致，不能将角色变体额外算成音色需求。报告 `资产适配场景` 为文本，不推断场景 ID。提取状态成功不授予素材/音色验收，版本与 API 均保持 v1。

资产快照新增可选 `display_name: string`，不改变 v1 Envelope 和身份字段。Compiler 顺序为：匹配记录非空 `display_name` → `source=user_uploaded` 且唯一匹配、单一可用图片路径的原文件名（去目录和最后扩展名）→ canonical name 与语义变体名用 ` - ` 连接 → canonical name。纯 `V01/V02` 等编号不拼入展示名。多个候选路径、未确认匹配或不可用媒体不从文件名猜名称；生成资产不采用自动 ID 文件名。所有名称继续经过快照脱敏。

新匹配记录应持久化展示名；legacy 只派生快照，不改报告或文件。2026-09-30 起，看板的角色、场景、道具名称统一使用 canonical name 与非编号变体名，不使用可能来自本地文件名的 display_name；资产列表、分镜引用和图片预览保持一致，旧快照直接适用。上述 Compiler 字段派生与 Runtime 持久化规则保留兼容，不迁移历史数据；音色仍按基础角色命名和去重。Asset ID、基础 ID、Clip 引用及最终提示词保持原值，重名不合并资产。

## 提示词模板展示

Clip 快照新增可选 `prompt_template: {status: "ready"|"missing"|"invalid", prompt: string, references: Array<{token: string, kind: "image"|"audio", asset_id?: string}>}`。它仅来自当前唯一请求行的 `请求体模板JSON`，正文保留模板 prompt，引用按 metadata.content 中图片/音频各自出现顺序编号、图片在前。绑定需与请求行引用表的 Token、类型和 URL 一致，URL 仅内部比对；未知/冲突绑定保留无 asset_id 的占位。模板结构要求对象、非空 prompt、metadata.content 数组和有效图片/音频条目；这里的 ready 只表示可展示，不代表生产校验通过。

页面不读取实际请求或 Clip总表正文作回退；模板不可用展示空状态，旧快照无此字段提示刷新。不追加非模板资产，不增加标题。胶囊只是 Token 展示替换，上方可用本地媒体仍经媒体 API 预览/试听。`content.final_prompt`、`prompt_references` 等旧字段语义及生产门禁不变；渲染选择切换不修改生产事实。用户授权修改模板的流程见 [运行合同](runtime-and-export.md#修改-clip-提示词的写回流程)。

## Manifest

Manifest 必须包含 `project_id`、单调递增 `revision`、时间、producer、权威文件引用、所有快照引用和兼容性信息。每个引用必须使用项目相对路径、SHA-256、字节数和媒体类型。新 producer 固定为：

`project.json.manturhub_base` 与 `producer.manturhub_base` 是经过校验、规范化且不带路径、凭证、查询或 fragment 的 HTTPS origin 字符串。项目字段是锁站与审计证据，Manifest 字段发布该证据；当前远端站点由显式 `MANTURHUB_BASE` 或 CLI `getBaseUrl()` 自动解析，新项目通过 `resolve-manturhub-environment` 取得后写入，不询问用户。旧 v1 消费者仍可读取同名字段。无远端血缘项目可在首次远端 prepare 前安全重绑；有任何远端身份、上传、报价、批准、提交或导入记录时不得自动改写。

```json
{
  "skill_name": "mantur-drama-visual-studio",
  "skill_version": "1.0.5",
  "snapshot_compiler_version": "1.0.5"
}
```

所有快照 Envelope 必须与 Manifest 的 `project_id`、`revision` 一致，并保留完整 `schema_version/project_id/revision/generated_at/source_manifest_sha256/data`。

## 状态枚举

旧协议的 Clip 校验状态 `待校验`（及机器值 `pending`）仍映射为 `pending`；当前 OpenAPI 分镜由共享 videoSelection 只读技术复核，通过后快照发布 validation_status=passed、review_status=not_required、prompt_status=completed，不制造人工确认；`校验未通过` 和未知非空值仍映射为失败。不修改原分镜报告或原始平台产物来修复展示。

- Stage：`not_started | ready | running | waiting_for_user | blocked | partially_completed | completed | failed | cancelled`
- Task：`created | queued | running | completed | failed | cancelled | unknown`
- Video：`waiting_for_assets | waiting_for_previous_tail | waiting_for_quote | waiting_for_approval | ready_to_submit | submission_unknown | queued | running | completed | failed | cancelled`
- Media availability：`available | missing | invalid`
- Review：`not_required | pending | passed | rejected`；音色复核单独使用 `review_required`

未知非空状态必须阻断迁移，不得猜成成功。

## 原子发布顺序

1. Runtime 原子写入权威结果。
2. 更新 `project.json` 中的权威文件指针。
3. 运行 `refresh-ui-snapshot`。
4. Compiler 校验全部 Envelope、文件引用和 Manifest 后最后替换 Manifest。
5. 已运行服务在下一次请求中读取新 Manifest，并以新 ETag 暴露 revision。

`--no-write` 只执行读取、迁移、归一化和校验，不改文件。任何失败不得替换上一版有效 Manifest，也不得触发远端任务。

服务运行期间对权威 JSON 的自动同步只是主动刷新的兜底，等待稳定约 2 秒、每 10 秒补查。同步状态和 JSON 发布指纹凭据仅存 Runtime 私有目录，不进入 Manifest 或业务快照。凭据与当前 Manifest 校验值、项目和 revision 匹配后才允许自动编译去重；凭据写入失败不撤销成功发布。手动刷新仍强制回验媒体，纯媒体文件变化不触发自动同步。

写入刷新在读取 revision 前取得项目排他锁。锁记录包含 PID、随机 token、版本和创建时间；兼容既有 `{pid, token}` 记录。竞争者确认持有 PID 存活时只按固定周期等待，不创建 `.reap`，也不能按锁龄抢占。主锁损坏、缺少合法 PID 或无法证明持有者死亡时失败关闭，最终返回 `PROJECT_BUSY`，不得按文件年龄删除。

只有合法主锁的 PID 已确认死亡时才进入回收；结构化 `.reap` 记录 reaper 的 PID、token、创建时间和目标主锁的 PID/token。reaper 删除主锁前必须重新读取并同时比对目标 PID、token 和原始内容，再次确认目标 PID 死亡；清理 `.reap` 前也必须比对自身 token。存活 reaper 只等待，死亡 reaper 自动清理后重试。旧版空文件或损坏 `.reap` 仅在至少存在 5 秒且当前主锁持有者仍可证明死亡时恢复；残留 `.reap` 不阻止直接取得一个已不存在的主锁。所有 `ENOENT` 均视为其他恢复者已完成，不重复执行临界区。

遇到 `PROJECT_BUSY` 只重试本地刷新。每个 revision 使用独立目录，全部文件回读后原子替换 Manifest；已发布目录不覆盖、不移动、不自动清理。API 客户端只跟随 Manifest 的文件引用，不拼接目录模板。发布前复核所选源和媒体指纹，变化时重编译；`--no-write` 返回 `SOURCE_CHANGED`，且不创建锁、索引或快照。

## 增量来源与任务关联

新在线资产操作 v2 私有保存于 runtime/online-asset-extraction；仅 runs/asset-extraction-<本地ID>.json 脱敏活动检查点进入 Compiler。下载后接入器验证持久化请求、批准、受理、原始成功 Job 及检查点血缘，允许自身检查点；其他任务和下游冲突仍阻断，详见 [在线资产合同](online-asset-extraction.md)。公开 Schema 不变。

每次刷新重新读取 `project.json`：显式指针优先，其次既有 Manifest 指针，最后采用标准路径。`workflow_state` 可指定 `extraction_state/extraction_result/asset_inventory/asset_matching_report/clip_compile_report/normalized_tasks/normalized_runs/deliveries`。`clip_compile.enriched_report` 或 `clip_compile.legacy_compile_report` 是分镜显式选择；未被选择的后处理报告不覆盖标准报告。显式路径无效、缺失、解析失败或版本不支持时失败关闭，不回退到旧报告。

标准任务/Run 索引为 `.pipeline-state/tasks.json` 与 `.pipeline-state/runs.json`，结构为 `{ "schema_version": 1, "items": [] }`；同时读取 `.pipeline-state/runs/**/*.json` 检查点及 `results/**/*-video-result.json`。任务记录保存 `run_id/task_id/clip_id/asset_id/stage/operator_id/attempt/request_sha256/status/progress/updated_at` 等关联事实，远端引用仅在权威文件中。新 Run 持久化稳定 ID；legacy 采用任务身份或稳定文件路径生成本地 ID，不使用内容哈希。`project.selected_runs[clip_id]` 明确选定 Run，否则按 attempt 和记录时间选择；无法判断的冲突要求聊天决策。

Clip 快照的可选 `latest_video_attempt` 按 attempt、记录时间和稳定身份发布当前分镜版本的最新生成尝试，供排队、生成、技术完成、失败和取消状态展示；它不替代 `latest_video_run`，不改变 `project.selected_runs`、严格完成、真实尾帧或交付。终态检查点的既有可选 `error_code/error_message` 经 Compiler 脱敏后进入 `latest_video_attempt.error`；密钥、完整 URL、本机路径和内部标识不得进入快照，非终态网络／限流错误不得作为视频失败发布。EpisodeSummary 的可选 `active_video_attempt_count` 只统计最新尝试为 `queued/running` 的 Clip。二次生成期间已有可用视频覆盖数保持不变；更高 attempt 自然替换旧失败尝试供页面展示，私有历史不删除。旧消费者忽略两个字段及可选错误。

## 交付记录

`project.json` 不保存交付目标。Compiler 不为全集或每集生成 `not_started` 占位交付项，只读取 `export-episodes`／`export-jianying-drafts` 实际写入的记录。公共项目快照为兼容保留 `project.deliverables`：无真实记录时为 `[]`，存在按集 ZIP 时包含 `episode_clips`，存在剪映记录时包含 `jianying_draft`。

5C 不改变公开结构：导出前由 Compiler 核对当前报告的完整目标；新版报告按交付计划或唯一合规候选确定 Run，复用 Runtime 技术证据、生产血缘与真实尾帧依赖校验，不要求交付选片等于全局采用。多候选须明确选择，衔接差异须显式接受；completed 字段不能替代这些门禁。两种导出的本地输入仍兼容，旧报告保留 Runtime 原兼容检查。发布前复核源并保存交付选择凭据，失败保留既有包和索引；快照失败单独恢复。具体流程见 [运行导出合同](runtime-and-export.md#按集-zip-输入合同)。

`workflow_state.deliveries` 或 Manifest 的 `deliveries` 指针指向交付索引；无指针时默认 `.pipeline-state/deliveries.json`。Runtime 在项目级锁中原子合并 `items`，按 `delivery_id` 更新而不是覆盖其他集。记录包含 `type/episode_id/expected_clip_ids/included_clip_ids/artifact_path/artifact_bytes/artifact_sha256/status/validation/updated_at`。状态为 `not_started/building/ready/failed/invalid`；Compiler 验证产物与交付计划选定视频的证据后发布，不要求候选成为全局采用。旧交付按原兼容证据读取，详见 [选片合同](video-result-selection.md)。剪映包 ready 只代表包验收，用户机器上的导入/播放验收仍需单独聊天确认。

剪映交付可附加 `installation`：`status` 为 `not_requested/pending/installed/failed`，`app_acceptance` 为 `pending/passed/failed`，`target_platform` 为 `windows/macos`。生成格式 `generator_format/serialization_version` 与实测应用版本 `application_version` 分开保存；未知应用版本为 null，不阻断已验证格式的安装。Runtime 还记录实际 `installed_path`、草稿 ID、安装时间与重试信息；完整收据在 `.pipeline-state/runtime/jianying-installs/`，不作为 UI 媒体输入。Snapshot 只发布状态、平台、应用验收和脱敏错误码，不暴露项目外路径。剪映新版和旧版草稿历史可共存；当前交付索引指向最近一次导出，旧包和原已安装草稿不被覆盖。

## 媒体门禁

媒体记录的机器来源是 `assets/local-project-media-contract.json`。completed 视频必须同时引用本地视频和真实尾帧；两者都必须位于项目内、为非符号链接普通文件、非空、扩展名与 MIME 匹配且 SHA-256 有效。只有新快照成功回读后才允许提交 completed 状态。

视频权威结果必须声明 `video_sha256`、`last_frame_sha256`、`validation_status: "passed"`、`tail_frame_is_real: true` 和 `tail_frame_source_sha256`（等于源视频哈希）。同场连续镜头还记录 `previous_clip_id` 与 `previous_tail_sha256`，必须匹配采用的前镜头尾帧。不得仅为通过门禁填入这些字段：必须先实际校验媒体和尾帧来源。legacy 缺少证据时保留媒体并待审核。

资产需唯一匹配、明确 `source` 和验收 `review_status`；文件存在本身不能完成。图片经 Agent 真实视觉检查后用私有 `review_origin=automatic_image_analysis` 与 `image_quality_analysis` 自动采用，公开匹配行仍使用 `matched/passed`，无需正常图片人工确认，不写虚假的 user_confirmed。平台候选采用前留在私有 operation；旧 pending 不由 Compiler 自动升级，详见[图片自动采用](asset-operations.md#图片自动采用与提交前核对)。音色 `ai_direct` 仅在项目策略明确允许时接受；已绑定音色需合规本地音频，并由真实用户试听确认或绑定媒体 SHA 的结构化质量分析支持。仅文件名、时长、文件存在或笼统“未发现问题”都不能自动通过。分镜需模板、技术校验、依赖与本次全集内批次完整，无需用户分镜确认；时长优先采用 `project.clip_policy`，缺省读取质量报告 `duration_planning.preferred_band`，最后才使用 legacy 60–90 秒默认值。

音色算子可选旧链接空值与历史原生图片审核的兼容只发生在 [素材操作入口](asset-operations.md)，不扩展公开 Schema。原始输出、原审核及媒体摘要保留；恢复的音频先使用现有 `review_status=pending`、`status=review_required` 和本地媒体引用，页面显示待试听确认，不计音色就绪。续跑时可基于原候选、当前选择摘要和新的可靠质量分析安全升级；旧待确认记录不批量自动升级。图片 provider 切换不抹除已验证的历史候选归属，也不放宽新素材接入或验收条件。


## 2026-09-16 资产产物兼容与恢复

角色、群众、重要度、基础资产关系和音色策略的兼容语义只在 [资产接入合同](asset-extraction-import.md#本地校验边界) 完整定义；本协议只消费其受控派生报告，不在发布阶段重写或推断这些规则。

当前成功提取接入可保留经原操作、请求、批准、受理、归档、终态回执与检查点校验的历史失败/取消记录；在途、未知提交、其他成功记录和下游冲突继续阻断。远端成功而本地接入失败时仅修复适配并恢复原操作，不重新上传、报价或调用提取。结构错误的本地诊断提供受限字段路径、规则及枚举，不输出完整内容。

PRIMARY_JSON 的平台主版本仍须为 `drama.production-assets.v2`。其业务 `schema_version` 可为 canonical `asset_extract_model_result_v2`，或 `asset_extract_v2` 的数字 minor／patch 标签；后者只在内存中映射到 canonical v2 校验档案，原字节和来源版本保持不变。任意名称、非数字后缀、v3 及结构不兼容产物仍阻断；分镜阶段复用同一规则。

## 音色兜底许可与角色决策（2026-09-16）

allow_ai_direct=true 仅表示项目允许兜底，不代表角色已选择直出。没有角色级音色匹配记录时保持 unresolved（页面右侧显示“未就绪”），不计配置完成，并阻断分镜/视频准备。Agent 先盘点用户音频并核对角色、媒体质量和验收；有效绑定优先。确认没有可用音色后，沿用已批准的项目兜底策略，在匹配报告 voices 中按 base_asset_id 记录 status=ai_direct 及 reason（说明匹配结果与采用原因），再原子保存、刷新回读。已有明确 ai_direct 记录继续兼容，但仍要求项目许可且不能同时指定参考音频；缺失、待审核或冲突的绑定不得被全局开关覆盖。none 规则不变。不得批量把未匹配角色改写为直出，也不得修改历史 Run 或重新提交付费任务。


1.0.5 的新 wan 产物通过 [v3 接入入口](wan-compilation-v3.md) 生成本协议的派生报告。资产提取业务版本 `2.0` 的完整校验见 [资产接入规则](asset-extraction-import.md)。
