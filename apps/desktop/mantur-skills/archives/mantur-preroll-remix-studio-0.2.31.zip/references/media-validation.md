# 媒体读取与验收合同

默认媒体读取使用随包解析器，不要求本机ffmpeg/ffprobe或额外安装媒体依赖。运行条件见[工具调用合同](cli.md)。文件大小来自文件读取，分辨率/时长/帧率/音轨等来自媒体容器，不是普通filesystem stat字段。首次导入读取一次并与SHA256/size绑定保存；之后素材恢复、计划和上传复用已测事实。新产物一次读取得到可信参数，再将同SHA/size的inspection传给addAsset，避免再次解析。

## 平台事实与本机事实

当前上传confirm只确认存储、类型与字节大小，没有视频参数；不要把AVAILABLE当作视频合法或已解码。生成/合成结果物化会在所选video或videos[i]上回填width/height/durationSec，usage.mediaMetadataSource=MATERIALIZED_FILE说明来源，videoSecondsVerified指媒体计量来源，不是完整解码。

仅取当前选定媒体对象，不能从另一个视频或汇总usage取尺寸。合法且匹配文件的事实可复用，精确视频ticks保留以避免秒数舍入多一帧；fps/hasAudio/rotation/SAR等缺失信息由已下载文件头补齐，缺音轨字段不能当作false。参数不一致以文件及计划核验为准并记录，不伪造云端完整合同或另起付费元信息任务。

## 内置读取范围

MP4/MOV使用随包固定的mp4box 0.5.4 all CommonJS，许可证位于scripts/mp4box-LICENSE.txt，上游来源和原文件SHA位于scripts/mp4box-SOURCE.json；用户不运行npm install。PNG检查签名、chunk边界和CRC；WebM读取EBML Info/Tracks元信息，跳过视频Cluster负载。普通及可靠连续时间轴的分片MP4支持精确ticks、平均fps、音轨、正交旋转；非方像素或非正交显示信息标未知，不能静默拉伸。复杂编辑/时间轴或缺可靠Duration明确不支持，不造默认时长/帧率。

读取仅元信息，跳过mdat/Cluster视频负载；不在本机裁剪或合成。解析在临时Node worker线程中，10秒期限，MP4元信息32MiB/样本100万/轨16/深度16预算，worker堆384+32MiB上限；WebM元信息16MiB。边界和分配数量在vendor展开前验证。错误仅安全code/说明，不回显原始文件内文本或私有路径。约束用于拒绝无法可靠核验文件，不转而强制安装工具。

## QA事实

默认QA包含metadata=true/container=true、decode=false/decodeStatus=not_performed、绑定文件SHA和来源。这表示媒体参数和容器结构检查通过，不表示全帧解码、画面质量、水印像素或声音内容已经验证。其中`hasAudio=true`只证明有音轨，不证明实际可听、对白清晰、指定音效出现或音画同步；未试听就标为声音内容未验，不能据元信息判定满足或不满足提示词。浏览器预览和远端模型质量另行验收。工作台显示实际验收范围，不把元信息读取冒充解码。

旧decode=true只有明确绑定当前SHA时可在新复验保留；旧展示记录保持历史含义。旧MEDIA_DECODE_FAILED必须绑定失败文件SHA，未知绑定不得弱检查自动通过；旧ENOENT仅缺工具不等于文件坏；已保存缓存可本地核验，缺失远端文件按[恢复合同](recovery.md)处理。新候选按选择绑定/不同hash区分，不能把前一个文件的QA赋给新文件。

## 可选已安装工具

机器已安装工具且用户选择加强验收时：

```text
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" verify-media --operation "<OP_ID>" --local-tools true --full-decode true
```

local-tools仅选择本机ffprobe参数复验；full-decode仅选择本机ffmpeg全解码，均可单独省略。默认verify-media依然为包内检查。检查先验证原文件SHA，在锁外执行长读取/解码，写回时重载确认同一媒体；只更新QA，不报价、上传、调用、下载或重做媒体。工具缺失/权限不足/检查未完成返回可选未执行，原项目不改，不提示必须安装。

明确解码失败会记录qa_failed与失败SHA，保留原Job/费用；同一失败缓存不能被默认弱检查洗成成功。加强验收再次真实通过可清对应失败记录；不同产物仍要有自己的证据。对尚未保存的旧失败产物应先核对原Job/下载，不因缺QA而重新收费生成。

产物经公共接入下载，业务不另写网络传输。下载失败只保留原任务和待产物事实，成功落盘仍须本页的媒体检查；本地合成夹具不能冒充真实远端下载、模型质量或生产交付通过。
