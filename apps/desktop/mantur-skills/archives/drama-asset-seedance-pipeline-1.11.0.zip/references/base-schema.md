# Feishu Base project schema

Create or reconcile these tables. Do not create a relationship table.

## 风格参考图

Create this table only when the project contains reference images.

Required fields: reference ID, user label, user note, scope (global/asset-specific), applicable asset types, visible style facts, original filename, checksum, width, height, aspect ratio, original attachment, public image URL, review status, updated time.

Reference IDs are open semantic labels, not fixed male/female slots. Store one record per source image and preserve the original attachment. The public URL is plain text.

Per-asset reference bindings use `reference-routing-v3` and must record every selected reference's roles plus `literal_embedding=forbidden`. A style-only binding is not permission to reproduce the source subject or place the source image inside generated output.

## 项目文件

Store original script, image, audio, and video files.

Required fields: file name, media type, checksum, original attachment, public URL, source, matched asset ID, match status, match evidence.

JianYing delivery remains in this same table; do not create another Sheet. Add missing fields when
that deliverable is selected: episode number, draft ZIP attachment, draft ZIP public URL, Clip
count, actual total duration seconds, target JianYing profile/version, delivery status, validation
summary, and package SHA-256. Use one record per episode. `生成ZIP`、`已导入待打开验收` and
`已打开验收` are distinct states; never report the last state without a real app-open check.

## 项目美术规范

Required fields: project name, world rules, positive style, negative constraints, aspect ratio, character proportion, crowd rules, audio policy, Clip policy, requested video concurrency, effective video concurrency, concurrency unit, queue policy, updated time.

## 角色资产

Required fields: asset ID, base asset ID, variant ID, canonical name, aliases, asset subtype (character/crowd), role, importance, production class, base/variant, crowd size class, venue type, gender, age, age range, spoken languages, personality, voice description, wardrobe/style, visual facts, story phase, wardrobe tags, applicable episode range, applicable scenes, forbidden tags, transition event, **variant rule JSON / 变体规则JSON**, evidence, generation prompt, generation policy, voice policy, normalized voice profile JSON, voice source, preset voice ID, preset voice asset ID, preset voice catalog version, voice match policy version, voice match status, voice match score, voice match reason, voice candidate JSON, voice conflict status, reference binding JSON, primary layout reference, target width, target height, target aspect ratio, output width, output height, aspect validation status, image provider, provenance, local filename, generation execution ID, original image attachment, image URL, voice attachment, voice URL, voice checksum, review status.

Crowd assets belong in this table with `asset subtype = crowd`. Do not create a separate crowd table.

`voice source` is one of `user_uploaded / preset_library / custom_generated / ai_direct / unresolved`. A preset match must preserve the catalog voice ID, asset ID, permanent public URL, versions, score/reason and checksum; never store only a URL with no identity. For every bound user/preset/custom voice, upload the verified MP3/WAV copy into `voice attachment`, while `voice URL` remains the anonymous public URL actually used in `reference_audio`. A Feishu attachment URL must never replace the permanent preset catalog URL. All ordinary visual variants of one canonical character inherit the same voice. If a story-backed voice-state variant is required, record its transition evidence explicitly instead of silently replacing the base voice.

## 场景资产

Required fields: asset ID, base asset ID, variant ID, canonical name, aliases, importance, visual facts, topology, entrances, exits, fixed objects, applicable episode range, applicable scenes, forbidden tags, **variant rule JSON / 变体规则JSON**, evidence, generation prompt, generation policy, reference binding JSON, primary layout reference, target width, target height, target aspect ratio, output width, output height, aspect validation status, image provider, provenance, local filename, generation execution ID, original image attachment, image URL, review status.

## 道具资产

Required fields: asset ID, base asset ID, variant ID, canonical name, aliases, owner, importance, visual facts, material/structure, applicable episode range, applicable scenes, forbidden tags, **variant rule JSON / 变体规则JSON**, evidence, generation prompt, generation policy, reference binding JSON, primary layout reference, target width, target height, target aspect ratio, output width, output height, aspect validation status, image provider, provenance, local filename, generation execution ID, original image attachment, image URL, review status.

## Clip总表

Required fields: Clip ID, episode, scene group, order, source lines, duration, model original duration, duration added seconds, episode model original total seconds, episode final total seconds, episode duration status, dialogue duration, scene, characters, variants, props, crowd, continuity mode, previous Clip ID, **variant decision JSON / 变体决策JSON**, prompt, missing assets, deferred assets, continuity conflicts, lint status, review status.

`变体规则JSON` and `变体决策JSON` are plain-text JSON fields. Do not turn their inner values into Feishu select fields. The only status outcome remains the existing `校验状态`; the only conflict detail remains the existing `连续性冲突`.

`episode duration status`, `continuity mode`, `lint status` and `review status` are Feishu single-select fields. Their only valid Chinese values come from `assets/storyboard-status-contract.json`; do not create free-text status fields or append options from model output.

## Seedance2.0请求体

Required fields: Clip ID, model, duration, model original duration, duration added seconds, episode model original total seconds, episode final total seconds, episode duration status, prompt, request template JSON as plain text, request stage, reference bindings, continuity mode, previous Clip ID, previous-tail URL, tail injection status, 视频供应路径, 视频算子ID, 生产请求JSON, 报价ID, 报价馒头数, 报价有效期, 用户批准状态, ManturHub任务ID, generation status, actual prompt, actual request JSON as plain text, submission response JSON, 成片附件, 成片URL, 尾帧附件, 尾帧URL, 计费回执JSON, error code, error message.

`episode duration status`, `request stage`, `continuity mode`, `tail injection status`, `用户批准状态` and `generation status` are Feishu single-select fields. Their exact values and legacy mappings come from `assets/storyboard-status-contract.json`. Keep the upstream raw status only inside `submission response JSON`; never write it directly into a Chinese status field.

`成片附件` and `尾帧附件` are Feishu `attachment` fields. `成片URL` and `尾帧URL` are plain `text` fields containing raw public URLs. New Bases must use these canonical names. An existing `成片` or `尾帧` field may be reused only when `+field-list` proves that its real type is `attachment`; a same-named text field is not equivalent, so create the missing canonical attachment field. The bundled machine-readable source is `assets/feishu-base-media-contract.json` and can be read with the allowlisted `base-media-contract` action.

`视频供应路径` 固定记录 `manturhub`，`视频算子ID` 固定记录实际使用的 `op.video.generate`。`报价ID`、`报价馒头数`、`报价有效期`、`用户批准状态` 必须在付费调用前写入；任务提交后再写 `ManturHub任务ID`，终态后写 `计费回执JSON`。

`request template JSON` is the compile-time body. `actual request JSON` stays empty until the Agent injects a real previous tail (when required) and completes the final quote. A pending tail must never be represented by a fake URL.

## Write rules

- Keep `Clip总表` and `Seedance2.0请求体` one-to-one on Clip ID.
- Before writing either table, run `storyboard-status-contract`; create or reconcile the declared status fields as `type=select, multiple=false`. Before migrating old rows, run `normalize-storyboard-statuses`; an unknown status is a blocking error.
- Store URL and JSON fields as plain text to prevent Markdown conversion.
- Keep reference IDs and asset reference binding JSON stable; do not replace source references with generated images.
- Upload local files with `+record-upload-attachment`; never write a local path into an attachment cell.
- A video row cannot become completed until `成片附件 / 成片URL / 尾帧附件 / 尾帧URL` have all been read back as non-empty.
- Preserve user columns that are outside this schema.
- When updating an existing Base, add missing fields but do not rename or delete existing fields without explicit approval.
- Never store provider endpoints, provider request fragments, credentials, signing headers, Worker credentials, direct-run buttons, or raw upstream stack traces in Base.
