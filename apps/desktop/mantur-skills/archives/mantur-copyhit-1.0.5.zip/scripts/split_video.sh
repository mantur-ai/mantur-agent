#!/usr/bin/env bash
# 按 N 秒把视频切成 part1/part2/...（重编码，切点准；不能用 -c copy 否则跳关键帧对不齐）
# 用法: split_video.sh <input> [seg_seconds=15] [outdir=.]
set -e
IN="$1"; SEG="${2:-15}"; OUT="${3:-.}"
[ -z "$IN" ] && { echo "用法: split_video.sh <input> [seg_seconds=15] [outdir=.]"; exit 1; }
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$IN")
N=$(python3 -c "import math;print(math.ceil(float('$DUR')/$SEG))")
mkdir -p "$OUT"
for i in $(seq 0 $((N-1))); do
  ss=$((i*SEG)); idx=$((i+1))
  ffmpeg -y -ss $ss -i "$IN" -t $SEG -c:v libx264 -preset medium -crf 20 -c:a aac -movflags +faststart "$OUT/part${idx}.mp4" 2>/dev/null
  echo "→ part${idx}.mp4 (${ss}~$((ss+SEG))s)"
done
echo "共 $N 段，时长 ${DUR}s"
