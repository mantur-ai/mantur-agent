import { createHash } from "node:crypto";
import { closeSync, existsSync, lstatSync, openSync, readFileSync, rmSync } from "node:fs";
import { request } from "node:http";
import { isAbsolute, resolve } from "node:path";
import { assertProjectWritePath, parseOptions, plainObject, projectRoot, writeJson } from "./common.mjs";
import { refreshUiSnapshot, resolveSkillRoot } from "./studio.mjs";
import { withProjectLock } from './project-lock.mjs';
import { spawnInternalNode } from './child-process.mjs';

const SERVICE_VERSION = "mantur-drama-readonly/v1";

function statePath() {
  return assertProjectWritePath(resolve(projectRoot(), ".pipeline-state", "runtime", "readonly-service.json"));
}

function stateFileExists() {
  const path = statePath();
  return existsSync(path) && lstatSync(path).isFile();
}

function readState() {
  const path = statePath();
  if (!existsSync(path) || !lstatSync(path).isFile()) return null;
  try {
    const value = JSON.parse(readFileSync(path, "utf8"));
    return plainObject(value) ? value : null;
  } catch {
    return null;
  }
}

function snapshotSyncStatus(state) {
  if (state?.snapshot_sync_version !== 2 || !state.instance_id) {
    return {enabled:false, state:'unavailable', restart_required:true};
  }
  try {
    const path = assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/snapshot-sync.json'));
    const value = JSON.parse(readFileSync(path, 'utf8'));
    if (value.schema_version !== 1 || value.pid !== state.pid || value.project_id !== state.project_id
      || value.instance_id !== state.instance_id || !['waiting','compiling','idle','error','stopped'].includes(value.state)) throw new Error();
    const result = {enabled:value.enabled === true,state:value.state,restart_required:false};
    for (const key of ['last_checked_at','last_success_at','last_error_at']) if (typeof value[key] === 'string' && /^\d{4}-\d{2}-\d{2}T[\d:.]+Z$/.test(value[key])) result[key]=value[key];
    if (Number.isInteger(value.revision) && value.revision >= 0) result.revision=value.revision;
    if (Number.isInteger(value.last_successful_revision) && value.last_successful_revision >= 0) result.last_successful_revision=value.last_successful_revision;
    if (Number.isInteger(value.compiler_exit_code)) result.compiler_exit_code=value.compiler_exit_code;
    if (plainObject(value.batch_update) && typeof value.batch_update.active === 'boolean') result.batch_update={active:value.batch_update.active,
      ...(typeof value.batch_update.started_at==='string'?{started_at:value.batch_update.started_at}:{}),
      ...(typeof value.batch_update.expires_at==='string'?{expires_at:value.batch_update.expires_at}:{})};
    if (['SOURCE_CHANGED','PROJECT_BUSY','SOURCE_PARSE_FAILED','SOURCE_FILE_MISSING','SOURCE_PATH_INVALID',
      'SOURCE_SCHEMA_UNSUPPORTED','SNAPSHOT_RECEIPT_WRITE_FAILED','SNAPSHOT_SYNC_STATE_WRITE_FAILED',
      'SNAPSHOT_MANIFEST_INVALID','SNAPSHOT_COMPILE_FAILED','SNAPSHOT_COMPILER_EXITED','PROJECT_UPDATE_IN_PROGRESS'].includes(value.error_code)) result.error_code=value.error_code;
    return result;
  } catch { return {enabled:true,state:'error',error_code:'SNAPSHOT_SYNC_STATE_UNAVAILABLE',restart_required:false}; }
}

function currentProjectId() {
  const path = assertProjectWritePath(resolve(projectRoot(), ".pipeline-state", "manifest.json"));
  try {
    const value = JSON.parse(readFileSync(path, "utf8"));
    return plainObject(value) && typeof value.project_id === "string" ? value.project_id : null;
  } catch {
    return null;
  }
}

function processExists(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function validState(state, expectedProjectId = null) {
  return plainObject(state)
    && state.schema_version === 1
    && state.service_version === SERVICE_VERSION
    && typeof state.project_id === "string"
    && state.project_id.length > 0
    && (expectedProjectId === null || state.project_id === expectedProjectId)
    && state.host === "127.0.0.1"
    && Number.isInteger(state.port)
    && state.port > 0
    && state.port <= 65535
    && Number.isInteger(state.pid)
    && state.pid > 0;
}

function health(state, timeoutMs = 1200) {
  if (!validState(state) || !processExists(state.pid)) return Promise.resolve(null);
  return new Promise((resolveHealth) => {
    const call = request({
      host: "127.0.0.1",
      port: state.port,
      path: "/api/v1/health",
      method: "GET",
      headers: { Host: `127.0.0.1:${state.port}` },
      timeout: timeoutMs,
    }, (response) => {
      const chunks = [];
      response.on("data", (chunk) => chunks.push(chunk));
      response.on("end", () => {
        try {
          const value = JSON.parse(Buffer.concat(chunks).toString("utf8"));
          resolveHealth(
            response.statusCode === 200
            && value.ok === true
            && value.service_version === SERVICE_VERSION
            && value.project_id === state.project_id
            && value.pid === state.pid
              ? value
              : null,
          );
        } catch {
          resolveHealth(null);
        }
      });
    });
    call.once("timeout", () => call.destroy());
    call.once("error", () => resolveHealth(null));
    call.end();
  });
}

function sleep(milliseconds) {
  return new Promise((resolveSleep) => setTimeout(resolveSleep, milliseconds));
}

function removeStaleState() {
  rmSync(statePath(), { force: true });
}

function childExited(child) {
  return child.exitCode !== null || child.signalCode !== null || !processExists(child.pid);
}

async function terminateManagedChild(child) {
  if (childExited(child)) return true;
  try { child.kill('SIGTERM'); } catch { /* child may already be exiting */ }
  for (let attempt = 0; attempt < 40 && !childExited(child); attempt += 1) await sleep(50);
  if (!childExited(child)) {
    try { child.kill('SIGKILL'); } catch { /* child may already be exiting */ }
    for (let attempt = 0; attempt < 20 && !childExited(child); attempt += 1) await sleep(50);
  }
  return childExited(child);
}

function removeStateForPid(pid) {
  const state = readState();
  if (state !== null && state.pid === pid) removeStaleState();
}

function launchMode(state) {
  return ['detached', 'host_managed'].includes(state?.launch_mode) ? state.launch_mode : 'legacy_unknown';
}

function runningResult(state, liveHealth, reused) {
  return {
    ok: true,
    running: true,
    reused,
    project_id: state.project_id,
    pid: state.pid,
    port: state.port,
    url: `http://127.0.0.1:${state.port}`,
    revision: liveHealth.revision,
    started_at: state.started_at,
    instance_id: state.instance_id,
    launch_mode: launchMode(state),
    snapshot_sync: snapshotSyncStatus(state),
    ...statusDiagnostics(state),
  };
}

export async function readonlyServiceStatus(tokens) {
  parseOptions(tokens, { positionals: 0 });
  const state = readState();
  const projectId = currentProjectId();
  if (projectId === null || !validState(state, projectId)) {
    if (state !== null || stateFileExists()) removeStaleState();
    return { ok: true, running: false, state: state === null ? "not_started" : "stale_record_removed" };
  }
  const liveHealth = await health(state);
  if (liveHealth === null) {
    removeStaleState();
    return { ok: true, running: false, state: "stale_record_removed", project_id: state.project_id };
  }
  return runningResult(state, liveHealth, true);
}

function statusDiagnostics(state) {
  const sync=snapshotSyncStatus(state);
  let diagnostic={};
  try {
    const value=JSON.parse(readFileSync(assertProjectWritePath(resolve(projectRoot(),'.pipeline-state/runtime/readonly-service-diagnostics.json')),'utf8'));
    if(plainObject(value)&&value.pid===state.pid&&value.project_id===state.project_id) diagnostic=value;
  } catch { /* optional private diagnostics */ }
  return {
    last_error_code: sync.error_code || (typeof diagnostic.last_error_code==='string'?diagnostic.last_error_code:null),
    last_error_at: sync.last_error_at || (typeof diagnostic.last_error_at==='string'?diagnostic.last_error_at:null),
    batch_update: sync.batch_update || {active:false},
    last_successful_revision: Number.isInteger(sync.last_successful_revision)?sync.last_successful_revision:null,
  };
}

export async function startReadonlyService(tokens, requireExtraction = false) {
  const launched = await withProjectLock(assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/service-start.lock')),
    () => startUnlocked(tokens, requireExtraction, {launchMode:'detached'}));
  return launched.result;
}

export async function serveReadonlyService(tokens, writeStartup = (payload) => process.stdout.write(`${JSON.stringify(payload)}\n`)) {
  let managedChild = null;
  let stopSignal = null;
  const forwardSignal = (signal) => {
    stopSignal ??= signal;
    if (managedChild !== null && !childExited(managedChild)) {
      try { managedChild.kill(signal); } catch { /* child may already be exiting */ }
    }
  };
  const onTerm = () => forwardSignal('SIGTERM');
  const onInt = () => forwardSignal('SIGINT');
  process.once('SIGTERM', onTerm);
  process.once('SIGINT', onInt);
  try {
    const launched = await withProjectLock(assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/service-start.lock')),
      () => startUnlocked(tokens, false, {
        launchMode:'host_managed',
        onSpawn:(child) => {
          managedChild = child;
          if (stopSignal !== null && !childExited(child)) {
            try { child.kill(stopSignal); } catch { /* child may already be exiting */ }
          }
        },
        stopSignal:() => stopSignal,
      }));
    writeStartup(launched.result);
    if (launched.child === null) return launched.result;
    managedChild = launched.child;

    const outcome = launched.child.exitCode !== null || launched.child.signalCode !== null
      ? {code:launched.child.exitCode, signal:launched.child.signalCode}
      : await new Promise((resolveExit, rejectExit) => {
          launched.child.once('error', rejectExit);
          launched.child.once('exit', (code, signal) => resolveExit({code, signal}));
        });
    let stateReleased = false;
    if (outcome.code !== 0 && !['SIGTERM', 'SIGINT'].includes(outcome.signal)) {
      for (let attempt = 0; attempt < 50; attempt += 1) {
        const current = readState();
        if (current === null || current.pid !== launched.result.pid) { stateReleased = true; break; }
        await sleep(50);
      }
    }
    if (outcome.code !== 0 && !['SIGTERM', 'SIGINT'].includes(outcome.signal) && !stateReleased) {
      throw Object.assign(new Error(`host-managed readonly service exited unexpectedly (${outcome.signal ?? outcome.code ?? 'unknown'})`),
        {code:'READONLY_SERVICE_EXITED'});
    }
    return launched.result;
  } finally {
    process.off('SIGTERM', onTerm);
    process.off('SIGINT', onInt);
  }
}

export async function openWorkbench(tokens) {
  const { options } = parseOptions(tokens, { positionals: 0, booleans: ['on-project-ready', 'after-extraction', 'link-only', 'require-existing'] });
  if (options['on-project-ready'] && options['after-extraction']) {
    throw Object.assign(new Error('Choose only one automatic workbench trigger.'), {code:'WORKBENCH_OPTIONS_CONFLICT'});
  }
  const automatic = options['on-project-ready'] || options['after-extraction'];
  let failureStage = 'project_validation';
  try {
    const source = options['on-project-ready'] ? inspectReadyProject() : null;
    if(options['on-project-ready']){
      const {assertProjectEpisodeScope}=await import('./project-episode-scope.mjs');
      await assertProjectEpisodeScope(projectRoot(),undefined,{requireSealed:true});
      const {sealProjectVideoModel}=await import('./project-video-model.mjs');
      await sealProjectVideoModel(projectRoot());
    }
    failureStage = 'service_preparation';
    const state = options['require-existing']
      ? (await withProjectLock(assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/service-start.lock')),
          () => startUnlocked([], options['after-extraction'] === true, {requireExisting:true}))).result
      : await startReadonlyService([], options['after-extraction'] === true);
    failureStage = 'page_check';
    const response = await fetch(state.url + '/', {signal:AbortSignal.timeout(2000)});
    if (!response.ok || !response.headers.get('content-type')?.includes('text/html')) {
      const error = new Error('当前服务未提供看板。请在聊天中明确停止旧服务后，再运行 open-workbench；或检查 Skill 静态资源是否完整。');
      error.code = 'WORKBENCH_UNAVAILABLE';
      throw error;
    }
    // Recheck after publication/startup before reserving an automatic browser attempt.
    failureStage = 'project_validation';
    if (source !== null && inspectReadyProject() !== source) {
      throw Object.assign(new Error('Project changed during workbench preparation.'), {code:'SOURCE_CHANGED'});
    }
    const presentation = automatic
      ? await claimWorkbenchPresentation(state, options['link-only'] === true,
        options['on-project-ready'] ? 'project_ready' : 'first_extraction')
      : { open_via_agent: !options['link-only'], presentation_reason: options['link-only'] ? 'link_only' : 'explicit_request' };
    return {...state, url:state.url+'/', browser_opened:false, ...presentation};
  } catch (error) {
    if (!automatic) throw error;
    // A viewing failure is not an extraction failure and never authorizes resubmission.
    return {ok:false, browser_opened:false, open_via_agent:false, production_result_preserved:true,
      retry_production:false, error:{code:'WORKBENCH_HANDOFF_FAILED', stage:failureStage,
        cause_code: ['PROJECT_EPISODE_SCOPE_REQUIRED','PROJECT_EPISODE_SCOPE_INVALID','PROJECT_EPISODE_SCOPE_IMMUTABLE','PROJECT_EPISODE_STRUCTURE_UNRESOLVED','PROJECT_EPISODE_EVIDENCE_INVALID','PROJECT_EPISODE_EVIDENCE_MISMATCH','PROJECT_VIDEO_MODEL_REQUIRED','PROJECT_VIDEO_MODEL_IMMUTABLE','VIDEO_MODEL_UNVERIFIED','WORKBENCH_PROJECT_NOT_READY','SOURCE_CHANGED','WORKBENCH_UNAVAILABLE','EXTRACTION_REPORT_REQUIRED',
          'READONLY_SERVICE_NOT_RUNNING','PROJECT_UPDATE_IN_PROGRESS','SOURCE_FILE_MISSING','SOURCE_PATH_INVALID','SOURCE_PARSE_FAILED',
          'SOURCE_SCHEMA_UNSUPPORTED','PROJECT_BUSY','SNAPSHOT_RECEIPT_WRITE_FAILED'].includes(error?.code)
          ? error.code : 'WORKBENCH_PREPARATION_FAILED',
        message:'看板暂不可用；保留项目与已有生产结果，仅检查项目输入、快照或本地服务，不重新提交生产任务。'}};
  }
}

function inspectReadyProject() {
  try {
    const projectBytes = readFileSync(assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/project.json')));
    const project = JSON.parse(projectBytes.toString('utf8'));
    const source = project.source_script;
    if (!plainObject(project) || typeof project.project_name !== 'string' || !project.project_name.trim()
      || !plainObject(source) || typeof source.path !== 'string' || !source.path.trim()
      || isAbsolute(source.path) || /^[a-zA-Z]:/.test(source.path)
      || !/^[a-f0-9]{64}$/.test(source.sha256)) throw new Error('Invalid project source');
    const path = assertProjectWritePath(resolve(projectRoot(), source.path));
    if (!lstatSync(path).isFile()) throw new Error('Invalid script file');
    const bytes = readFileSync(path);
    if (!bytes.length || createHash('sha256').update(bytes).digest('hex') !== source.sha256) throw new Error('Script changed');
    return createHash('sha256').update(projectBytes).digest('hex');
  } catch {
    throw Object.assign(new Error('Save a confirmed project script with a valid relative path and SHA-256 first.'),
      {code:'WORKBENCH_PROJECT_NOT_READY'});
  }
}

async function claimWorkbenchPresentation(state, linkOnly, reason) {
  try {
    const path = assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/workbench-presentation.json'));
    return await withProjectLock(assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/runtime/workbench-presentation.lock')), async () => {
      if (existsSync(path)) {
        const previous = JSON.parse(readFileSync(path, 'utf8'));
        if (previous.schema_version !== 1 || typeof previous.project_id !== 'string'
          || !['attempt_reserved', 'link_only'].includes(previous.disposition)) throw new Error('Invalid presentation record');
        if (previous.project_id === state.project_id) return {open_via_agent:false, presentation_reason:'already_handled'};
      }
      // Reserve before returning: even concurrent Agents must not both open a tab.
      // This records an attempt, never claims the host browser actually opened.
      writeJson(path, {schema_version:1, project_id:state.project_id, revision:state.revision,
        disposition:linkOnly ? 'link_only' : 'attempt_reserved', recorded_at:new Date().toISOString()});
      return {open_via_agent:!linkOnly, presentation_reason:linkOnly ? 'link_only' : reason};
    });
  } catch {
    // An unreadable/unwritable marker must not cause repeated unsolicited windows.
    return {open_via_agent:false, presentation_reason:'presentation_record_unavailable', presentation_warning:'WORKBENCH_PRESENTATION_STATE_UNAVAILABLE'};
  }
}

async function startUnlocked(tokens, requireExtraction = false, {
  launchMode: requestedLaunchMode = 'detached',
  requireExisting = false,
  onSpawn = () => {},
  stopSignal = () => null,
} = {}) {
  parseOptions(tokens, { positionals: 0 });
  const refreshed = refreshUiSnapshot([]);
  const projectId = refreshed.manifest?.project_id ?? refreshed.project_id;
  if (typeof projectId !== "string" || !projectId) throw new Error("snapshot compiler did not return a project_id");
  if (requireExtraction) {
    const manifestPath = assertProjectWritePath(resolve(projectRoot(), '.pipeline-state/manifest.json'));
    const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
    if (manifest.project_id !== projectId || !manifest.authoritative_files?.asset_report) {
      throw Object.assign(new Error('Published extraction report is required'), {code:'EXTRACTION_REPORT_REQUIRED'});
    }
  }

  const current = readState();
  if (validState(current, projectId)) {
    const liveHealth = await health(current);
    if (liveHealth !== null) {
      return {result:runningResult(current, liveHealth, true), child:null};
    }
  }
  if (current !== null || stateFileExists()) removeStaleState();
  if (requireExisting) {
    throw Object.assign(new Error('A verified readonly service must already be running.'), {code:'READONLY_SERVICE_NOT_RUNNING'});
  }

  const skillRoot = resolveSkillRoot();
  const serverEntry = resolve(skillRoot, "runtime", "readonly-server.mjs");
  if (!existsSync(serverEntry) || !lstatSync(serverEntry).isFile()) {
    throw new Error("bundled readonly service is missing; reinstall mantur-drama-visual-studio@1.0.5");
  }
  const logPath=assertProjectWritePath(resolve(projectRoot(),'.pipeline-state/runtime/readonly-service.log'));
  const logFd=openSync(logPath,'a');
  let child;
  try { child = spawnInternalNode(serverEntry, [
    "--project-root",
    projectRoot(),
    "--state-file",
    statePath(),
    "--launch-mode",
    requestedLaunchMode,
  ], {
    detached: requestedLaunchMode === 'detached',
    stdio: ["ignore", logFd, logFd],
    parentEnvironment: process.env,
    environmentProfile: 'service',
  }); } finally { closeSync(logFd); }
  if (requestedLaunchMode === 'detached') child.unref();
  let childError = null;
  const recordChildError = (error) => { childError = error; };
  child.once('error', recordChildError);
  try {
    onSpawn(child);
    for (let attempt = 0; attempt < 50; attempt += 1) {
      const interruptedBy = stopSignal();
      if (interruptedBy !== null) {
        throw Object.assign(new Error(`host-managed readonly service startup interrupted by ${interruptedBy}`),
          {code:'READONLY_SERVICE_START_INTERRUPTED'});
      }
      if (childError !== null) {
        throw Object.assign(new Error('readonly service process failed during startup'),
          {code:'READONLY_SERVICE_START_FAILED', cause:childError});
      }
      if (childExited(child)) {
        throw Object.assign(new Error('readonly service process exited before becoming healthy'),
          {code:'READONLY_SERVICE_EXITED_DURING_START'});
      }
      await sleep(100);
      const state = readState();
      if (!validState(state, projectId)) continue;
      const liveHealth = await health(state);
      if (liveHealth !== null) {
        return {result:runningResult(state, liveHealth, false), child:requestedLaunchMode === 'host_managed' ? child : null};
      }
    }
    throw Object.assign(new Error("readonly service did not become healthy within 5 seconds"),
      {code:'READONLY_SERVICE_START_TIMEOUT'});
  } catch (error) {
    if (requestedLaunchMode !== 'host_managed') {
      if (!processExists(child.pid)) removeStateForPid(child.pid);
      throw error;
    }
    const stopped = await terminateManagedChild(child);
    if (stopped) removeStateForPid(child.pid);
    if (!stopped) {
      throw Object.assign(new Error('host-managed readonly service could not be cleaned up after startup failure'),
        {code:'READONLY_SERVICE_CLEANUP_FAILED', cause:error});
    }
    throw error;
  } finally {
    child.off('error', recordChildError);
  }
}

export async function stopReadonlyService(tokens) {
  const { options } = parseOptions(tokens, { positionals: 0, booleans: ["confirm-stop"] });
  if (!options["confirm-stop"]) {
    throw new Error("stopping the readonly service requires an explicit chat request and --confirm-stop");
  }
  const state = readState();
  const projectId = currentProjectId();
  if (projectId === null || !validState(state, projectId)) {
    if (state !== null || stateFileExists()) removeStaleState();
    return { ok: true, running: false, stopped: false, state: "not_running" };
  }
  const liveHealth = await health(state);
  if (liveHealth === null) {
    removeStaleState();
    return { ok: true, running: false, stopped: false, state: "stale_record_removed" };
  }
  process.kill(state.pid, "SIGTERM");
  for (let attempt = 0; attempt < 40 && processExists(state.pid); attempt += 1) await sleep(50);
  if (processExists(state.pid)) throw new Error("readonly service did not stop after SIGTERM");
  removeStaleState();
  return { ok: true, running: false, stopped: true, project_id: state.project_id };
}
