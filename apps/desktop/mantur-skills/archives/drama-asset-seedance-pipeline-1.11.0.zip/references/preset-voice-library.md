# Preset voice library contract

The bundled library is a catalog of immutable public ManturHub audio assets, not a folder of expiring upload links. `assets/voice-library/catalog.json` is the machine-readable source.

## Priority and ownership

1. A user-provided, uniquely matched voice always wins.
2. Preset matching is allowed only when the project policy enables it.
3. Custom voice generation is used only when the user explicitly requests and approves its price.
4. AI-direct speech is used only when the project policy already allows it and no user/preset/custom voice is selected.

Provider failure never changes this order automatically. Keep the character unresolved and expose the real error.

## Character profile

Normalize these asset-extractor fields before matching:

```json
{
  "asset_id": "CHAR-001",
  "canonical_name": "Example",
  "gender": "female",
  "age_range": "young-adult",
  "voice_presentation": "女声",
  "age_feel": "青年感",
  "pitch_band": "中音",
  "timbre_tags": ["清亮干练"],
  "expression_tags": ["冷静沉稳"],
  "role_tags": ["女主", "白领"],
  "voice_description": "青年女性，中音，清亮干练，语速稳定",
  "personality": "理性、克制"
}
```

`voice_presentation` and `age_feel` must be known before automatic matching. Do not infer gender from a name, filename, costume or fruit species. Use `童声` for an actual child voice profile, not merely for a playful adult.

## Deterministic match

Run:

```bash
manturhub skill exec drama-asset-seedance-pipeline match-voice --project "$PROJECT_DIR" -- character-voice-profile.json \
  --reserved-voice-id M001 \
  --output voice-match.json
```

Pass every preset already occupied by another named character through repeated `--reserved-voice-id`. Use `--allow-reuse` only when the user allows reuse for crowds or one-off characters. For a visual variant of an existing canonical character, pass `--existing-voice-id`; this locks identity instead of rematching.

Candidate scoring may run in parallel. Final assignment must be a deterministic global pass ordered by character importance, with every occupied preset reserved before the next named character is committed. If two important characters want the same voice, keep the higher-priority assignment and re-evaluate or request review for the other; do not accept whichever parallel task writes first.

Only `status=matched` or `matched_locked_identity` may populate `preset voice ID`, `preset voice asset ID`, `voice URL` and `voice checksum`. The selected matcher object must carry the catalog `voice_id`, `asset_id`, `public_url` and `sha256` together. `review_required` exposes the top candidates and reasons for audition. `unresolved/no_candidate` remains empty. A low margin, unknown age/presentation, inactive asset, reserved identity or a `待试听确认` catalog entry cannot be silently auto-selected.

## URL and integrity gate

Before first use in a project, verify the selected catalog row:

- `active=true` and non-empty `asset_id`;
- public HTTPS URL has no query string and supports anonymous GET/Range;
- MIME is `audio/mpeg` and actual content SHA-256 matches the catalog;
- actual file duration is at least two seconds;
- `catalog_version`, `match_policy_version`, `voice_id`, checksum and match reason are written to Base.

Do not replace this URL with a private upload URL or a long-lived-looking signed URL. Public preset assets are immutable; a changed audio file requires a new object key, checksum and catalog version.

After a match is accepted, download the immutable audio into the project cache, verify MIME/duration/SHA-256, and upload that local file to the character row's Feishu `voice attachment` field. Store the permanent catalog URL separately in the plain-text `voice URL` field. The request compiler consumes `voice URL`; the attachment is for human review and archive.

For every Clip spoken by that character, the prompt must contain the corresponding `@AudioN` next to the speaker and `metadata.content` must contain the same URL as a `reference_audio` item. `@AudioN` numbering follows audio items in content order. A matched preset is neither a missing voice nor an AI-direct voice.

## Voice-state variants

Wardrobe, location, emotion and ordinary facial/pose variants do not create a new voice. A new voice-state asset requires direct story evidence such as childhood/adulthood, aging, transformation, electronic processing or an intentional disguise. Record the event, episode and evidence lines, then match or generate the new state independently while keeping its link to the base canonical character.
