#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { check, initialize, loadProject, withLock, saveProject, addAsset,createManagedProject,assertProjectDirectory,assertWritableProject,assertProjectStorage,projectStorageStatus } from './project.mjs';
import * as flow from './workflow.mjs';
import { doctor, guide, openWorkbench,presentImportedProject } from './onboarding.mjs';
import { checkSkillUpdate } from './skill-update.mjs';
import { bindProjectClient, publicProjectClient, executionDefaults, readInvocationContext } from './integration.mjs';
import { upgradeProject } from './upgrade.mjs';
import {verifyMedia} from './optional-media-tools.mjs';
import {selectMode,modeChoice} from './production-mode.mjs';
import {projectGuidance} from './guidance.mjs';
import {errorView,safeErrorCode} from './diagnostics.mjs';

export const contract = { runtimeVersion: '0.2.0', schemaVersion: 2 };

const args=process.argv.slice(2); const flags={};let action,viewer,dir;
async function guidanceProject(){if(!dir)return null;try{return await loadProject(dir);}catch{return null;}}
try{
  for(let i=0;i<args.length;i++){if(args[i].startsWith('--')){const key=args[i].slice(2);check(args[i+1]&&!args[i+1].startsWith('--'),'ARGUMENT_VALUE_REQUIRED');flags[key]=args[++i];}else{check(!action,'ONE_ACTION_ONLY');action=args[i];}}
  if(action==='attribution-context'){
    const invocationContext=await readInvocationContext(path.resolve(flags.project||process.env.MANTURHUB_PROJECT||process.cwd()));
    console.log(JSON.stringify({ok:true,result:{readOnly:true,invocationContext}}));
    process.exit(0);
  }
  if(action!=='create-project')flags.project ||= (await executionDefaults()).project || (['doctor','guide','check-updates'].includes(action)?process.cwd():undefined);
  check(action&&(flags.project||action==='create-project'),'USAGE','node scripts/studio.mjs --project DIR ACTION [--file JSON] [--stage fronts|analysis|compose]');
  check(flags.headless===undefined||['true','false'].includes(flags.headless),'HEADLESS_INVALID');
  check(flags.browser===undefined||['auto','host'].includes(flags.browser),'BROWSER_MODE_INVALID');
  check(flags.confirm===undefined||action==='run'&&flags.operation,'CONFIRM_SINGLE_OPERATION_REQUIRED','收费令牌只能用于一项明确的原操作。');
  check(flags['update-choice']===undefined||['continue','update'].includes(flags['update-choice']),'UPDATE_CHOICE_INVALID');
  for(const key of ['local-tools','full-decode'])check(flags[key]===undefined||['true','false'].includes(flags[key]),'MEDIA_CHECK_MODE_INVALID');
  dir=flags.project?path.resolve(flags.project):undefined;
  let cachedInput;
  const input=async()=>{check(flags.file,'INPUT_FILE_REQUIRED');return cachedInput ??= JSON.parse(await fs.readFile(path.resolve(flags.file),'utf8'));};
  let result;
  let project;
  if(!['doctor','create-project','init'].includes(action)){
    try{project=await loadProject(dir);}catch(error){if(error.code!=='ENOENT')throw error;}
  }
  check((flags['existing-cli']===undefined)===(flags['config-dir']===undefined),'CLI_BINDING_PAIR_REQUIRED');
  const defaults=await executionDefaults();
  const bindingArgs=[...(defaults.bindingArgs||[])];
  for(const [flag,value] of [['--source',flags.source],['--business-code',flags['business-code']],['--existing-cli',flags['existing-cli']],['--config-dir',flags['config-dir']]])if(value!==undefined){
    const existing=bindingArgs.indexOf(flag);if(existing>=0)bindingArgs.splice(existing,2);
    bindingArgs.push(flag,value);
  }
  const localClient=p=>publicProjectClient({project:p,projectDir:dir,confirm:flags.confirm,bindingArgs:bindingArgs.length?bindingArgs:undefined});
  const wire=p=>bindProjectClient(p,localClient(p));
  const viewOptions={headless:flags.headless==='true',browser:flags.browser||'host',bindingArgs};
  const viewerActions=new Set(['guide','status','select-mode','prepare-fronts','prepare-analysis','collect-highlights','highlight-options','select-highlights','prepare-highlights','plan','prepare-compose','quote','approve','run','resume','retry','redownload','select-result','add-assets']);
  // Recover/show the same viewer before potentially slow processing, outside the write lock.
  viewer=project&&viewerActions.has(action)&&!viewOptions.headless?await presentImportedProject(dir,{},{...viewOptions,...(action==='guide'?{reveal:'always'}:{})}):undefined;
  async function updateProject(action){
    const deadline=Date.now()+20000;
    for(;;){let entered=false;
      try{return await withLock(dir,()=>{entered=true;return action();});}
      catch(error){if(entered||error.code!=='PROJECT_LOCKED'||Date.now()>=deadline)throw error;await new Promise(resolve=>setTimeout(resolve,100));}
    }
  }
  let updateCheck;
  if(action==='check-updates')result=await checkSkillUpdate();
  const preparing=new Set(['create-project','init','prepare-fronts','prepare-analysis','prepare-highlights','prepare-compose','retry']);
  const submitting=action==='run'&&project?.operations.some(op=>op.status==='prepared'&&(!flags.operation||op.id===flags.operation));
  if((preparing.has(action)||submitting)&&(!project||project.schemaVersion===2&&!project.legacyOrigin)){
    updateCheck=await checkSkillUpdate();
    if(updateCheck.status==='update_available'){
      const continuing=flags['update-choice']==='continue'&&flags['update-target']===updateCheck.updateTarget;
      if(!continuing)result={status:flags['update-choice']==='update'?'update_requested':'needs_update_decision',nextAction:'choose-update',
        message:'请通过当前安装入口更新，或明确继续本次已核对的版本；尚未执行本制作动作。',updateCheck};
    }
  }
  if(action==='upgrade-project')result=await upgradeProject(dir,{apply:flags.apply==='true',confirmed:flags.confirmed==='true',sourceSha256:flags['source-sha256']});
  if(project)wire(project);
  if(result!==undefined){/* Version decisions are returned before any project write or production call. */}
  else if(action==='create-project'){
    const created=await createManagedProject(await input(),{parentDirectory:flags['parent-directory']});dir=created.projectDir;result=flow.summary(created.project);
  }
  else if(action==='doctor'){result=await doctor(dir,{bindingArgs});if(!result.ready)process.exitCode=1;}
  else if(action==='guide'){result=await guide(dir);check(result.status!=='project_state_review_required','PROJECT_INVALID','项目状态需要核对，暂不能给出可靠的制作下一步。');}
  else if(action==='verify-media'){assertWritableProject(project);result=await verifyMedia(dir,flags.operation,{localProbe:flags['local-tools']==='true',fullDecode:flags['full-decode']==='true'});}
  else if(action==='open-workbench'||action==='serve'){result=await openWorkbench(dir,viewOptions);}
  else if(action==='status'){result=flow.summary(await loadProject(dir));}
  else if(action==='highlight-options'){result=flow.highlightOptions(await loadProject(dir));}
  else if(action==='capabilities'){result=await flow.capabilities(wire(await loadProject(dir)));}
  else {await assertProjectDirectory(dir);result=await updateProject(async()=>{
    if(action==='init')return flow.summary(await initialize(dir,await input()));
    const p=wire(await loadProject(dir));
    assertWritableProject(p);
    const needsStorage=['prepare-fronts','prepare-analysis','prepare-highlights','prepare-compose','quote','retry'].includes(action)||action==='run'&&p.operations.some(op=>op.status==='prepared'&&(flags.operation?op.id===flags.operation:op.stage===flags.stage));
    if(needsStorage)await assertProjectStorage(dir);
    switch(action){
      case 'select-mode':return selectMode(dir,p,await input());
      case 'add-assets':{const spec=await input();for(const item of spec.assets)await addAsset(dir,p,item);await saveProject(dir,p);return flow.summary(p);}
      case 'prepare-fronts':return flow.prepareFronts(dir,p,await input());
      case 'prepare-analysis':return flow.prepareAnalysis(dir,p,await input());
      case 'collect-highlights':return flow.collectHighlights(dir,p);
      case 'select-highlights':return flow.selectHighlights(dir,p,await input());
      case 'prepare-highlights':return flow.prepareHighlights(dir,p,flags.file?await input():{});
      case 'plan':return flow.planOutputs(dir,p,await input());
      case 'prepare-compose':return flow.prepareCompose(dir,p);
      case 'quote':return flow.quoteStage(dir,p,flags.stage);
      case 'approve':return flow.approveStage(dir,p,flags.stage,await input());
      case 'run':return flow.runStage(dir,p,flags.operation?p.operations.find(o=>o.id===flags.operation)?.stage:flags.stage,undefined,flags.operation);
      case 'resume':return flow.resumeStage(dir,p,flags.operation?p.operations.find(o=>o.id===flags.operation)?.stage:flags.stage,undefined,flags.operation);
      case 'retry':return flow.retryFailed(dir,p,flags.operation,await input());
      case 'redownload':{const op=p.operations.find(o=>o.id===flags.operation);check(op&&['artifact_pending','qa_failed'].includes(op.status)&&op.output,'DOWNLOAD_RECOVERY_NOT_AVAILABLE');delete op.downloaded;delete op.downloadedFor;op.status='artifact_pending';await saveProject(dir,p);return {id:op.id,status:op.status,newPaidTask:false};}
      case 'select-result':return flow.selectResult(dir,p,flags.operation,Number(flags.index));
      default:check(false,'ACTION_UNKNOWN');
    }
  });}
  if(['init','create-project'].includes(action)&&!['needs_update_decision','update_requested'].includes(result.status))result={...result,storageCheck:await projectStorageStatus(dir)};
  if(viewer&&['run','resume','add-assets'].includes(action)){
    const after=await presentImportedProject(dir,{},viewOptions);
    if(after.warning||after.workbench?.reused===false)viewer=after;
  }
  if(['init','add-assets','create-project'].includes(action)&&!['needs_update_decision','update_requested'].includes(result.status)){
    if(viewer)result={...result,...viewer};
    else result=await presentImportedProject(dir,result,viewOptions);
  }
  if(['open-workbench','serve'].includes(action))result=await presentImportedProject(dir,result,{...viewOptions,open:async()=>result,reveal:'always'});
  if(updateCheck&&!result.updateCheck&&action!=='check-updates')result={...result,updateCheck};
  const hostAttribution=result.hostAttribution||viewer?.hostAttribution;
  if(hostAttribution&&!result.hostAttribution)result={...result,hostAttribution};
  const display=result.workbench||result.warning||result.headless?result:viewer;
  // Every action exposes one host-facing location; existing result fields remain
  // intact for installed callers that consumed the earlier nested response.
  const guidance=projectGuidance(await guidanceProject(),{action,result,warningCode:display?.warning?.reasonCode||display?.warning?.code});
  console.log(JSON.stringify({ok:true,result,guidance,...(hostAttribution?{hostAttribution}:{}),...(display?{projectDir:display.projectDir,workbench:display.workbench,presentation:display.presentation,warning:display.warning,...(display.headless?{headless:true}:{})}: {})},null,2));
}catch(e){const guidance=projectGuidance(await guidanceProject(),{action,errorCode:safeErrorCode(e.code),warningCode:viewer?.warning?.reasonCode||viewer?.warning?.code});console.log(JSON.stringify({ok:false,guidance,error:errorView(e),...(e.code==='MODE_CONFIRMATION_REQUIRED'?{decision:modeChoice()}:{}),...(viewer?{projectDir:viewer.projectDir,workbench:viewer.workbench,presentation:viewer.presentation,warning:viewer.warning,...(viewer.hostAttribution?{hostAttribution:viewer.hostAttribution}:{})}: {})}));process.exitCode=1;}
