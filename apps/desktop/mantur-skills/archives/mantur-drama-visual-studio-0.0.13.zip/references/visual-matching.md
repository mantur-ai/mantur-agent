# Visual asset matching rules

## Evidence order

Use all evidence together:

1. User-declared asset ID, character name, type, and variant.
2. Canonical names, aliases, and evidence lines extracted from the script.
3. Visible pixels or video content.
4. Filename and folder naming.

A filename alone never proves identity when two script assets remain plausible.

## Existing-media batch workflow

For an already confirmed source scope, reuse its saved directories. Inventory candidate files and compare duplicate checksums in one pass. Use user labels, script names, aliases, variant descriptions, and episode evidence to shortlist plausible targets; do not compare every file against every extracted asset by default. This shortlist is for efficient review, never identity proof.

Inspect the actual pixels of every image proposed for adoption. A contact sheet may help scan many files together if each image remains legible; open the original at sufficient detail when identity, clothing, injury, scene layout, image quality, or headcount cannot be resolved from the sheet. Do not infer unseen details from the filename, thumbnail, or a prior Agent's summary.

For each uniquely matched, visually checked image in the authorized source scope, use the automatic image review contract in [asset operations](asset-operations.md#图片自动采用与提交前核对). Adopt it without requesting whole-list user confirmation. Summarize the adopted mapping, conflicts, quality problems and backup files for the user to inspect voluntarily. Multiple candidates require actual visual comparison: choose one that best fits identity, current requirements, reference constraints and legibility, recording why. Preserve alternatives; ask only when the evidence cannot support a clear choice. Never fabricate user confirmation or visual evidence. Unmatched requirements remain distinct from unused files.

Style references are not identity evidence unless the user explicitly identifies the depicted asset. A visual match can guide rendering style without asserting that the pictured subject is a script character.

A style reference is also not an output element. Do not treat the source image, its depicted character, its background, its props, its text or its logo as something that should appear inside the newly generated asset. Only an explicit `identity / wardrobe / structure` role permits transfer of that named feature class, and literal embedding of the source image remains forbidden.

## Match decision

Accept a match only when it is unique and has no conflicting evidence.

- `matched`: explicit metadata or a unique script candidate agrees with visible facts.
- `variant_match`: identity is known and visible state agrees with one declared variant.
- `unresolved`: multiple candidates remain, visual facts contradict metadata, or the file lacks sufficient evidence.

Do not emit artificial probability scores. Record the evidence and contradiction instead.

## Duplicate and variant handling

- Compare checksums first; identical bytes are one source file.
- Keep the clearest user-provided image when multiple files depict the same base variant.
- Do not merge materially different clothing, age, injury, disguise, or story phase.
- Do not create a variant solely because framing, pose, crop, lighting, or expression differs.
- Do not use a group image as a single-character identity asset unless the target person is explicitly and unambiguously isolated.
- Classify single-person files as character assets, not crowd assets.
- Use crowd assets only for multi-person compositions and record the visible headcount class.
- When an extracted crowd row appears to correspond only to a single-person file, leave that proposal unresolved for identity review; a filename or role label cannot waive the crowd composition rule.

## Output entry

Every resolved image entry must include:

```json
{
  "filename": "local-or-uploaded-name.png",
  "url": "https://public-object-url",
  "kind": "character",
  "asset_id": "CHAR-001",
  "canonical_name": "Name",
  "display_name": "Name-晚礼服裙",
  "variant_id": "CHAR-001-V02",
  "variant_name": "Wardrobe or state",
  "is_base": false,
  "visual_facts": ["visible fact"],
  "applicable_episode_range": "EP11-20",
  "applicable_scenes": ["scene evidence"],
  "forbidden_tags": ["conflicting state"],
  "output_width": 1672,
  "output_height": 941,
  "provenance": "user_uploaded"
}
```

Use `variant_id: null` only for a canonical base asset or a type without variants. Public URLs must be raw text, never Markdown links.

Save `display_name` on the local matching entry keyed by `asset_id`: use the user's explicit name, otherwise the uniquely matched user image's original filename without its directory and final extension. Keep `canonical_name` and IDs unchanged. Generated images use semantic names, not ID filenames. A display name is a label, never identity evidence. See [local-project-schema.md](local-project-schema.md#资产展示名称) for snapshot fallbacks.

For generated assets, record actual `output_width/output_height` for audit and visual review. The canvas is selected per asset use; neither a reference image nor the project's video ratio is an automatic acceptance criterion.

Reject generated assets that reproduce a reference as a picture-in-picture, frame, screen, poster, thumbnail, collage panel, decal or readable source text/logo. For style-only references, also reject copied source subjects, clothing, props, backgrounds or narrative actions.
