// Local evidence and review-record checks. No network, semantic classifier or authorization inference.
export const FACT_PREFIX = 'SOURCE_FACT_V1 ';
const need = (ok, message) => { if (!ok) throw new Error(message); };
const object = value => value && typeof value === 'object' && !Array.isArray(value);
const text = value => typeof value === 'string' && value.trim().length > 0;
const fields = (value, keys) => object(value) && Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
const integer = value => Number.isInteger(value) && value > 0 && value <= 2147483647;
const arcFields = ['protagonistAction', 'visibleConsequence', 'emotionalTurn'];

/** Validate the opt-in string convention while leaving ordinary constraints untouched. */
export function parseSourceFacts(constraints = []) {
  const facts = [], ids = new Set();
  for (const item of constraints) {
    if (typeof item !== 'string' || !item.startsWith(FACT_PREFIX)) continue;
    need(item.length <= 500, 'Source fact exceeds the existing 500-character constraint limit; shorten evidence without changing its meaning');
    let fact;
    try { fact = JSON.parse(item.slice(FACT_PREFIX.length)); } catch { throw new Error('Invalid SOURCE_FACT_V1 JSON'); }
    need(fields(fact, ['id', 'sourceSha256', 'evidence', 'constraint', 'targetEpisodes']), 'Unexpected source fact fields');
    need(typeof fact.id === 'string' && /^[A-Za-z][A-Za-z0-9_-]{0,31}$/.test(fact.id) && !ids.has(fact.id), 'Invalid or duplicate source fact id');
    need(typeof fact.sourceSha256 === 'string' && /^[a-f0-9]{64}$/.test(fact.sourceSha256), 'Invalid source fact digest');
    need(!facts.length || facts[0].sourceSha256 === fact.sourceSha256, 'Source facts cannot mix source digests');
    need(text(fact.constraint), 'Source fact needs an explicit constraint');
    need(Array.isArray(fact.evidence) && fact.evidence.length >= 1 && fact.evidence.length <= 2, 'Source fact needs 1..2 excerpts');
    for (const e of fact.evidence) need(fields(e, ['startLine', 'endLine', 'quote']) && integer(e.startLine) && integer(e.endLine)
      && e.endLine >= e.startLine && text(e.quote), 'Invalid source evidence range or quote');
    need(Array.isArray(fact.targetEpisodes) && fact.targetEpisodes.length <= 4 && new Set(fact.targetEpisodes).size === fact.targetEpisodes.length
      && fact.targetEpisodes.every(n => integer(n) && n <= 200), 'targetEpisodes requires 0..4 distinct confirmed target mappings');
    ids.add(fact.id); facts.push(fact);
  }
  need(facts.length <= 12, 'At most 12 pivotal source facts; this ledger is not a replacement for the full source');
  return facts;
}

/** Verify exact source bytes/line excerpts, NOT whether an interpretation logically follows them. */
export function verifySourceFacts(facts, inspected, episodeCount) {
  need(inspected?.body !== undefined && inspected.report.status === 'READY', 'A verified frozen text source is required');
  const lines = inspected.body.match(/[^\r\n]*(?:\r\n|\r|\n)|[^\r\n]+$/g) || [];
  for (const fact of facts) {
    need(fact.sourceSha256 === inspected.report.sha256, `Source fact ${fact.id} does not match the active uploaded text`);
    need(fact.targetEpisodes.every(n => n <= episodeCount), `Source fact ${fact.id} target mapping exceeds the project episode count`);
    for (const e of fact.evidence) {
      need(e.endLine <= lines.length && lines.slice(e.startLine - 1, e.endLine).join('').includes(e.quote),
        `Source fact ${fact.id} quote is not verbatim within the supplied lines`);
    }
  }
}

/** Replace the complete ledger in a proposed config; other constraints remain unchanged. */
export function sourceFactsConfig(config, ledger, inspected) {
  need(config.mode === 'ADAPT' && Array.isArray(ledger) && ledger.length > 0, 'Provide a nonempty source fact array for ADAPT');
  const entries = ledger.map(fact => FACT_PREFIX + JSON.stringify(fact));
  const facts = parseSourceFacts(entries);
  verifySourceFacts(facts, inspected, config.episodeCount);
  const contentConstraints = [...(config.episode?.contentConstraints || []).filter(value => !value.startsWith(FACT_PREFIX)), ...entries];
  need(contentConstraints.length <= 100, 'Combined contentConstraints exceeds 100 entries');
  return { ...structuredClone(config), episode: { ...config.episode, contentConstraints } };
}

const at = (value, path) => {
  if (!/^\/(?:[^/~]|~[01])+(?:\/(?:[^/~]|~[01])+)*$/.test(path)) return undefined;
  for (const part of path.slice(1).split('/').map(v => v.replace(/~1/g, '/').replace(/~0/g, '~'))) {
    if (!value || !Object.hasOwn(value, part)) return undefined;
    value = value[part];
  }
  return value;
};

/** Validate a human/Agent reading record bound to real artifacts; does not perform semantic review. */
export function checkFactReview(context, report) {
  const { binding, facts, output, decisions } = context;
  need(fields(report, ['binding', 'checks']) && fields(report.binding, Object.keys(binding))
    && Object.keys(binding).every(key => report.binding[key] === binding[key]), 'Fact review binding changed; obtain the current checklist');
  need(Array.isArray(report.checks) && report.checks.length === facts.length * output.concepts.length, 'Review every fact in every candidate');
  const seen = new Set(), candidates = new Map(output.concepts.map(c => [c.id, []]));
  for (const row of report.checks) {
    need(fields(row, ['factId', 'conceptId', 'status', 'explanation', 'decisionRiskIds', 'evidence']), 'Unexpected fact review fields');
    const fact = facts.find(f => f.id === row.factId), index = output.concepts.findIndex(c => c.id === row.conceptId);
    const key = JSON.stringify([row.factId, row.conceptId]);
    need(fact && index >= 0 && !seen.has(key), 'Unknown or duplicate review pair'); seen.add(key);
    need(['MATCH', 'CONFLICT', 'UNKNOWN', 'APPROVED_CHANGE'].includes(row.status) && text(row.explanation) && row.explanation.length <= 2000, 'Give an explicit status and causal explanation, not a score or PASS assertion');
    need(Array.isArray(row.decisionRiskIds) && new Set(row.decisionRiskIds).size === row.decisionRiskIds.length
      && row.decisionRiskIds.every(id => decisions.some(d => d.riskId === id)), 'Review cites an unknown source decision');
    need(row.status === 'APPROVED_CHANGE' ? row.decisionRiskIds.length > 0 : row.decisionRiskIds.length === 0, 'Only APPROVED_CHANGE cites actual source decision IDs');
    need(Array.isArray(row.evidence) && row.evidence.length <= 20, 'Fact review evidence must be bounded');
    const paths = new Set();
    for (const e of row.evidence) {
      need(fields(e, ['path', 'quote']) && typeof e.path === 'string' && e.path.startsWith(`/concepts/${index}/`)
        && text(e.quote) && e.quote.length <= 500, 'Review needs short quotes from this actual candidate');
      const value = at(output, e.path);
      need(typeof value === 'string' && value.includes(e.quote), 'Fact review quote is not present at the actual output path');
      paths.add(e.path);
    }
    if (['MATCH', 'APPROVED_CHANGE'].includes(row.status)) {
      const base = `/concepts/${index}`;
      need(paths.has(`${base}/synopsis`), 'Check actual synopsis, not localizationNotes');
      const arc = output.concepts[index].episodeArc;
      const mapped = fact.targetEpisodes.length ? fact.targetEpisodes : arc.filter((_, n) => arcFields.every(f => paths.has(`${base}/episodeArc/${n}/${f}`))).map(e => e.episode ?? e.episodeNumber);
      need(mapped.length > 0, 'Unmapped facts need an explicit actual arc location or UNKNOWN');
      for (const episode of mapped) {
        const n = arc.findIndex(e => (e.episode ?? e.episodeNumber) === episode);
        need(n >= 0 && arcFields.every(f => paths.has(`${base}/episodeArc/${n}/${f}`)), 'Check action, consequence and emotional cause in every mapped target episode');
      }
    }
    candidates.get(row.conceptId).push(row.status);
  }
  return { binding, readyConceptIds: [...candidates].filter(([, statuses]) => statuses.every(s => ['MATCH', 'APPROVED_CHANGE'].includes(s))).map(([id]) => id),
    semanticVerification: 'CALLER_REVIEW_ONLY', instruction: 'This checks artifact bindings, coverage and literal quotes, not semantic truth or permission to select. Read the source, decisions and all cited fields; preserve hard conflicts, record minor issues. No operator was called.' };
}

/** Required local reading topics; supplemental facts never replace general source/decision checks. */
export function upstreamTopics(facts, decisions) {
  return ['custody', 'event-timing', ...facts.map(f => `fact:${f.id}`), ...decisions.map(d => `decision:${d.riskId}`)];
}

/** Check literal evidence and current bindings, not the truth of a caller's narrative interpretation. */
export function checkUpstreamReview({ binding, stage, authority, output, facts, decisions }, report) {
  need(fields(report, ['binding', 'checks']) && fields(report.binding, Object.keys(binding))
    && Object.keys(binding).every(k => report.binding[k] === binding[k]), 'Upstream review binding changed; obtain the current checklist');
  const topics = upstreamTopics(facts, decisions), seen = new Set();
  need(Array.isArray(report.checks) && report.checks.length === topics.length, 'Review custody, event timing and every source fact/decision');
  const blocked = [], minor = [];
  for (const row of report.checks) {
    need(fields(row, ['id', 'status', 'explanation', 'authority', 'evidence']) && topics.includes(row.id) && !seen.has(row.id), 'Unknown or duplicate upstream topic');
    seen.add(row.id);
    need(['MATCH', 'MINOR', 'CONFLICT', 'UNKNOWN'].includes(row.status) && text(row.explanation) && row.explanation.length <= 2000,
      'Give a bounded causal explanation and upstream status');
    for (const [name, data] of [['authority', authority], ['evidence', output]]) {
      need(Array.isArray(row[name]) && row[name].length <= 24 && (row.status === 'UNKNOWN' || row[name].length > 0), 'Upstream review needs bounded authority and actual-output evidence');
      for (const e of row[name]) {
        need(fields(e, ['path', 'quote']) && typeof e.path === 'string' && text(e.quote) && e.quote.length <= 500, 'Use short, literal upstream evidence');
        const value = at(data, e.path);
        need(typeof value === 'string' && value.includes(e.quote), 'Upstream quote is not present at the actual path');
      }
    }
    if (row.status !== 'UNKNOWN') {
      // A model's self-assessment is not the action being assessed. Other quotations may supplement it.
      const actualPath = stage === 'blueprint'
        ? /^\/episodes\/\d+\/(?:beats\/\d+\/description|openingHook|endingHook|objective|carryForward\/\d+)$/
        : /^\/(?:characters|locations|props|relationships|continuityRules)\//;
      need(row.evidence.some(e => actualPath.test(e.path)), 'Quote actual asset rules or episode actions, not only self-reported compliance');
      if (row.id.startsWith('fact:')) {
        const n = facts.findIndex(f => `fact:${f.id}` === row.id);
        need(row.authority.some(e => e.path.startsWith(`/facts/${n}/`)), 'Cite the corresponding source fact');
      }
      if (row.id.startsWith('decision:')) {
        const n = decisions.findIndex(d => `decision:${d.riskId}` === row.id);
        need(row.authority.some(e => e.path === `/sourceDecisions/${n}/decision`), 'Cite the corresponding approved decision');
      }
    }
    if (['CONFLICT', 'UNKNOWN'].includes(row.status)) blocked.push(row.id);
    if (row.status === 'MINOR') minor.push(row.id);
  }
  const serverConflicts = stage === 'blueprint' ? (output.readthroughReport?.sourceDecisionChecks || [])
    .filter(c => c.status === 'CONFLICT').map(c => c.riskId) : [];
  return { binding, readyForConfirmation: !blocked.length && !serverConflicts.length, blockedTopics: blocked,
    serverConflicts, minorTopics: minor, semanticVerification: 'CALLER_REVIEW_ONLY',
    instruction: 'Literal evidence and coverage checked only. Model APPLIED cannot override caller CONFLICT; MATCH is not semantic proof or user approval. Preserve upstream conflicts, continue minor items only within authorization. This read-only report does not change state or automatically guard answer; the Agent must honor its result.' };
}

/** Evidence gate for a specific human-confirmed false positive, never a semantic classifier. */
export function blueprintConflictProof(context, report, riskId, reason) {
  need(context.stage === 'blueprint', 'False-positive release only supports a current blueprint');
  const review = checkUpstreamReview(context, report);
  need(!review.blockedTopics.length, 'Resolve actual CONFLICT/UNKNOWN topics before a false-positive release');
  need(text(reason) && reason.trim().length >= 20 && reason.length <= 2000, 'Explain why this specific model finding is a false positive, with evidence');
  const checks = context.output.readthroughReport?.sourceDecisionChecks || [];
  const matches = checks.filter(c => c.riskId === riskId);
  need(matches.length === 1 && matches[0].status === 'CONFLICT', 'Choose exactly one existing server CONFLICT riskId');
  const check = matches[0], decision = context.decisions.find(d => d.riskId === riskId);
  need(decision && decision.decision.trim() === check.decision.trim(), 'Conflict must quote the current approved decision verbatim');
  const row = report.checks.find(r => r.id === `decision:${riskId}`);
  need(row?.status === 'MATCH', 'The selected decision must be MATCH, not minor, unknown or conflicting');
  need(Array.isArray(check.beatIds) && check.beatIds.length > 0 && new Set(check.beatIds).size === check.beatIds.length,
    'No unambiguous beat evidence; retain the conflict and investigate or reopen');
  const coveredBeats = [];
  for (const beatId of check.beatIds) {
    const found = [];
    context.output.episodes.forEach((ep, e) => ep.beats.forEach((beat, b) => {
      if (beat.id === beatId) found.push({ beatId, path: `/episodes/${e}/beats/${b}/description`, description: beat.description });
    }));
    need(found.length === 1 && text(found[0].description), 'Conflict references a missing, ambiguous or undescribed beat');
    need(row.evidence.some(e => e.path === found[0].path), 'Quote every beat cited by the selected conflict in its decision check');
    coveredBeats.push(found[0]);
  }
  return { riskId, reason: reason.trim(), serverCheck: structuredClone(check), coveredBeats, review,
    semanticVerification: 'CALLER_REVIEW_ONLY', instruction: 'Read the full approved decision, model explanation and actual beats. A valid report is not semantic proof. Explicit user approval of this exact false-positive release is still required; original CONFLICT remains intact.' };
}
