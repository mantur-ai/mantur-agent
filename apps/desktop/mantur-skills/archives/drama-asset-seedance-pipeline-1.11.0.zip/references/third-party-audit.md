# Third-party format-reference audit

The installable Skill contains no third-party runtime package and has no Python, `ffprobe`, or external CLI dependency for JianYing draft generation.

The implementation was checked against these public format references on 2026-08-15:

- `renezander030/capcut-cli` v0.19.0 source at commit `bf80df13b40f5e0e965e23deba23580d202df022` (MIT, Copyright 2026 Rene Zander): draft layout, microsecond timeline units, material/segment linkage, macOS draft path, registration index behavior, and its explicit JianYing version write guard.
- `notinmood/JianyingDraft.PY` / pyJianYingDraft public documentation (MIT): independent confirmation that timeline and material metadata are stored in the draft JSON family.

No source code, template file, enum catalogue, dependency, binary, or generated artifact from either project is vendored in this Skill. The bundled JS implementation is local and limited to the plain video-only profile described in `jianying-draft-delivery.md`. Therefore no third-party license payload executes on the user machine.

The key compatibility conclusion is intentionally conservative: JianYing 5.9.x is the only enabled plaintext profile; 6.0+ and unknown versions fail closed. Public reports or schema similarity do not count as local GUI-open verification.
