import { createHash, randomUUID } from "node:crypto";
import { generateJianyingDraft, JIANYING_PROFILES } from './jianying-format.mjs';
import { probeMp4File } from './jianying-media-probe.mjs';
import { installDraftPackage, nativeDraftPlatform, requireDraftDirectory, reserveDraftName } from './jianying-install.mjs';
import { deliveryRecord, saveDelivery, expectedClips } from './deliveries.mjs';
import { withProjectLock } from './project-lock.mjs';
import {captureDeliveryGate, publishWithDeliveryGate} from './delivery-gate.mjs';
import {
  constants,
  linkSync,
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { dirname, extname, relative, resolve } from "node:path";
import {
  assertProjectWritePath,
  parseOptions,
  plainObject,
  projectRoot,
  readJson,
  writeJson,
} from "./common.mjs";
import { inspectIsoBmff, sha256Media } from "./media.mjs";
import { createStoredZip } from "./zip.mjs";

const FORMAT_VERSION = 'jianying-portable-v2';

function sha256Text(value) {
  return createHash("sha256").update(value).digest("hex");
}

function safeName(value, fallback = "draft") {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u0000-\u001f<>:"/\\|?*]+/g, "-")
    .replace(/\s+/g, " ")
    .replace(/^[-. ]+|[-. ]+$/g, "")
    .slice(0, 80) || fallback;
}

function requireProfile(options) {
  let platform = options['target-platform'] || nativeDraftPlatform();
  if (options['target-profile']) {
    const requested = options['target-profile'] === 'jianying-macos-5.9' ? 'macos'
      : Object.entries(JIANYING_PROFILES).find(([, id]) => id === options['target-profile'])?.[0];
    if (!requested || (options['target-platform'] && requested !== platform)) throw new Error('Invalid or conflicting Jianying profile');
    platform = requested;
  }
  if (!Object.hasOwn(JIANYING_PROFILES, platform || '')) throw new Error('--target-platform windows|macos is required on this host');
  return { id: JIANYING_PROFILES[platform], platform, app_version_range: '5.9.0-format', format_version: FORMAT_VERSION };
}

function validateSha(value, label) {
  const normalized = String(value || "").toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(normalized)) throw new Error(`${label} 缺少有效 SHA-256`);
  return normalized;
}


function extensionFor(row) {
  const candidate = row.video_path || row.video_url || "video.mp4";
  const suffix = extname(String(candidate).split("?")[0]).toLowerCase();
  return [".mp4", ".mov", ".m4v"].includes(suffix) ? suffix : ".mp4";
}


function parseManifest(inputPath) {
  const payload = readJson(assertProjectWritePath(inputPath), { object: true });
  if (payload.schema_version !== 1 || !Array.isArray(payload.clips) || !Array.isArray(payload.episodes)) {
    throw new Error("剪映交付清单必须是 schema_version=1 且包含 clips[]/episodes[]");
  }
  const projectName = safeName(payload.project_name, "漫剧项目");
  const clips = [];
  const clipIds = new Set();
  const positions = new Set();
  for (const [index, raw] of payload.clips.entries()) {
    if (!plainObject(raw)) throw new Error(`clips[${index}] 必须是 object`);
    const clipId = String(raw.clip_id || "").trim();
    const episode = Number(raw.episode_number ?? raw.episode);
    const scene = Number(raw.scene_index);
    const clip = Number(raw.clip_index ?? raw.order);
    if (!clipId || clipIds.has(clipId)) throw new Error(`clips[${index}] Clip ID 缺失或重复`);
    if (![episode, scene, clip].every((item) => Number.isInteger(item) && item >= 1)) {
      throw new Error(`${clipId} 缺少合法 episode_number/scene_index/clip_index`);
    }
    if (String(raw.status || "").toLowerCase() !== "completed") throw new Error(`${clipId} 尚未完成，拒绝生成残缺草稿`);
    if (!raw.video_path) throw new Error(`${clipId} 缺少项目内本地视频`);
    const position = `${episode}:${scene}:${clip}`;
    if (positions.has(position)) throw new Error(`重复时间线位置: ${position}`);
    positions.add(position);
    clipIds.add(clipId);
    clips.push({
      clip_id: clipId,
      episode_number: episode,
      scene_index: scene,
      clip_index: clip,
      video_path: assertProjectWritePath(String(raw.video_path)),
      sha256: validateSha(raw.sha256, clipId),
      planned_duration_seconds: raw.planned_duration_seconds === undefined ? null : Number(raw.planned_duration_seconds),
      extension: extensionFor(raw),
    });
  }
  const expectations = new Map();
  for (const row of payload.episodes) {
    if (!plainObject(row) || !Number.isInteger(Number(row.episode_number)) || Number(row.episode_number) < 1) {
      throw new Error("episodes[] 包含非法 episode_number");
    }
    const episode = Number(row.episode_number);
    if (expectations.has(episode) || !Array.isArray(row.expected_clip_ids) || !row.expected_clip_ids.length) {
      throw new Error(`EP${episode} 缺少唯一 expected_clip_ids`);
    }
    const expected = row.expected_clip_ids.map((item) => String(item || "").trim());
    if (expected.some((item) => !item) || new Set(expected).size !== expected.length) {
      throw new Error(`EP${episode} expected_clip_ids 为空或重复`);
    }
    expectations.set(episode, new Set(expected));
  }
  const grouped = new Map();
  for (const row of clips) {
    if (!grouped.has(row.episode_number)) grouped.set(row.episode_number, []);
    grouped.get(row.episode_number).push(row);
  }
  if (new Set([...grouped.keys(), ...expectations.keys()]).size !== grouped.size || grouped.size !== expectations.size) {
    throw new Error("clips[] 与 episodes[] 的集数集合不一致");
  }
  for (const [episode, rows] of grouped) {
    const actual = new Set(rows.map((row) => row.clip_id));
    const expected = expectations.get(episode);
    const missing = [...expected].filter((id) => !actual.has(id));
    const extra = [...actual].filter((id) => !expected.has(id));
    if (missing.length || extra.length) {
      throw new Error(`EP${episode} 目标 Clip 不完整；missing=${missing.join(",") || "-"}; extra=${extra.join(",") || "-"}`);
    }
    rows.sort((a, b) => a.scene_index - b.scene_index || a.clip_index - b.clip_index || a.clip_id.localeCompare(b.clip_id));
  }
  return { projectName, grouped };
}


async function stageClip(row, assetsDir, index) {
  const name = `EP${String(row.episode_number).padStart(2, '0')}-CLIP${String(index + 1).padStart(2, '0')}${row.extension}`;
  const target = resolve(assetsDir, name);
  const source = assertProjectWritePath(row.video_path);
  if (!existsSync(source) || !lstatSync(source).isFile() || !statSync(source).size) throw new Error('Source video missing');
  copyFileSync(source, target, constants.COPYFILE_EXCL);
  if (sha256Media(target) !== row.sha256) throw new Error('Source video SHA-256 mismatch');
  const media = inspectIsoBmff(target);
  const probed = await probeMp4File(target);
  return { ...row, asset_name: name, staged_path: target, ...media, probed };
}

function validateDraft(draft, rows) {
  const track = draft.tracks.length === 1 && draft.tracks[0];
  if (!track || track.type !== "video" || track.segments.length !== rows.length) throw new Error("草稿主视频轨结构不合法");
  if (draft.materials.transitions.length || draft.materials.texts.length || draft.materials.audios.length) {
    throw new Error("草稿包含第一版禁止的转场、字幕或独立音频轨");
  }
  let cursor = 0;
  const timeline = [];
  for (let index = 0; index < rows.length; index++) {
    const segment = track.segments[index];
    const row = rows[index];
    if (segment.target_timerange.start !== cursor || segment.target_timerange.duration !== row.duration_us) {
      throw new Error(`${row.clip_id} 时间线存在间隙、重叠或时长漂移`);
    }
    timeline.push({
      clip_id: row.clip_id,
      scene_index: row.scene_index,
      clip_index: row.clip_index,
      start_us: cursor,
      duration_us: row.duration_us,
      end_us: cursor + row.duration_us,
      source_duration_us: row.duration_us,
      has_audio: row.has_audio,
    });
    cursor += row.duration_us;
  }
  if (cursor !== draft.duration) throw new Error("草稿总时长与主轨不一致");
  return timeline;
}

function writeText(path, body) {
  const target = assertProjectWritePath(path);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, body, { encoding: "utf8", flag: "wx" });
  return target;
}

function idempotencyKey(projectName, episode, rows, profile) {
  return sha256Text(JSON.stringify({
    schema: 2,
    project_id: readJson(resolve(projectRoot(), '.pipeline-state/manifest.json'), {object:true}).project_id,
    format_version: FORMAT_VERSION,
    naming_version: 3,
    project_name: projectName,
    episode_number: episode,
    target_profile: profile.id,
    clips: rows.map((row) => ({
      clip_id: row.clip_id,
      scene_index: row.scene_index,
      clip_index: row.clip_index,
      sha256: row.sha256,
    })),
  }));
}

function statePathFor(key) {
  return assertProjectWritePath(resolve(projectRoot(), ".pipeline-state", "jianying-drafts", `${key}.json`));
}

function reusableDelivery(key, expectedZip) {
  const statePath = statePathFor(key);
  if (!existsSync(statePath)) return null;
  const state = readJson(statePath, { object: true });
  if (state.idempotency_key !== key || resolve(state.zip_path || "") !== expectedZip) {
    throw new Error(`剪映交付幂等状态异常: ${key.slice(0, 12)}`);
  }
  if (!existsSync(expectedZip) || !lstatSync(expectedZip).isFile()) return null;
  if (sha256Media(expectedZip) !== state.zip_sha256) throw new Error("既有剪映 ZIP 哈希与幂等状态不一致，拒绝覆盖");
  return { ...state, reused: true };
}

async function buildEpisode(projectName, episode, rows, outputDir, profile, publish, options, fingerprint) {
  const contentKey = idempotencyKey(projectName, episode, rows, profile);
  const publicationPath=assertProjectWritePath(resolve(projectRoot(),'.pipeline-state/runtime/jianying-publications',sha256Text(JSON.stringify({outputDir,episode,profile:profile.id}))+'.json'));
  let publication=existsSync(publicationPath)?readJson(publicationPath,{object:true}):null;
  if(publication&&(publication.schema_version!==1||!['pending','completed'].includes(publication.status)||typeof publication.folder_name!=='string'||!/^[a-f0-9]{64}$/.test(publication.key)))throw new Error('JIANYING_PUBLICATION_INVALID');
  if(publication?.status==='pending') {
    if(publication.content_key!==contentKey||publication.fingerprint!==fingerprint)throw new Error('JIANYING_PENDING_SOURCE_CHANGED');
    if(publication.folder_name.includes('/')||publication.folder_name.includes('\\')||publication.folder_name.length>80)throw new Error('JIANYING_PUBLICATION_INVALID');
  } else {
    const suffix=`-EP${String(episode).padStart(2,'0')}-剪映草稿`;
    const baseName=projectName.slice(0,60-suffix.length).trimEnd()+suffix;
    const folder=await reserveDraftName(baseName,outputDir,{draftsDir:options['drafts-dir'],install:!options['package-only']&&profile.platform===nativeDraftPlatform()});
    publication={schema_version:1,status:'pending',content_key:contentKey,fingerprint,folder_name:folder,key:sha256Text(contentKey+randomUUID())};
    writeJson(publicationPath,publication);
  }
  const key=publication.key,folderName=publication.folder_name,draftName=folderName;
  const zipPath=assertProjectWritePath(resolve(outputDir,folderName+'.zip'));
  const reusable = reusableDelivery(key, zipPath);
  if (reusable) {
    await publish(reusable);
    return reusable;
  }
  if (existsSync(zipPath)) throw new Error(`目标 ZIP 已存在但不属于可信幂等记录: ${zipPath}`);
  const staging = assertProjectWritePath(resolve(outputDir, `.manturhub-jianying-${process.pid}-${key.slice(0, 12)}`));
  if (existsSync(staging)) throw new Error(`剪映暂存目录已存在: ${staging}`);
  const packageRoot = resolve(staging, folderName);
  const assetsDir = resolve(packageRoot, "material", "import");
  mkdirSync(assetsDir, { recursive: true });
  try {
    const staged = [];
    for (let index = 0; index < rows.length; index++) staged.push(await stageClip(rows[index], assetsDir, index));
    const generated = generateJianyingDraft({
      draftName, folderName, targetPlatform: profile.platform, identitySeed: key,
      videos: staged.map(row => ({clipName:row.clip_id, filename:row.asset_name, metadata:row.probed})),
    });
    const generatedPaths = generated.entries.map(entry => writeText(resolve(packageRoot, entry.path), entry.content));
    const draft = JSON.parse(generated.entries.find(entry => entry.path === 'draft_content.json').content.toString('utf8'));
    const timeline = validateDraft(draft, staged);
    const actualTotalUs = staged.reduce((sum, row) => sum + row.duration_us, 0);
    const report = {
      schema_version: 1,
      ok: true,
      target_profile: profile.id,
      episode_number: episode,
      clip_count: staged.length,
      checks: {
        all_target_clips_completed: true,
        source_media_parseable: true,
        source_hashes_match: true,
        deterministic_order: "episode_number,scene_index,clip_index",
        single_video_track: true,
        contiguous_timeline: true,
        no_transitions: true,
        no_subtitles: true,
        no_bgm: true,
        source_audio_preserved: true,
      },
      actual_total_duration_us: actualTotalUs,
      timeline_total_duration_us: draft.duration,
      timeline,
    };
    const reportPath = writeText(resolve(packageRoot, "validation-report.json"), `${JSON.stringify(report, null, 2)}\n`);
    const packageFiles = [...generatedPaths, reportPath, ...staged.map((row) => row.staged_path)].map((path) => ({
      path: relative(packageRoot, path).replaceAll("\\", "/"),
      size_bytes: statSync(path).size,
      sha256: sha256Media(path),
    }));
    const manifest = {
      schema_version: 1,
      delivery_type: "jianying-portable-draft",
      idempotency_key: key,
      target_profile: profile.id,
      target_jianying_version: profile.app_version_range,
      target_platform: profile.platform,
      generator_format: FORMAT_VERSION,
      naming_version: 3,
      draft_folder_name: folderName,
      draft_id: draft.id,
      draft_name: draft.name,
      episode_number: episode,
      clip_count: staged.length,
      actual_total_duration_us: actualTotalUs,
      timeline_total_duration_us: draft.duration,
      clips: staged.map((row) => ({
        clip_id: row.clip_id,
        episode_number: row.episode_number,
        scene_index: row.scene_index,
        clip_index: row.clip_index,
        asset_path: `material/import/${row.asset_name}`,
        sha256: row.sha256,
        size_bytes: row.size_bytes,
        actual_duration_us: row.duration_us,
        actual_duration_seconds: row.duration_seconds,
        planned_duration_seconds: Number.isFinite(row.planned_duration_seconds) ? row.planned_duration_seconds : null,
        width: row.width,
        height: row.height,
        has_audio: row.has_audio,
      })),
      files: packageFiles,
    };
    const manifestPath = writeText(resolve(packageRoot, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
    const zipFiles = [manifestPath, ...packageFiles.map((row) => resolve(packageRoot, row.path))].map((path) => ({
      path,
      name: `${folderName}/${relative(packageRoot, path).replaceAll("\\", "/")}`,
    }));
    const stagedZip=resolve(staging,'package.zip');
    createStoredZip(stagedZip, zipFiles);
    const zipSha = sha256Media(stagedZip);
    const state = {
      schema_version: 1,
      idempotency_key: key,
      episode_number: episode,
      zip_path: zipPath,
      publication_record: publicationPath,
      zip_sha256: zipSha,
      clip_count: staged.length,
      actual_total_duration_seconds: Number((actualTotalUs / 1000000).toFixed(6)),
      target_profile: profile.id,
      target_jianying_version: profile.app_version_range,
      status: "ready",
      validation_summary: `${staged.length} Clips；真实媒体可解析；主轨连续；无转场/字幕/BGM`,
      project_file_record: {
        episode_number: episode,
        draft_zip_url: null,
        draft_zip_local_file: zipPath,
        clip_count: staged.length,
        actual_total_duration_seconds: Number((actualTotalUs / 1000000).toFixed(6)),
        target_jianying_version: profile.app_version_range,
        status: "草稿包校验通过",
        validation_summary: `${staged.length} Clips；主轨连续；素材哈希通过`,
      },
    };
    await publish(state,()=>linkSync(stagedZip,assertProjectWritePath(zipPath)));

    return { ...state, reused: false };
  } catch (error) {
    // Never remove a published package on index/refresh failure.
    throw error;
  } finally {
    rmSync(staging, { recursive: true, force: true });
  }
}

function completePublication(state) {
  if(!state.publication_record)return;
  const path=assertProjectWritePath(state.publication_record),record=readJson(path,{object:true});
  if(record.key===state.idempotency_key)writeJson(path,{...record,status:'completed'});
}

async function publishInstallation(state, installation) {
  const record = deliveryRecord('jianying_draft', state.episode_number, state.included_clip_ids, state.zip_path, 'ready',state.storyboard_revision??'');
  await saveDelivery({...record, installation,...(state.video_selection?{video_selection:state.video_selection}:{})});
  const updated = {...state, installation, project_file_record:{...state.project_file_record,
    status:'草稿包校验通过', installation_status:installation.status, application_acceptance:installation.app_acceptance}};
  writeJson(statePathFor(state.idempotency_key), updated);
  return updated;
}

async function tryInstall(state, options, profile) {
  if (options['package-only'] || profile.platform !== nativeDraftPlatform()) {
    return {status:'not_requested', target_platform:profile.platform, app_acceptance:'pending',
      reason:options['package-only']?'package_only':'cross_platform'};
  }
  try { return await installDraftPackage(state.zip_path, {draftsDir:options['drafts-dir'], expectedSha256:state.zip_sha256}); }
  catch(error) { return {status:'failed', target_platform:profile.platform, app_acceptance:'pending',
    error_code: /^JIANYING_[A-Z_]+$/.test(error.code||'') ? error.code : 'JIANYING_INSTALL_FAILED',
    message:error instanceof Error ? error.message : String(error), retry_action:'import-jianying-draft', package_preserved:true}; }
}

export async function exportJianyingDrafts(tokens) {
  const {options, positionals} = parseOptions(tokens, {
    positionals:1, values:['output-dir','target-profile','target-platform','drafts-dir','selection-plan'], booleans:['package-only'],
  });
  const profile = requireProfile(options);
  if (!options['package-only'] && profile.platform === nativeDraftPlatform()) {
    requireDraftDirectory({ draftsDir: options['drafts-dir'], platform: profile.platform });
  }
  const outputDir = assertProjectWritePath(options['output-dir'] || 'deliverables/jianying');
  mkdirSync(outputDir, {recursive:true});
  const {projectName, grouped} = parseManifest(positionals[0]);
  // Establish current project identity and completion facts before staging any exports.
  const deliveries = [];
  for (const [episode, rows] of [...grouped.entries()].sort((a,b)=>a[0]-b[0])) {
    const expected = expectedClips(episode);
    if (JSON.stringify(rows.map(r=>r.clip_id)) !== JSON.stringify(expected)) throw new Error('Jianying target Clip set differs from the selected report');
    await withProjectLock(assertProjectWritePath(resolve(projectRoot(), `.pipeline-state/runtime/jianying-EP${episode}.lock`)), async()=>{
      const gate=await captureDeliveryGate(projectRoot(),episode,rows,options['selection-plan']);
      const publish=(state,move=()=>{})=>publishWithDeliveryGate(projectRoot(),gate,async()=>{
        state.storyboard_revision=gate.storyboard_revision??'';
        if(gate.selection_receipt)state.video_selection=gate.selection_receipt;
        writeJson(statePathFor(state.idempotency_key),{...state,included_clip_ids:expected});
        move();
        await saveDelivery({...deliveryRecord('jianying_draft',episode,expected,state.zip_path),...(gate.selection_receipt?{video_selection:gate.selection_receipt}:{})},{refresh:false});
      });
      const state={...await buildEpisode(projectName,episode,rows,outputDir,profile,publish,options,gate.fingerprint),included_clip_ids:expected,...(gate.selection_receipt?{video_selection:gate.selection_receipt}:{})};
      await publishInstallation(state,{status:'pending',target_platform:profile.platform,app_acceptance:'pending'});
      const installation = await tryInstall(state,options,profile);
      deliveries.push(await publishInstallation(state,installation));
      if(['installed','not_requested'].includes(installation.status))completePublication(state);
    });
  }
  return {ok:true, delivery:'jianying-drafts', target_profile:profile.id, deliveries};
}

export async function importJianyingDraft(tokens) {
  const {options,positionals} = parseOptions(tokens,{positionals:1,values:['drafts-dir','app'],booleans:['confirm-write']});
  // Explicit invocation authorizes installation; --confirm-write remains accepted for older callers.
  const archive = assertProjectWritePath(positionals[0]);
  let installation, installError;
  try { installation = await installDraftPackage(archive,{draftsDir:options['drafts-dir']}); }
  catch(error) {
    installError = error;
    installation = {status:'failed', app_acceptance:'pending',
      error_code:/^JIANYING_[A-Z_]+$/.test(error.code||'') ? error.code : 'JIANYING_INSTALL_FAILED',
      message:error instanceof Error ? error.message : String(error), retry_action:'import-jianying-draft', package_preserved:true};
  }
  // Locate the trusted project-local export receipt to publish installation independently of package creation.
  const statesDir = assertProjectWritePath(resolve(projectRoot(),'.pipeline-state/jianying-drafts'));
  if (existsSync(statesDir)) {
    for (const name of readdirSync(statesDir).filter(name=>name.endsWith('.json'))) {
      const state = readJson(assertProjectWritePath(resolve(statesDir,name)),{object:true});
      if (state.zip_path === archive && state.included_clip_ids) { await publishInstallation(state,installation); if(installation.status==='installed')completePublication(state); }
    }
  }
  if (installError) return {ok:false, installation, error_code:installation.error_code, message:installation.message};
  return {ok:true, installation, imported_path:installation.installed_path, draft_id:installation.draft_id, reused:installation.reused};
}
