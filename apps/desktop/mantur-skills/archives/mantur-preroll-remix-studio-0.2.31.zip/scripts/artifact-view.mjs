import path from 'node:path';
import {openAsset} from './project.mjs';

const number=value=>Number.isFinite(value)?value:null;
const mediaExtensions=new Set(['.mp4','.webm','.mov','.png','.jpg','.jpeg','.wav','.mp3']);
const availabilityMessages={
  available:'本地文件可读取；播放与画面质量仍需审阅。',
  unchecked:'尚未检查本地文件。',
  missing:'本地文件已移动或缺失，请在聊天中恢复原产物，不必重新制作。',
  unavailable:'本地文件暂不可用，请在聊天中核对或恢复原产物。',
  not_downloaded:'媒体尚未下载或尚未准备好，请在聊天中恢复原任务。',
  missing_record:'原任务记录仍保留，产物记录待恢复；不会自动重新制作。',
};
export const availabilityView=status=>({status,message:availabilityMessages[status]});

/** Read-only existence check; no hashing, downloading or production submission. */
export async function inspectAssetAvailability(root,assets){
  const entries=[];
  // Keep only one descriptor open while checking a potentially large library.
  for(const asset of assets||[]){
    let status='unavailable';
    if(typeof asset.relativePath!=='string'||!asset.relativePath)status='not_downloaded';
    else if(!path.isAbsolute(asset.relativePath)){
      try{
        const opened=await openAsset(root,asset);
        try{if(mediaExtensions.has(path.extname(opened.file).toLowerCase())&&opened.info.size>0&&(!Number.isFinite(asset.size)||asset.size===opened.info.size))status='available';}
        finally{await opened.handle.close();}
      }catch(error){if(['ENOENT','ENOTDIR'].includes(error.code))status='missing';}
    }
    entries.push([asset.id,availabilityView(status)]);
  }
  return new Map(entries);
}

/** Whitelist-only presentation joined by operation identity, never by output names. */
export function buildArtifactView(p,{assets,operations,projectPlan,label,id}){
  const assetById=new Map(assets.map(asset=>[asset.id,asset]));
  const operationById=new Map(operations.filter(op=>op.id).map(op=>[op.id,op]));
  const rawOperationById=new Map((p.operations||[]).map(op=>[op.id,op]));
  const references=[];
  const addPlans=(rows,context)=>{
    let outputOrder=0;
    for(const raw of rows||[]){
      const plan=projectPlan(raw,context.intent);
      for(const output of plan.outputs)references.push({...context,raw,plan,output,outputOrder:outputOrder++});
    }
  };
  (p.planHistory||[]).forEach((batch,index)=>addPlans(batch.plans,{current:false,groupId:`history-${index}`,groupLabel:`历史方案 ${index+1}`,groupOrder:index,intent:batch.intent}));
  addPlans(p.plans,{current:true,groupId:'current',groupLabel:'当前计划',groupOrder:(p.planHistory||[]).length,intent:p.intent});
  const directReferences=new Map();
  for(const ref of references){
    const previous=directReferences.get(ref.output.operationId);
    if(ref.output.operationId&&(!previous||ref.groupOrder>previous.groupOrder))directReferences.set(ref.output.operationId,ref);
  }
  const recordAvailability=(op,asset)=>asset?.availability||availabilityView(op.assetId||op.status==='succeeded'?'missing_record':'not_downloaded');
  const resultRecords=[];
  for(const [operationId,op] of operationById){
    if(op.stage!=='compose')continue;
    const rawOp=rawOperationById.get(operationId);
    const direct=directReferences.get(operationId);
    // A retry may replace operationId on the plan; match immutable fingerprints only.
    const fallback=!direct&&rawOp?.planFingerprint?references.findLast(ref=>ref.raw.fingerprint===rawOp.planFingerprint&&ref.output.id===rawOp.planId):null;
    const ref=direct||fallback,asset=assetById.get(op.assetId),current=direct?.current===true;
    resultRecords.push({id:operationId,operationId,assetId:asset?.id||op.assetId||null,current,
      groupId:ref?(ref.current&&!current?'prior-current':ref.groupId):'unlinked',
      groupLabel:ref?(ref.current&&!current?'当前方案的历史制作':ref.groupLabel):'方案详情未记录',
      groupOrder:ref?.groupOrder??-1,outputOrder:ref?.outputOrder??null,plan:ref?.plan||null,output:ref?{...ref.output,operationId}:null,
      detailAvailable:!!ref,submission:op.submission,status:op.status,availability:recordAvailability(op,asset)});
  }
  const currentAssets=new Set();
  for(const ref of references.filter(ref=>ref.current)){
    if(ref.output.front?.assetId)currentAssets.add(ref.output.front.assetId);
    for(const segment of ref.output.segments||[])if(segment.kind==='front'&&segment.assetId)currentAssets.add(segment.assetId);
  }
  const selectedIds=new Set((p.highlights||[]).map(h=>h.id));
  const currentFrontIds=new Set(p.frontOperationIds||[]),currentClipIds=new Set(p.highlightOperationIds||[]);
  const highlightView=op=>{
    const source=op.highlightSource;
    if(source&&typeof source==='object')return {id:id(source.id??op.highlightId),episode:number(source.episode),start:number(source.start),end:number(source.end),reason:label(source.reason),score:number(source.score),analysisOperationId:id(source.analysisOperationId)};
    const video=op.input?.timeline?.find(row=>row.track==='video'),trim=video?.extra?.find(row=>row.type==='trim');
    const matchingAssets=(p.assets||[]).filter(asset=>asset.role==='episode'&&video?.source?.fileId&&asset.upload?.receipt?.fileId===video.source.fileId);
    const sourceEpisode=matchingAssets.length===1?number(matchingAssets[0].episode):null;
    // The same highlight ID can occur in several analyses; do not infer provenance.
    return {id:id(op.highlightId),episode:sourceEpisode,start:number(trim?.start),end:number(trim?.end),reason:'',score:null,analysisOperationId:null};
  };
  const frontRecords=[],ownedAssets=new Set();
  for(const [operationId,op] of operationById){
    if(!['fronts','highlights'].includes(op.stage))continue;
    const rawOp=rawOperationById.get(operationId),asset=assetById.get(op.assetId),highlight=op.stage==='highlights'?highlightView(rawOp):null;
    if(asset)ownedAssets.add(asset.id);
    const currentRequest=(op.stage==='fronts'?currentFrontIds:currentClipIds).has(operationId);
    frontRecords.push({id:operationId,operationId,assetId:asset?.id||op.assetId||null,kind:op.stage==='highlights'?'highlight':'generated',
      currentRequest,adoptedByCurrentPlan:!!asset&&currentAssets.has(asset.id),
      selected:op.stage==='highlights'&&currentRequest&&selectedIds.has(rawOp.highlightId),
      highlight,submission:op.submission,status:op.status,availability:recordAvailability(op,asset)});
  }
  for(const asset of assets.filter(a=>a.role==='front'&&!ownedAssets.has(a.id)))frontRecords.push({
    id:`asset-${asset.id}`,operationId:null,assetId:asset.id,kind:'imported',currentRequest:false,
    adoptedByCurrentPlan:currentAssets.has(asset.id),selected:false,highlight:null,submission:null,status:'imported',availability:asset.availability,
  });
  const succeeded=resultRecords.filter(record=>record.status==='succeeded');
  return {resultRecords,allResultCount:succeeded.length,historicalResultCount:succeeded.filter(record=>!record.current).length,frontRecords};
}
