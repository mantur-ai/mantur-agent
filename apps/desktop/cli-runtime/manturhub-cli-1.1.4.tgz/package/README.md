# @manturhub/cli

ManturHub 算子广场的统一 Agent 调用通道。CLI 通过 REST 实时发现和调用全部上线算子，也可浏览配方、安装平台 Skill 和 Agent 套件；新算子上线后无需更新 CLI 即可发现。

## 安装与登录

```bash
npm install -g @manturhub/cli
manturhub login
```

`login` 使用 `/api/auth/client/sessions` 的 DEVICE 授权流程：浏览器复用网页登录态，核对用户码后点击授权，CLI 在后台领取 accessToken / refreshToken。无浏览器终端可运行 `manturhub login --no-browser`，在另一台设备打开显示的地址。Ctrl+C 取消等待；会话最长 10 分钟，不自动切换旧接口或 API Key 登录。

凭证保存在 `~/.manturhub/client-credentials.json`（原子替换，权限 `600`），按网关 origin 隔离，每个站点只激活一个账号。**CLI 使用私有明文文件，不宣称使用系统钥匙串**；不要分享此文件。登录前会退出该站点的现有账号。`manturhub logout` 先尝试撤销 CLI 专用 Key，再注销当前客户端，无论服务端是否在线都会清除本地账号凭证；手动 API Key 不受影响。

账号余额使用 `/api/billing/accounts/me`，API Key 余额继续使用 `/api/openapi/v1/credits/balance`。账号请求使用 `Authorization`；到期前 65 分钟刷新，并在 HTTP 401 后刷新重试一次。文件锁防止不同 CLI 进程同时轮换凭证，流式上传遇到 401 刷新后要求重新执行，不重复发送已经消费的流。服务端撤销或封禁会清除该站点账号。 业务接口刷新后仍返回 401 时，先调用账号校验接口；账号仍有效则保留凭证并提示接口鉴权不匹配，不会用其他凭证静默重试。异常退出若留下 `client-credentials.lock` 目录，先确认没有 CLI 登录或刷新进程，再删除这个空锁目录。

已登录账号首次访问 `/api/openapi/v1/` 时，CLI 通过账号接口创建名为 `Mantur CLI` 的专用 Key（`operator.read`、`operator.invoke`，有效期 90 天），明确提示后保存到同一份权限 `600` 的账号凭证文件。报价、算子调用、上传与作业查询统一发送此 Key，不把账号 token 当作 API Key。账号余额仍使用账号 token。刷新 token 保留同账号的专用 Key，切换账号不复用旧 Key；显式环境变量或传入的 API Key 保持优先。

创建专用 Key 受进程间锁保护，发送请求前记录创建意图。超时、响应不完整或进程中断后不会自动重复创建：请在当前站点的 Key 管理核对并撤销 `Mantur CLI` Key，再重新登录。专用 Key 被拒绝或过期时明确报错，不清除账号登录、不自动换 Key、不重放付费提交。退出时远端撤销失败会提示手动处理，本地凭证仍清除。凭证文件包含长期调用密钥，请勿复制或上传。

API Key 仍可显式使用 `MANTURHUB_KEY` 或 stdin 导入，走原有 `x-api-key` 通道：

```bash
printf '%s' "$YOUR_MANTURHUB_KEY" | manturhub login --key-stdin
```

`MANTURHUB_KEY` 优先于账号登录；设置该变量时先取消它才能发起浏览器授权。已有 `config.json` 中的 Key 保留；已登录站点优先使用账号凭证。

本次联调使用测试站，显式指定环境并保持凭证目录隔离：

```bash
export MANTURHUB_BASE=https://mantur-hub-dev.guiyi.cn
export MANTURHUB_CONFIG_DIR="$PWD/.mantur-cli-test"
node bin/cli.js login
node bin/cli.js balance --json
node bin/cli.js logout
```

`MANTURHUB_CONFIG_DIR` 仅指定新账号凭证与锁目录，不改变旧 API Key 配置位置。不要把测试凭证目录提交到 Git。服务端必须返回同站点 `/auth/device?user_code=...` 授权地址；跨站地址、localhost 错误配置会明确拒绝。

需要 Node.js ≥ 18。也可免安装运行：`npx -y @manturhub/cli <命令>`。

### 漫途 Agent 内置模式

`MANTURHUB_IDENTITY_MODE=desktop-managed` 时，CLI 只读取 Main 发放的短期本地授权描述文件，所有 OpenAPI 请求通过 loopback broker。账号 token 和专用调用 Key 不传给 CLI，也不读取全局 Key 或独立 CLI 登录文件。描述文件缺失、过期、跨站请求或非法路径均明确失败。登录、退出和切换账号在漫途 Agent 中操作；独立终端仍使用上述浏览器授权流程。生产默认地址为 `https://hub.mantur.ai`，测试环境仅由显式配置选择。

## 快速开始

```bash
# 发现与查看当前 Key 已授权的算子
manturhub ls --cat text
manturhub describe 电商文案生成

# 先按入参查实时预扣，再调用
manturhub quote 电商文案生成 --json '{"product_info":"便携榨汁杯，USB 充电，300ml","scene":"product_title","tone":"lively"}'
manturhub run 电商文案生成 --json '{"product_info":"便携榨汁杯，USB 充电，300ml","scene":"product_title","tone":"lively"}'
```

CLI 会在付费调用前按算子实时 schema 校验未知字段、必填项、类型、枚举和长度/数值范围，校验失败不会发起 invoke。校验通过后会显示本次预计消耗和计费依据，获得确认才调用；完成后在最终 JSON 的 `_billing` 返回实际消耗和退款，并同步显示到终端。批量参数按整批请求试算；多次调用应逐笔汇总 `charged_dumplings` 和 `refunded_dumplings`，不得自行估算。

面向用户的列表、详情、报价、确认和结算统一显示中文算子名，也可直接用中文名调用。英文算子 ID 仅保留在 `--json` 机器输出和内部 API 请求中，供 Agent 与脚本稳定使用。

在 Agent 或脚本等非交互环境中，第一次运行只返回报价和 `confirmation_token`，不会调用或扣费；Agent 向用户确认后，使用提示中的 `--confirm <confirmation_token>` 执行。确认标识绑定算子、入参、价格版本和幂等 ID：内容或价格变化时拒绝调用，同一次调用重试时复用幂等 ID，避免重复扣费。

## 主要命令

| 命令 | 说明 |
|---|---|
| `manturhub ls [--cat image\|video\|audio\|text\|data] [--json]` | 实时列出上线算子 |
| `manturhub describe <中文算子名> [--json]` | 查看精确入参与异步属性 |
| `manturhub quote <中文算子名> [--json '{...}' \| --json-file params.json]` | 按入参查询 Java API 返回的实时预扣；无入参时显示最高预扣 |
| `manturhub run <中文算子名> --json '{}' [--confirm <confirmation_token>] [--no-wait]` | 调用算子；非交互确认传确认标识，异步任务默认轮询到终态 |
| `manturhub run <中文算子名> --json-file params.json` | 从文件读取参数，适合长提示词和自动化 |
| `manturhub upload <本地文件>` | 通过预签名 PUT 流式上传图片、音频或视频，并输出 `downloadUrl` |
| `manturhub status <poll_url>` | 查询 `run --no-wait` 返回的异步任务 |
| `manturhub balance [--json]` | 查询余额及美元等值（1 馒头 = $0.01 USD） |
| `manturhub skill ls [--json]` / `skill add <slug> [--client codex]` | 浏览并从当前 ManturHub 站点安装业务 Skill |
| `manturhub skill outdated [--json]` / `skill update <slug> [--force]` | 比较本地与线上版本并更新；本地修改默认不覆盖 |
| `manturhub skill doctor <slug>` / `skill run <slug> --project <目录>` | 验证 Skill 安装与依赖；从指定项目目录启动或恢复工作流 |
| `manturhub skill exec <slug> <action> -- <参数>` | 给 Agent 使用的安全机器入口；只执行 Skill 包声明的白名单动作 |
| `manturhub recipe [关键词]` / `recipe get <ID>` | 搜索并查看已验证配方 |
| `manturhub suite ls [--json]` / `suite install <slug>` | 安装多角色 Agent 套件，不复制 API Key |
| `manturhub init [--force]` | 从线上安装核心 `manturhub` Skill，并给当前项目写入 Agent 使用引导 |

机器消费输出可在支持的查询命令上加 `--json`；`quote` 的 `--json` 不带值时仅输出机器 JSON，带 JSON 值时同时作为本次试算入参。进度和提示写入 stderr，JSON 结果写入 stdout。

## Skill 本地运行契约

需要确定性本地动作的 Skill 可在包根目录声明 `skill-runtime.json`：

```json
{
  "schema_version": 1,
  "runtime": "node",
  "minimum_cli_version": "0.9.10-dev.20260810.11",
  "entry": "runtime/runner.mjs",
  "doctor_action": "doctor",
  "run_action": "run",
  "actions": ["doctor", "run", "validate-input"]
}
```

CLI 只执行 `actions` 白名单内的动作，且入口必须是 Skill 包内的 `.mjs` 文件。执行前会验证当前站点、可信安装记录、整包 SHA-256、frontmatter 版本和最低 CLI 版本；本地内容被修改、入口越界或动作未声明时直接失败，不会寻找其他脚本或解释器。动作必须只向 stdout 写一个 JSON object，日志与进度写 stderr。

环境变量：`MANTURHUB_KEY`（优先于配置文件） · `MANTURHUB_BASE`（显式覆盖当前发布通道的默认网关）。

ManturHub 算子广场：https://hub.mantur.ai
