# 资产需求修订与视频并发约定

适用 Skill 版本 1.0.5。这里只开放已实现的受限路径，不表示真实付费验收完成。

## 视频额度

所有合法锁定站点统一使用项目内默认最多 **5 条活动场次链**。这是 `skill_default` 本地调度策略，不是实时接口返回的平台账号额度，也不按正式站／开发站分流。项目请求值仍为 1–20，有效值取项目值与 5 的较小值；账号级总量由平台最终限制。QPM 是独立维度，未知 QPM 不阻断，不把并发 5 解释成每分钟 5 次。

账号并发由 Skill 指导 Agent，平台负责最终限制，不再建立本机共享额度文件或扫描历史项目。旧 `~/.mantur-drama-runtime/video-quotas/` 文件留存但不读取、不迁移、不自动删除。多 Agent/设备不保证本地合计绝不超过 5。

Agent 将排队、运行中和未知提交计入已知在途任务；恢复原操作不依赖共享额度登记。终态后不再计入平台任务数，下载/审核不占该预算，但下一 Clip 仍须前序验收及真实尾帧。代码保留项目内链槽和操作锁，不得清空这些记录；429 退避、原地址/请求/幂等键不变。详见 [并发与恢复](video-concurrency-policy.md)。

## 两阶段本地修改

先执行 `prepare-asset-revision --input input/revision.json`，不联网：

```json
{"schema_version":1,"changes":[{"asset_id":"CHAR-001-V04","changes":{"变体名":"商务装","角色提示词":"用户确认的新角色图片提示词"}}]}
```

仅支持原行已存在的字符串字段：`变体名`、`造型/画面要点`、该类型的角色/场景/道具提示词、`负面提示词`、`生成策略`。负面提示词可清空，生成策略只接受 `reference_required` 或 `defer_to_video`，其他字段不能空白。禁止修改 ID、基础身份、角色名、声音、集数或媒体绑定；本路径不提供删除或忽略资产。纯展示名称纠错仍走 `display_name`，不必创建生产修订。

用户可以明确指定单个或多个资产改为“可延后”；Agent 必须把自然语言范围展开成明确 `asset_id` 列表，不能用名称相似度、类型全选或未展示的隐式规则替用户决定。示例：

```json
{"schema_version":1,"changes":[{"asset_id":"PROP-014-V01","changes":{"生成策略":"defer_to_video"}}]}
```

Runtime 只允许非 S 级基础资产进入 `defer_to_video`，且该资产不能拥有语义变体或成为已记录图片依赖的基础图；V02+、关键资产及依赖基础图继续保持 `reference_required`。这些是可机器验证的最低门禁；Agent 仍须结合剧本说明该资产是否一次性、是否承担跨镜连续性，并把资产名、ID、出现集数及前后策略一起展示给用户确认。恢复为必需图片使用同一动作写 `reference_required`。prepare 返回单独的 `policy_changes` 以及完整影响清单；状态修改本身不授权生成图片，也不删除已经存在的媒体、审核或历史任务。

返回差异（策略修改另列 `policy_changes`）、受影响资产/Clip/未提交操作和 `approval_binding`。Agent 展示影响并取得明确确认后，将返回绑定原样写入确认文件，加 `approved:true` 和真实 `approved_at`，执行：

```text
apply-asset-revision --revision-id <返回ID> --approval input/revision-approval.json
```

禁止替用户伪造批准。基线变化则重新 prepare 和确认。修改确认、生产清单全局人审、费用批准是三个不同步骤。

原始 PRIMARY_JSON/XLSX/Job 和哈希不变；Runtime 私有目录保存候选、批准和发布凭据，结果目录保存有效需求和派生报告，原子切换项目指针。连续修订相对原始行累计，每个资产最多一个 override；恢复原值移除相应 changes，但不会自动恢复旧审核。

行摘要按参考 Skill 的 Java UTF-16 键排序、数组保序及 Jackson 转义规则实现。当前仅支持字符串、布尔、null、数组和普通对象（递归）；行内含任何数字、异常 Unicode 等则返回 `ASSET_ROW_ENCODING_UNVERIFIED`，不能猜摘要或手改基线。源实现核对及合成向量不等于部署实测。

## 修改后的恢复

- 目标图片及明确记录的基础图依赖进入待复核；策略改为可延后后不再计入必需图片缺失。原图片、音色、无关资产和历史 Run 不删除。
- 通过 `apply-asset-review` 重新审核：除原有证据、媒体 SHA、原选择 SHA 等字段，还必须提供本次 `requirement_revision`。同图合规可以复用；不合规则显式选择替换/另行批准生成。
- 替换使用新内容路径，不覆盖历史媒体。若 Clip 仍引用旧 SHA，应按模板编辑合同同步引用；新 fileId 必须来自真实上传确认并绑定新 SHA。不要拼造 fileId，不要把旧 fileId 配新 SHA。
- Clip 模板默认不改，不重新调用分镜算子；修改正文/引用后由共享技术校验重新核对当前素材、需求与模板，无需用户分镜确认。历史 Run 的需求证据仍独立复核，不自动将过期视频改为完成。
- 已提交任务恢复原请求；需求变更使未提交的旧准备/批准失效。历史预览与视频覆盖数量保留，严格完成/尾帧复用/交付受新门禁约束。
- 旧视频仍适用时，`apply-video-review` 必须提供 `requirement_revalidation:true` 和当前 `videoSelection.reviewBinding`，以及实际视觉、音频、连续性证据及用户确认。单独记录当前复核绑定，保留原生产绑定、请求和采用历史；后续链逐级复核。不自动批量重新生成。
- 更新后的有效需求及累计 overrides 被清单准备/导入共用；不同分镜和下游历史的覆盖冲突保护仍保留。确需重编译须另确认范围与费用。

本地事实保存后快照失败只恢复 `refresh-ui-snapshot`，不能重复修改或重复提交。页面、HTTP v1、Manifest 和 Envelope 不变。
