import {startServer} from './server.mjs';
import {loadProject,withLock} from './project.mjs';
import {workbenchContext} from './onboarding.mjs';
import {backgroundRecovery} from './background-recovery.mjs';
import {publicProjectClient} from './integration.mjs';

const dir=process.argv[2];
let server,committed=false;
// An unregistered listener must not survive a lost parent or failed registration.
process.once('disconnect',()=>{if(!committed)process.exit(1);});
try{
  const message=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('启动握手超时')),10000);process.once('message',message=>{clearTimeout(timer);message?.type==='start'&&message.control?resolve(message):reject(Error('启动握手无效'));});});
  Object.assign(process.env,await workbenchContext(message.context||{},{received:true}));
  const project=await loadProject(dir),controller=new AbortController();
  const recover=backgroundRecovery(dir,{signal:controller.signal});
  const account=publicProjectClient({project,projectDir:dir,signal:controller.signal});
  const reviewOnly=project.schemaVersion!==2||!!project.legacyOrigin;
  const balanceOptions=reviewOnly?{balanceUnavailableReason:'LEGACY_PROJECT_READ_ONLY'}
    :account.capabilities.balanceQuery?{queryBalance:options=>account.queryBalance(options)}
    :account.capabilities.accountBoundBalance?{readBalance:(identity,options)=>account.balance(identity,options),identifyBalance:options=>account.balanceIdentity(options)}
      :{balanceUnavailableReason:'CONTRACT_UNSUPPORTED'};
  server=await startServer({projectDir:dir,port:Number.isInteger(message.port)&&message.port>=0&&message.port<=65535?message.port:0,loadProject:()=>loadProject(dir),control:message.control,deferBalanceStart:true,onCloseError:()=>{process.exitCode=1;},...balanceOptions,
    ...(project.schemaVersion===2&&!project.legacyOrigin?{synchronize:()=>committed?recover():{operations:[],skipped:[]},stopSynchronization:()=>controller.abort()}: {})});
  await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(Error('启动登记超时')),10000);
    process.once('message',data=>{clearTimeout(timer);data?.type==='commit'?resolve():reject(Error('启动登记无效'));});
    process.send?.({ok:true,type:'ready',url:server.url,workbench:server.workbench},error=>{if(error){clearTimeout(timer);reject(error);}});
  });
  committed=true;server.startBalance();
  process.send?.({ok:true,type:'committed'},error=>{if(error)process.exit(1);});
  for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>{void server.close().then(()=>process.exit(0),()=>process.exit(1));});
}catch(error){if(process.connected)process.send?.({ok:false,...(error.code==='EADDRINUSE'?{code:'WORKBENCH_PORT_IN_USE'}:{})},()=>process.exit(1));else process.exit(1);}
