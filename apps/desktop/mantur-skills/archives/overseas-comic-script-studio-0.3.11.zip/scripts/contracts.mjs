// Admission checks for newly prepared calls. Semantic quality remains advisory.
// Required public v1 fields are covered against captured operator schemas in tests.
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = value => typeof value === 'string' && value.trim().length > 0;
const need = (ok, message) => { if (!ok) throw new Error(`Output contract: ${message}`); };
export const requiredFields = {
  'source-analyze': { string: ['schemaVersion', 'summary', 'reportMarkdown'], object: ['sourceBible'], array: ['protectedElements', 'flexibleElements', 'bannedSourceNames', 'plotSkeleton', 'risks', 'appliedRecipes'] },
  concept: { string: ['schemaVersion', 'mode', 'recommendedConceptId'], array: ['concepts', 'decisionNotes', 'appliedRecipes'] },
  assets: { string: ['schemaVersion', 'mode', 'storyBibleMarkdown', 'assetsDigest'], array: ['characters', 'locations', 'props', 'relationships', 'namingLedger', 'continuityRules', 'appliedRecipes'] },
  blueprint: { string: ['schemaVersion', 'action', 'title', 'blueprintDigest'], object: ['globalArc', 'readthroughReport'], array: ['units', 'episodes', 'unresolvedSetups', 'continuityConstraints', 'appliedRecipes'] },
  episode: { string: ['schemaVersion', 'generationMode', 'title', 'markdown'], integer: ['episodeNumber'], object: ['statistics', 'continuityDelta', 'continuitySnapshot'], array: ['scenes', 'scriptLines', 'warnings', 'appliedRecipes'] },
  review: { string: ['schemaVersion', 'action', 'status'], object: ['summary'], array: ['appliedRecipes'] },
};
function fields(value, spec, path) {
  need(object(value), `${path} must be an object`);
  for (const [type, keys] of Object.entries(spec)) for (const key of keys) {
    const item = value[key];
    need(Object.hasOwn(value, key) && (type === 'string' ? text(item) : type === 'object' ? object(item)
      : type === 'array' ? Array.isArray(item) : Number.isSafeInteger(item)), `${path}.${key} must be ${type}`);
  }
}
export function checkCharacterIdentities(assets) {
  need(Array.isArray(assets?.characters) && assets.characters.length > 0, 'assets.characters must not be empty');
  const names = assets.characters.map(character => character?.canonicalName);
  need(names.every(text) && new Set(names.map(name => name.trim())).size === names.length,
    'assets.characters canonicalName must be non-empty and unique; preserve the confirmed identity keys');
}
export function checkNewOutput(kind, value, input) {
  fields(value, requiredFields[kind], kind);
  for (const recipe of value.appliedRecipes) {
    fields(recipe, { string: ['code', 'contentDigest'] }, 'appliedRecipes');
    need(/^[a-f0-9]{64}$/.test(recipe.contentDigest), 'appliedRecipes.contentDigest must be a SHA256');
  }
  if (kind === 'concept') {
    for (const item of value.concepts) {
      fields(item, { string: ['id', 'title', 'logline', 'synopsis', 'genre', 'targetAudience', 'coreHook'],
        array: ['episodeArc', 'localizationNotes', 'risks'], integer: ['score'] }, 'concepts');
      need(item.score >= 0 && item.score <= 100, 'concepts.score must be 0..100');
    }
    need(value.concepts.some(item => item.id === value.recommendedConceptId), 'recommendedConceptId must identify a returned concept');
  }
  if (kind === 'assets') checkCharacterIdentities(value);
  if (kind === 'blueprint') {
    need(value.units.length > 0 && value.units.every(object), 'blueprint.units must contain objects');
    for (const episode of value.episodes) {
      need(object(episode) && Array.isArray(episode.beats) && episode.beats.length >= 3 && episode.beats.length <= 7,
        'blueprint episode beats must contain 3..7 beats');
      const ids = episode.beats.map(beat => beat?.id);
      need(ids.every(text) && new Set(ids).size === ids.length, 'blueprint beat IDs must be non-empty and unique within the episode');
    }
  }
  if (kind === 'episode') {
    need(['WRITE', 'REWRITE', 'LOCALIZE'].includes(value.generationMode)
      && (!input.generationMode || value.generationMode === input.generationMode), 'episode generationMode mismatch');
    // Legacy scenes/lines may omit optional IDs. Check supplied links without inventing identifiers.
    need(value.scenes.every(object), 'episode scenes must contain objects');
    const ids = value.scenes.filter(scene => scene.id !== undefined).map(scene => scene.id);
    need(ids.every(text) && new Set(ids).size === ids.length, 'duplicate or empty scene IDs');
    for (const line of value.scriptLines) if (line?.sceneId !== undefined) need(ids.includes(line.sceneId), 'scriptLines.sceneId must identify a scene');
  }
  if (kind === 'review') fields(value, { array: input.action === 'FIX'
    ? ['revisedEpisodes', 'resolvedIssueIds', 'unresolvedIssues', 'changeSummary'] : ['issues'] }, 'review');
}
