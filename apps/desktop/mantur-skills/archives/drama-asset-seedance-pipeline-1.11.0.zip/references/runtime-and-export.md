# Agent video runtime and export contract

This release deliberately has no long-running scheduler service. The Agent owns orchestration and persists every transition under the project directory and in the Feishu request row.

Asset extraction and Clip compilation use the same persisted asynchronous pattern. Their environment-specific observation windows and the rule that 60 seconds without a terminal state is not failure are defined in [async-wait-policy.md](async-wait-policy.md).

## State machine

`template_ready -> waiting_previous_tail | ready_to_quote -> quoted -> approved -> submitted -> processing -> completed | failed`

- `waiting_previous_tail` may become `ready_to_quote` only after the exact previous Clip in the same scene chain is completed with a valid tail URL.
- A task ID is written before any second network action.
- An ambiguous submission response is `submission_unknown`, not permission to retry.
- A changed actual request invalidates the old quote.

## Parallelism

The complete machine and Agent contract is in [video-concurrency-policy.md](video-concurrency-policy.md). The default is five project-global scene chains. A chain is `(episode, scene_group)` and is strictly serial; independent chains do not share tail frames. User configuration, live QPM, balance and operator limits determine the effective value. Exceeding chains use stable FIFO order; multiple Agent processes must share the same project-global limit.

## Compiled Seedance template

The compiled body is provider-shaped and requires:

```json
{
  "model": "doubao-seedance-2-0-260128",
  "prompt": "...不要背景音乐，不要字幕。",
  "duration": 10,
  "metadata": {
    "content": [],
    "resolution": "480p",
    "ratio": "9:16",
    "generate_audio": true,
    "seed": -1,
    "return_last_frame": true
  }
}
```

Do not move `return_last_frame` outside `metadata` in this compiler-owned template.

Historical direct SumOne response normalization is an internal migration/audit tool and is not
installed or invoked by the default user workflow. New projects accept only the normalized
ManturHub operator result. A completed task with no official tail blocks only that scene chain.

## Legacy image-provider state

New projects persist only `native_agent_imagegen` or `manturhub:op.image.generate`. The historical
value `codex_imagegen` is recognized only as an alias for an Agent-native image capability. It is
never silently rerouted. When the current Agent still exposes native image generation, normalize
the label and append an audit entry with:

```bash
manturhub skill exec drama-asset-seedance-pipeline migrate-image-provider --project "$PROJECT_DIR" -- \
  --to native_agent_imagegen --confirm-native-imagegen
```

When the current Agent has no native image generation, switching an old project to the current-site
ManturHub operator changes the actual provider and therefore requires a separate explicit decision:

```bash
manturhub skill exec drama-asset-seedance-pipeline migrate-image-provider --project "$PROJECT_DIR" -- \
  --to manturhub:op.image.generate --confirm-provider-change
```

Both paths update only the fixed project state file and append `provider_migrations`; unknown values
fail closed.

## ManturHub video operator (default)

Inspect the live schema before every paid run. Convert the materialized compiler template with:

```bash
manturhub skill exec drama-asset-seedance-pipeline materialize-video-params --project "$PROJECT_DIR" -- actual-seedance-request.json --output manturhub-video-params.json
```

The converter maps the model, prompt, duration, resolution, ratio, image references and roles,
reference audio, seed, audio policy and `return_last_frame=true` without inventing media. Quote
and submit that exact file through `op.video.generate`. Save the ManturHub task ID and poll URL
before any further network action. A completed operator result must contain valid `video_url` and
`last_frame_url`; otherwise only that scene chain is blocked.

For `run --no-wait`, persist progress with the allowlisted `poll-checkpoint` action. It accepts
the same active/success/failure/cancellation states as the current CLI, rejects missing or unknown
states, and never submits or resubmits a paid task.

```bash
manturhub skill exec drama-asset-seedance-pipeline poll-checkpoint --project "$PROJECT_DIR" -- \
  <poll_url> --state-file .pipeline-state/<clip-id>.json --output-dir .pipeline-state/checkpoints
```

## Export manifest

The ZIP exporter accepts only completed local files:

```json
[
  {"clip_id":"CLIP-EP01-001","episode":1,"order":1,"video_path":"/project/videos/EP01/001.mp4","status":"completed"}
]
```

It produces one ZIP per episode and aborts on an incomplete or missing file.

## Optional JianYing draft delivery

When the user selects `--deliverable jianying-drafts` through `skill run`, follow
[jianying-draft-delivery.md](jianying-draft-delivery.md). This is a separate portable-ZIP
delivery, not a replacement for the ordinary per-episode clip ZIP. It uses actual media durations,
one hard-cut video track, package-local media and a version-gated import step. JianYing 6.0+ and
unknown profiles are rejected; default export never writes the user's editor directory.
