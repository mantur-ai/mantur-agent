import { Worker } from 'node:worker_threads';

const messages = {
  MEDIA_METADATA_INVALID: '媒体容器结构不完整或元数据无效，请重新导出文件。',
  MEDIA_METADATA_UNSUPPORTED: '暂不支持此文件的媒体结构或时间轴，请重新导出普通 MP4、MOV、WebM 或 PNG。',
  MEDIA_METADATA_LIMIT: '媒体元数据超过安全读取上限，请重新导出或拆分文件。',
  MEDIA_METADATA_TIMEOUT: '媒体信息读取超时，请检查文件后重试。',
  VIDEO_MISSING: '文件中没有可读取尺寸和时长的视频轨道。',
};
// Parsing is isolated from the workbench. No external executables, downloads,
// decoder, credentials or project state are involved.
export async function inspectMedia(file, options = {}) {
  const timeoutMs = Math.min(10000, Number.isFinite(options.timeoutMs) && options.timeoutMs > 0 ? options.timeoutMs : 10000);
  return new Promise((resolve, reject) => {
    let worker;
    try {
      worker = new Worker(new URL('./media-probe-worker.mjs', import.meta.url), {
        workerData: { file }, execArgv: [],
        resourceLimits: { maxOldGenerationSizeMb: 384, maxYoungGenerationSizeMb: 32, stackSizeMb: 4 },
      });
    } catch { reject(Object.assign(new Error(messages.MEDIA_METADATA_INVALID), { code:'MEDIA_METADATA_INVALID' })); return; }
    let settled = false;
    const finish = (code, result) => {
      if (settled) return;
      settled = true; clearTimeout(timer); void worker.terminate();
      if (code) reject(Object.assign(new Error(messages[code] || messages.MEDIA_METADATA_INVALID), { code: messages[code] ? code : 'MEDIA_METADATA_INVALID' }));
      else resolve(result);
    };
    const timer = setTimeout(() => finish('MEDIA_METADATA_TIMEOUT'), timeoutMs);
    worker.once('message', value => value?.ok ? finish(null, value.result) : finish(value?.code || 'MEDIA_METADATA_INVALID'));
    worker.once('error', error => finish(error.code === 'ERR_WORKER_OUT_OF_MEMORY' ? 'MEDIA_METADATA_LIMIT' : 'MEDIA_METADATA_INVALID'));
    worker.once('exit', () => { if (!settled) finish('MEDIA_METADATA_INVALID'); });
  });
}
