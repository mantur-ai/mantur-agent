# 剧本算子业务调用合同

按本次阶段阅读：[源稿分析](#源稿分析)、[创意方案](#创意方案)、[资产](#资产)、[蓝图](#蓝图)、[分集](#分集)、[审校改稿](#审校改稿)、[配方](#配方)。执行、费用和恢复只遵循 [工具合同](cli.md)，本页不重复认证或网络接口。

## 参数与结果的共同规则

先 describe 本次算子，核对当前身份可用的输入定义及服务提供的输出定义；本页不是上架证明，也不复制完整 Schema。字段或版本不兼容时停止核对，不猜字段、不以旧示例绕过校验。模型和供应路由由服务端维护，不传模型覆盖参数。

本业务有意只编排这六个创编算子。独立的 `op.script.evaluate` 不是本流程 SCAN/FIX 的替代品，不因账号额外授权就自动调用。允许调用范围由产品发布时显式维护；平台新增算子后先评估业务入口、合同、费用与回归，再升版纳入，不动态扩大白名单。服务端若在同一任务内执行有限模型重试，Skill 仍只查询原任务，不在外层叠加自动 run；用户发起的新调用仍须单独确认费用。

以下 `js` 块是**参数对象的组装表达式**，不是命令或可原样提交的 JSON：变量必须来自当前项目的已确认配置、真实成功输出和用户决策。`project.mjs prepare` 已自动生成相同结构的 inputFile，按 [项目运行](runtime.md) 调用即可，不执行这些表达式来修改已准备的输入。`json` 输出块均为**虚构内容的字段节选**，省略了其他必需字段，不能导入项目或作为下游输入。

| 变量 | 权威来源 |
| --- | --- |
| `config` | 已确认且锁定的项目配置；集数、市场、语言、载体、字数与可选阶段约束 |
| `brief` | runtime的scopedBrief(config)：CREATE等于config.brief；ADAPT附加用户确认范围和缺失背景（旧项目注明未记录），合计≤12000字符 |
| `sourceAnalysis`、`assets`、`blueprint` | 对应成功任务的完整 `output`，不是整个任务回执或 Markdown 摘要；sourceAnalysis仅可按runtime附加独立人工评审风险，原对象不改 |
| `selectedConcept` | 用户选定的真实 ID 对应的 `concepts[]` 完整元素，不是整个方案 output |
| `episodeNumber`、`previousEpisode` | 当前待写集号；第 2 集起读取前一集完整 output（包括 FIX 后的当前版本） |
| `episodes`、`priorReview` | 本批最多 20 集当前完整 output；针对该批当前稿件的成功 SCAN output |
| `confirmedIssueIds`、`revisionInstruction` | 用户确认的服务端问题 ID 与修改要求；不使用本地验收清单前缀 |
| `draftKind` | 当前稿别 WORKING/DELIVERY；新项目由 runtime 状态决定，不靠模型猜测 |
| `sourceEpisode`、`sourceEpisodes` | 成品 LOCALIZE 的同集工作稿；成品 SCAN/FIX 中与 episodes 同批次、同顺序的工作稿完整输出 |
| `recipeBindings` | 此算子适用的已锁定公共＋专用配方绑定；空数组表示明确不绑定 |
| `sourceDecisions` | 源稿确认时记录的真实用户澄清数组；CREATE或无需澄清时为空，不能用模型建议冒充用户决定 |
| `requirements` | 从锁定配置和sourceDecisions组装的原始要求，独立于模型生成的方案/资产/蓝图 |

新项目按 [语言与双稿](languages.md) 确认 `languagePlan={workingLanguage,targetLanguage}`，两者仅 `zh/en`。六算子均传该对象；旧项目缺省保持原语言行为。分集和审校另传 `draftKind`；不是额外的路由或模型参数。方案/资产/蓝图说明用工作语言，专名按目标市场和成品语言锁定。源稿分析的 targetLanguage 是成品语言，但分析报告用工作语言。

项目 N 集必须显式传递：分析/方案/资产用 `episodeCount`，蓝图用 `targetEpisodeCount`，分集用当前 `episodeNumber`。源稿分析用 `targetLanguage`，其他生成阶段用 `outputLanguage`。当前完整项目受资产/蓝图/分集的 1–60 集限制；分析和方案能接受更大集数不等于整条链路支持。字数不等于时长验收。

除源稿分析外，所有阶段（包括SCAN/FIX）都携带同一个`requirements`结构（正文篇幅取当前稿别预算），避免逐层摘要丢失职业、人物关系或制作限制。使用前确认五算子的describe均包含此字段；旧合同不支持时停止，不删掉原要求降级调用。服务兼容旧调用方省略此字段，但不能因此声称核对了未提供的原要求。

<!-- example: requirements-input -->
```js
({
  brief,
  namingConstraints: config.assets?.namingConstraints || [],
  contentConstraints: config.episode?.contentConstraints || [],
  protectedElements: config.source?.protectedElements || [],
  allowedChanges: config.source?.allowedChanges || [],
  targetWordsMin: config.languagePlan && draftKind === 'DELIVERY' ? config.deliveryWordsMin : config.targetWordsMin,
  targetWordsMax: config.languagePlan && draftKind === 'DELIVERY' ? config.deliveryWordsMax : config.targetWordsMax,
  sourceDecisions
})
```

brief最多12000字符；命名/内容约束各最多100项，每项分别最多300/500字符。原始protectedElements/allowedChanges也各最多100项、每项500字符；允许修改不是要求全部修改，更不能撤销保护项。字数100–5000且min≤max，约束最终单集正文，不是方案/分析文字长度。sourceDecisions每项只有riskId和decision，最多100项，ID最多120字符且不重复、决定最多2000字符；与sourceAnalysis共同传入时，ID必须属于真实risks。原稿事实和用户授权的改编处理方式分别保存，不回写分析JSON。

改编可在既有requirements.contentConstraints中携带`SOURCE_FACT_V1 `＋紧凑JSON的关键原文证据约定，见[源事实格式与本地核对](source-facts.md)。仍是每项≤500字符的字符串，不新增算子字段或修改sourceAnalysis；最多12条、使用真实上传文本摘要与行号，不代表服务端认证原文或用户授权。CLI传参不变，五个后续算子完整透传；调用前核对服务端已支持这一证据约定，不能以JSON被接受就声称语义核验通过。

## 源稿分析

`op.script.source-analyze`：仅在 ADAPT 分析用户选定、获准使用的原稿；CREATE 不调用。

输入来源：`config.source` 含 `adaptationGoal`，可含 `sourceLanguage/protectedElements/allowedChanges`；市场、语言和集数取项目配置。`sourceFileId` 只能来自已获授权的文件 ID 或 CLI 对用户选定原稿的上传结果，不传本地路径或任意 URL 代替。

<!-- example: source-input -->
```js
({
  ...(config.languagePlan ? { languagePlan: config.languagePlan } : {}),
  ...config.source,
  targetMarket: config.targetMarket,
  targetLanguage: config.languagePlan?.targetLanguage || config.outputLanguage,
  episodeCount: config.episodeCount,
  recipeBindings,
  sourceFileId
})
```

新项目先锁定本地sourceScope；没有fileId时用prepare的本地`--source-file`参数完成容量检查和文件绑定，随后执行返回的独立上传，再用`bind-source-upload`绑定AVAILABLE回执；报价和确认的固定JSON直接含fileId，不使用`--file`。不把路径放入算子sourceFileId，不另加sourceScope字段；remote fileId的未检查分支见[runtime](runtime.md)。上传类型/大小及最终容量以服务端为准。

输出为 `script.source-analysis.v1`；`summary/sourceBible/plotSkeleton` 支持梳理因果骨架，`protectedElements/flexibleElements/bannedSourceNames/risks` 支持确认边界，`reportMarkdown` 用于展示。示意：

```json
{"schemaVersion":"script.source-analysis.v1","protectedElements":["女主通过证据洗清父亲嫌疑"],"flexibleElements":["职业与城镇背景"],"bannedSourceNames":["原稿人名"],"risks":[]}
```

停止点：用户确认原作圣经与改编边界，才将完整 output 作为方案、资产、审校的 `sourceAnalysis`。人工漏报风险按runtime的`--source-risks`独立保存，在输入副本risks中带`origin=CALLER_REVIEW`和`requiresConfirmation=true`，对应决定仍放requirements.sourceDecisions；不能改模型原风险或源稿事实。原稿不全、扫描识别异常或保护要求矛盾时先澄清，不因任务成功推断已完整读取或已获版权许可。

风险对象可含`id/requiresConfirmation/evidence/question`。`requiresConfirmation=true`意味着必须把证据和问题展示给用户，取得处理决定后用runtime的`--source-decisions`记录。旧风险没有该标记不等于源稿自洽，仍需人工检查；不能只写“确认”来替用户选择矛盾的修复方式。

## 创意方案

`op.script.concept`：CREATE 从简报生成方向；ADAPT 必须已有确认的源稿分析。先有用户需求，不自动从数据榜单升级为改编任务。

输入来源：`brief/targetMarket/outputLanguage/carrier/episodeCount` 来自配置；`config.concept` 可提供 `genre/audience`。本流程固定请求 3 个方案；服务允许其他数量并不改变当前项目的三选一流程。

<!-- example: concept-input -->
```js
({
  ...(config.languagePlan ? { languagePlan: config.languagePlan } : {}),
  targetMarket: config.targetMarket, outputLanguage: config.languagePlan?.workingLanguage || config.outputLanguage,
  carrier: config.carrier, ...config.concept,
  mode: config.mode, brief,
  requirements,
  episodeCount: config.episodeCount, conceptCount: 3,
  ...(config.mode === 'ADAPT' ? { sourceAnalysis } : {}),
  recipeBindings
})
```

CREATE 禁止 `sourceAnalysis`；ADAPT 传完整对象。输出为 `script.concept.v1`；各 `concepts[]` 含 `id/title/logline/synopsis/genre/targetAudience/coreHook/episodeArc/localizationNotes/risks/score`，另有 `recommendedConceptId/decisionNotes/appliedRecipes`。

每个候选的 `episodeArc` 必须非空且恰好覆盖 `1..episodeCount`，不重号、不缺集。每项包含整数 `episode`、非空字符串 `protagonistAction/visibleConsequence/emotionalTurn`；历史 `episodeNumber` 别名可读，双字段必须一致。它是每集简要的行动、后果与情绪承诺，不代替蓝图拍单。单项节选：

```json
{"episode":1,"protagonistAction":"女主试用归还的钥匙","visibleConsequence":"钥匙无法打开更换后的锁","emotionalTurn":"对父亲的怀疑转为主动查证"}
```

空数组、空对象或只有梗概的方案不能进入选择或下游。runtime 导入时保留原结果为 `OUTPUT_INVALID` 并停止；升级前已存坏方案仍可查看导出，但不能继续确认或准备调用。不要补造弧线、手改历史或自动收费重试；保留原恢复 ID 和失败证据，先处理服务结果问题。`risks/localizationNotes` 允许为空，不为凑字段编造风险或本地化说明。

```json
{"schemaVersion":"script.concept.v1","mode":"CREATE","recommendedConceptId":"concept-b","decisionNotes":["场景集中，但需要强化主角动机"]}
```

展示三个方案的冲突、情感回报和制作代价，用户选定真实 `id` 后，把对应完整元素交给资产、蓝图和分集的 `selectedConcept`。推荐 ID/分数不是用户选择，也不是市场成功概率。缺方案、重复 ID、模式不符或推荐项不存在时停止，不能补造第三个方案。

选题前按[人物核对](quality-gates.md#创意候选人物核对)对照角色映射、性别和指定代词的各自依据及全部候选的实际叙述。新提纲用姓名/稳定角色称谓/中性表达，身份和代词设定保留在localizationNotes；这不改变公开字段或后续对白规则。服务最终返回`LLM_OUTPUT_SCHEMA_VIOLATION`或`TERMINAL_PROJECTION_FAILED`时，按真实终态与账务处理，不能仅凭错误码认定是性别冲突；只有详情明确`CONCEPT_NARRATIVE_REFERENCE`及字段路径时才定位为提纲引用约束。服务内部补试不等于允许Agent再发新调用。旧成功候选有真实冲突时可经确认选另一个无冲突候选，不伪造失败/成功回执。

能力边界：服务支持 `priorConcepts + revisionInstruction` 定向修订；当前项目脚本不编排此动作。可按[上游恢复](recovery.md)显式重开concept，基于已确认要求重新生成候选；这是另行报价的新调用，不是旧任务重试或保留旧ID的定向修订。原候选/已选历史及费用不覆盖。

ADAPT 另按[事件顺序核对](quality-gates.md#改编候选事件顺序核对)读取源句与每个候选的梗概/弧线，不能只读模型的保留声明。当前服务没有自由文本时序的确定性校验，SUCCEEDED 不证明无偏离；不猜造 chronology 等合同字段，不用手改结果或自动付费重跑弥补。

## 资产

`op.script.assets`：锁定方案后建立人物、场景、道具和连续性圣经。不能只把方案标题或一段概述传入。

输入来源：用户已选的 `selectedConcept`，配置中的市场/语言/载体/集数，`config.assets.namingConstraints` 中的命名要求；ADAPT 还要完整 `sourceAnalysis`，CREATE 禁止携带。

<!-- example: assets-input -->
```js
({
  ...(config.languagePlan ? { languagePlan: config.languagePlan } : {}),
  targetMarket: config.targetMarket, outputLanguage: config.languagePlan?.workingLanguage || config.outputLanguage,
  carrier: config.carrier, ...config.assets,
  mode: config.mode, episodeCount: config.episodeCount, selectedConcept,
  requirements,
  ...(config.mode === 'ADAPT' ? { sourceAnalysis } : {}),
  recipeBindings
})
```

输出为 `script.assets.v1`：`characters/locations/props/relationships/namingLedger/continuityRules/storyBibleMarkdown/assetsDigest/appliedRecipes`。人物字段节选（不是完整产物，不能用来替代真实输出）：

```json
{"characters":[{"id":"char-mara","canonicalName":"Mara","gender":"FEMALE","role":"PROTAGONIST","goal":"找回齿轮证据","motivation":"洗清父亲嫌疑"}]}
```

新资产的 `characters[].gender` 使用稳定代码：`MALE` 男性、`FEMALE` 女性、`NON_BINARY` 非二元、`OTHER` 其他明确设定、`UNSPECIFIED` 未设定/证据不足、`NOT_APPLICABLE` 不适用。中英文稿均保留代码，不翻译 JSON 枚举。角色定位 `role`、外貌和配音类型不能代替性别设定；依据、其他设定说明和原创待确认建议写在服务端生成的故事圣经/外貌说明中，不能自行添加假想的 `genderSource` 等合同字段。改编依据源稿明确证据和用户授权，不从姓名、服装、声线猜测；原创未定项可提出建议，但不能声称用户已确认。

字段合法不代表文字一致：性别与指定代词的证据分别保留，核对方案localizationNotes、资产说明、蓝图与正文。无两项证据时采用中性表达；有明确代词时不反推性别。完整检查与发现偏离后的停点见[质量检查](quality-gates.md#角色性别与制作交接)，不新增自定义入参或自行补设定。

按[资产确认检查](quality-gates.md#角色性别与制作交接)展示性别、依据和待确认项，再确认动机、关系、专名、道具初始状态和制作约束；通过后完整 output → 蓝图、分集和审校的 `assets`。`assetsDigest` 保留服务原值，不自行重新计算或仅保留摘要。已保存旧资产缺少 `gender` 时显示“旧资产未提供，待确认”，不补写字段、不重生成；用户可明确保留未定项继续创作，制作前再确认。若真实结果有非法值、与要求/源稿冲突或用户要求改设定，暂停并按上游修订边界处理，不用 note 冒充资产已修改。缺核心人物、命名违背改编边界或用户否定资产时同样暂停。

## 蓝图

`op.script.blueprint`：方案与资产确认后构建完整目标集数的全季结构。本流程显式使用 `action=BUILD`，不传修订字段。

<!-- example: blueprint-input -->
```js
({
  ...(config.languagePlan ? { languagePlan: config.languagePlan } : {}),
  targetMarket: config.targetMarket, outputLanguage: config.languagePlan?.workingLanguage || config.outputLanguage,
  carrier: config.carrier, action: 'BUILD', selectedConcept, assets,
  targetEpisodeCount: config.episodeCount, recipeBindings, requirements
})
```

输出为 `script.blueprint.v1`；`globalArc/units` 描述全季与单元，`episodes[]` 是逐集拍单，`unresolvedSetups/continuityConstraints/readthroughReport` 用于通读检查，另有 `blueprintDigest/appliedRecipes`。拍单字段节选：

```json
{"episodes":[{"episodeNumber":1,"title":"失踪的齿轮","objective":"发现父亲被栽赃","openingHook":"钟楼停摆","endingHook":"证据在最可信的人手中","carryForward":["女主尚不知道藏匿者"]}]}
```

必须完整覆盖 1..N 集；单元连续不重叠，每集 `beats` 为 3–7 项。确认后，分集的 `episodeBeat` 取对应集号的**完整拍单（包括 beats）**，`blueprintDigest` 取原值；审校 `blueprint` 取整个 output。不要把 `episodes` 数组或全蓝图当成单集拍单。

缺集、跳号、拍数异常或因果/伏笔未解决时停止确认。只写前两集样稿仍保留全季 N 集蓝图，不能为通过验收缩减项目目标。

能力边界：服务的 `REVISE` 需要 `revisionTarget`（STRUCTURE/UNIT/EPISODE_BEATS）、真实 `revisionScopeIds`、`revisionInstruction/priorBlueprint`。当前项目不支持该动作的版本传播，不能直接调用后手改蓝图、摘要或旧集引用。

## 分集

`op.script.episode`：工作稿按已确认蓝图顺序 WRITE；用户确认工作稿后跨语种成品用 LOCALIZE。第 2 集起必须带前集完整输出与其 `continuitySnapshot`，不能用人工前情摘要替代。

<!-- example: episode-input -->
```js
({
  ...config.episode,
  ...(config.languagePlan ? { languagePlan: config.languagePlan, draftKind } : {}),
  generationMode: config.languagePlan && draftKind === 'DELIVERY' ? 'LOCALIZE' : 'WRITE', episodeNumber,
  ...(config.languagePlan && draftKind === 'DELIVERY' ? { sourceEpisode } : {}),
  episodeBeat: blueprint.episodes.find(item => item.episodeNumber === episodeNumber),
  selectedConcept, assets, blueprintDigest: blueprint.blueprintDigest,
  outputLanguage: config.languagePlan ? config.languagePlan[draftKind === 'DELIVERY' ? 'targetLanguage' : 'workingLanguage'] : config.outputLanguage,
  targetWordsMin: config.languagePlan && draftKind === 'DELIVERY' ? config.deliveryWordsMin : config.targetWordsMin,
  targetWordsMax: config.languagePlan && draftKind === 'DELIVERY' ? config.deliveryWordsMax : config.targetWordsMax,
  ...(episodeNumber > 1 ? { previousEpisode, continuitySnapshot: previousEpisode.continuitySnapshot } : {}),
  recipeBindings, requirements
})
```

LOCALIZE 必须 `languagePlan`、`draftKind=DELIVERY`、不同的两种语言和完整 `sourceEpisode`；禁止用于重新编写剧情。保持场景ID/顺序、逐行类型/场景归属/说话人，翻译全文、标题与连续性说明。同语种由本地独立导出，不发 LOCALIZE。第2集起 previousEpisode 必须是成品前集，不能误传工作前集。服务拒绝缺源稿、同集不匹配或结构身份变化，语义仍要对照核验。

ACTION/CAPTION/SFX 允许携带源稿中已有的非空角色元数据，不能仅因非对白就判为非法或本地删除。服务端本地化内部译文格式不属于公开合同，调用者仍只传完整公开源稿并接收 `script.episode.v1`；不导入内部译文或自行拼接成功回执。服务修复后的新调用由源稿保留身份，Skill继续严格核对公开结果，不能为绕过错误放宽说话人/场景校验。

`config.episode.contentConstraints` 传用户内容约束，`targetWordsMin <= targetWordsMax`。找不到对应拍单或前集未成功时不调用。

输出为 `script.episode.v1`：`generationMode/episodeNumber/title/scenes/scriptLines/markdown/statistics/continuityDelta/continuitySnapshot/warnings/appliedRecipes`。示意：

```json
{"schemaVersion":"script.episode.v1","generationMode":"WRITE","episodeNumber":1,"statistics":{"wordCount":520},"warnings":[]}
```

`markdown` 用于阅读/导出，结构化行与场景用于检查；完整 output → 下一集 `previousEpisode` 和审校 `episodes[]`，快照取同一版本。检查集号、目标语言、字数、警告及动作/对白；wordCount 合格不代表时长、节奏或道具交接合格。每五集按 runtime 抽检，用户只要样稿时到指定集数即导出停止。

连续性事实按正文实际展示的事件核对，delta的change/evidence仅为派生摘要。线性场景的摘要先后措辞有误但最终状态/因果不变时保持非阻断，不删字段或改inputFile。LOCALIZE只在新成品delta中对齐有明确正文依据的顺序措辞并披露，不改源稿、身份键、终态或历史知情事实；源语言知情仍须完整翻译，已有成品前集知情原句保留。不确定时保留源义并提示。详见[顺序差异与续写](warnings-and-revisions.md#正文与连续性摘要的顺序差异)。

内部模型采用一份场景块，由服务端派生上述公开字段；调用方仍只使用公开scenes/scriptLines，不传sceneBlocks作为输入。每场必须有对应标题，跨地点切场或插入镜头需明确。旧结果的场景/连续性警告仍保留，不因新实现自动修正历史产物。

新记录（含 FIX 内嵌分集）必须包含字符串数组 `warnings` 以及非负整数 `statistics.wordCount/sceneCount/dialogueCount`，正文计数必须大于零；空 warnings 数组合法，缺字段不等于无问题。`MODEL_WARNINGS_MISSING` 可作为服务端明确警告保留并进入人工检查。嵌套结果出现服务端 `<truncated>` / `_truncated=true` 标记时保留回执为 OUTPUT_INVALID，先查询原任务完整结果；不补造证据或另开付费调用。runtime 不复刻服务端字数算法，也不把字数偏差当结构失败。

能力边界：服务 `generationMode=REWRITE` 还要求 `revisionInstruction/priorEpisode`；后续集同样要前集与快照。当前项目未编排任意单集重写及后续失效传播；已有 SCAN 问题的受限修复走下面的 review FIX，不擅自替代用户的重写要求。

少量已明确的正文/状态错误也可经用户确认用[本地精确修订](warnings-and-revisions.md)，它不是REWRITE或FIX调用，不伪造成功回执。修改后保留其他集但本地核对后续连续性；要求/概念/蓝图矛盾仍按上游恢复处理，不通过局部补丁掩盖。

## 审校改稿

`op.script.review`是独立的可选能力：SCAN只找问题，FIX只修改用户确认的问题；一次调用不会因为报告有问题就授权下一次收费调用。默认写完阶段后只提示是否需要，未明确同意不调用；支持用户主动要求对当前已完成集数做阶段审校，不按每集自动循环。获准后按完整请求体分批，最多20集、相邻重叠一集，不传占位集。费用决策见[review-policy](review-policy.md)，调度见[runtime](runtime.md)。evidence是字符串；sourceEpisodes仅在跨语种成品中对照工作稿，不是原作、不用于WORKING。

<!-- example: scan-input -->
```js
({
  ...(config.languagePlan ? { languagePlan: config.languagePlan, draftKind } : {}),
  ...(config.languagePlan && draftKind === 'DELIVERY' && config.languagePlan.workingLanguage !== config.languagePlan.targetLanguage ? { sourceEpisodes } : {}),
  action: 'SCAN', episodes, blueprint, assets, requirements,
  ...(config.mode === 'ADAPT' ? { sourceAnalysis } : {}),
  recipeBindings
})
```

新项目报告用工作语言，FIX 正文用当前稿别语言。跨语种 DELIVERY 的 SCAN/FIX 必须带对应完整工作稿 `sourceEpisodes`，数量、顺序与 episodes 相同；其他稿别不传。审校比较漏译/增写/因果/人物关系/专名，不能只凭蓝图宣布翻译忠实。

SCAN 不传 `confirmedIssueIds/revisionInstruction/priorReview`。输出为 `script.review.v1`；读取 `status/summary/issues/appliedRecipes`。

原稿不变时的再次SCAN使用runtime的显式rescan入口，新call仍发送相同公开参数，不新增reviewEpoch等服务端字段。仅缺少批外前文/结局属于summary的覆盖限制，不应作为正文FIX问题；真实已提供结局缺兑现或正文矛盾仍须检查。模型混淆二者时保留原回执并人工标注，不伪造issue ID或自动改稿。

问题节选：

```json
{"action":"SCAN","status":"REVIEW_REQUIRED","issues":[{"id":"I1","severity":"MAJOR","episodeNumber":1,"dimension":"CONTINUITY","description":"钥匙易主缺少动作","evidence":"前场仍由父亲持有，后场出现在女主手中","suggestion":"补充明确交接"}]}
```

PASS 对应无问题，REVIEW_REQUIRED 对应有问题；展示严重度、证据和建议，等待用户确认修哪些 ID，不把 SCAN 当成改稿完成。

<!-- example: fix-input -->
```js
({
  ...(config.languagePlan ? { languagePlan: config.languagePlan, draftKind } : {}),
  ...(config.languagePlan && draftKind === 'DELIVERY' && config.languagePlan.workingLanguage !== config.languagePlan.targetLanguage ? { sourceEpisodes } : {}),
  action: 'FIX', episodes, blueprint, assets, requirements,
  confirmedIssueIds, revisionInstruction, priorReview,
  ...(config.mode === 'ADAPT' ? { sourceAnalysis } : {}),
  recipeBindings
})
```

通过runtime的fix决定记录真实问题范围、`--with-rescan confirmed|later|skip`和`--repair-budget`，再prepare；一次说明FIX与可选复扫费用，不强制捆绑购买，实际价格仍由CLI确认。confirmedIssueIds必须来自有效SCAN，不传展示序号、本地前缀或人工新增ID。episodes使用原批次当前完整稿件，不只传一段Markdown。

单次确认问题的影响范围最多两集；无集号/null集号按原批次全部集计算，不伪造更小范围。服务端另检查完整输入与修订稿回写预算，容量错误不是需要反复尝试的模型质量错误。`SCRIPT_INPUT_CAPACITY_EXCEEDED`、`SCRIPT_FIX_SCOPE_TOO_LARGE`、`SCRIPT_FIX_OUTPUT_CAPACITY_EXCEEDED` 都应停止并说明范围，未知受理状态仍只恢复原调用。Skill上传和存档保留完整JSON；服务端仅在模型副本中删除与scriptLines确定性渲染完全相同的markdown，不允许客户端自行删除不同文本、报告证据或源稿内容。`fixEpisodeNumbers`是服务端派生的提示信息，不是调用方入参。

FIX 输出 `revisedEpisodes/resolvedIssueIds/unresolvedIssues/changeSummary`，以及 `status/summary/appliedRecipes`。状态节选：

```json
{"action":"FIX","status":"PASS","resolvedIssueIds":["I1"],"unresolvedIssues":[],"changeSummary":["补充钥匙交接动作"]}
```

完整revisedEpisodes按集号更新视图，使相关旧审校失效；只有获准才再次SCAN。用户可直接保留修订稿并标明未复核，不把FIX的PASS当作终审。越范围修改、未确认ID或结果缺失时停止；复扫仍有问题先展示，由用户决定，不自动再FIX。三轮是项目上限，不是默认套餐，不能无限付费修复。

内部模型Schema收紧不改变上述公开合同：`revisedEpisodes[].continuityDelta/continuitySnapshot`仍是对象，统计和阅读稿仍由服务端生成。Skill不解码内部模型结果、不放宽公开结构、不补空对象或已修复ID；失败保留原稿，按[runtime恢复规则](runtime.md#服务升级后复用现有项目)处理。

服务端从有效正文重新计算统计（FIX 为修订稿，未修集保留当前稿）；可选 `summary.episodeStatistics/statisticsBasis` 用于展示当前口径。旧服务未返回该摘要扩展不算合同失败；模型文字与沿用问题中的旧数值不能覆盖分集 statistics，不擅自修改引用证据。翻译审校的对照维度见[质量检查](quality-gates.md)，同结构不代表同含义。

## 配方

绑定格式示例（市场和时长是项目选择，不是所有项目默认值）：

```json
{"recipeBindings":[{"code":"rcp.script.preset.overseas-webtoon.v1","contentDigest":"905fb3962862151802c3082a496e934ce61e831492dea604b7db34032d482ffd","parameters":{"targetMarket":"US","episodeDurationSeconds":90}}]}
```

内置绑定：`rcp.script.preset.overseas-webtoon.v1` 的摘要如上；`rcp.script.webtoon-redline.v1` 为 `80b717647df7d90775399485c8fa34fdfdc3a19a62413a1109a04379e84afe7c`。专用配方只传适用算子，公共与专用不能重复 code。

保留输出 `appliedRecipes` 与锁定输入供追溯；摘要不匹配、配方停用或合同变化时按 runtime 停止并处理配置迁移，不替换旧项目摘要后重跑。配方不是客户端系统提示词，也不授权选择模型或绕过审校。
