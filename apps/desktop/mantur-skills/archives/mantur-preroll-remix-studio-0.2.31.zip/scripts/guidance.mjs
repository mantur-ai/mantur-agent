import {episodeCount,validId} from './project.mjs';
import {modeView,modeChoice} from './production-mode.mjs';
import {planReview} from './plan.mjs';

const choice=(id,label,reply=label)=>({id,label,reply});
const reviewChoice=()=>choice('review','先只查看素材','我先只查看素材，暂不开始制作。');
const stages=new Set(['fronts','analysis','highlights','compose']);
const operationView=op=>({...validId(op.id)?{id:op.id}:{},...(stages.has(op.stage)?{stage:op.stage}:{}),status:op.status});
const operationScope=operations=>({operationIds:operations.filter(op=>validId(op.id)).map(op=>op.id),...(operations.length&&stages.has(operations[0].stage)&&operations.every(op=>op.stage===operations[0].stage)?{stage:operations[0].stage}:{})});
const recoverable=op=>typeof op.recoveryId==='string'&&/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(op.recoveryId);
const pendingStatuses=new Set(['unknown','running','remote_succeeded','artifact_pending','qa_failed']);
const stoppedCodes=new Set(['CLI_CONFIRMATION_INVALID','CLI_RECEIPT_INVALID','CLI_REJECTION_INVALID','CLI_RECOVERY_ID_CHANGED','CLI_REJECTION_MISMATCH','JOB_RECEIPT_INVALID','JOB_STATUS_INVALID','JOB_STATUS_REGRESSION','JOB_ID_MISMATCH','ANALYSIS_OUTPUT_INVALID','VIDEO_RESULT_MISSING','ARTIFACT_URL_UNAVAILABLE']);
function recoveryGuidance(operations,assets=[]){
  const common={operations:operations.map(operationView),...operationScope(operations)};
  const mediaOperations=operations.filter(op=>op.status==='qa_failed'||op.error?.code==='MEDIA_DECODE_FAILED'||op.qa?.decodeStatus==='failed');
  const mediaAction=mediaOperations.length&&mediaOperations.every(op=>validId(op.assetId)&&assets.some(asset=>asset.id===op.assetId))?'verify-media':'status';
  if(operations.some(op=>op.error?.code==='MULTIPLE_RESULTS_SELECT_REQUIRED'))return {...common,status:'needs_result_selection',nextAction:'select-result',message:'原任务返回多个结果，需要先在聊天中确认采用哪一个，再恢复该结果的下载；不会自动选择第一条。'};
  if(operations.some(op=>op.error?.code==='MEDIA_DECODE_FAILED'||op.qa?.decodeStatus==='failed'))return {...common,status:'media_review_required',nextAction:mediaAction,message:'原产物存在明确解码失败记录，文件和任务记录已保留。请助手核对原文件并说明修复或加强复验方案；不能靠普通刷新或较弱检查宣称通过，也不会重新制作。'};
  if(operations.some(op=>stoppedCodes.has(op.error?.code)))return {...common,status:'recovery_blocked',nextAction:'status',message:'原调用记录需要核对，请助手检查原工具回执和当前接入能力后说明处理办法。不要重新提交、伪造恢复记录或改用本地合成，也不能据此推断是否收费。'};
  if(operations.some(op=>!recoverable(op)))return {...common,status:'recovery_blocked',nextAction:'status',message:'原调用缺少有效恢复标识，当前无法安全继续。请助手核对原工具记录，找回同一调用的恢复入口；不要重新提交或改用本地制作，是否收费仍需核对原记录。'};
  if(operations.some(op=>op.status==='qa_failed'))return {...common,status:'media_review_required',nextAction:mediaAction,message:mediaAction==='verify-media'?'原产物已保存，但媒体检查未通过。请助手核对原文件与计划差异，给出复验或恢复原产物的办法；保留原任务，不自动重新制作。':'原任务的媒体检查未通过，产物尚未登记为可复验素材。请助手先核对下载缓存和原产物差异，说明恢复或修复办法；不反复执行缺少素材的复验命令，也不重新制作。'};
  const downloading=operations.some(op=>['remote_succeeded','artifact_pending'].includes(op.status));
  return {...common,status:'resumable',nextAction:'resume',actor:downloading?'assistant':'wait',message:downloading?'原任务已有结果，正在等待下载或恢复原产物。请助手沿用原任务收取并验收文件；下载失败不重新生成。':'原任务已提交或提交状态待核实，工作台会尝试同步。需要继续时由助手沿用原恢复标识核对进度，不重复提交制作。'};
}
function executionGuidance(p,operations,stage){
  const prepared=operations.filter(op=>op.status==='prepared');
  const scope={stage,...operationScope(prepared)};
  if(!prepared.length)return {status:'needs_state_review',nextAction:'status',stage,message:'本阶段状态需要核对，请助手检查当前任务记录，再说明可继续的步骤。'};
  const storedError=prepared.find(op=>op.error)?.error?.code;
  if(storedError&&stoppedCodes.has(storedError))return recoveryGuidance(prepared);
  if(storedError&&['LOGIN_REQUIRED','OPERATOR_AUTH_REQUIRED','AUTH_CHECK_FAILED'].includes(storedError))return accessGuidance(storedError);
  if(prepared.some(op=>op.error?.phase==='quote'||['QUOTE_CHANGED','BALANCE_INSUFFICIENT','BALANCE_UNKNOWN','QUOTE_INVALID','POST_EXECUTION_SETTLEMENT_UNSUPPORTED'].includes(op.error?.code)||!op.quoteHash||!op.requestHash||!Number.isFinite(op.quote?.estimatedPoints)||op.quote.estimatedPoints<0))return {status:'awaiting_execution',nextAction:'quote',...scope,message:'本阶段需要核对当前有效报价，再展示实际范围与费用；已有匹配且有效的预算决定继续保留，实际收费确认仍按公共工具合同处理。'};
  const approved=prepared.every(op=>{
    const approval=(p.approvals||[]).findLast(a=>a.stage===stage&&a.items?.some(item=>item.operationId===op.id&&item.requestHash===op.requestHash&&item.quoteHash===op.quoteHash));
    return approval&&Number.isFinite(approval.maxPoints)&&approval.items.reduce((total,item)=>total+(p.operations.find(o=>o.id===item.operationId)?.quote?.estimatedPoints??Infinity),0)<=approval.maxPoints;
  });
  const estimatedPoints=prepared.reduce((total,op)=>total+op.quote.estimatedPoints,0);
  if(!approved)return {status:'needs_budget_decision',nextAction:'approve',...scope,estimatedPoints,message:`本阶段已有报价，当前待执行项预计合计 ${estimatedPoints} 馒头。请助手展示具体范围与费用，再由你明确预算；预算决定不替代实际收费确认。`};
  return {status:'ready_to_execute',nextAction:'run',...scope,estimatedPoints,message:'本阶段已有匹配的预算决定，由助手按原范围继续，并遵循公共工具返回的实际收费确认。登录授权或本地预算记录都不能替代收费确认。'};
}
function accessGuidance(status){
  return {status:'access_blocked',nextAction:'doctor',actor:'user',title:'先完成工具接入核对',message:status==='LOGIN_REQUIRED'?'当前工具尚未登录，请按本次检查返回的授权指引完成登录，随后在聊天中说“已完成授权，继续核对”。这不代表已批准制作费用，也不改变尾贴和水印选择。':'当前工具或调用授权尚未就绪，请助手按接入检查说明处理缺项，再继续原项目。不要因工具受阻改用本地合成，也不自动省略尾贴或水印。',question:'接入处理完成后，请回到聊天告诉助手继续核对。',choices:[choice('check-access','核对接入状态','请先核对工具和授权状态，说明还缺什么；暂不提交制作。'),reviewChoice()]};
}

function guideProject(p){
  if(!p)return {status:'needs_input',message:'请选择爆款前贴或高光前贴模式，提供至少3集原始剧集。尾贴和PNG水印默认要求提供，也可明确选择不添加；可先导入现有素材预览。爆款模式支持文案、参考视频生成或复用已有前贴。助手会整理计划，你不需要编写JSON。',nextAction:'create-project',modes:['viral','highlight']};
  if(p.schemaVersion===1||p.legacyOrigin){
    const originalToolOperations=p.operations.filter(o=>['unknown','running','remote_succeeded','artifact_pending','qa_failed'].includes(o.status)).map(o=>({id:o.id,status:o.status}));
    return {status:'local_review_only',readOnly:true,nextAction:'open-workbench',newProjectAction:'create-project',originalToolOperations,
      message:originalToolOperations.length?'旧项目仅在此审阅本地历史；待处理任务请使用原入口和原环境收尾。新制作请明确创建新项目，不复用历史授权。':'旧项目仅在此审阅本地历史；新制作请明确创建新项目，不复用历史上传、任务或授权。'};
  }
  const productionMode=modeView(p);
  const clipping=productionMode.mode!=='viral'&&Array.isArray(p.highlightPool);
  const selected=new Set((p.highlights||[]).map(h=>h.id));
  const clipOps=(p.highlightOperationIds||[]).map(id=>p.operations.find(o=>o.id===id)).filter(Boolean);
  const plansCurrent=p.plans.every(plan=>{
    const highlightId=plan.front?.highlightId;
    if(!highlightId)return true;
    if(!selected.has(highlightId))return false;
    if(!clipping)return true;
    const clip=clipOps.find(o=>o.highlightId===highlightId);
    return clip?.status==='succeeded'&&!!clip.assetId&&plan.segments?.[0]?.assetId===clip.assetId;
  });
  const active=new Set([...(plansCurrent&&p.plans.length?p.plans.map(x=>x.operationId):[]),...(clipping?p.highlightOperationIds||[]:[]),...(!p.plans.length&&!clipping?(productionMode.mode==='viral'?p.frontOperationIds||[]:productionMode.mode==='highlight'?p.analysis?.operationIds||[]:[...(p.frontOperationIds||[]),...(p.analysis?.operationIds||[])]):[])]);
  const waiting=p.operations.filter(o=>active.has(o.id)&&pendingStatuses.has(o.status));
  if(waiting.length)return recoveryGuidance(waiting,p.assets);
  const rejected=p.operations.filter(o=>active.has(o.id)&&o.status==='rejected');
  if(rejected.length)return {status:'needs_decision',nextAction:'status',requiresNewCallDecision:true,message:'当前请求被公开工具明确拒绝，尚未受理为制作任务。请核对原因、修正输入，并由用户决定是否发起新调用；不要继续报价或恢复这条请求，也不据此推断收费或退款。',operations:rejected.map(operationView)};
  const failed=p.operations.filter(o=>active.has(o.id)&&o.status==='failed');
  if(p.plans.length&&plansCurrent&&(!clipping||(clipOps.length===p.highlights.length&&clipOps.every(o=>o.status==='succeeded')))){
    const complete=p.plans.every(plan=>p.operations.some(o=>o.id===plan.operationId&&o.status==='succeeded'));
    if(complete)return {status:'completed',message:'当前成片已完成，可以打开工作台播放和下载。',nextAction:'open-workbench',outputs:p.plans.length};
  }
  if(productionMode.status!=='confirmed')return {...modeChoice(),productionMode,message:'爆款前贴智剪：按文案或参考视频生成前贴，也可以复用已有前贴；高光前贴智剪：从指定剧集中挑选片段作为前贴。选好后会继续提示需要提供的内容。'};
  const available=episodeCount(p);
  if(available<3)return {status:'needs_input',message:`当前有${available}集原片，还需补充${3-available}集才能开始新制作；尾贴和PNG不计入。`,nextAction:'add-assets',missingEpisodes:3-available};
  const missing=['ending','logo'].filter(role=>p.packaging?.[role]!==false&&!p.assets.some(a=>a.role===role));
  if(missing.length)return {status:'needs_input',message:`默认要求提供${missing.map(role=>role==='ending'?'尾贴':'PNG水印').join('和')}，请补充或明确选择不添加；助手会在计划中记录该决定。已导入素材可在看板预览，无需重新生成已有前贴。`,nextAction:'add-assets',missing};
  const stale=op=>op?.status==='prepared'&&(op.modeInvalidated||op.modeDecisionId!==p.modeDecision.id||op.productionMode!==productionMode.mode);
  const sourceIds=productionMode.mode==='viral'?p.frontOperationIds:p.analysis?.operationIds;
  if(sourceIds?.some(id=>stale(p.operations.find(op=>op.id===id))))return {status:'needs_reprepare',nextAction:productionMode.mode==='viral'?'prepare-fronts':'prepare-analysis',message:'未提交的旧准备记录不属于本次模式，请沿用明确需求重新准备，再核对报价与授权；原任务和产物仍保留。'};
  if(clipping&&clipOps.some(stale))return {status:'needs_reprepare',nextAction:'prepare-highlights',message:'请为当前选定高光重新准备裁剪，旧未提交记录不会继续执行。'};
  if(p.plans.some(plan=>plan.modeDecisionId!==p.modeDecision.id))return {status:'needs_reprepare',nextAction:'plan',message:'旧剪辑计划尚未绑定本次模式，请使用原素材和用户已确认区间重新编排，再准备合成。'};
  if(p.plans.some(plan=>stale(p.operations.find(op=>op.id===plan.operationId))))return {status:'needs_reprepare',nextAction:'prepare-compose',message:'请按当前已确认计划重新准备合成，再核对报价与授权。'};
  if(failed.length)return {status:'needs_decision',message:'有任务明确失败，请让助手查看原任务原因和退款情况。修正输入或确需重新付费时，说明费用并依据授权处理，不能用空报价继续。',nextAction:'status',requiresNewChargeDecision:true,operations:failed.map(operationView)};
  if(clipping){
    if(p.analysis.selectionRequired&&p.highlightPool.length>=p.analysis.count)return {status:'needs_decision',message:`部分原选定高光已失效，其余有效选择和裁片已保留。现有${p.highlightPool.length}条候选，请重新选定${p.analysis.count}条；不需要重新分析其他集。`,nextAction:'select-highlights',selectionRequired:true,available:p.highlightPool.length};
    if(p.highlights.length<p.analysis.count)return {status:'needs_decision',message:`有效候选仅${p.highlights.length}条，少于要求的${p.analysis.count}条；请扩大分析范围或明确减少数量。`,nextActions:['prepare-analysis','select-highlights']};
    if(clipOps.length!==p.highlights.length)return {status:'candidates_selected',message:`已筛选${p.highlights.length}条候选，仅裁剪这些片段；下一步准备裁剪并查询费用。`,nextAction:'prepare-highlights'};
    if(!clipOps.every(o=>o.status==='succeeded'))return executionGuidance(p,clipOps,'highlights');
    if(!p.plans.length||!plansCurrent)return {status:'ready_for_plan',message:'所选高光片段已就绪，可播放、下载并确认后续拼接计划。',nextAction:'plan'};
  }
  if(p.plans.length){
    if(p.plans.some(x=>!x.operationId))return {status:'plan_ready',message:'剪辑计划已就绪，请先逐条核对前贴、接续集数与起止时间、尺寸、尾贴和水印；保留已明确的选择，需要调整时只重编受影响计划，再准备合成。',nextAction:'prepare-compose',stage:'compose'};
    return executionGuidance(p,p.plans.map(plan=>p.operations.find(op=>op.id===plan.operationId)).filter(Boolean),'compose');
  }
  for(const [stage,ids] of [['fronts',p.frontOperationIds],['analysis',p.analysis?.operationIds]]){
    if((stage==='fronts')!==(productionMode.mode==='viral'))continue;
    if(!ids?.length)continue;
    const operations=ids.map(id=>p.operations.find(o=>o.id===id));
    if(operations.every(o=>o?.status==='succeeded'))return {status:'ready_for_plan',message:stage==='analysis'?'分析已完成，可以整理高光并确定接续计划。':'前贴已就绪，可以确定正片接续计划。',nextAction:stage==='analysis'&&!p.highlights.length?'collect-highlights':'plan'};
    return executionGuidance(p,operations.filter(Boolean),stage);
  }
  if(productionMode.mode==='viral')return {status:'choose_front_source',productionMode,message:'本次采用爆款前贴智剪。请明确按文案或参考视频生成，或明确复用已有前贴，并提供数量和接续区间；已有素材不会自动成为已选前贴。',nextActions:['prepare-fronts',...(p.assets.some(a=>a.role==='front')?['plan']:[])]};
  return {status:'needs_input',productionMode,message:'本次采用高光前贴智剪。请确认分析剧集范围、选定高光数量和后续接续区间。',nextAction:'prepare-analysis'};
}

const decisions={
  needs_mode_decision:['选择本次制作方式','这次想用哪一种方式？也可以先只查看素材。',()=>[choice('viral','爆款前贴智剪','我选择爆款前贴智剪，请告诉我下一步需要提供什么。'),choice('highlight','高光前贴智剪','我选择高光前贴智剪，请告诉我下一步需要提供什么。'),reviewChoice()]],
  choose_front_source:['选择前贴来源','这次前贴来自哪里？',()=>[choice('text','用文案生成','我想按文案生成前贴，请帮我整理还需确认的信息。'),choice('reference','参考视频生成','我想参考视频生成前贴，请先核对参考素材。'),choice('existing','复用已有前贴','我想复用已有前贴，请让我确认采用哪个文件。'),reviewChoice()]],
  needs_budget_decision:['确认范围与预算','请先查看具体范围和报价，再明确是否批准对应预算。',()=>[choice('show-quote','查看范围和报价','请列出本阶段制作范围及实际报价，暂不提交制作。'),choice('adjust','调整本次范围','我想先调整制作范围，再重新核对报价。'),reviewChoice()]],
  confirmation_required:['本次收费等待确认','请查看助手展示的本项实际报价，再明确确认或暂不执行。',()=>[choice('review-charge','查看本项收费详情','请展示本次实际收费项目、范围和金额，等我明确决定。'),choice('pause-charge','暂不执行','暂不确认这次收费，请保留当前项目。')]],
  needs_result_selection:['选择原任务的结果','请让助手列出原任务返回的结果，再指定采用哪一个。',()=>[choice('show-results','查看可选结果','请列出原任务的可选结果，我确认后再恢复所选结果下载。')]],
  media_review_required:['核对原产物','请让助手说明媒体检查失败原因和原产物处理办法。',()=>[choice('inspect-media','核对原文件','请核对原产物的检查问题并给出复验或恢复办法，不重新制作。')]],
  recovery_blocked:['原调用需要核对','请让助手核对原工具记录，并说明恢复所需信息。',()=>[choice('inspect-record','核对原调用记录','请检查原调用记录和恢复入口，不重新提交制作。'),reviewChoice()]],
  local_review_only:['继续审阅历史项目',null,()=>[choice('review-history','查看历史结果','请打开当前历史项目，帮我查看已有结果。'),choice('new-project','另建新项目','我想另建一个项目开始新制作，请先确认制作范围。')]],
  completed:['当前计划已完成',null,()=>[choice('review-results','播放与下载成片','请展示当前成片的播放和下载入口。'),choice('change-plan','提出修改需求','我想修改当前成片，请先确认修改范围和可能产生的费用。')]],
};
function decorate(value){
  const spec=decisions[value.status];
  let title=spec?.[0]||'接下来',question=spec?.[1]??null,choices=spec?.[2]()||[],actor=value.actor||(['needs_mode_decision','needs_input','choose_front_source','needs_decision','needs_budget_decision','confirmation_required','needs_result_selection','media_review_required','recovery_blocked'].includes(value.status)?'user':['completed','local_review_only'].includes(value.status)?'none':'assistant');
  if(value.status==='needs_input'){
    if(value.missingEpisodes){title='补充原始剧集';question=`请再提供 ${value.missingEpisodes} 集原始剧集，或先只审阅现有素材。`;choices=[choice('add-episodes','继续添加剧集','我来补充原始剧集，请帮我导入并核对集数。'),reviewChoice()];}
    else if(value.missing?.length){title='确认尾贴与水印';question='请补充缺少的包装素材，或明确选择不添加哪一项。';choices=[choice('add-packaging','补充缺少的素材','我要补充缺少的尾贴或 PNG 水印，请先核对素材。'),...value.missing.map(role=>role==='ending'?choice('without-ending','本次不加尾贴','本次明确不添加尾贴；水印选择保持不变。'):choice('without-logo','本次不加水印','本次明确不添加水印；尾贴选择保持不变。'))];}
    else if(value.productionMode?.mode==='highlight'){title='确认高光制作范围';question='准备分析哪几集、选几条高光，以及从哪一集哪一秒接续正片？';choices=[choice('highlight-scope','填写高光需求','我选择高光前贴智剪，接下来告诉你分析集数、选片数量和正片接续区间。'),reviewChoice()];}
    else {title='开始前贴与混剪';question='请选择爆款前贴或高光前贴，也可以先提供素材只做预览。';choices=decisions.needs_mode_decision[2]();}
  }
  if(value.status==='needs_decision'&&!choices.length){title='需要你的决定';question=value.requiresNewChargeDecision?'请先核对失败原因及原账务，再决定是否需要新的付费尝试。':value.requiresNewCallDecision?'请先核对拒绝原因和修正方案，再决定是否发起新调用。':'请按当前有效候选确认选择或调整范围。';choices=[choice('review-decision','先看当前情况','请展示当前情况和可选方案，等我决定后再继续。'),reviewChoice()];}
  if(value.status==='resumable'){title=value.actor==='wait'?'正在等待原任务':'继续收取原产物';choices=[choice('check-progress','查看原任务进度','请核对原任务进度并说明当前在等什么，不重新制作。')];}
  if(!choices.length&&actor==='assistant')choices=[choice('continue','继续当前步骤','请按当前项目和我已确认的范围继续；缺少决定或收费确认时明确提示我。')];
  return {title,actor,question,choices,...value};
}

/** Read-only projection: failures must not hide the original action's diagnostic. */
export function projectGuidance(project,context={}){
  try{
    if(project)for(const key of ['assets','operations','plans','highlights','approvals']){
      if(project[key]!==undefined&&(!Array.isArray(project[key])||project[key].some(value=>!value||typeof value!=='object'||Array.isArray(value))))throw Error('Invalid project projection');
    }
    return guidanceFromProject(project,context);
  }catch{
    return {status:'project_state_review_required',title:'先核对项目状态',actor:'assistant',question:null,
      message:'当前项目状态无法可靠读取，暂不能判断下一步。请助手核对原项目文件和最近的错误，保留已有文件与任务记录；不要覆盖项目、重新收费制作或把本次异常当作成功。',
      nextAction:'status',choices:[choice('review-project-state','核对原项目状态','请先核对原项目状态和最近错误，说明可恢复的内容与下一步；不要覆盖项目或重新制作。')]};
  }
}

function guidanceFromProject(project,context={}){
  const p=project?{...project,assets:project.assets||[],operations:project.operations||[],plans:project.plans||[],highlights:project.highlights||[]}:null;
  if(p&&(p.schemaVersion===1||p.legacyOrigin))return decorate({...guideProject(p),recoverableOperations:[]});
  const rows=Array.isArray(context.result?.operations)?context.result.operations:[];
  const confirming=rows.filter(op=>op.confirmationRequired===true);
  if(confirming.length)return decorate({status:'confirmation_required',nextAction:'run',...operationScope(confirming.map(row=>p?.operations.find(op=>op.id===row.id)||row)),...(p?.plans.length?{composeReview:planReview(p)}:{}),message:'公共工具正在等待本次实际收费确认。请助手展示本项范围和实际金额，取得明确决定后通过原确认入口继续；登录授权和预算批准不代替本次确认。'});
  const errorCode=context.errorCode||rows.find(op=>op.error)?.error?.code;
  if(context.action==='doctor'&&context.result?.ready===false)return decorate(accessGuidance(context.result.checks?.find(item=>item.item==='public-cli')?.status));
  if(errorCode&&['LOGIN_REQUIRED','OPERATOR_AUTH_REQUIRED','AUTH_CHECK_FAILED','CLI_NOT_FOUND','CLI_VERSION_UNSUPPORTED','PACKAGE_OR_CLI_UNAVAILABLE'].includes(errorCode))return decorate(accessGuidance(errorCode));
  if(context.result?.status==='needs_update_decision'||context.result?.status==='update_requested')return decorate({status:'needs_update_decision',nextAction:'choose-update',title:'确认版本选择',actor:'user',question:'更新后继续，还是明确继续本次已核对的版本？',message:'当前制作动作尚未执行，请按原安装入口更新，或明确继续本次已核对的版本；不会自动替换安装。',choices:[choice('update','先更新','我选择先按当前安装入口更新，再继续原项目。'),choice('continue-version','继续当前版本','我选择继续本次已核对的版本，请保留原项目与已确认范围。')]});
  const next=guideProject(p);
  if(['MULTIPLE_RESULTS_SELECT_REQUIRED','MEDIA_DECODE_FAILED'].includes(errorCode))return decorate(recoveryGuidance([{status:'qa_failed',error:{code:errorCode}}]));
  if(context.warningCode||typeof errorCode==='string'&&errorCode.startsWith('WORKBENCH_'))return decorate({status:'workbench_unavailable',nextAction:'open-workbench',title:'重新展示原工作台',actor:'assistant',message:p?'项目记录已读取，但工作台展示尚未完成。请助手先核对旧工作台归属与宿主限制，再重新打开原项目页面；暂时不能打开时说明限制及当前业务下一步。':'工作台展示尚未完成。请助手先核对项目位置与可读状态，再恢复原项目页面；暂时不能打开时说明限制和下一步。',question:null,choices:[choice('reopen','重新打开工作台','请核对并重新打开当前项目的工作台，告诉我业务下一步是什么。')]});
  if(errorCode&&!['recovery_blocked','resumable','media_review_required','needs_result_selection','needs_decision'].includes(next.status)&&!['MULTIPLE_RESULTS_SELECT_REQUIRED','MEDIA_DECODE_FAILED','MODE_CONFIRMATION_REQUIRED','EPISODES_INSUFFICIENT','AUTHORIZATION_REQUIRED','QUOTE_REQUIRED','QUOTE_CHANGED','BUDGET_EXCEEDED','STAGE_NOT_PREPARED','NOTHING_TO_RESUME'].includes(errorCode))return decorate({status:'action_blocked',nextAction:'guide',title:'当前步骤需要处理',actor:'assistant',message:p?'当前动作未完成，已有项目记录仍可读取。请助手核对本次错误和最新项目状态，说明缺少的信息及恢复办法；不要自动重试收费，也不改用本地制作替代。':'当前动作未完成，尚不能核实项目是否创建或可读取。请助手核对项目位置、输入和本次错误，明确说明恢复办法；不要覆盖已有文件、自动重试收费或改用本地制作替代。',question:null,choices:[choice('review-blocker','查看阻断原因','请说明当前停在哪里、已完成什么，以及我下一步需要提供什么；不要重新提交制作。')]});
  const recoverableOperations=p?p.operations.filter(op=>pendingStatuses.has(op.status)&&recoverable(op)&&!stoppedCodes.has(op.error?.code)&&!['MULTIPLE_RESULTS_SELECT_REQUIRED','MEDIA_DECODE_FAILED'].includes(op.error?.code)&&op.qa?.decodeStatus!=='failed'&&op.status!=='qa_failed').map(operationView):[];
  const currentIds=new Set(next.operationIds||[]);
  const linkedIds=new Set(p?[...p.plans.map(plan=>plan.operationId),...(p.frontOperationIds||[]),...(p.analysis?.operationIds||[]),...(p.highlightOperationIds||[])]:[]);
  const historical=p?p.operations.filter(op=>pendingStatuses.has(op.status)&&!currentIds.has(op.id)&&(op.modeDecisionId!==p.modeDecision?.id||!linkedIds.has(op.id))):[];
  const historicalRecovery=[...new Set(historical.map(op=>op.stage))].map(stage=>recoveryGuidance(historical.filter(op=>op.stage===stage),p.assets));
  const composeReview=p?.plans.length?planReview(p):[];
  return decorate({...next,...p?{productionMode:modeView(p),recoverableOperations,historicalRecovery,composeReview}:{}});
}
