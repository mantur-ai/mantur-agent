import {
  closeSync,
  existsSync,
  fstatSync,
  lstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readSync,
  rmSync,
  writeFileSync,
  writeSync,
} from "node:fs";
import { dirname, isAbsolute, relative, resolve } from "node:path";
import { deflateRawSync } from "node:zlib";

const CRC_TABLE = Array.from({ length: 256 }, (_, value) => {
  let crc = value;
  for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  return crc >>> 0;
});

export function crc32(buffer, initial = 0xffffffff) {
  let crc = initial;
  for (const byte of buffer) crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ byte) & 0xff];
  return crc >>> 0;
}

export function createZip(target, files) {
  const localParts = [];
  const centralParts = [];
  let offset = 0;
  for (const file of files) {
    const name = Buffer.from(file.name.replaceAll("\\", "/"), "utf8");
    const body = readFileSync(file.path);
    const compressed = deflateRawSync(body);
    const crc = (crc32(body) ^ 0xffffffff) >>> 0;
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(8, 8);
    local.writeUInt16LE(0, 10);
    local.writeUInt16LE(33, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(compressed.length, 18);
    local.writeUInt32LE(body.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    localParts.push(local, name, compressed);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(8, 10);
    central.writeUInt16LE(0, 12);
    central.writeUInt16LE(33, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(compressed.length, 20);
    central.writeUInt32LE(body.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    centralParts.push(central, name);
    offset += local.length + name.length + compressed.length;
  }
  const centralBody = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralBody.length, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  writeFileSync(target, Buffer.concat([...localParts, centralBody, end]));
}

function archiveName(value) {
  const name = String(value || "").replaceAll("\\", "/");
  if (
    !name
    || name.startsWith("/")
    || name.endsWith("/")
    || isAbsolute(name)
    || name.split("/").some((part) => !part || part === "." || part === "..")
  ) {
    throw new Error(`invalid ZIP entry name: ${value}`);
  }
  const bytes = Buffer.from(name, "utf8");
  if (bytes.length > 65535) throw new Error(`ZIP entry name is too long: ${name}`);
  return { name, bytes };
}

function streamFile(path, onChunk) {
  const fd = openSync(path, "r");
  try {
    const size = fstatSync(fd).size;
    const buffer = Buffer.alloc(1024 * 1024);
    let position = 0;
    while (position < size) {
      const bytes = readSync(fd, buffer, 0, Math.min(buffer.length, size - position), position);
      if (!bytes) throw new Error(`failed to read ${path} at byte ${position}`);
      onChunk(buffer.subarray(0, bytes));
      position += bytes;
    }
    return size;
  } finally {
    closeSync(fd);
  }
}

function writeAll(fd, buffer) {
  let offset = 0;
  while (offset < buffer.length) {
    const written = writeSync(fd, buffer, offset, buffer.length - offset);
    if (!written) throw new Error(`failed to write ZIP at byte ${offset}`);
    offset += written;
  }
}

function crc32File(path) {
  let crc = 0xffffffff;
  const size = streamFile(path, (chunk) => { crc = crc32(chunk, crc); });
  return { size, crc: (crc ^ 0xffffffff) >>> 0 };
}

export function createStoredZip(target, files) {
  if (!Array.isArray(files) || !files.length || files.length > 65535) {
    throw new Error("portable ZIP requires 1-65535 files");
  }
  const names = new Set();
  const entries = files.map((file) => {
    const named = archiveName(file.name);
    if (names.has(named.name)) throw new Error(`duplicate ZIP entry: ${named.name}`);
    names.add(named.name);
    if (!existsSync(file.path) || !lstatSync(file.path).isFile() || lstatSync(file.path).isSymbolicLink()) {
      throw new Error(`ZIP source is not a regular file: ${file.path}`);
    }
    const measured = crc32File(file.path);
    if (measured.size > 0xffffffff) throw new Error(`ZIP64 is not supported: ${file.path}`);
    return { ...file, ...named, ...measured };
  });
  mkdirSync(dirname(target), { recursive: true });
  const fd = openSync(target, "wx");
  const centralParts = [];
  let offset = 0;
  try {
    for (const entry of entries) {
      if (offset > 0xffffffff) throw new Error("ZIP64 is not supported for packages larger than 4 GiB");
      const local = Buffer.alloc(30);
      local.writeUInt32LE(0x04034b50, 0);
      local.writeUInt16LE(20, 4);
      local.writeUInt16LE(0x0800, 6);
      local.writeUInt16LE(0, 8);
      local.writeUInt16LE(0, 10);
      local.writeUInt16LE(33, 12);
      local.writeUInt32LE(entry.crc, 14);
      local.writeUInt32LE(entry.size, 18);
      local.writeUInt32LE(entry.size, 22);
      local.writeUInt16LE(entry.bytes.length, 26);
      local.writeUInt16LE(0, 28);
      writeAll(fd, local);
      writeAll(fd, entry.bytes);
      streamFile(entry.path, (chunk) => writeAll(fd, chunk));

      const central = Buffer.alloc(46);
      central.writeUInt32LE(0x02014b50, 0);
      central.writeUInt16LE(20, 4);
      central.writeUInt16LE(20, 6);
      central.writeUInt16LE(0x0800, 8);
      central.writeUInt16LE(0, 10);
      central.writeUInt16LE(0, 12);
      central.writeUInt16LE(33, 14);
      central.writeUInt32LE(entry.crc, 16);
      central.writeUInt32LE(entry.size, 20);
      central.writeUInt32LE(entry.size, 24);
      central.writeUInt16LE(entry.bytes.length, 28);
      central.writeUInt32LE(offset, 42);
      centralParts.push(central, entry.bytes);
      offset += local.length + entry.bytes.length + entry.size;
    }
    const centralBody = Buffer.concat(centralParts);
    if (offset + centralBody.length > 0xffffffff) throw new Error("ZIP64 is not supported for packages larger than 4 GiB");
    writeAll(fd, centralBody);
    const end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0);
    end.writeUInt16LE(0, 4);
    end.writeUInt16LE(0, 6);
    end.writeUInt16LE(entries.length, 8);
    end.writeUInt16LE(entries.length, 10);
    end.writeUInt32LE(centralBody.length, 12);
    end.writeUInt32LE(offset, 16);
    writeAll(fd, end);
    return entries.map(({ name, size, crc }) => ({ name, size, crc32: crc.toString(16).padStart(8, "0") }));
  } catch (error) {
    closeSync(fd);
    rmSync(target, { force: true });
    throw error;
  } finally {
    try { closeSync(fd); } catch { /* already closed after failure */ }
  }
}

function readExactly(fd, position, length) {
  const buffer = Buffer.alloc(length);
  let offset = 0;
  while (offset < length) {
    const bytes = readSync(fd, buffer, offset, length - offset, position + offset);
    if (!bytes) throw new Error(`truncated ZIP at byte ${position + offset}`);
    offset += bytes;
  }
  return buffer;
}

function safeExtractPath(root, name) {
  const normalized = archiveName(name).name;
  const target = resolve(root, normalized);
  const relation = relative(root, target);
  if (relation.startsWith("..") || isAbsolute(relation)) throw new Error(`ZIP entry escapes extraction root: ${name}`);
  return target;
}

export function extractStoredZip(archive, destination, { maxFiles = 1000, maxBytes = 20 * 1024 ** 3 } = {}) {
  if (existsSync(destination)) throw new Error(`ZIP extraction destination already exists: ${destination}`);
  mkdirSync(destination, { recursive: true });
  const fd = openSync(archive, "r");
  const archiveSize = fstatSync(fd).size;
  const extracted = [];
  let total = 0;
  let position = 0;
  try {
    while (position + 4 <= archiveSize) {
      const signature = readExactly(fd, position, 4).readUInt32LE(0);
      if (signature === 0x02014b50 || signature === 0x06054b50) break;
      if (signature !== 0x04034b50) throw new Error(`unexpected ZIP signature at byte ${position}`);
      if (extracted.length >= maxFiles) throw new Error("ZIP contains too many files");
      const header = readExactly(fd, position, 30);
      const flags = header.readUInt16LE(6);
      const method = header.readUInt16LE(8);
      const crcExpected = header.readUInt32LE(14);
      const compressed = header.readUInt32LE(18);
      const size = header.readUInt32LE(22);
      const nameLength = header.readUInt16LE(26);
      const extraLength = header.readUInt16LE(28);
      if (flags & 0x0008) throw new Error("ZIP data descriptors are not supported");
      if (method !== 0 || compressed !== size) throw new Error("portable draft ZIP must use stored entries");
      total += size;
      if (total > maxBytes) throw new Error("ZIP extracted size exceeds the limit");
      const name = readExactly(fd, position + 30, nameLength).toString("utf8");
      const target = safeExtractPath(destination, name);
      mkdirSync(dirname(target), { recursive: true });
      const out = openSync(target, "wx");
      let crc = 0xffffffff;
      let copied = 0;
      const dataStart = position + 30 + nameLength + extraLength;
      const buffer = Buffer.alloc(1024 * 1024);
      try {
        while (copied < size) {
          const wanted = Math.min(buffer.length, size - copied);
          const bytes = readSync(fd, buffer, 0, wanted, dataStart + copied);
          if (!bytes) throw new Error(`truncated ZIP entry: ${name}`);
          const chunk = buffer.subarray(0, bytes);
          writeAll(out, chunk);
          crc = crc32(chunk, crc);
          copied += bytes;
        }
      } finally {
        closeSync(out);
      }
      crc = (crc ^ 0xffffffff) >>> 0;
      if (crc !== crcExpected) throw new Error(`ZIP CRC mismatch: ${name}`);
      extracted.push({ name, path: target, size });
      position = dataStart + size;
    }
    if (!extracted.length) throw new Error("ZIP contains no files");
    return extracted;
  } catch (error) {
    closeSync(fd);
    rmSync(destination, { recursive: true, force: true });
    throw error;
  } finally {
    try { closeSync(fd); } catch { /* already closed after failure */ }
  }
}
