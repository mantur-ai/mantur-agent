# 注册入口

只选择当前明确宿主的链接，无法确认时选 unknown。已有账号使用登录；没有账号由用户选择注册。注册完成后仍需完成同一 CLI 环境的授权。

- [workbuddy](https://hub.mantur.ai/login?from=workbuddy&businessCode=overseas-comic-script-studio-skill)
- [codex](https://hub.mantur.ai/login?from=codex&businessCode=overseas-comic-script-studio-skill)
- [claude-code](https://hub.mantur.ai/login?from=claude-code&businessCode=overseas-comic-script-studio-skill)
- [unknown](https://hub.mantur.ai/login?from=unknown&businessCode=overseas-comic-script-studio-skill)

## 已安装 CLI 的登录指引

在当前宿主执行 ACCESS check，携带 --source workbuddy、--source codex 或 --source claude-code；无法确认使用 --source unknown。未登录时 check 返回 loginInstructions；若另有 quickLoginInstructions 且用户在同一已检查环境执行，优先展示其简短 command/args，无需展开默认环境变量和内部 Node/CLI 路径。跨终端、指定 CLI/配置目录或没有简版时，保持完整 loginInstructions.command/args/env。两种形式都不能省略来源和产品参数；不自行猜测或缩短绑定。命令参数形式为：

- workbuddy: `auth login --from workbuddy --business-code overseas-comic-script-studio-skill`
- codex: `auth login --from codex --business-code overseas-comic-script-studio-skill`
- claude-code: `auth login --from claude-code --business-code overseas-comic-script-studio-skill`
- unknown: `auth login --from unknown --business-code overseas-comic-script-studio-skill`

注册businessCode表示引流Skill产品及独立技能入口，与本次算子调用businessCode分开。连接器由WorkBuddy执行认证指令，固定WorkBuddy来源，认证命令显式传入连接器注册入口码；调用业务上下文不能覆盖注册产品，不借用独立CLI。


默认链接为生产入口。显式测试模式仅使用ACCESS registration/check动态返回的同源入口和完整loginInstructions，不使用本页静态生产链接；见[test-mode.md](test-mode.md)。
