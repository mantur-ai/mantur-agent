import {billingView} from './billing-view.mjs';
import http from 'node:http';
import { readFile, realpath } from 'node:fs/promises';
import path from 'node:path';
import { visibleHighlights } from './plan.mjs';
import { episodeCount,openAsset } from './project.mjs';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { workbenchIdentity } from './workbench-identity.mjs';
import { createSynchronizer } from './synchronizer.mjs';
import { createBalanceMonitor } from './account-balance.mjs';
import { createBalanceQueryMonitor } from './balance-query-monitor.mjs';
import { buildAnalysisDetails } from './analysis-view.mjs';
import { operationSubmission } from './operation-time.mjs';
import { modeView } from './production-mode.mjs';
import { projectGuidance } from './guidance.mjs';
import {sanitizeText} from './diagnostics.mjs';
import {availabilityView,inspectAssetAvailability,buildArtifactView} from './artifact-view.mjs';

const uiDir = fileURLToPath(new URL('../assets/', import.meta.url));
const roles = new Set(['episode', 'ending', 'logo', 'reference', 'front', 'result']);
const states = new Set(['prepared','unknown','running','remote_succeeded','artifact_pending','qa_failed','succeeded','failed','rejected']);
const number = v => Number.isFinite(v) ? v : null;
// User text is untrusted too: redact credentials, URLs and local paths before display.
const label = v => sanitizeText(v,{maxLength:1000,redactPaths:true});
const id = v => typeof v === 'string' && /^[a-zA-Z0-9_-]{1,160}$/.test(v) ? v : null;
const media = a => `/media/${encodeURIComponent(a.id)}`;
const qaView=value=>value&&typeof value==='object'?{metadata:value.metadata===true,container:value.container===true,decode:value.decode===true,decodeStatus:value.decode===true?'passed':['not_performed','failed'].includes(value.decodeStatus)?value.decodeStatus:'unknown',metadataSource:['container','platform+container'].includes(value.metadataSource)?value.metadataSource:null,platformMetadataStatus:value.platformMetadataStatus==='inconsistent'?'inconsistent':null}:null;

const errorMessages = Object.freeze({
  REMOTE_FAILED:'制作任务失败，请在聊天中核对原任务后恢复。',
  NETWORK_REQUEST_FAILED:'连接中断，请在聊天中恢复原任务。',
  DOWNLOAD_FAILED:'成片下载中断，请在聊天中恢复下载。',
  DOWNLOAD_EMPTY:'下载文件为空，请在聊天中重新获取原任务产物。',
  HTTP_503:'服务暂时不可用，请在聊天中恢复当前步骤。',
  ARTIFACT_URL_UNAVAILABLE:'成片下载地址暂不可用，请刷新原任务结果。',
  MEDIA_DECODE_FAILED:'成片解码检查未通过，请在聊天中检查这条成片。',
  MEDIA_METADATA_UNSUPPORTED:'当前文件的媒体信息无法可靠读取，请在聊天中核对文件格式；不会自动重新制作。',
  MEDIA_METADATA_INVALID:'媒体容器结构或参数检查未通过，请核对原文件；已保留原任务和下载记录。',
  MEDIA_METADATA_LIMIT:'媒体信息超出安全解析范围，请在聊天中核对原文件。',
  OUTPUT_GEOMETRY_OR_DURATION_MISMATCH:'成片尺寸或时长与计划不符，需要重新验收。',
  FRONT_OUTPUT_GEOMETRY_MISMATCH:'前贴实际尺寸与生成目标不符，请在聊天中核对原产物；不会自动重新生成。',
  QUOTE_CHANGED:'费用预估已变化，请在聊天中重新确认。',
  FRONT_NO_LONGER_CURRENT:'这条前贴请求已不在当前制作范围中，请在聊天中明确恢复范围后重新准备与报价。',
  COMPOSE_NO_LONGER_CURRENT:'这条合成计划已成为历史记录，不会再次提交；已提交任务可恢复原产物。',
  ANALYSIS_NO_LONGER_CURRENT:'这条分析计划已不在当前范围中，不会重新提交；已提交的历史任务仍可恢复。',
  AUTHORIZATION_REQUIRED:'尚未确认本次制作费用，请在聊天中确认。',
  BUDGET_EXCEEDED:'预计费用超出已确认范围，请在聊天中调整。',
  ASSET_CHANGED:'素材发生变化，请在聊天中重新核对素材。',
  MULTIPLE_RESULTS_SELECT_REQUIRED:'返回了多个视频，请在聊天中选定一个前贴。',
});
const billingLabels=Object.freeze({COMPLETED:'已结算，以账单为准',DEDUCTED:'已预扣，等待最终结算',SETTLED:'已结算，以账单为准',CHARGED:'已计费，以账单为准',PENDING:'尚未结算',REFUNDED:'已退款，以账单为准',TEST_FIXTURE_NOT_BILLED:'本地测试，无真实计费'});
// The browser only receives display text, never command context or confirmation data.
function guidanceView(project){
  const value=projectGuidance(project);
  return {title:label(value.title),message:label(value.message),question:label(value.question),
    actor:['user','assistant','wait','none'].includes(value.actor)?value.actor:'none',
    choices:(Array.isArray(value.choices)?value.choices:[]).slice(0,3)
      .filter(choice=>id(choice.id)&&typeof choice.label==='string'&&typeof choice.reply==='string')
      .map(choice=>({id:choice.id,label:label(choice.label),reply:label(choice.reply)}))};
}
export function projectSnapshot(p,{availability}={}) {
  const assets = (p.assets || []).filter(a => id(a.id) && roles.has(a.role)).map(a => ({
    id:a.id, role:a.role, name:label(a.name), episode:number(a.episode), duration:number(a.duration),
    width:number(a.width), height:number(a.height), displayWidth:number(a.displayWidth), displayHeight:number(a.displayHeight), hasAudio:!!a.hasAudio, size:number(a.size),
    availability:availability?.get(a.id)||availabilityView('unchecked'),
    mediaUrl:!availability||availability.get(a.id)?.status==='available'?media(a):null
  }));
  const clipIds = new Set(p.highlightOperationIds || []);
  const highlights = visibleHighlights(p).map(h => {
    const row={id:id(h.id),episode:number(h.episode),start:number(h.start),end:number(h.end),reason:label(h.reason),score:number(h.score)};
    if(Array.isArray(p.highlightPool)) {
      const op=(p.operations||[]).find(o=>clipIds.has(o.id)&&o.stage==='highlights'&&o.highlightId===h.id);
      const asset=assets.find(a=>a.id===op?.assetId);
      Object.assign(row,{clipOperationId:id(op?.id),clipStatus:states.has(op?.status)?op.status:'not_prepared',clipAssetId:asset?.id||null,clipMediaUrl:op?.status==='succeeded'&&asset?asset.mediaUrl:null});
    }
    return row;
  });
  const front = f => f ? {assetId:id(f.assetId),highlightId:id(f.highlightId)} : null;
  const frontSize = v => v&&['follow_body','custom'].includes(v.policy)?{policy:v.policy,ratio:label(v.ratio),resolution:label(v.resolution),bodyWidth:number(v.bodyWidth),bodyHeight:number(v.bodyHeight),expectedWidth:number(v.expectedWidth),expectedHeight:number(v.expectedHeight)}:null;
  const output = o => ({id:id(o.id),label:label(o.label),front:front(o.front),body:(o.body || []).map(b=>({episode:number(b.episode),start:number(b.start),end:number(b.end)})),operationId:id(o.operationId),duration:number(o.duration),segments:(o.segments||[]).map(s=>({kind:['front','episode','ending'].includes(s.kind)?s.kind:null,assetId:id(s.assetId),episode:number(s.episode),start:number(s.start),end:number(s.end),outputStart:number(s.outputStart),outputEnd:number(s.outputEnd)}))});
  const projectPlan = (v,intent) => ({id:id(v.id),label:label(v.label),intent:label(v.intent ?? intent),revision:number(v.revision),
    packaging:v.packaging?{ending:typeof v.packaging.ending==='boolean'?v.packaging.ending:null,logo:typeof v.packaging.logo==='boolean'?v.packaging.logo:null}:null,
    canvas:v.canvas ? {width:number(v.canvas.width),height:number(v.canvas.height),fps:number(v.canvas.fps)}:null,
    logo:v.logo?{x:number(v.logo.x),y:number(v.logo.y),width:number(v.logo.width),height:number(v.logo.height),opacity:number(v.logo.opacity)}:null,
    outputs: Array.isArray(v.outputs) ? v.outputs.map(output) : [output(v)]});
  const plans = (p.plans || []).map(v=>projectPlan(v,p.intent));
  const currentIds=new Set(plans.flatMap(plan=>plan.outputs.map(o=>o.operationId)).filter(Boolean));
  const currentResultCount=new Set((p.operations||[]).filter(o=>currentIds.has(o.id)&&o.stage==='compose'&&o.status==='succeeded').map(o=>o.id)).size;
  const available=episodeCount(p);
  const frontStyleDecision=p.frontStyleDecision&&['uniform','per_front'].includes(p.frontStyleDecision.mode)?{mode:p.frontStyleDecision.mode}:null;
  const analysisDetails=buildAnalysisDetails(p,{label,id});
  const operations=(p.operations || []).map(o=>({id:id(o.id),stage:['fronts','analysis','highlights','compose'].includes(o.stage)?o.stage:null,label:label(o.label),status:states.has(o.status)?o.status:'unknown',submission:operationSubmission(o),qa:qaView(o.qa),assetId:id(o.assetId),...(o.stage==='analysis'?{analysisDetail:analysisDetails.get(o.id)}:{}),frontStyle:typeof o.frontStyle?.name==='string'?{name:label(o.frontStyle.name)}:null,frontSize:frontSize(o.frontSize),hasError:!!o.error,errorMessage:o.error?(errorMessages[o.error.code]||'当前步骤需要恢复，请在聊天中查看并处理。'):null,estimatedPoints:number(o.quote?.estimatedPoints),billingStatus:Object.hasOwn(billingLabels,o.billing?.billingStatus??o.billing?.status)?(o.billing.billingStatus??o.billing.status):null,billingLabel:billingLabels[o.billing?.billingStatus??o.billing?.status]||'结算状态待核对',actualPoints:billingView(o.billing).actualPoints,prechargedPoints:billingView(o.billing).prechargedPoints,refundedPoints:billingView(o.billing).refundedPoints}));
  for(const operation of operations)if(operation.status==='rejected')Object.assign(operation,{hasError:true,errorMessage:'公开工具明确未受理此请求；请在聊天中核对原因、修正输入，并决定是否发起新调用。',billingStatus:null,billingLabel:'未受理；无本次结算记录',actualPoints:null,prechargedPoints:null,refundedPoints:null});
  const artifacts=buildArtifactView(p,{assets,operations,projectPlan,label,id});
  const mediaRevision=crypto.createHash('sha256').update(JSON.stringify(assets.map(a=>[a.id,a.availability.status]).sort((a,b)=>a[0].localeCompare(b[0])))).digest('hex').slice(0,20);
  const origin=p.legacyOrigin?.environment??(p.schemaVersion===1?p.environment:null);
  const historicalEnvironment=['live','local-test'].includes(origin)?origin:null;
  return {...artifacts,mediaRevision,currentResultCount,id:id(p.id),title:label(p.title),environment:p.environment==='local-test'?'local-test':'unverified',historicalEnvironment,revision:number(p.revision),assets,highlights,plans,
    productionMode:modeView(p),guidance:guidanceView(p),
    frontStyleDecision,
    episodeRequirement:{minimum:3,available,missing:Math.max(0,3-available),ready:available>=3},
    highlightSummary:p.analysis?{requested:number(p.analysis.count),selected:highlights.length,ready:highlights.filter(h=>h.clipStatus==='succeeded'&&h.clipMediaUrl).length,shortage:Math.max(0,(number(p.analysis.count)||0)-highlights.length),...(p.analysis.selectionRequired?{selectionRequired:true,available:Array.isArray(p.highlightPool)?p.highlightPool.length:null}:{})}:null,
    operations};
}

/** Local review and existing-job synchronization; no production submission API. */
export async function startServer({projectDir,loadProject,port=0,control,synchronize,stopSynchronization=()=>{},syncIntervalMs=15000,readBalance,identifyBalance,queryBalance,balanceIntervalMs=30000,deferBalanceStart=false,balanceUnavailableReason,onCloseError=()=>{}}) {
  const root = await realpath(projectDir);
  const workbench={...await workbenchIdentity(root),...(control?{instanceId:control.instanceId}:{})};
  if(control&&(!/^[a-f0-9]{64}$/.test(control.token)||typeof control.instanceId!=='string'))throw new Error('Invalid workbench control');
  const initialProject=await loadProject();
  const legacyBalance=initialProject.schemaVersion!==2||!!initialProject.legacyOrigin;
  const unavailableReason=legacyBalance?'LEGACY_PROJECT_READ_ONLY':balanceUnavailableReason;
  const balance=queryBalance?createBalanceQueryMonitor({queryBalance,unavailableReason})
    :createBalanceMonitor({readBalance,identity:identifyBalance,intervalMs:balanceIntervalMs,unavailableReason});
  const startBalance=()=>balance.start();
  const sync=createSynchronizer(synchronize,{intervalMs:syncIntervalMs});
  const headers = {
    'Content-Security-Policy':"default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; media-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
    'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'no-store',
    'Cross-Origin-Resource-Policy':'same-origin','X-Frame-Options':'DENY'
  };
  const server = http.createServer(async (req,res)=>{
    Object.entries(headers).forEach(([k,v])=>res.setHeader(k,v));
    const fail = (code,message) => {res.statusCode=code;res.setHeader('Content-Type','text/plain; charset=utf-8');res.end(req.method==='HEAD'?undefined:message);};
    try {
      const expected = `127.0.0.1:${server.address().port}`;
      if(req.headers.host !== expected || (req.headers.origin && req.headers.origin !== `http://${expected}`)) return fail(403,'不允许访问');
      if(req.headers['sec-fetch-site'] === 'cross-site') return fail(403,'不允许跨站访问');
      const url = new URL(req.url,`http://${expected}`);
      const send = (body,type) => {res.setHeader('Content-Type',type);res.setHeader('Content-Length',Buffer.byteLength(body));res.end(req.method==='HEAD'?undefined:body);};
      if(req.method==='POST'&&url.pathname==='/api/workbench/shutdown'&&control){
        const token=String(req.headers['x-workbench-control']||'');
        if(!/^[a-f0-9]{64}$/.test(token)||!crypto.timingSafeEqual(Buffer.from(token),Buffer.from(control.token))||req.headers['x-workbench-instance']!==control.instanceId)return fail(403,'不允许操作');
        res.once('finish',()=>{void close().catch(onCloseError);});
        return send(JSON.stringify({stopping:true}),'application/json; charset=utf-8');
      }
      if(req.method==='POST'&&url.pathname==='/api/balance'&&queryBalance){
        if(req.headers.origin!==`http://${expected}`||req.headers['x-workbench-sync']!=='1')return fail(403,'不允许操作');
        res.statusCode=202;return send(JSON.stringify({balance:balance.trigger()}),'application/json; charset=utf-8');
      }
      if(req.method==='POST'&&url.pathname==='/api/sync'&&(synchronize||readBalance||queryBalance)){
        if(req.headers.origin!==`http://${expected}`||req.headers['x-workbench-sync']!=='1')return fail(403,'不允许操作');
        res.statusCode=202;return send(JSON.stringify({sync:sync.trigger(),balance:queryBalance?balance.snapshot():balance.trigger({force:true})}),'application/json; charset=utf-8');
      }
      if(!['GET','HEAD'].includes(req.method)) {res.setHeader('Allow','GET, HEAD');return fail(405,'只读工作台');}
      if(url.pathname==='/api/snapshot'){
        const project=await loadProject(),availability=await inspectAssetAvailability(root,project.assets);
        return send(JSON.stringify({...projectSnapshot(project,{availability}),workbench,sync:sync.snapshot(),balance:balance.snapshot()}), 'application/json; charset=utf-8');
      }
      const staticFiles = {'/':['index.html','text/html; charset=utf-8'],'/app.js':['app.js','text/javascript; charset=utf-8'],'/presentation.js':['presentation.js','text/javascript; charset=utf-8'],'/sync.js':['sync.js','text/javascript; charset=utf-8'],'/style.css':['style.css','text/css; charset=utf-8'],'/mantur-logo.png':['mantur-logo.png','image/png']};
      if(staticFiles[url.pathname]) {const [name,type]=staticFiles[url.pathname];return send(await readFile(path.join(uiDir,name)),type);}
      if(!url.pathname.startsWith('/media/')) return fail(404,'未找到');
      let assetId; try{assetId=decodeURIComponent(url.pathname.slice(7));}catch{return fail(400,'无效媒体');}
      if(!id(assetId)) return fail(404,'未找到媒体');
      const project = await loadProject();
      const asset = (project.assets||[]).find(a=>a.id===assetId && roles.has(a.role));
      if(!asset || typeof asset.relativePath!=='string' || path.isAbsolute(asset.relativePath)) return fail(404,'未找到媒体');
      const {file,info,handle}=await openAsset(root,asset);
      let streaming=false;
      try{
      if(req.aborted||res.destroyed)return;
      const ext=path.extname(file).toLowerCase();
      const mime={'.mp4':'video/mp4','.webm':'video/webm','.mov':'video/quicktime','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.wav':'audio/wav','.mp3':'audio/mpeg'}[ext];
      if(!mime) return fail(415,'不支持的媒体类型');
      res.setHeader('Content-Type',mime);res.setHeader('Accept-Ranges','bytes');
      if(url.searchParams.get('download')==='1') res.setHeader('Content-Disposition',`attachment; filename="media${ext}"; filename*=UTF-8''${encodeURIComponent(path.basename(file)).replace(/['()*]/g,c=>'%'+c.charCodeAt(0).toString(16).toUpperCase())}`);
      let start=0,end=info.size-1;
      if(req.headers.range) {
        const match=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
        if(!match || (!match[1]&&!match[2]) || info.size===0) {res.setHeader('Content-Range',`bytes */${info.size}`);return fail(416,'无效范围');}
        if(!match[1]) {const suffix=Number(match[2]);start=Math.max(0,info.size-suffix);if(suffix<=0)start=info.size;}
        else {start=Number(match[1]);if(match[2])end=Math.min(end,Number(match[2]));}
        if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>=info.size||end<start) {res.setHeader('Content-Range',`bytes */${info.size}`);return fail(416,'无效范围');}
        res.statusCode=206;res.setHeader('Content-Range',`bytes ${start}-${end}/${info.size}`);
      }
      res.setHeader('Content-Length',Math.max(0,end-start+1));
      if(req.method==='HEAD'||info.size===0)return res.end();
      const stream=handle.createReadStream({start,end,autoClose:true});
      streaming=true;
      stream.on('error',()=>res.destroy());res.on('close',()=>stream.destroy());stream.pipe(res);
      }finally{if(!streaming)await handle.close();}
    } catch(error) {if(!res.headersSent)fail(error.code==='ASSET_PATH_INVALID'?403:404,'文件暂不可用，请在聊天中恢复任务');else res.destroy();}
  });
  let closing;
  function close(){
    return closing??=(async()=>{
      const balanceStopped=balance.close();stopSynchronization();
      const stopped=new Promise((resolve,reject)=>{
        if(!server.listening){resolve();return;}
        server.close(error=>error?reject(error):resolve());
        server.closeAllConnections();
      });
      const [balanceResult]=await Promise.all([balanceStopped,sync.close(),stopped]);
      if(!balanceResult.cleanupComplete)throw Object.assign(new Error('余额查询资源清理尚未完成。'),{code:'BALANCE_CLEANUP_INCOMPLETE'});
    })();
  }
  try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});}catch(error){stopSynchronization();await Promise.all([balance.close(),sync.close()]);throw error;}
  sync.trigger();if(!deferBalanceStart)startBalance();
  return {startBalance,url:`http://127.0.0.1:${server.address().port}`,workbench,close};
}
