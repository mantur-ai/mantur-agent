# Mantur Skill 广场渠道约定

本包适配平台现有 Skill 上传、审核、下载规则，不要求服务端增加 CLI 包类型。平台注入的开放接口说明描述底层协议；本包选择 ManturHub CLI 作为该协议的客户端实现，不是另一套认证或计费通道。

- 平台说明中的 API Key、幂等请求、文件上传、任务轮询由 CLI 处理。Agent 通过包内 ACCESS 转发，不读取凭据文件、不要求用户粘贴 Key、不另写 HTTP 调用。准备和执行步骤见下文与 [CLI 工具合同](cli.md)。
- 平台注入的积分是上传时快照；执行时仍通过 CLI 获取当前报价并遵守费用确认，不依据快照跳过确认或自动重试。
- 上传后的顶层 version 由平台管理（首次通常 0.0.1，后续按 current 自动递增 patch）；metadata.source_version 标识本仓库发行版本。两个编号含义不同，不据此迁移项目或判断业务 runtime/schema 兼容性。
- 平台重写 SKILL.md 并归一化 ZIP 路径，下载包的摘要不是上传源 ZIP 摘要。工作项目仍保存在用户选择的工作区，平台分发并不代表云端执行脚本。

# 通用独立技能接入

通用Agent、Mantur Skill广场下载的技能与WorkBuddy独立技能使用同一种接入：复用Agent实际执行命令环境中已安装的CLI和登录态，不维护另一套Skill私有安装或产品登录目录。需要Node>=20、本地文件/命令权限和正式站点网络权限；npm只在安装或升级CLI时需要。远程执行环境不一定能访问用户电脑上的CLI；缺少运行能力时暂停说明，不用对话模拟调用。先读 [access.md](access.md)。

## 首次实际调用前检查

仅梳理需求或读取已有报告时跳过。准备调用算子时：

1. 检查`node --version`。缺失或低于20时，引导用户安装受支持的Node（https://nodejs.org）并重启命令环境，不自动下载执行安装脚本或使用sudo。
2. ACCESS替换为本包`scripts/access.mjs`的绝对路径，执行：

```bash
node "ACCESS" --source HOST check
```

被其他业务复用时在check前加入`--business-code BUSINESS`，或由当前调用进程提供MANTURHUB_BUSINESS_CODE；显式参数优先，缺失才取包的默认业务。check的invocationAttribution区分businessCode与skillCode，bindingArgs保留业务上下文。登录引流使用Skill产品id加-skill（新归因包），旧profile仍用原产品id，不用调用业务覆盖。

HOST替换为当前实际宿主workbuddy、codex或claude-code；无法确认使用unknown，普通终端为cli。每次执行明确传入，不从下载包、安装目录或--client推断，不写全局账号配置。支持归因的profile v2缺少宿主会停止。

check从当前PATH定位首个manturhub，要求CLI 1.2.10及以上正式版；配置目录沿用MANTURHUB_CONFIG_DIR，未设置时使用当前用户`.manturhub`。只调用本地`auth status --json`，不安装、不登录、不联网准备Key，不读取或复制凭据文件。检查会报告cliPath、configDir、baseUrl、status和bindingArgs；v2还报告source，未登录时生成loginInstructions和registrationUrl；不扫描其他安装/账号目录，遇到错误不尝试另一个CLI。

3. 按结果处理：

| 检查结果 | 处理 |
| --- | --- |
| CLI缺失/低于最低版本 | 提示用户在同一执行环境安装或升级；已有合格较新版不降级 |
| LOGIN_REQUIRED | v2同一已检查默认环境优先展示quickLoginInstructions；跨终端或没有简版则完整使用loginInstructions，始终保留from/businessCode；旧profile使用带来源注册链接。浏览器完成后重新check |
| OPERATOR_AUTH_REQUIRED | 说明CLI将为现有账号准备算子Key；获准后执行下方authorize，再check |
| READY | 复用现有登录态，进入业务；不重复登录或准备Key |
| 站点、身份模式、原生依赖或状态异常 | 停止并按错误修复；不静默切换站点、账号或清理凭据 |

CLI安装/升级指引（由用户执行，或另获明确安装授权后执行；不是check的自动动作）：

```bash
npm install -g @manturhub/cli@1.2.10 --include=optional --registry=https://registry.npmjs.org
```

使用已验证版本，不追latest。保留optional dependencies；更换Node/CPU架构需核对CLI原生依赖。权限错误时引导修复用户级Node/npm环境，不自动sudo。安装后重启宿主命令环境再check。

登录指引优先使用check额外返回的quickLoginInstructions.command/args，前提是用户在同一已检查命令环境执行；默认例子为 manturhub auth login --from HOST --business-code PRODUCT-skill。这个简版由check根据当前CLI发现方式、配置目录与状态决定，不是模型手动删除环境变量的结果。跨终端、指定CLI/配置目录或没有简版时，保留完整loginInstructions.command/args/env。两种形式都携带--from当前宿主与--business-code当前包的注册入口编码，不能改成不带来源的普通auth login。无浏览器交互时只追加--no-browser，展示授权链接并保留进程等待完成；Skill不自动发起登录。已有账号登录，未注册用户在网页选择注册；注册不会自动授权CLI。没有CLI时执行node "ACCESS" --source HOST registration取得引流链接，或读取[注册入口](registration.md)，不安装、不联网、不读凭据。不要在独立技能使用`--workbuddy`。用户管理共享CLI的登录/登出，适配器不提供install/login/logout。

展示前逐项核对登录参数：--from 与当前 check.source 相同，--business-code 与 check.businessCode（注册上下文，非 invocationAttribution.businessCode）相同，选择的指令及适用环境使用返回值。不能把 bindingArgs 中用于调用的业务 A/B 拼到登录命令；缺字段先重新 check，不给出不完整的登录替代命令。后续操作提示登录失效时，使用它返回的登录指引或重新 check；不要根据一条简短错误自行拼普通 auth login。此约束适用于归因 profile；旧 profile 仍按带来源注册链接处理，不向旧 CLI 增发选项。

## 固定检查后的入口

首次check完成后，简述当前站点和CLI环境；无歧义时无需反复询问复用。后续authorize、describe、run及resume使用check返回的bindingArgs（当前宿主、调用业务和非敏感路径）。下面示例省略业务选项，实际执行应完整使用返回数组；将CLI_PATH和CONFIG_DIR替换为返回的绝对路径：

```bash
node "ACCESS" --source HOST --existing-cli "CLI_PATH" --config-dir "CONFIG_DIR" authorize --approve-key
node "ACCESS" --source HOST --existing-cli "CLI_PATH" --config-dir "CONFIG_DIR" check
node "ACCESS" --source HOST --existing-cli "CLI_PATH" --config-dir "CONFIG_DIR" exec -- doctor --json
```

authorize仅在已登录但算子Key未就绪且用户批准时执行：由CLI通过一次describe按需准备Key，不执行付费算子。已有同任务授权无需重复询问；失败停止，不反复创建。check只证明本地状态，不能保证远端Key没有撤销。

可以直接传成对的绝对路径来检查用户明确指定的CLI/配置目录；与环境变量冲突时停止，不悄悄覆盖。所有使用同一配置目录的工具共享账号与恢复记录，不存在产品级隔离；路径固定也不等于账号锁。

旧包私有环境中的未决任务必须回到原CLI/配置目录及原账号恢复，可用上述显式路径；不迁移/删除旧凭据，不在新默认环境重提。连接器目录由宿主管理，独立入口不借用；同一需求只选择一个入口，不能双跑。

## 业务调用

所有业务工具示例经ACCESS的`exec -- <CLI参数>`执行，携带同一bindingArgs；project/research返回的cli.args原样传递，不直接执行其cli.command。按 [cli.md](cli.md) 处理费用、结果与原任务恢复。用户项目放工作区，不写Skill安装目录；仅记录必要的非敏感接入路径，不把机器路径写入发行包。


## CLI 新版检查与升级

最低兼容版本为 CLI 1.2.10，初次安装和用户批准的升级使用 `@manturhub/cli@1.2.10`。CLI 1.2.10 是本包的回归基线，不是安装上限。每次开始使用先运行 ACCESS check；生产包额外返回 cliUpdate 和 upgradeInstructions。检查仅查询 npm 官方 latest 元数据，成功缓存24小时，失败缓存5分钟；查询失败时已满足最低版本的 CLI 可以继续。可设置 MANTURHUB_DISABLE_SKILL_CLI_UPDATE_CHECK=1 关闭新版查询，最低版本校验仍保留。

发现 UPDATE_AVAILABLE 时向用户展示本地版本、最新版及 Node 要求；用户确认后，由当前 Agent 自动执行 upgradeInstructions 的 command/args。执行前用同一 Node/npm 的 `npm root -g` 核对结果与 verifyGlobalRoot 指向同一个 CLI 包；显式选择的 CLI 或非全局安装由原安装方式升级，不能改用另一个 PATH 入口。指引的 configDir 和 cliPath 用于核对，不读取、复制或删除凭据。`--engine-strict` 防止装入当前 Node 不支持的版本。

升级放在新任务开始前完成；存在未决调用或费用确认时先沿原环境恢复，不在 exec/resume 期间更新。升级后重新执行同一 check，确认 CLI 路径、站点和配置目录一致且版本满足最低要求，再复用新返回的 bindingArgs。失败停止，不使用旧确认令牌重提，不自动切换账号或站点。连接器只提示用户通过宿主重新初始化/更新，由 cli.json 安装 latest；Skill 不直接升级宿主管理的环境。
