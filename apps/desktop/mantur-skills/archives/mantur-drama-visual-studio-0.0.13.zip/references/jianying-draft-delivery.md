# 剪映草稿交付与本机安装

这是 Skill 包内的本地确定性动作，不是远端算子或剪映 GUI 导出 API。用户要求导出即授权本机安装，不需再执行第二条导入命令；同时保留项目内便携 ZIP。

候选冻结、交付版本选择与两个导出动作共享选择计划的规则统一由[视频选片合同](video-result-selection.md)定义；本文件只规定剪映打包和本机安装。

## 入口

```text
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" export-jianying-drafts completed-videos.json
```

- `--output-dir deliverables/jianying`：项目内 ZIP 输出目录，亦为默认值。
- `--target-platform windows|macos`：默认当前系统；跨平台只生成包。
- `--drafts-dir <目录>`：覆盖默认草稿根目录。
- `--package-only`：跳过安装。用户说“不要改剪映目录”时必须使用。
- 完成视频后，只有用户当次明确选择剪映交付才调用 `export-jianying-drafts`；初始化、doctor 和 run 不保存交付计划。

默认目录：Windows 使用实际环境变量 `%LOCALAPPDATA%\JianyingPro\User Data\Projects\com.lveditor.draft`；macOS 使用 `~/Movies/JianyingPro/User Data/Projects/com.lveditor.draft`。本机原生自动安装不查询 Windows 注册表或 macOS 应用包，而是在创建输出目录、ZIP、编号预留、发布／交付记录和快照刷新前，要求默认或 `--drafts-dir` 指定目录已经存在且为安全目录。目录缺失时返回 `JIANYING_DIRECTORY_NOT_FOUND`，本次不产生任何上述新产物，也不改已有交付：

> 未找到本机剪映草稿目录。这通常表示尚未安装剪映，或安装后还没有打开过。请先从剪映官网下载安装，并至少打开一次剪映；完成后告诉我“继续导出剪映草稿”。

不得猜测其他磁盘或创建虚假的应用资料目录。用户回复“继续导出剪映草稿”后，在目录已就绪的前提下重跑同一导出及当前选片计划，不重新生成视频。`--package-only` 和跨平台导出跳过目录预检；目录存在只代表自动安装目标可用，不等于应用已核实或打开验收通过。

## 输入与完成门禁

5C 衔接：与按集 ZIP 复用交付门禁。新 fileId 报告只导出按交付选择规则确定且技术证据、血缘及真实尾帧有效的 Run；不是最新尝试、也不是任意可预览视频。打包前及发布前各复核一次，源变化时拒绝新发布，旧草稿和包保留。导出入口不改生成器格式、视频生产门禁或前端。

输入 JSON 使用 `schema_version=1`、`project_name`、`episodes[]` 和 `clips[]`：

```json
{
  "schema_version": 1,
  "project_name": "示例漫剧",
  "episodes": [{"episode_number": 1, "expected_clip_ids": ["CLIP-EP01-001"]}],
  "clips": [{
    "clip_id": "CLIP-EP01-001", "episode_number": 1,
    "scene_index": 1, "clip_index": 1, "status": "completed",
    "video_path": ".pipeline-state/results/videos/EP01/CLIP-EP01-001.mp4",
    "sha256": "64-lowercase-hex", "planned_duration_seconds": 10
  }]
}
```

- 按 episode、scene、clip 排序；位置和 Clip ID 唯一，完整目标集合同时与当前分镜报告核对。
- 每个 Clip 必须通过最新 Compiler 完成门禁：交付选定 Run、本地视频、真实尾帧、MIME、哈希和关联一致。不能仅相信输入的 completed。
- 仅接受项目内普通非空视频；禁止越界、父目录链接、远端 URL 和哈希不符。
- 使用包内纯 JavaScript 解析 MP4/MOV 的真实时长、尺寸、编码、帧率及音轨；计划时长只用于审计。
- 画布按首个视频选择最近的受支持尺寸，素材保留原尺寸和统一默认变换，允许混合尺寸。单主视频轨连续排列并保留源音轨，不添加转场、字幕、背景音乐或独立音频。

## 格式与幂等

名称规则（2026-09-17 更新）：ZIP 文件直接放在输出目录，不套哈希子目录；ZIP 内文件夹、剪映显示名称和实际安装目录统一为 `<剧名>-EPxx-剪映草稿`。成功后再次导出创建 `…剪映草稿（1）`、`…剪映草稿（2）` 等新编号，ZIP 使用对应同名文件。不覆盖旧包或用户编辑。按输出文件与安装目录现有最大编号分配；本机根目录锁和私有编号预留避免不同项目同名并发碰撞。内部内容摘要与每次导出的身份仍保存在私有记录。旧哈希目录保留，不直接改写剪映保存或加密后的时间线；新导出使用新命名。

新格式为 `jianying-windows-portable-v2`、`jianying-macos-portable-v2`。`5.9.0` 是生成格式版本，不是应用版本要求；不再按应用 ≥6.0 一律拒绝，也不宣称所有版本已实机兼容。

```text
<剧名>-EPxx-剪映草稿（可选编号）/
├── config.json
├── draft_content.json
├── draft_info.json
├── draft_meta_info.json
├── material/import/EPxx-CLIPxx.mp4
├── manifest.json
├── validation-report.json
└── 导入说明.txt
```

Windows 的 draft_info 为简短元信息，macOS 为完整时间线副本；两者都有完整素材库和 config。草稿 ID、素材 ID 和时间线引用跨文件一致。路径使用 `##_draftpath_placeholder_0E685133-18CE-45ED-8CB8-2904A212EC80_##`，安装时保留该机制，不写开发机目录。

内容身份包含项目 ID、集数、平台、生成器格式、排序后的 Clip 身份与视频哈希；每次成功后新导出另分配身份、编号和草稿 ID。未完成发布记录绑定内容、当前需求、编号及原包；中断后恢复该编号与包，不新增重复草稿。安装失败仍重试原包，来源变化或包被篡改则阻断。旧格式支持历史回读，但新导出不复用旧缓存；旧包需重新导出后安装。

## 安装与重试

固定顺序：校验项目 ZIP → 取得草稿根目录级锁 → 唯一暂存目录 → 复制并逐文件回验 → 原子改名 → 安装收据。

不修改 root_meta_info.json，由剪映发现新草稿。不结束剪映进程，返回“已安装，可刷新草稿列表或重新打开剪映”。目标及父目录不得是链接；重复安装校验收据、内容身份和标记，不覆盖或恢复用户编辑、保存甚至加密后的 JSON。收据缺失或身份冲突时保留目录并报告 JIANYING_INSTALL_CONFLICT。

通过前置目录预检后，若目录在打包／安装期间被删除、权限变化或发生其他竞态，失败仅清理本次暂存目录，不删正式草稿或已经生成的有效 ZIP。安装失败用返回 ZIP 重试，不重新生成视频：

```text
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" import-jianying-draft "<项目内ZIP>" --drafts-dir "<现存草稿根目录>"
```

兼容接受旧 `--confirm-write` 和 `--app` 参数，但不再要求或使用它们探测应用；导出与重试共用安装模块。重试时目录缺失返回与前置预检相同的用户文案，并保留原包。

## 交付记录与回复

- 包状态 ready 表示目标 Clip、完整包结构、素材哈希、引用和连续时间线通过校验。
- 安装状态独立为 not_requested/pending/installed/failed。安装收据与完整目录只保留在 Runtime 私有权威记录和聊天回复。
- 应用验收独立为 pending/passed/failed；未在剪映中检查可见性、播放、顺序、源音轨及保存重开时保留 pending。
- 交付记录原子合并并刷新快照；安装字段可选且脱敏，不在快照暴露项目外目录，不改变只读 API。
- 默认回复分别给出 ZIP 位置、实际安装位置或安装错误、是否复用、应用验收结果。没有 macOS 实机验收时明确未实测，不沿用 Windows 结论。
