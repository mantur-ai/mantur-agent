import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url));
const hash=crypto.createHash('sha256');
function capture(directory){
  for(const item of fs.readdirSync(path.join(root,directory),{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){
    const relative=path.join(directory,item.name);
    if(item.isDirectory())capture(relative);
    else if(item.isFile()){hash.update(relative);hash.update('\0');hash.update(fs.readFileSync(path.join(root,relative)));hash.update('\0');}
  }
}
const entry=fs.readFileSync(path.join(root,'SKILL.md'),'utf8');
hash.update(entry);
for(const directory of ['scripts','assets'])capture(directory);
// Capture once: a running viewer must never advertise newly installed code.
// Channel packaging owns release metadata; source checkouts may be unversioned.
const frontmatter=/^---\r?\n([\s\S]*?)\r?\n---/.exec(entry)?.[1]||'';
const version=frontmatter.match(/^\s*source_version:\s*["']?(\d+\.\d+\.\d+)["']?\s*$/m)?.[1]
  ||frontmatter.match(/^\s*version:\s*["']?(\d+\.\d+\.\d+)["']?\s*$/m)?.[1]||null;
const buildId=hash.digest('hex');
export async function workbenchIdentity(projectDir){
  const real=await fs.promises.realpath(projectDir);
  return {version,buildId,projectKey:crypto.createHash('sha256').update(real).digest('hex')};
}
