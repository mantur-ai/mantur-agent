# 本地项目运行

改编补证据用`source-facts`，候选核对用`check-facts`，资产/蓝图确认前用`check-upstream`；格式、边界和示例见[关键源事实](source-facts.md)。三者不修改state或调用算子；第一项输出待确认配置，经既有reopen应用，后两项检查绑定与引用，不执行语义审校，也不自动确认产物。

## 边界与启动

脚本只管理本地文件，无外部依赖或网络请求。算子调用、上传、费用与恢复遵循 [工具合同](cli.md)，模型执行与结算在服务端。Agent 负责理解需求、展示、取得用户确认和检查正文。不要把本地 callId 当作恢复 ID 或服务端 jobId。

CLI 纳管安装后的 `skill doctor/run/exec` 由随包 `skill-runtime.json` 进入 `scripts/launch.mjs`。doctor 只检查本地安装完整性；run 对空项目展示配置引导，对已有项目读取状态，不自动初始化、上传或生成。若是手工安装，直接按下列本地命令操作；不伪造 CLI 安装记录。入口出错先检查安装是否完整，按 [工具合同](cli.md) 处理 CLI 检查。

项目schemaVersion=8。安装版本读取随包scripts/project.mjs的RUNTIME声明；state.json中的runtimeVersion只记录项目最近一次写入版本，不据此推断安装版本。兼容读取v1–v8；首次写入或旧版首次export保存新revision，保留回执、账务、对象及旧导出。旧于schema8的脚本不能读写v8，防止忽略误报解除证据、局部修订/连续性门禁、回退到错误配置或把可选审校重新变成强制调用；不降级。升级不主动审校或重提任务，已有pending仍按原callId恢复，未开始的旧SCAN改为可选，旧FIX缺联合复扫授权时需另行确认或跳过。旧SCAN缺轮次视为0，缺有效签名/覆盖的报告不冒充当前已审校。旧改编缺sourceScope仍显示未知，新源稿分析须新建确认范围的项目。

逐集新增`issues/triage/issue-decision`本地警告台账，`revise-local`精确修订及`check-continuity`后续核对，完整格式单一维护在[警告与局部纠偏](warnings-and-revisions.md)。next通过qualityAdvisories披露未分诊和待复核建议，默认不阻断逐集生成；真实证据已确认的CORE冲突、修改后连续性问题或用户明确暂停才返回issue-decision。continuity-check需检查修改集至当前末集的正文及快照，不自动改后续集。工作来源确认可保留未核实建议并继续成品；最终质量接受仍需人工检查和逐ID确认剩余问题。本地export始终允许披露未核对稿。

下文 `RUNTIME` 表示当前 Skill 目录内 `scripts/project.mjs` 的绝对路径，`PROJECT` 表示用户工作目录下 `.mantur-script/<project-id>` 的绝对路径。用 Node 执行；替换占位符并正确引用带空格的参数，不依赖当前工作目录。工具运行条件由工具合同提供。

```bash
node "RUNTIME" --help
node "RUNTIME" init --project "PROJECT" --config "项目配置.json"
node "RUNTIME" status --project "PROJECT"
node "RUNTIME" next --project "PROJECT"
node "RUNTIME" plan --project "PROJECT"
```

项目配置由AI在用户确认两项语言与范围后生成，不让用户手写。未指定时推荐中文工作稿＋中文成品稿，未确认不init并开始调用；推荐不由脚本自动填入。以下是用户已确认中文双稿的原创示例（配方代码/摘要应从已确认的配方绑定获取；不要随意生成摘要）：

```json
{
  "name": "港湾档案",
  "mode": "CREATE",
  "brief": "美国市场悬疑漫剧，中文工作稿、中文成品；女主找出钟楼事故的证据，两集完整短篇，第二集揭示关键证据。",
  "targetMarket": "US",
  "languagePlan": { "workingLanguage": "zh", "targetLanguage": "zh" },
  "carrier": "VERTICAL_COMIC",
  "episodeCount": 2,
  "targetWordsMin": 400,
  "targetWordsMax": 800,
  "deliveryWordsMin": 400,
  "deliveryWordsMax": 800,
  "recipeBindings": []
}
```

`recipeBindings: []` 是明确不绑定配方，不是默认忽略配方。业务需要配方时用 [operators.md](operators.md) 的确认绑定。`recipeBindings` 只放适用所有阶段的公共配方；算子专用配方放 `operatorRecipeBindings: {"op.script.review": [{"code": "rcp.script.webtoon-redline.v1", "contentDigest": "80b717647df7d90775399485c8fa34fdfdc3a19a62413a1109a04379e84afe7c"}]}`。同一调用的公共与专用绑定不能重复 code；同一专用配方可绑定多个适用算子，但全项目的同 code 摘要和参数必须一致。适用范围仍以服务端为准。配置会锁定到项目，脚本不会自动升级配方。可选 `concept: {genre, audience}`、`assets: {namingConstraints}`、`episode: {contentConstraints}` 的值按线上 Schema 组织。改编配置改为 `mode=ADAPT`，增加 `source: {adaptationGoal: "LOCALIZE_OVERSEAS", sourceLanguage: "zh"}`，可按 Schema 加 `protectedElements/allowedChanges`。不把原稿、文件路径、Key、Token 或签名 URL 写入配置。

## 配方和配置变化

新项目必须先确认[两项语言选择及本地化费用](languages.md)，以`languagePlan`初始化，不同时传`outputLanguage`。中文双稿只是推荐，缺语言字段仍报错，不自动补成任何组合。工作稿预算使用targetWordsMin/Max；成品预算使用deliveryWordsMin/Max，两组均100–5000。同语种预算相同，本地复制而非自动改稿。只含outputLanguage的旧项目继续单稿，不重新推荐或自动增加成品任务。

`plan`及导出的执行计划列出实际`languagePlan`与`localization`：`additionalCalls`为完整项目额外LOCALIZE次数，同语种为0、异语种为集数；`additionalCostCredits`同语种为0，异语种为null且`quoteStatus=AWAITING_LIVE_QUOTES`（待实时报价，不是免费）。它不联网、不报价，也不证明用户已同意。基础计划不是剩余任务清单，不能因重看plan而重跑已完成集数；只做前期或工作稿时说明本次不执行本地化。

配置不能手改；仅用户已确认的brief、concept、assets、episode约束可通过[上游恢复](recovery.md)预览/修订并撤下受影响下游。配方、模式、语言、集数、源稿参数/范围等仍锁定，不支持原地迁移。若服务端摘要不匹配、配方已停用或必需参数发生不兼容变化，停止新调用并先处理旧 pending；保留原项目和费用事实，向用户说明差异。只有用户明确同意，才按新合同规划迁移或建立新项目、重新确认必要输入与费用。不得手改 config、state 或不可变对象，不自动导入旧产物作为新版本成功结果，也不自动重新运行付费阶段。

## 一次推进的确定步骤

1. `next` 若返回 `operator`，通过 ACCESS 执行 `describe <operator> --json` 核对线上合同。随后 `prepare`，它从已保存的真实成功输出自动组装参数，返回 callId、inputFile 和 CLI 参数数组。
2. 普通调用或源稿绑定完成后，返回的 cli.args 原样交给 `node "ACCESS" exec -- <cli.args>`，不要直接运行 cli.command；不要改生成的 input.json。source-analyze 先按下节上传并绑定 fileId；报价、确认都使用同一份固定 JSON，不追加 `--file`。
3. 分别保存 CLI **实际退出码**、原始 JSON stdout 和原始 stderr，优先用 `record --stderr` 读取调用恢复 ID，避免手工抄错。非交互模式报价确认在 stderr，不能把整个 stderr 当任务 JSON 导入。项目脚本不保存确认令牌。
4. 使用 `record` 导入；看 `next`，到暂停点先 `export` 并展示文件，得到真实用户答复再 `answer`。不要循环绕过停点。

```bash
node "RUNTIME" prepare --project "PROJECT"
# 运行返回的 manturhub run <operator> --json-file <inputFile>（不要把此注释当命令）
node "RUNTIME" record --project "PROJECT" --call "本地callId" --exit-code 0 --result "CLI的stdout.json" --stderr "同一次run的stderr.txt"
node "RUNTIME" export --project "PROJECT"
node "RUNTIME" answer --project "PROJECT" --decision "真实方案ID" --note "用户明确选择了这个方案"
```

### 源稿准备（仅ADAPT）

先按[改编](adaptation.md)检查、选段并确认`sourceScope`，将它和`source`一同放入新项目配置；不发给算子作为新字段。

```bash
node "RUNTIME" prepare --project "PROJECT" --source-file "已确认的UTF-8原稿.txt"
# 若文件由source.mjs select产生，则同一次prepare增加：
# --source-selection "已确认的UTF-8原稿.txt.scope.json"
```

prepare再次检查文本上限，拒绝发生在创建call/pending之前；通过后冻结上传字节到`source-files/<sha256>.<ext>`，状态保存检查与可选选段凭证。原文件后续修改不改变本次绑定；项目内副本也不可手改。该目录包含用户原稿，不入Git、不自动分享。`sourceUploadRequired=true`时尚无可执行的算子cli参数，先把返回的 `sourceUpload.cli.args`（upload、绝对路径、--json）通过 ACCESS 执行，保留 check 的 bindingArgs/bindingEnv 及 sourceUpload.cli.accessArgs。不改用另一终端身份、配置或测试环境。

保存这一次上传的真实 JSON stdout，再绑定到同一个本地 callId：

```bash
node "RUNTIME" bind-source-upload --project "PROJECT" --call "prepare返回的callId" --upload-result "这次上传的stdout.json"
```

绑定核对 AVAILABLE、fileId、SHA256、大小和冻结原文，只有一致才把fileId写入未报价的input.json，返回正式cli.args。之后报价与确认原样使用，不能重新上传、从共享缓存读取另一个ID或手改输入。相同回执重放幂等；不同fileId即使文本相同也不能覆盖已绑定ID。两个项目分别保存自己的上传回执并明确对应callId，不按文件名/完成顺序/文本哈希猜测所属项目。只保存公开身份摘要，不把上传下载链接写入项目或导出。

上传失败或中断先处理原上传回执，不用 `record` 把上传错误当算子失败；未绑定前不能报价。旧在途调用不自动迁移、不重写原输入：已经报价/受理的继续原回执恢复；确证未受理且用户决定重新准备时，才采用新上传流程。

只有既有fileId且无法取得本地文件时，用户须明确确认文件身份、范围及本地容量未验证，再使用：

```bash
node "RUNTIME" prepare --project "PROJECT" --params "仅含sourceFileId的JSON文件" --source-unchecked-note "用户确认的文件身份与本地容量未验证原因"
```

此分支标为REMOTE_UNCHECKED，不得用它绕过已知超限。远端ID不能与source-file/选段凭证混用。范围、检查和历史未检查状态可通过status与导出的`源稿范围.md`查看；原始算子结果不加伪造覆盖字段。

源稿分析、资产和蓝图停点的 decision 是 `confirm`；每五集中途抽检是 `continue`；创意选择必须用真实 ID，不用展示序号。`--note` 记录用户原意，不能伪造批准。脚本不能证明用户实际同意，AI 仍必须先取得授权。

蓝图若返回`readthroughReport.sourceDecisionChecks`，其中未解除的`CONFLICT`会在停点展示并阻止confirm及新分集调用；`APPLIED`仍须逐条比对实际拍点，旧结果缺清单也不代表已核对。实际拍点符合已批准改编而仅自检误报时，先按[误报解除](source-facts.md#蓝图误报的明确确认与解除)完整举证、预览、取得用户针对该项的明确许可，才能执行`resolve-blueprint-conflict`；不会改原CONFLICT、自动确认蓝图或发起收费调用。未确认蓝图导出为“蓝图待确认稿”，确认后才称“蓝图确认稿”。真实冲突用[上游恢复](recovery.md)定位最早偏离阶段，预览并取得用户决定后重开；不手改已存结果，不把锁定产物当作用户必须遵从的要求。

源稿风险包含`requiresConfirmation=true`时，逐项展示`id/evidence/question`，取得用户处理决定后创建澄清JSON（不是改写源稿分析），例如：

```json
[{"riskId":"源稿输出中的真实风险ID","decision":"用户明确同意的处理方式，不能用模型建议代替"}]
```

```bash
node "RUNTIME" answer --project "PROJECT" --decision confirm --source-decisions "源稿澄清.json" --note "记录真实用户答复与改编边界"
```

所有需确认风险均要有非空决定，未知/重复ID会被拒绝；仅源稿确认阶段能使用此参数。未明确解决的矛盾不填写“同意全部”来放行。无此类风险可照常confirm，但仍需人工检查源稿因果及`next.namingBoundary`，先解决保留原名与硬禁名的冲突。决定保存在本地视图，随之后的`requirements`传至方案、资产、蓝图、分集、SCAN/FIX，原始分析保持不变。checkpoint/undo会同时恢复对应决定；已推进项目可经确认`reopen --from source`重开源稿确认点，不要求已有检查点，也不重新分析源稿。完整流程和配置修订范围见[上游恢复](recovery.md)。

人工发现分析漏报时，不编造一个模型风险ID。将人工风险另存为数组，每项只含`id`（`MANUAL_SOURCE_`前缀加1–100位字母/数字/下划线/短横线）、`description`、`evidence`、`question`；后三项为1–2000字符，evidence引用原文及位置，最多100项。然后在同一次源稿确认中增加`--source-risks "人工源稿风险.json"`，并在`--source-decisions`中逐ID记录真实决定。原模型风险不能替换、删除或覆盖；不能借此改写锁定配置/改编授权范围。runtime保留独立人工记录，仅向下游sourceAnalysis输入副本追加标为`origin=CALLER_REVIEW`的风险；原始分析及源稿事实不变。导出摘要披露人工风险与澄清，checkpoint/undo一并恢复。它不是最终质量接受或收费重试授权。

prepare会把锁定brief、命名/内容约束、原始保留/可改边界、正文长度和源稿澄清构造成requirements。ADAPT在brief中附加已确认源稿范围和未覆盖内容（合计仍≤12000字符），沿现有requirements.brief及concept.brief传递，不篡改sourceAnalysis；旧项目未记录范围时明确注明。允许调整不是要求一定调整，也不取消保护项。它不会添加已准备调用的新字段；未决调用仍用原输入恢复。使用新prepare前通过describe确认该字段可用，不能临时删除它来兼容旧服务。

达到用户本次指定阶段就 export 并停止，不因 next 返回后续算子而继续。比如只要源稿分析可保留源稿确认停点；只要三个方案可保留选题停点。next/status/export 不发起算子调用，查看已有项目无需新建项目或重复生成。立项配置仍有必需的集数/字数等字段，缺失时先给出待确认规划，不能称支持“零配置单阶段调用”。长季仅写前几集时仍保存原目标集数，导出是未完稿。整季方案/蓝图范围与本轮正文试写范围分开说明：规划全季并不授权写完全季，也不与只试写若干集冲突；模型把这两者误报为冲突时记录说明，不擅自缩小episodeCount或扩大调用范围。

### 错误、篇幅与费用的阅读提示

- `record` 保留公开 `standardError` 的 code/category/supportId/message/suggestion/suggestedActions 等白名单字段，随 status/next 与导出运行记录展示。建议仅供排查，不是重试授权；不保存内部路由、凭据或未知扩展字段。`MODEL_SUBMIT_AMBIGUOUS` 先检查原任务与结算，只恢复原恢复ID；服务端中断不能靠重建项目修复，不能把本地记录改进说成模型服务故障已解决。
- 每集按当前工作稿或成品稿的目标范围提示偏短/偏长，优先使用有效的服务端statistics.wordCount，缺失才用本地Unicode计数并注明。提醒在findings、next的qualityAdvisories和导出问题清单中可见；warnings=[]不表示符合篇幅。`advisoryOnly=true`的篇幅提醒可直接保留交付，不要求逐ID接受，不强制截断、重生成或付费修订。字/词数不能推算实际成片时长；本地与服务端计数差异另列，不改原始统计。
- `status.billingSummary` 与导出运行记录只汇总实际回执：优先公开billing的最终points；refundedPoints单列且不再次从points相减。没有公开billing才兼容_billing.final=true的charged_dumplings/refunded_dumplings。预扣、报价、缺失/不完整结算都不当最终费用；未知为null，knownNetPoints只代表已确认部分，totalNetPoints未知时向用户说明还有待核对任务。同一jobId重复恢复只计一次，冲突结算待核对，不凭模型猜测。该汇总不替代CLI/服务端账务。

公共费用、退出码和恢复合同见 [cli.md](cli.md)；以下只说明如何同步本地项目：

- **退出 3**：`record --call <id> --exit-code 3`，不传 result。项目保持 `WAITING_CONFIRMATION`。展示 CLI 报价，获准后以原输入、原确认令牌执行 CLI，再 record 同一个 callId。令牌只交给 CLI，不写项目或成品。
- **用户拒绝报价**：仅当尚未提交的 WAITING_CONFIRMATION，才可 `answer --decision cancel-quote --note <用户拒绝原意>`，项目暂停。审校/FIX报价被拒绝同时撤回未提交的审校/改稿计划；普通continue只解除暂停，不恢复收费授权，需用户另行明确review/rescan/fix，或skip-review后交付。其它创作调用也须用户明确继续并再次确认报价。已产生恢复 ID 或 jobId 的调用不可这样丢弃。
- **网络失败或无任务输出**：`record --call <id> --exit-code 1 --recovery-id <已取得的恢复ID>`。保持 UNKNOWN，不能新建调用。如果连恢复 ID 都未拿到，先核对 CLI 调用记录/平台记录；不要声称未扣费。
- **失败stdout仍是网关错误包装**：旧工具可能在非零退出时输出含`code/data`的原始错误，而不是任务对象。单独保留原stdout/stderr，不解包data、不伪造结构化拒绝；用实际退出码和已取得的恢复ID执行record，不传`--result`，项目保持UNKNOWN。不要把“必须解包”的导入错误理解为允许改写服务端回执。
- **明确未提交或受理拒绝**：CLI stdout为`schemaVersion=mantur.cli.submission.v1`且`status=NOT_SUBMITTED/REJECTED`时，以`record --call <id> --exit-code 1 --result <原stdout.json>`保存；REJECTED还需原`--recovery-id`。脚本核对算子、原始输入摘要、阶段证据与恢复ID，不允许已经受理/活跃的任务降级。输入摘要基于CLI调用前的完整固定JSON，新调用已含绑定的sourceFileId；不追加`--file`或在报价后换ID。旧调用按原输入证据核对，不补写字段。错误回执保留、项目仍暂停；用户明确同意后，才能`answer --decision abandon`停止，或`answer --decision retry`允许重新报价。两者均须真实`--note`，不自动再调用。
- **旧工具或旧服务没有明确证据**：不凭422、错误文字、无jobId推断未受理；仍用UNKNOWN规则。只有报价前确实未提交且没有恢复ID的旧记录可以走下方人工证明；已存在恢复ID的未知记录先核对原调用，不补造拒绝回执或手改状态。明确拒绝的resume只读原拒绝回执，不轮询也不重试。若恢复工具提示“使用原确认标识重试”，仍不得重新run：未知受理只核对原恢复ID和平台记录；沿用旧确认令牌也不能代替未重复提交的证明。恢复工具无法取得jobId时暂停人工核对，不升级工具后自动重投。
- **任务处理中或 CLI 轮询超时**：记录公开 JSON 和真实退出码；项目保持 pending。执行 `manturhub resume <原恢复ID>` 后 record 同一个 callId，不再 run。
- **终态提交回执还没有结果**：退出 0、SUCCEEDED、output=null/缺省，且带 jobId 和 CLI 标准 pollUrl 时，record 标记 NEEDS_RESULT_FETCH，保持同一 callId 待处理。通过 ACCESS 的 resume 查询原恢复 ID，再 record 完整结果；不跟随或保存回执中的任意 URL。
- **结果查询仍缺 output 或字段非法**：停止核对线上合同，记录 OUTPUT_INVALID；不造数据、不继续下游。缺少标准回执标记的空结果不能冒充“仍在查询”。项目脚本只是关键结构护栏，不是服务端完整 Schema 验证器。
- **正文完整性**：新 WRITE/LOCALIZE/FIX 分集需包含合法行、warnings 数组及服务端统计；字段缺失/类型错误或截断标记保留原回执为 OUTPUT_INVALID。旧记录仍可查看导出，缺警告显示未检查，不补造空数组。新发现的未接受问题会使旧验收失效，需要重新人工核对；不自动发起 SCAN/FIX。
- **明确 FAILED/CANCELED 等终态**：保持暂停。先核对公开错误是否仍表示结果未确认；这种情况按 [recovery](recovery.md) 的 `retry-unconfirmed` 知情授权流程，普通 retry 会被拒绝。其他明确失败，用户要求新尝试时 `answer --decision retry --note "用户要求重新尝试"` 才清除本地 pending；后续 CLI 是新的独立报价/调用，不是原任务 resume，不保证免费。
- 状态文件锁提示：等另一个写进程完成。如果进程崩溃，先核对 `.project.lock` 中的 PID、命令与时间并确认无写进程，再只删除这个锁文件；不自动超时抢锁，不删除项目。

脚本不对未知调用结果做“取消本地任务就当没发生”的处理。`status` 会列出 pending 输入、jobId、恢复 ID；不要手动清空它。`record` 重放完全相同成功结果是幂等的，不会重复推进。

**补录结算与迟到查询**：通过 ACCESS 查询原任务后，仍用原 callId 与真实 CLI stdout/退出码执行 record。已确认成功或失败的原回执保持不变；同 jobId 的后续回执追加到 receiptHistory，导出为 data/ 中的查询证据。缺账务或旧 RUNNING 不会覆盖已确认终态；成功后的最终结算可以补录，不重复应用正文、不清除别的 pending。提供了 output 时必须与原产物一致；换任务、换算子、冲突终态或修改正文拒绝导入。费用读 `billingSummary` 的完整证据汇总，call.billing 仅是原记录快照；最终结算不被缺省查询抹掉，同任务不重复计费，互相冲突的最终金额明确待核对。旧项目没有历史字段时从现存原回执开始追加，不伪造已丢失的查询。

`--stderr` 只读取同一次调用的 CLI 恢复 ID／任务 ID 标记，不保存原始 stderr 或其中的报价令牌；多次调用拼接、任务 ID 不同会拒绝导入。报价与 resume 的 stderr 可以没有新标记，沿用原绑定；旧 `--recovery-id` 仍兼容。误把本地 callId 传为恢复 ID 时忽略该值并提示，合法结果仍可导入；未知任务保持 pending，先取得原 run 的 stderr 再恢复，不能重提。

旧成功记录若把本地 callId 存成恢复 ID，可对同一 call 执行 `record --exit-code 0 --result "最初成功stdout.json" --stderr "原run的stderr.txt" --repair-recovery confirmed`。仅当旧错误值等于本地 callId、stderr 的恢复 ID 与 jobId 明确、jobId 与已保存任务一致、成功回执完全相同时修复。修复仅更新恢复绑定并留审计事件，保留正文、质量状态、账务及其它 pending 调用；不允许任意改绑。旧成功记录缺恢复 ID 时也可用相同原始证据补绑定（无需 repair-recovery）。缺原始证据先核对原任务，不手改 state 或伪造 stderr。

### 服务升级后复用现有项目

先`status/next/export`核对稿别、成功集号、原call/job/恢复ID和账务；升级不是重建项目或重跑前期、WRITE、LOCALIZE的理由。既有成功资产/正文/报告仍为原始事实，不能因新服务发布就称旧问题已修复。

- 仍在运行或结果未知：只查询原任务，升级不解除pending。
- 已确认失败终态：保留原回执。只有用户明确允许新尝试才记录`retry`，重新prepare、报价和确认；失败的源稿分析只恢复该阶段，失败的FIX复用现有正文、报告及确认范围。复核原FIX＋复扫选择与剩余预算；授权过期、超额或范围变更重新确认，不把“服务已发布/继续”当免费重试或复扫授权。
- FIX失败没有修订稿，不安排复扫，也不把原稿标成已修复。可按用户决定停止此次可选改稿并交付带问题的原稿。
- 结果成功但内容错语或性别证据矛盾：这不是失败终态，不能走retry冒充免费修复；先展示原产物和修订边界。已有双稿不为了验证新提示词重新生成，需要新生成能力验证时另说明样例范围和费用。
- 旧创意候选按[人物核对](quality-gates.md#创意候选人物核对)和[改编事件顺序核对](quality-gates.md#改编候选事件顺序核对)区分真实矛盾与提纲写法。尚未选题可在确认后选另一无冲突真实候选；全部冲突则保留选题停点，不用note冒充修订。需要正式修改当前项目时先按[上游恢复](recovery.md)预览影响、取得用户决定并重开，再另行确认新调用费用；不直接重新prepare已锁定阶段、不改state/output。仅验证部署效果的新创意仍在独立测试记录保留，不覆盖原项目已选方案和剧本。

模型内部传输格式由服务端处理。调用者始终传公开连续性对象、scenes/scriptLines；不得自行将连续性转为字符串、拼接缺字段或导入内部模型响应。`LLM_OUTPUT_SCHEMA_VIOLATION`只说明结构校验失败，不足以断言截断、具体缺字段或补试次数；内部尝试数以平台日志为准，Skill不叠加自动调用。

### 明确未提交与非法终态的解除

旧工具只有报价stderr、没有结构化拒绝回执时：先保留原stdout/stderr及实际退出码，核对实际命令在报价阶段退出、未执行提交接口，并核对调用记录。仅422、容量错误文字或缺少ID不够。确认后可独立记录人工证明，**不把它包装成CLI回执，不覆盖原result**：

```json
{"callId":"当前本地callId","operatorCode":"op.script.review","inputDigest":"原输入规范化JSON的SHA256","phase":"QUOTE","outcome":"NOT_SUBMITTED","evidence":"实际报价错误、原证据位置，以及核对提交阶段/调用记录的结论；不是仅凭无ID。"}
```

inputDigest对原input.json递归按对象键排序、数组保持顺序后，以JSON.stringify紧凑序列化计算SHA256，不是带缩进文件的哈希。证明只允许上述六个字段，evidence最多4000字符；脚本只校验绑定关系，不能代替事实核查。不抄另一call的证明。

```bash
node "RUNTIME" record --project "PROJECT" --call "原callId" --exit-code 1 --submission-evidence "已核实报价未提交.json"
```

此入口仅适用于PREPARED/UNKNOWN/WAITING_CONFIRMATION，且从未记录jobId、恢复ID或活跃回执；不同时传result/recovery-id。记录为NOT_SUBMITTED、来源MANUAL_PRE_SUBMIT，保持pending；原错误对象及证明分别导出。重复相同证明幂等，不能覆盖不同证明。用户明确允许停止/重新规划后，才执行`answer --decision abandon --note "真实答复"`，再经`answer --decision continue --note "真实答复"`进入新prepare。没有上述核对证据仍保持UNKNOWN，只核对原调用。

`PREPARED` 只是本地占位，不证明命令尚未执行；没有 ID 也不是未提交证据。核对 CLI 的实际阶段及平台记录后，如果命令确未运行或停在报价阶段，可记录以下证明（不含令牌/Key），再显式解除：

```json
{"phase":"QUOTE","outcome":"NOT_SUBMITTED","evidence":"实际错误和核对结论：报价阶段失败，尚未调用提交接口；不能仅写没有任务ID。"}
```

命令根本没运行时用 `phase=NOT_STARTED`，其它情况不冒充报价失败。

```bash
node "RUNTIME" answer --project "PROJECT" --decision abandon --submission-evidence "未提交证明.json" --note "用户要求停止这次已核实未提交的调用"
```

仅 PREPARED/UNKNOWN/WAITING_CONFIRMATION 且从未记录任务 ID、恢复 ID、活跃回执时支持此入口。脚本保存证明与历史，不声称能自动验证证明内容。解除后项目暂停，可以 checkpoint/undo；用户要求重新尝试时再 `answer --decision continue --note "真实答复"`，新 prepare/run 仍走报价与费用确认。原稿此前可能已上传，解除不删除文件。

分集调用已明确的终态 `SUCCEEDED`、带 jobId，但本地校验为 OUTPUT_INVALID 时，先恢复查询同一任务核对完整结果。服务修复后，用户明确同意新尝试可记录 `answer --decision retry --note "用户确认仅重试当前失败集，重新报价"`，再 prepare；只续做当前缺失阶段，原失败回执、原输入、账务和已完成集保留。新 callId 是另一次可能收费的调用，仍需 CLI 实时报价与确认，不保证退款；UNKNOWN、活跃任务、客户端超时不可走此路径。也可用 `answer --decision abandon --note "用户选择保留错误回执并停止此调用；知悉不退款"` 停止，不传未提交证明；原坏结果不能接受或送入下游。

`status/next.manuscripts` 与导出的“稿件进度”分别列出工作稿/成品稿已完成及缺失集号、当前阻塞集；只有成品范围齐全才 complete。工作稿完成、成品只完成部分时必须披露具体数量，不能称全季英文成品已封存。升级旧项目不重建、不回写原产物；新 WRITE/LOCALIZE/FIX 导入核对场景数、对白数及完整结构，失配保留为 OUTPUT_INVALID。字数受 Java/Node 的 Unicode 版本影响，差异显示为 countAdvisories，保留服务端统计和原始回执，不因此停写或重新收费生成。缺正文、截断标记、非法行和 LOCALIZE 身份/行结构变化仍严格拒绝。

任一算子明确失败后，若原回执有jobId及真实服务端失败终态，也支持上述abandon，不必假装同意retry才能停止或重新规划。原任务、账务、失败证据及已有产物保留；审校/FIX停止时还会撤回未提交的审校/复扫计划。再continue只解除暂停，不授权新的收费调用：用户可导出已有阶段、按reopen预览修订上游，或另行批准新调用。结果未知或仍在运行不能abandon；带`_timeout`的客户端等待超时不当作服务端终态，仍只恢复原任务，即使status文字写FAILED/TIMEOUT也不允许新建重试。

如果确知旧 prepare 对应的是报价失败且用户希望继续，可沿用它的原 input 和 callId 重新取得报价，执行真实 CLI 后 record；本地 callId 不是服务端幂等保障，不代表重复 run 一定不会扣费。凡已受理或受理状态未知，仍只 resume 原任务，不使用这条路径。

## 可选审校、交付和验收

执行前展示`plan`返回的完整步骤及默认调用次数（审校默认0），费用确认遵循[可选审校与费用](review-policy.md)。`plan/status/next/export`均不调用算子。默认写完本阶段全部集数，逐集只写作；每5集进度摘要不暂停，也不是付费审校。最终成品仅提示是否需要审校，不因未回复而执行。

### 用户选择审校或跳过

没有审校授权时，全部集数完成返回`review-choice`，`prepare`拒绝创建SCAN。它不是必须付费才能解除的停点：可直接confirm-working/deliver/export。用户跳过或继续其他步骤时记录skip-review；没有回复时只导出现稿，不能伪造允许审校的note。

```bash
node "RUNTIME" answer --project "PROJECT" --decision review --note "用户明确要求对当前已完成集数审校，费用按实时报价确认"
# 或不调用审校（两条命令是不同选择，不顺序执行）
node "RUNTIME" answer --project "PROJECT" --decision skip-review --note "未获得审校授权，按用户原交付范围继续；不代表质量验收"
```

中途主动review只冻结当前已完成集数，完整请求按容量分批；成功后partial quality停点展示结果，`answer --decision continue-writing --note <决定>`恢复写作，不为后续每集自动审校。报告中的已有问题仍保留；阶段覆盖不是全剧通过。未提交的后续审校可skip-review；已有pending要先按原任务/报价处理，不能靠可选入口清掉未知任务。

当前已有完整有效SCAN时，review拒绝重复，需明确rescan。review不授权FIX；输出轻微问题不会自动改稿。所有新调用仍有CLI费用门禁。

### 新项目先确认工作稿，再生成独立成品

工作稿全部集数完成后，在quality或review-choice停点展示已有问题、已审/未审范围，取得用户对成品来源的明确确认；不要求购买SCAN。已经主动开始的审校须完成或明确skip-review（pending仍需闭环）：

```bash
node "RUNTIME" answer --project "PROJECT" --decision confirm-working --note "用户确认这一版工作稿用于制作所选语言的成品；费用另行确认"
```

该动作保存确认前检查点、工作稿引用、覆盖说明及已有报告，不做最终accept。未扫描直接确认时记录SKIPPED，不伪造PASS。跨语种后续prepare逐集产生LOCALIZE，sourceEpisode来自同集工作稿、前集和快照来自成品稿；成品完成后重新给出可选审校，不继承工作稿审校授权。同语种不重复调用，沿用正文和实际覆盖。`status.draftKind`表示稿别，workingEpisodes列出工作稿集号。

工作确认前禁止最终accept。确认后不得覆盖工作稿；如要改工作来源，先解决pending，按用户要求undo到`view.workingDraft.snapshotId`对应检查点。不会删除旧调用和账务，不自动复用旧成品。工作稿未决问题以`WORKING:`前缀进入最终findings；确认成品来源不等于接受这些问题。不能把这个前缀当作服务端issue ID交给FIX。

### 当前稿别的审校与最终验收

仅用户选择审校后才调度调用。按当前已完成稿件的完整紧凑JSON UTF-8字节数分批，单批144 KiB、最多20集，包含资产、蓝图、要求、配方、源稿及跨语种两份正文。相邻批次重叠一集，短稿可为1–20、20–39，长稿缩小；不代表全季长程语义穷尽检查。当前请求批次完成后返回quality，不等于自动通过，也不触发FIX。全剧审校不是每完成一集就重扫已有集数。

本地预算不是服务端token准入保证。单集/相邻对/共享上下文超限时以review-choice的`REVIEW_CAPACITY`原因说明，不能prepare审校，但用户可跳过并交付未审校稿。服务端拒绝仍按实际状态恢复，不裁剪、循环重试或伪称完整覆盖。历史报告不符合当前签名/覆盖时保留证据并披露，不能自动补扫收费。

升级后不改已prepare的输入或在途任务。对于已核实未提交的超限批次，先按上方证据和用户决定解除旧call；abandon审校会撤回原计划，continue不恢复收费授权。用户重新明确review后才prepare当前规划，不能重用旧确认令牌。已有正文、旧审校和失败证据都保留，获准后只补当前批次缺少的SCAN，不重跑分集。新批次仍被服务端拒绝时停下核对，不循环缩批报价或裁剪共享上下文。

### 原稿不变，主动重新审校

用户明确要求再次审查当前稿别、且已有全部当前SCAN，`next.kind=quality`或`done`时：

```bash
node "RUNTIME" answer --project "PROJECT" --decision rescan --note "用户要求原稿不变，重新审校当前稿别；费用仍按实际报价确认"
node "RUNTIME" next --project "PROJECT"
node "RUNTIME" prepare --project "PROJECT"
```

`rescan`只创建本地审校新轮次（reviewEpoch），保存返回的snapshotId与用户决定；不联网、不生成正文、不执行FIX、不清除或退还旧费用。旧报告、call与原稿引用保持不变，新轮次不能复用旧SCAN/PASS，按当前完整请求预算重新逐批SCAN；每批新call都经工具合同报价/确认/record。在当前版本下配置与稿件不变时，复扫输入与原同批SCAN一致。不要复用旧callId、任务ID、确认令牌，也不要重新record旧成功回执冒充新扫描。

有pending（包括报价待确认、未知、运行中、失败尚未处理）、暂停、未完成批次、FIX/复扫/修订待确认时均拒绝。先按原状态处理，不通过rescan绕过恢复或用户决定。不带`--review/--issues/--instruction`挑批/选问题；本入口覆盖当前稿别所有批次。途中报价被拒绝则撤回未提交计划并暂停；continue仅解除暂停，重新授权review后才补本轮未完成批次，或skip-review交付。新任务失败或未知仍只处理原call，不自动再开轮次。

重新扫描会撤销原质量接受，保留人工发现但标记checked=false/needsRecheck；完成后仍需人工核查和用户决定，不把问题数下降或ID变化当作修复成功。工作稿阶段只扫工作稿；进入成品后只扫成品，跨语种仍携带同集确认工作稿对照，不改已确认工作稿。若需退回修改工作来源，使用原有检查点撤销规则。

导出显示当前轮次与`审校历史.md`索引，完整新旧回执和账务仍在data/及运行记录；旧阅读稿保留原revision。用户要求取消本地复扫计划时可用返回snapshotId执行undo，但必须先解决pending；不取消服务端任务/退款，撤回后也不自动恢复旧质量接受。

### 已确认问题的限定改稿

用户要求修复时，先查看计划并同时说明改稿、预计复扫费用；由用户选择是否一起做，用有效SCAN的callId及真实问题ID：

```bash
node "RUNTIME" plan --project "PROJECT" --review "SCAN的callId" --issues "ISSUE_1,ISSUE_2"
node "RUNTIME" answer --project "PROJECT" --decision fix --review "SCAN的callId" --issues "ISSUE_1,ISSUE_2" --instruction "用户确认的修改要求" --with-rescan confirmed --repair-budget "用户确认的总积分上限" --note "记录用户明确批准的FIX报价、预计复扫批次和费用、总上限"
node "RUNTIME" prepare --project "PROJECT"
```

每次FIX只选涉及最多两集的真实问题ID。问题未给集号或集号为null时，影响范围按整个原批次计算；超过两集先暂停核对问题范围，不改写原问题集号、编造拆分ID或自动发起多轮调用。单集过大仍可能触发服务端完整回写容量保护，当前不支持场景补丁。

报告类 ID `PROGRAM_REPORT_LANGUAGE` / `PROGRAM_REPORT_COMPLETENESS` 不能用于正文 FIX（answer 和新 prepare 均会拒绝）。保留原报告，人工核对完整建议，或另外取得 SCAN 授权；这不自动允许修改正文。其它真实剧本问题可以独立确认，不能伪造或更名报告问题来绕过。已 prepare/在途的调用仍按原记录恢复，升级不改输入。

`--with-rescan confirmed`表示明确一起授权，预算包含FIX及预计复扫；也可选`later`或`skip`只授权FIX，预算仅覆盖本次改稿，不能自动复扫。later完成后再次review需新的费用确认，不沿用FIX-only预算；skip保留修订稿及未审校标识。用户可在无pending时skip-review撤回复扫，旧费用与修订不删除。runtime保存授权及范围，不执行结算；Agent提交前必须核对CLI实时报价、已花/预留费用和余额上限，未知即停止。

FIX传完整原批次、priorReview和真实confirmedIssueIds，未授权集只读。修改集及后续批次旧SCAN失效，失效不等于授权收费。一起授权时先复扫原修复批次，再补授权范围内失效批次；尺寸变化使批次超出原计划时重新询问，不能扩大套餐。复扫仍有问题进入repair-decision，展示stillReported/noLongerReported/newlyReported，由用户keep-revision或rollback-revision（均须note）；不是自动追加一轮FIX。记录变化不证明修复/退步，FIX的PASS也不等于终审。全项目最多三次FIX尝试只是上限，不是默认执行次数。人工发现保留并标记needsRecheck，未复扫可交付但必须披露。

用户需要人工质量验收时，完成或跳过已请求的审校后，按[quality-gates.md](quality-gates.md)检查真实正文；未做算子审校也可人工检查，但不能虚报模型覆盖，生成：

```json
{
  "checked": true,
  "notes": "记录实际检查了什么与证据位置，不写未执行的检查",
  "findings": [
    {"id": "MANUAL_PROP_HANDOFF", "description": "第2集钥匙易主缺少交接动作"}
  ]
}
```

```bash
node "RUNTIME" quality --project "PROJECT" --report "人工检查.json"
node "RUNTIME" status --project "PROJECT"
```

没问题时 findings 为空。`status.findings` 合并服务端问题、场次数量/警告检查和人工发现；服务端问题 ID 在本地验收清单中加 `<SCAN callId>:` 前缀，避免多批次同名冲突。人工发现不能伪造为服务端 issue ID 交给 FIX。

只要交付可`answer --decision deliver --note <交付决定>`后export，保持qualityAccepted=false，不强求购买审校或质量接受。最终验收需`answer --decision accept --accept-quality confirmed --note <明确验收答复>`，已有问题逐ID列入`--issues`，缺少工作稿/成品稿审校时还需`--unreviewed acknowledged`记录用户知道覆盖限制。全部成品集数及人工检查必须完整，未知任务不能绕过；“继续/好的”不是最终验收。未审校下的用户验收不是算子PASS，导出仍披露未审范围。

## 检查点、撤销与产物

```bash
node "RUNTIME" checkpoint --project "PROJECT" --label "用户确认蓝图后"
node "RUNTIME" undo --project "PROJECT" --snapshot "返回的snapshotId" --note "用户要求撤回此轮修改"
node "RUNTIME" export --project "PROJECT"
```

撤销只恢复本地项目视图，保留所有调用历史与费用事实，不取消服务端任务、不退款、不删除旧成品。恢复后撤销质量接受，保留检查点中的人工问题、原稿签名和说明，并标记needsRecheck、checked=false；即使正文相同也需重新核查。恢复旧稿时以所选检查点的问题为准，其他版本发现仍在历史中，不能声称被修复。用户选择 rollback-revision 时采用同一规则；不按问题总数自动撤回。存在未决调用时不能撤销。

目录：

- `state.json`：版本化项目状态、当前视图、暂停点、调用索引、决策事件、快照索引。
- `objects/<sha256>.json`：输入、真实公开输出、快照的不可变对象；读取校验摘要，不得手改。
- `calls/<callId>/input.json`：CLI 入参文件。修改已准备输入会被 record 拒绝。
- `exports/revision-N/`：阅读索引、项目摘要（含停点与失败原因）、源稿分析、三个方案、已选方案、资产、蓝图确认稿、审校报告、运行记录（任务/恢复 ID、调用历史与实际账务）、data/ 原始调用回执、index.json；新项目正文分别在 working/episodes/epNN.md、working/正文合集.md 和 delivery/episodes/epNN.md、delivery/正文合集.md，工作稿确认后另保留working/审校报告.md。旧单稿项目保留原episodes/与正文合集路径。
- `artifacts.json`：最近一次导出索引，包含对应 revision。发生新修改后旧导出不会自动变化，必须再 export，不可把旧索引当当前成品。
- `审校历史.md`（位于当前导出目录）：主动复扫或改稿使旧报告失效后，保留当前稿别新旧SCAN索引和历史问题正文，标明轮次及是否属于当前覆盖；未复扫的旧问题标为待核实，不被删除或自动判定已修复。

仅导出已存在的阶段产物，未完成项目明确标注草稿；文件名固定，不把模型生成的标题直接拼接成路径。向用户提供 export 返回的**绝对文件路径链接**。

本版支持本项目工作稿到一个独立目标语言成品，不提供任意旧稿纯翻译导入、多目标语版本、双语排版、独立集纲生成、方案/蓝图定向修订或单集 REWRITE 的自动运行命令。遇到这些需求先解释当前边界，不能手改不可变对象或编造服务端结果，不扩展通用 CLI 或绕开算子计费。

## 项目业务上下文

开始新项目的实际调用准备时，可以显式传 --business-code。继续旧项目先执行本脚本 attribution-context --project PROJECT，只读取得绑定业务；随后按[工具合同](cli.md)，使用同一业务做接入检查。规划输出的 cli.accessArgs 用于外层检查，cli.args 原样转发。业务不同需新项目，不能把原调用转给另一个业务。旧项目已有调用但尚未绑定业务时，为后续新调用显式确认业务；未决调用仍先按原回执恢复，不补写历史。旧接入不发送新增参数或建立业务归因文件。

可选 `display-names` 命令为旧资产补阅读标签，允许在原任务待恢复时操作，但不改变该任务输入和恢复入口；格式与限制见[languages.md](languages.md#角色显示名与旧项目)。审校报告的引句来源为非阻断提示，见[review-policy.md](review-policy.md#审校引句归属)。

## 新结果准入与历史恢复

新 prepare 在调用记录中标记输出合同版本，record 核对公开 v1 必填字段和后续必需的角色身份、蓝图节拍、场景引用。字段缺失时保留真实回执与冻结输入，标记 OUTPUT_INVALID，不前进、不补造成功结果，也不自动重新收费。额外无害字段、未知性别和普通创作质量建议不据此阻断。历史在途记录按原兼容规则恢复，历史产物可查看和导出；开始新的下游调用前检查必需身份，避免到报价时才发现缺失。

ADAPT 的 adaptationGoal 使用 PRESERVE_CORE、REIMAGINE_STRUCTURE 或 LOCALIZE_OVERSEAS；具体改编要求写 brief、protectedElements、allowedChanges。旧项目自由文本目标不会阻止查看或恢复原调用；准备新的源稿分析前通过已确认配置修订选定合法值，不自动猜选。交付未改正文时保留已有人工检查和验收，后续正文修订仍使对应验收失效。

新调用的 `cli.accessArgs` 与输入同存，执行时一并交给接入器；它可能包含项目与运行上下文绑定。旧调用缺失这些字段仍可读取、原 ID 恢复和记录；不要为升级而改写冻结输入或原始回执。接入上下文由公共工具合同管理，本地导出与质量状态保持独立。
