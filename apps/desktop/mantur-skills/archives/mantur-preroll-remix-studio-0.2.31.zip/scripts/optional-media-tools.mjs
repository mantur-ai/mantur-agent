import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {check,loadProject,verifyAsset,withLock,saveProject,displayGeometry} from './project.mjs';
import {inspectMedia} from './media-probe.mjs';
const exec=promisify(execFile);

async function localProbe(file){
  const {stdout}=await exec('ffprobe',['-v','error','-show_streams','-show_format','-of','json',file],{timeout:60000,maxBuffer:4*1024*1024,shell:false,windowsHide:true});
  const data=JSON.parse(stdout),video=data.streams?.find(stream=>stream.codec_type==='video');
  check(video&&video.width>0&&video.height>0,'VIDEO_MISSING');
  const base=/^(\d+)\/(\d+)$/.exec(video.time_base||''),ticks=Number(video.duration_ts);
  const precise=base&&Number(base[1])>0&&Number(base[2])>0&&Number.isSafeInteger(ticks)&&ticks>0?ticks*Number(base[1])/Number(base[2]):null;
  return {width:video.width,height:video.height,...displayGeometry(video),duration:precise??Number(data.format?.duration||0),hasAudio:data.streams.some(stream=>stream.codec_type==='audio')};
}

/** Explicit local enhancement only; default production never calls these binaries. */
export async function verifyMedia(dir,operationId,{localProbe:useLocalProbe=false,fullDecode=false}={}){
  check(typeof useLocalProbe==='boolean'&&typeof fullDecode==='boolean','MEDIA_CHECK_MODE_INVALID');
  const initial=await loadProject(dir),op=initial.operations.find(item=>item.id===operationId);
  check(['succeeded','qa_failed'].includes(op?.status)&&op.assetId,'MEDIA_CHECK_ARTIFACT_REQUIRED','请先选择已下载并保存的前贴、裁片或成片。');
  const asset=initial.assets.find(item=>item.id===op.assetId);check(asset,'ARTIFACT_MISSING');
  const file=await verifyAsset(dir,asset);let facts,decodePassed=false,failure,decoding=false;
  if(!fullDecode&&op.decodeFailure?.sha256===asset.sha256)return {status:'failed',errorCode:'MEDIA_DECODE_FAILED',message:'此文件已有明确解码失败记录，不能用较弱检查代替；可重新选择完整解码验收。',newPaidTask:false};
  try{
    facts=useLocalProbe?await localProbe(file):await inspectMedia(file);
    if(op.expectedCanvas)check(facts.width===op.expectedCanvas.width&&facts.height===op.expectedCanvas.height&&Math.abs(facts.duration-op.expectedDuration)<=Math.max(2/op.expectedCanvas.fps,.08),'OUTPUT_GEOMETRY_OR_DURATION_MISMATCH');
    if(op.expectedHasAudio)check(facts.hasAudio===true,'OUTPUT_AUDIO_MISSING');
    if(fullDecode){
      decoding=true;
      const {stderr}=await exec('ffmpeg',['-v','error','-i',file,'-f','null','-'],{timeout:7200000,maxBuffer:1024*1024,shell:false,windowsHide:true});
      check(!stderr.trim(),'MEDIA_DECODE_FAILED');decodePassed=true;
    }
  }catch(error){
    if(['ENOENT','EACCES','EPERM'].includes(error.code))return {status:'optional_tool_unavailable',message:'所选本机加强验收工具未安装或没有执行权限；已跳过此可选检查，默认制作和已有成片仍可使用。',newPaidTask:false};
    if(error.killed||['ETIMEDOUT','ERR_CHILD_PROCESS_STDIO_MAXBUFFER'].includes(error.code))return {status:'optional_check_incomplete',message:'本机可选验收未完成，未记录解码通过；默认制作和已有成片仍可使用。',newPaidTask:false};
    failure=decoding?'MEDIA_DECODE_FAILED':['OUTPUT_AUDIO_MISSING','OUTPUT_GEOMETRY_OR_DURATION_MISMATCH'].includes(error.code)?error.code:'MEDIA_METADATA_INVALID';
  }
  // Do not hold the project lock for a full decode or let later edits receive stale QA.
  return withLock(dir,async()=>{
    const project=await loadProject(dir),current=project.operations.find(item=>item.id===operationId),actual=project.assets.find(item=>item.id===current?.assetId);
    check(['succeeded','qa_failed'].includes(current?.status)&&actual?.id===asset.id&&actual.sha256===asset.sha256,'MEDIA_CHECK_ARTIFACT_CHANGED','检查期间产物已变化，请重新选择当前产物。');
    await verifyAsset(dir,actual);
    const checkedAt=new Date().toISOString();
    if(failure){
      current.status='qa_failed';current.error={code:failure,message:failure==='MEDIA_DECODE_FAILED'?'本机加强解码验收未通过，请核对原产物；不会自动重新制作。':'本机加强媒体验收未通过，请核对原产物。'};
      current.qa={...current.qa,decode:false,decodeStatus:failure==='MEDIA_DECODE_FAILED'?'failed':'unknown',checkedAt,fileSha256:actual.sha256};
      if(failure==='MEDIA_DECODE_FAILED')current.decodeFailure={sha256:actual.sha256,checkedAt};
    }else{
      const retainedDecode=current.qa?.decode===true&&current.qa.fileSha256===actual.sha256;
      current.qa={...current.qa,metadata:true,container:true,localProbe:useLocalProbe,decode:decodePassed||retainedDecode,decodeStatus:decodePassed||retainedDecode?'passed':'not_performed',checkedAt,fileSha256:actual.sha256};
      if(decodePassed){delete current.decodeFailure;current.status='succeeded';delete current.error;}
    }
    await saveProject(dir,project);
    return {status:failure?'failed':'checked',operationId,newPaidTask:false,localProbe:useLocalProbe,decode:current.qa.decode===true,decodePerformedThisCheck:decodePassed,decodeStatus:current.qa.decodeStatus,...(failure?{errorCode:failure}:{})};
  });
}
