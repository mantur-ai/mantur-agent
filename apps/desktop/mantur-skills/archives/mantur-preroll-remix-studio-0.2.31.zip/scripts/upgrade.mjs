import { copyFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { atomicJson, check, loadProject, withLock } from './project.mjs';

export async function upgradeProject(dir,{apply=false,confirmed=false,sourceSha256}={}){
  const preview=await loadProject(dir);
  if(preview.schemaVersion===2)return {status:'ALREADY_CURRENT',schemaVersion:2,readOnly:!!preview.legacyOrigin};
  const source=await readFile(join(dir,'.preroll/project.json'));
  check(JSON.stringify(JSON.parse(source))===JSON.stringify(preview),'MIGRATION_PROJECT_CHANGED');
  const expected=createHash('sha256').update(source).digest('hex');
  const pending=preview.operations.filter(op=>['unknown','running','remote_succeeded','artifact_pending'].includes(op.status));
  const plan={status:pending.length?'BLOCKED_LEGACY_PENDING':'UPGRADE_PREVIEW',schemaVersion:1,targetSchemaVersion:2,
    projectId:preview.id,revision:preview.revision,sourceSha256:expected,pendingOperations:pending.map(op=>({id:op.id,status:op.status})),newPaidTask:false};
  if(!apply)return plan;
  check(confirmed===true,'MIGRATION_CONFIRMATION_REQUIRED');
  check(sourceSha256===expected,'MIGRATION_PREVIEW_CHANGED','请先预览，并使用该预览的源SHA确认升级。');
  check(!pending.length,'LEGACY_PENDING_REQUIRES_ORIGINAL_TOOL','旧未决调用必须在原环境完成，不伪造恢复记录。');
  return withLock(dir,async()=>{
    const file=join(dir,'.preroll/project.json'),bytes=await readFile(file),current=JSON.parse(bytes);
    check(current.schemaVersion===1&&current.revision===preview.revision&&bytes.equals(source),'MIGRATION_PROJECT_CHANGED');
    const digest=createHash('sha256').update(bytes).digest('hex');
    const backup=join(dir,'.preroll',`project-v1-${digest}.json`);
    await copyFile(file,backup,1);
    const migrated={...current,schemaVersion:2,legacyOrigin:{apiBase:current.apiBase,environment:current.environment},
      migration:{fromSchemaVersion:1,sourceSha256:digest,sourceRevision:current.revision,upgradedAt:new Date().toISOString()}};
    delete migrated.apiBase;delete migrated.environment;
    for(const operation of migrated.operations)if(operation.status==='prepared')operation.modeInvalidated=true;
    await atomicJson(file,migrated);
    return {...plan,status:'UPGRADED',backup,sourceSha256:digest,schemaVersion:2,readOnly:true};
  });
}
