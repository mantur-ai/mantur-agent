# 本地只读 JSON API

2026-09-22 视频显示扩展：公开 v1 结构不变；项目快照的 `ratio` 发布兼容后的有效项目比例，本地 MP4 可探测时在既有 MediaRef 可选字段发布真实宽高和时长。页面优先使用 Clip 模板比例，模板缺失的成片再回退媒体宽高、项目比例和 `9:16`；生成中、失败卡使用模板／项目比例。结果区按容器宽度排成 1–3 列，不增加写接口或生产按钮。

服务只绑定 `127.0.0.1`，端口由操作系统分配，运行记录为 `.pipeline-state/runtime/readonly-service.json`。快照 HTTP 处理器只读取当前 Manifest 及其引用；同宿主的独立 JSON 同步模块负责调用 Compiler 发布新快照，二者不调用 ManturHub、不代理远端 URL、不执行生产动作。余额控制器与快照隔离，仅在首次页面实时查询或私有生产刷新事件到达时执行受限余额命令；普通轮询只读私有缓存。服务不启用 CORS。

包内 Snapshot Compiler、只读服务和同步 Compiler 统一以隐藏、非 shell 子进程启动，并在加载前移除 `NODE_OPTIONS`／`NODE_PATH`，避免把 Agent 宿主注入的 Node preload 传播到包内进程。外部 ManturHub CLI 仍继承原宿主环境及安全 Hook；只读服务启动时仅在进程环境中临时中继原值，调用 CLI 时恢复并立即移除中继键。原值和中继键不得写入项目、日志、诊断、快照或 API。该隔离只约束 Skill 自己的进程，不代表已修复宿主自行派生的可见辅助窗口，也不构成 WorkBuddy 兼容验收。

## 聊天动作

```powershell
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" start-readonly-service
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" serve-readonly-service
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" open-workbench --require-existing
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" readonly-service-status
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" stop-readonly-service --confirm-stop
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" begin-snapshot-batch --lease-seconds 90
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" snapshot-batch-heartbeat --update-id <id>
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" commit-snapshot-batch --update-id <id>
node "$SKILL_DIR/scripts/studio.mjs" --project "$PROJECT_DIR" abort-snapshot-batch --update-id <id>
```

启动动作先刷新快照；同项目、同 project_id、PID 存活且 health 匹配的实例直接复用。陈旧记录会被清除后重启。`start-readonly-service` 生成 detached 服务；`serve-readonly-service` 输出单行启动 JSON 后保持前台运行，必须由宿主长期后台任务或用户终端持有。停止只能响应用户明确的聊天请求，并要求 `--confirm-stop`。

### 跨宿主生命周期与交接

服务只保证当前智能体会话期间存活，不安装系统服务、计划任务或隧道。Agent 不按产品名假定进程一定存活，而按工具能力选择启动方式：宿主提供明确的长期后台命令能力时，用该能力托管 `serve-readonly-service`；WorkBuddy 可用时传 `run_in_background=true`。没有这种能力的本地宿主使用 `start-readonly-service`。Codex 当前实测可走 detached，但仍遵守下述复核；远程或容器宿主还要单独确认用户浏览器能否访问执行机回环地址。

启动返回 `instance_id`、`launch_mode=detached|host_managed`、实际端口和 URL。Agent 必须等启动工具调用结束，再用新的独立工具调用执行 `readonly-service-status`，核对 `running=true` 且 `instance_id` 不变；随后才执行带 `--require-existing` 的 `open-workbench`。该选项只复用健康实例，缺失时返回 `READONLY_SERVICE_NOT_RUNNING`，不隐式启动或返回未经跨调用验证的 URL。旧健康状态缺少 `launch_mode` 时返回 `legacy_unknown` 并继续复用，不因此静默重启。

detached 复核失败时，若宿主存在长期后台任务能力，最多改用 host-managed 重试一次；否则不返回链接，并给出让用户在自己的终端保持运行的 `serve-readonly-service` 命令。不得用 `nohup`、`Start-Process`、watchdog、系统服务或计划任务绕过宿主回收。宿主直接强杀后台任务时可能留下陈旧状态，下次 status 会清理；正常停止仍只调用 `stop-readonly-service --confirm-stop`，不直接调用宿主的 TaskStop。看板故障不改变生产结果，也不授权重新提交任务。

## 权威 JSON 自动同步

服务启动后默认启用；浏览器关闭不停止同步，明确停止服务后才停止。监听当前选中的项目、提取、库存、匹配（含音色）、分镜、Task/Run/交付索引，以及检查点、视频结果和 legacy 草稿 JSON。沿用项目指针、Manifest 指针、标准路径的顺序，未被选中的报告不会影响发布。

连续两次内容检查相隔约 2 秒且稳定后编译；每 10 秒检查监听遗漏。编译耗时及页面约 3 秒轮询另计。自动编译在子进程执行，与主动刷新共用项目锁；相同 JSON 已发布则跳过。输入不完整或错误时保留上一版快照，按 5/10/20/30 秒退避，修复输入后重新等待稳定。不会回退其他报告、重新提交任务或改变完成门禁。

纯媒体变化不触发同步；替换图片、视频、尾帧或 ZIP 后仍须主动执行 `refresh-ui-snapshot`。主动刷新始终校验媒体；`--no-write` 不创建同步状态或发布凭据。

批量生图、转码、重建库存和集中更新 JSON 必须先开启快照批次。租约有效时自动同步等待，非持有者主动刷新返回 `PROJECT_UPDATE_IN_PROGRESS`；heartbeat 续租，commit 在完整输入稳定后刷新一次，abort 只结束等待、不回滚生产文件。媒体先写同目录临时文件，经 MIME、扩展名、大小和 SHA-256 校验后原子替换，权威 JSON 最后原子发布。租约默认 90 秒并会在 Agent 中断后过期，因此不会永久冻结同步。

`readonly-service-status` 返回附加 `snapshot_sync`：`enabled`、`state`（waiting/compiling/idle/error/stopped）、最近检查及成功时间、revision、脱敏 `error_code`、`batch_update` 和 `last_successful_revision`；顶层同时给出最近错误和批次摘要。同步版本为 2，旧实例返回 `enabled=false/restart_required=true`，不能静默重启。同步记录、发布凭据和只读服务诊断均位于 `.pipeline-state/runtime/`，只记录本地关联和脱敏错误码，不含 JSON 正文、密钥、远端 URL 或任务 ID；都不是生产输入，也不通过 HTTP 暴露。API 和业务 Snapshot Schema 不变。

## 冻结端点

```text
GET /api/v1/health
GET /api/v1/project
GET /api/v1/assets
GET /api/v1/episodes
GET /api/v1/episodes/:episode_id
GET /api/v1/tasks
GET /api/v1/deliveries
GET /api/v1/media/:media_id
```

`HEAD` 与对应 `GET` 使用相同状态码和响应头但没有 body。其他方法返回 `405` 和 `Allow: GET, HEAD`。未知路由、episode 或 media 返回结构化 JSON 错误。

Snapshot 端点直接返回完整 Envelope，以快照 SHA-256 作为 ETag；health 返回当前 `project_id`、`revision`、PID 和服务版本。`If-None-Match` 命中时返回 `304`。

媒体只可通过快照中已发布的 `media_id` 获取。服务拒绝绝对路径、路径穿越、项目外文件、符号链接、缺失/空文件和 MIME/扩展名不匹配；支持单段 byte range。文件通过同一个已打开句柄完成 stat、流式 SHA-256、签名检查和响应发送；替换、删除、错误 MIME 或客户端中断最多终止本次请求，不得终止 HTTP 服务。响应设置 CSP、`nosniff`、同源资源策略、禁止 framing 和私有 no-cache，不暴露凭据、签名 URL、远端 task ID 或文件系统绝对路径。

## 包内只读看板

静态页面随包发布于 `ui`，只读消费同源 API。资产按“已就绪 → 待处理 → 可延后”排列，同组保持原顺序；不显示“已就绪资产”标题或逐项操作提示。待处理／可延后数量切换筛选并定位原列表，不新增弹框。可延后图片显示蓝色，不计必需缺失或待处理，AI 直出音色不混入此筛选；音色按基础角色去重。

余额使用独立合同 `mantur.drama.account-balance/v1`：`GET /api/v1/account-balance` 只读 `.pipeline-state/runtime/account-balance.json`，`GET /api/v1/account-balance?refresh=1` 执行一次实时查询后返回。服务先完成本机 HTTP 监听和运行状态发布，再异步一次性定位并校验 ManturHub CLI Node 入口、`@manturhub/cli` 包身份、兼容版本和当前站点；慢 CLI 或初始化失败不阻止页面及快照 API。实时刷新直接执行固定入口的 `balance --json`，不通过 shell、`studio.mjs` 或完整 Runtime，不重复扫描入口和版本；CLI／PATH／站点变化需重启服务生效。每次调用仍在联网前检查项目锁站，且不做内部重试，在慢宿主中允许最多 60 秒；超时或输出越界时终止完整子进程树，随后返回不可用状态，不让后台 CLI 或遗留锁持续阻塞后续刷新。响应仅含 `available`、`refreshing`、`balance_points`、`unit`、`checked_at`；不可用时不伪造数值，前端在首次取得真实可用余额前或当前结果不可用时隐藏整个余额胶囊。HEAD 不触发实时查询，其他查询参数拒绝。父服务只解析成功 JSON 根对象中的 `totalBalance` 并原子写缓存；缓存只保存脱敏余额、单位、查询时间、可用状态和站点指纹，不保存邮箱、Key、完整响应、站点地址或任务标识；缓存和刷新事件不参与 Compiler、自动同步指纹或 revision。

完整提示词不得改写。视频历史仅供预览，严格完成按采用 Run 的技术门禁判断。筛选、剧集／Clip／结果选择、展开和媒体播放不改变业务事实；生成、上传、批准、重试均留在聊天中，不能增加页面业务按钮或 HTTP 写接口。

`open-workbench` 保留兼容的一步启动或复用能力；Skill 的正常 Agent 流程必须先完成跨工具调用复核，再使用 `--require-existing` 只复用服务并检查根页面，返回 `url`、`browser_opened=false` 和 `open_via_agent=true`。Agent 随后使用宿主浏览器工具打开链接；宿主无浏览器工具时返回链接。旧服务没有页面时明确报告 `WORKBENCH_UNAVAILABLE`，须得到用户停止旧服务的明确要求，不自动杀进程。

### 项目准备完成后的自动交接

新项目及恢复生产的主入口是 `open-workbench --on-project-ready`。Agent 在用户选定剧本、项目配置保存完成后调用；明确提供剧本并要求制作已构成选择，不必再次询问。单纯讨论、选稿或查询状态不调用。该步骤在远端生产预检、上传、报价和提交前执行，不授予生产权限；初始化的账号状态检查及获同意的登录可先完成，但看板打开不以登录成功为前提。

入口读取 project.json 的 `source_script.path/sha256`，要求非空剧名、项目内普通非空文件、有效相对路径及匹配的 SHA-256，拒绝越界和符号链接。正常 Agent 流程已先完成服务启动与跨调用复核；入口带 `--require-existing` 时只复用该服务，再刷新初始快照并检查页面，返回前复核项目与剧本。缺失、变更或无效输入返回 `WORKBENCH_PROJECT_NOT_READY` 原因，不猜文件、不自动补摘要、不创建假资产报告。服务准备成功前不写展示记录。

首次返回 `open_via_agent=true/presentation_reason=project_ready`，与下方 `--after-extraction` 共用同一记录和锁，后者保留资产报告门禁。两个自动选项互斥，同时传入返回 `WORKBENCH_OPTIONS_CONFLICT`，不启动服务。旧 schema_version=1 展示记录继续有效，无需迁移。普通显式打开仍不受自动防重限制。

所有自动交接失败均返回 `WORKBENCH_HANDOFF_FAILED`、`production_result_preserved=true/retry_production=false`，附带脱敏 `error.stage` 和 `error.cause_code`，区分输入校验、服务准备和页面检查；不返回未检查通过的 URL。既有快照保留，只恢复失败的本地步骤。浏览器尝试已预留后即使宿主失败或中断也不自动重复，仍可显式要求打开。

打开方式、只给链接、禁止服务和远程地址限制统一沿用下方规则。页面复用“待资产提取”与空列表，实际任务运行后才显示“提取中”；公共 Schema/API 与布局不变。

### 资产提取后的自动交接

作为旧项目和未完成前置展示的兼容补漏，提取报告落盘、项目指针更新、结构验收及快照发布成功后，Agent 先确认跨工具调用复核通过，再执行 `open-workbench --after-extraction --require-existing` 获取链接。提取前已预留展示时不再弹页。此时允许资产尚未匹配、图片尚未生成、存在阻断问题；不能以资产完成度为打开门槛。提取任务仍在运行、报告未通过结构验收或只有远端结果未落盘时，不调用此提取后入口。

- `--after-extraction`：检查当前成功发布的 Manifest 包含资产报告引用，再启动/复用服务。使用项目私有 `.pipeline-state/runtime/workbench-presentation.json` 记录 `schema_version=1`、`project_id`、`revision`、`disposition` 和 `recorded_at`；项目锁保护原子写入，防止并发打开。记录不包含端口、URL 或敏感数据，不属于生产事实、JSON 同步输入或公开 API。
- 首次返回 `open_via_agent=true/presentation_reason=first_extraction`，写入 `attempt_reserved`。这是浏览器尝试的预留，不是成功打开的记录。重复返回 `false/already_handled`；即使第一次浏览器失败或 Agent 中断，也不自动重复弹页，仍提供当前链接。普通显式 `open-workbench` 不受此防重限制。
- `--link-only`：用户不打开页面、无宿主打开工具时使用；与任一自动入口组合会写入 `link_only`，返回 `open_via_agent=false`。明确“不启动服务”时不要调用入口。宿主能力或用户限制比返回的建议优先。
- 记录不可读/写时仍返回可用链接，但禁止自动打开，附带 `presentation_warning=WORKBENCH_PRESENTATION_STATE_UNAVAILABLE`，不覆盖损坏记录、不反复尝试打开。
- 提取后服务/刷新/页面检查失败返回 `ok=false/error.code=WORKBENCH_HANDOFF_FAILED`、`production_result_preserved=true/retry_production=false`（命令退出码非零）。它只表示展示交接失败，不能据此把提取改成失败或重新提交算子；保留最后成功快照，先检查快照/服务。旧实例缺页面时仍必须由用户明确要求停止旧服务，不能自动重启。
- `url` 始终来自本次健康服务及页面检查，不从展示记录复用旧端口。Agent 必须在聊天中发送 `[打开生产进度看板](实际url)`；只有宿主工具证实打开成功才说“已打开”，queued 只说“已请求打开”。本地链接只在能访问执行机回环地址的环境有效，不承诺跨机器或跨源 iframe 可用。

浏览器由 Agent 调用宿主工具打开，Node 入口绝不启动浏览器。不会增加 HTTP 写接口、登录检查、生产调用或 UI 控件。后续 JSON 自动同步与 Agent 主动刷新继续按原约定执行。

宿主能识别同项目已打开的页面时，优先复用或定位该标签页，不创建重复标签页。展示记录仅限制自动尝试，不证明页面仍打开，也不记录宿主标签页 ID。

静态 GET/HEAD 仅允许 `/`、`/index.html`、`/app.js`、`/app.css`、`/brand-mantu.svg`、`/brand-mantur.png`、`/video-loading-background.png`、`/video-loading-background.webp`、`/mantur-balance.png`。文件来自 Skill 自身 `ui`，不是项目目录；其他包内文件不可通过 URL 读取。Logo 只打包一份原始 PNG，SVG 路由由该 PNG 合成原有内嵌图片包装，继续支持 Header/favicon；旧背景 PNG URL 是 WebP 的兼容别名，二者返回相同字节及 `image/webp`。所有资源继续使用相同 GET/HEAD、ETag、精确白名单及路径校验。旧服务不会自动重启，更新包后需要用户授权重新启动看板服务以加载新路由。HTML CSP 仅允许同源脚本、样式、图片、媒体与连接；不允许内联脚本、远端资源或 iframe 嵌入。Agent 内独立浏览器标签页可打开，跨源 iframe 不属于当前承诺。

看板以 ETag 查询快照，前后台切换暂停/恢复轮询，网络错误退避并保留旧数据；组合响应的 project_id/revision/source_manifest_sha256 必须相同才能更新页面。

Episode Clip 新增可选 `video_results: [{run_id, attempt, video: MediaRef}]`，为通过本地完整性检查的预览历史；可选 `latest_video_attempt` 只表示最新生成尝试，不替代采用结果。EpisodeSummary 可选 `active_video_attempt_count` 只统计排队或运行中的最新尝试。旧消费者可忽略这些字段，旧快照缺失时继续使用 `latest_video_run` 和 `video_counts`。预览历史不包含远端地址，不表示验收；严格完成计数仍以 `latest_video_run.status=completed` 为准。

`latest_video_attempt.error` 沿用既有可选 `SanitizedError`，仅在算子明确返回失败、超时或取消终态后发布；查询超时、网络错误和限流等恢复异常不写成视频失败。历史终态检查点缺少错误字段时，Compiler 只接受与该操作 ID、Job ID、Clip 和终态全部一致且内容唯一的本地归档轮询响应，不联网、不修改私有操作。错误的密钥、完整 URL、本机路径和内部标识在 Compiler 发布前脱敏。包内看板按最新 attempt 显示排队/生成 Loading 或失败卡；更高 attempt 自动替换旧状态卡，私有历史不删除。失败浮窗只显示脱敏后的 `error.message`，缺失时使用通用说明，不显示错误码。所有状态卡不计入视频结果数、采用、严格完成和交付门禁。Manifest、Envelope、路由及 schema version 保持不变。
