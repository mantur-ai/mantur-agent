# 第 5A 步：Seedance 生产清单、分镜与本地接入

本文的三参数与差量清单提交仅适用于 Seedance。新wan调用改读 [完整资产表 v3 调用](wan-compilation-v3.md)，不得执行本文的旧准备、提交或导入路径。历史wan记录仅只读保留；本次不修改 Runtime。

2026-09-23 创作风格：新分镜操作从项目解析结构化 `creative_style`，将完整预设或自定义文本写入 `visualStyle`，并把风格 revision 与提示词摘要绑定到候选、请求和操作身份。`visualNegative` 继续只承载禁止项，`hardConstraints` 继续承载硬约束。风格变化后旧的未提交操作返回 `PROJECT_CREATIVE_STYLE_CHANGED` 并重新准备／报价；已提交操作按原请求恢复。旧项目缺少风格继续兼容。详见 [视频创作风格合同](creative-style.md)。

2026-09-22 画面比例：新分镜操作从项目读取固定的 `video.ratio`（仅 `9:16 | 16:9`），描述文件显式比例必须与项目一致；两个分镜算子的请求、导入原件及每个转换后模板都要复核同一比例。冲突返回错误，不改写模板、不转换历史产物。正常项目准备应明确选择比例；若该步骤被绕过，Runtime 在首次封存时持久化 `9:16`。

分辨率的来源、中途修改和历史兼容由 [分辨率合同](video-resolution.md) 统一管理；模型选择、WAN 规范化与平台启用边界由 [视频模型合同](video-models.md) 统一管理。本文只定义分镜请求和接入时必须执行的参数一致性校验。

分镜默认通过（2026-09-17）：生成并接入的分镜通过当前结构、模板、素材、时长及连续性技术校验后默认采用，不再请求用户分镜确认，也不调用 apply-clip-review 制造人工通过记录。旧待审核产物按相同规则只读复核；明确驳回、未知状态或技术问题仍阻断。费用批准、素材确认、分镜版本替换决策和真实尾帧门禁保留。

当前开放 `production-manifest-v2-restricted-overrides-file-refs-v1` 窄路径：已验收本地资产 → 独立清单确认 → 上传及试算 → 明确费用批准 → 分镜提交/原任务恢复 → 原字节产物校验 → 本地 Clip 报告 → 看板。空 overrides 兼容；非空修改必须遵循 [需求修订合同](asset-revisions.md)。隔离模拟不等于真实付费验收。

## Agent 当前应做什么

使用现有 `doctor --stage clips` 或 `run --stage clips`。新 OpenAPI 附加 `clip_capabilities`，分别说明外层算子合同与业务文件合同：

- `operator_contract_ready`：本次实时详情的算子身份、可用状态及输入／输出 Schema 是否可识别和编译；不比较打包指纹或业务版本标签。
- `business_contract_ready / production_manifest_ready / local_clip_intake_ready` 为 true；`workflow_ready` 还要求实时外层合同通过。仅支持下列样例证据覆盖的窄路径，不代表支持完整平台枚举。
- 本模块的 `video_ready` 不代表独立视频执行入口，视频能力以 doctor --stage video 为准；`deployment_verified` 仍为 false。语义不兼容的外层合同使用 `OPERATOR_CONTRACT_UNVERIFIED`。
- CLI/认证查询失败仍先报告连接问题；不使用保存详情冒充实时通过，实际请求和结果按本次实时合同校验。

这些状态是包内实现事实，不能通过编辑项目字段或传入 operation_id 开启。具体输入仍由 prepare 校验。legacy、extraction 和素材窄路径保留各自门禁。

## 证据与支持范围

1. 原始需求、清单、Seedance 分镜与 WAN 保存资料仍保留平台提供的版本标签作为审计元数据；接入不再按这些 `v2/v3` 名称放行或拒绝，而是按明确字段结构、血缘和内容校验。内部约束来自真实保存资料，不冒充平台完整正式 Schema。
2. 样例需求身份符合 `upl_` 加 28 位字母数字，真实身份与剧本/需求/清单摘要必须一致，不替换 ID 使样例通过。
3. 支持空及受限非空 overrides、PNG/JPEG 图片、MP3 音色、EXCLUSIVE 与同基础角色音色 SHARED_SAME_ASSET。数字行摘要、受保护字段修改、REFERENCE_ONLY 与未知格式继续阻断；版本标签本身不阻断。
4. Seedance 第二版样例提供 COMPLETED、24 个 Clip 的完整 fileId/mediaRef/SHA 引用；第一版提供 REVIEW_REQUIRED 和 8 项缺失资产。WAN 实测样例有 6 个 Clip、29 个引用及角色变体审核问题，接入校验不得清除问题。保存资料不等于完整视频在线验收。

Job 的受理/恢复使用已有参考协议与受限解析。未知响应阻断，不猜分支。Job qualityReport 是投影，不与内部文件全文强求相等，但共同依赖身份必须一致。缺完整平台定义的其他路径继续保留缺口。

## 已实现的包内模块

`runtime/clip-compilation-contract.mjs` 是后续适配器可复用的纯函数模块，无网络或文件写入：

- `createClipContract(detail, operator)`：operator 由项目模型注册表选择，缺省为兼容旧 Seedance。检查算子身份并编译实时 JSON Schema，不读取打包指纹或版本白名单。具体请求由 `validateInput` 按实时 inputSchema 与业务约束校验，结果由 `inspectOutput` 按提交时保存的 outputSchema 与本地解析约束校验。
- `validateInput(input, expected)`：检查已绑定的三个远端身份、明确连续集数且不超出提取范围、Schema 与跨字段大小关系；不写默认值、不报价、不产生批准。
- `inspectOutput(output, expected)`：仅接受已解包的算子外层 output；检查需求血缘、唯一 JSON/XLSX 角色和不同文件身份。续期前后结果/产物身份必须一致；不因地址变化产生新任务。

输出摘要不回显远端 ID、地址、名称或错误正文。地址存在只表示可尝试下载，不证明媒体可访问或文件已校验；fileId-only、保留期结束分别表达。`REVIEW_REQUIRED` 保留实际技术问题；Seedance 外层 `COMPLETED` 但仍含缺失/歧义时记录 `quality_contradiction` 并按需复核原件，不标记质量通过，也不因此丢弃整份真实产物。旧 WAN 外层路径仍拒绝该矛盾。

分镜与视频统一限定 5–15 秒；4 秒拒绝。1080p 原值保留，视频阶段应用明确的本地输入枚举扩展。上述函数没有校验 PRIMARY_JSON 内容、执行清单全局人审或赋予素材验收，不向 Compiler 写报告。

## Runtime 动作

清单确认后的费用批准统一遵守 [报价与余额展示](quote-and-balance.md)：每次请求批准前执行 `query-account-balance`，展示精确费用、刚查的余额与预计余量或查询失败原因。清单确认本身不是费用批准。

## 集数范围默认策略

- 新的分镜编译意图未指定范围时，Agent 默认使用已封存全集填写 `episodes`，不主动要求用户选择几集，也不把“全集”误当成后续视频生成授权。
- 用户明确要求只编译部分集数时，在准备操作或询价前只提醒一次：一次性编译全剧有助于统一分镜规划，后续视频仍可只生成选中的片段；面向用户给出“建议用完整剧集直接进行分镜编译。”，并询问是否改用全集。尚未取得当前精确请求的有效实时报价时，不展示或推断具体金额。
- 用户了解后仍明确选择部分集数，按其连续范围继续，不再次劝说；Runtime 既有连续子集校验与操作身份保持不变，不把软默认实现成拒绝部分范围的硬限制。
- 恢复已保存的部分集数操作时，严格沿用原 `operation_id`、原范围、幂等键和批准状态，不重新提醒、不扩成全集，也不新建任务或重复扣费。

不得在询价前断言缩小范围不降价或全集与部分同价；需要比较费用时，分别以两份实际参数通过 CLI 查询报价，再如实比较。

该策略只改变 Agent 的新意图默认选择；已有项目、部分编译、版本切换、导入和恢复语义保持不变。视频仅按用户选中的 Clip 单独规划、报价和执行，未选分镜保留待生成；前序依赖按视频批次合同处理。

通过包内 `scripts/studio.mjs` 与现有项目参数执行：

| 动作 | 参数 | 职责 |
|---|---|---|
| prepare-clip-compilation | `--input <描述文件> [--manifest-review <确认文件>] [--no-write]` | 保存候选；确认后上传、校验精确请求并试算 |
| submit-clip-compilation | `--operation-id <本地ID> --approval <批准文件>` | 复核输入、合同及报价后提交一次 |
| resume-clip-compilation | `--operation-id <本地ID>` | 有界恢复原上传、提交、Job、下载或接入 |
| clip-compilation-status | `--operation-id <本地ID>` | 只读本地阶段、错误和下一步，不联网 |
| import-clip-compilation | `--input <接入描述文件> [--no-write]` | 已有产物校验/转换/快照，不登录或重新生成 |

准备描述文件：

```json
{"schema_version":1,"script":"input/script.md","requirements":"input/requirements.json","episodes":[1,2,3,4],"manifest_revision":1,"generation_intent":"first-approved-compilation","parameters":{}}
```

所有文件必须位于项目内，范围显式连续且不超出原提取范围。Agent 通常写入封存全集；只有用户在上述提醒后仍明确选择部分集数时才写入对应连续子集。选中本地资产报告必须等于原需求的受控转换；库存、匹配、审核和媒体 SHA 一致，一个资产只有一个采用媒体。音色按基础角色选择，再按变体展开共享；可延后图片不伪造文件。首版按本地原字节上传确认，不仅凭历史 fileId 字符串复用。

首次 prepare 无确认时不联网，返回 awaiting_manifest_review、candidate_path、manifest_review_binding。Agent 展示候选/范围，取得独立确认后，用返回 binding 加 approved:true 和真实 approved_at 保存文件，再传 --manifest-review。不能把单项素材 passed 自动写成清单 HUMAN_CONFIRMED。

确认后逐文件 upload → PUT → confirm AVAILABLE，保存精确请求和非扣费 precharge。用户明确批准金额/规则后，以返回 approval_binding 加 approved:true/approved_at 保存批准，才可 submit。清单确认不代替费用批准；不虚构报价 Token。首次提交前重新试算，变化返回 ONLINE_QUOTE_CHANGED、旧批准失效。原输入/选择/媒体变化须重新准备，不自动拆分付费任务。

## 状态与恢复

报价、提交、查询使用 [公共双域名路由](manturhub-preflight.md#openapi-双域名路由) 校验后的平台地址，并保存至私有操作记录；旧记录缺少地址时沿用原 BASE 路径，不切站重提。上传申请/确认仍使用 BASE。

私有分镜操作以 `credential_scheme + credential_sha256` 绑定调用身份；旧记录缺 scheme 视为 `legacy-key-v1`。原 Key 可恢复旧操作，切到 CLI 托管身份或换账号／站点／算子身份时不得迁移原批准或 Job，返回 `ONLINE_CREDENTIAL_CHANGED` 并等待用户恢复原认证或创建明确的新操作。

私有目录 `.pipeline-state/runtime/clip-operations/<本地ID>/` 保存不可变输入、候选、确认、批准、请求、上传阶段及响应；脱敏检查点进入 runs。真实远端 ID、临时地址、完整请求和费用不进入快照。

- 已确认文件不重复上传；确认响应丢失恢复原 uploadId。槽位申请收到明确 HTTP 非成功响应时保持 `not_started`，按错误修复或退避后恢复同一操作；请求已发出但无法确认是否创建槽位时立即写入 `application_unknown`，返回不可重试的 `UPLOAD_APPLICATION_UNKNOWN`，`polling.state=blocked`、`next_action=inspect_upload_application`，不猜测新申请。授权过期停止对应步骤。
- 提交前保存稳定幂等键；submission_unknown 每次 resume 最多同键同请求恢复一次，重复 submit 不再发送。幂等失效/冲突停止恢复。
- 有 Job 后只查询原任务，每次 resume 最多一次查询，由 Agent 在动作之间等待并持续调用。明确失败/取消/平台超时保留终态；查询超时不等于任务失败。
- 下载缺链接/过期重查原 Job，产物身份必须不变；首次成功记录固定归档，续期响应另存。摘要不符、保留期结束或仍无地址不重新分镜。
- 原字节流式下载、校验后原子保存；不从 fileId 猜地址，下载不携带平台 Key。
- 接入失败只恢复本地处理；`stage=intake` 与 `snapshot_pending` 只消费已保存 Job、产物和报告，不联网、不重提交，也不重新复算操作、风格、请求、清单确认、批准、受理或首个成功响应。
- 同操作使用操作锁；网络等待不占用项目发布锁。私有归档或项目绑定改变时拒绝恢复，不能用 operation_id 绕过血缘。

## 已有产物接入

```json
{"schema_version":1,"script":"input/script.md","requirements":"input/requirements.json","production_manifest":"input/manifest.json","primary_json":"input/PRIMARY_JSON.json","tabular_xlsx":"input/TABULAR_XLSX.xlsx","job":"input/job-final.json","episodes":[1,2,3,4],"media_mapping":"input/media-mapping.json"}
```

映射为 `{schema_version:1,items:[{asset_id,role,file_id,sha256,path}]}`，role 为 IMAGE/VOICE，每条绑定唯一。真实身份、摘要及媒体必须明确；不按名称/修改时间猜配。


接入校验技术成功、业务状态、原字节摘要、XLSX 结构、血缘、已交付请求与 Clip 的唯一对应、范围/顺序/场次/前序关系、引用与质量问题。COMPLETED 接入后由共享技术校验判定就绪，无需用户分镜确认；REVIEW_REQUIRED 及其原始问题保留，但本地按对实际视频请求的影响分类。WAN `basis=continuity` 组内无前态且已选资产一致时只发布不阻断提醒；缺失依赖、未知冲突及其他技术问题仍阻断。

Seedance 与 WAN v3 共用一部分局部交付接入规则：要求至少一个身份明确的 Clip；缺集、编号间隙、某 Clip 缺请求、可定位的资产 ID／时长／连续性问题，以及 `COMPLETED` 与质量缺失矛盾，保留原件并生成带作用域的问题。文件引用报告中的质量摘要若称资产或音色缺失，但没有任何 Clip 引用它，不因此阻断分镜或报告“分镜仍引用缺失资产”；确有引用时仍阻断受影响 Clip。旧报告缺乏可定位引用时保留原保守规则。当前仍要求已交付的每条请求模板本身安全、正确且与模型、比例、分辨率、引用绑定一致；模板无效不是“缺模板”，不能绕过校验。重复或冲突的 Clip／请求身份、来源／Job／产物校验失败、缺少关键质量报告结构仍整批拒绝。`delivery_scope.incomplete_episodes` 保存已知不完整剧集；这些剧集不计为分镜完成，也不得 ZIP／剪映导出。其余 Clip 仍独立执行素材、模板、连续性与视频门禁；部分展示、视频就绪与完整剧集交付须分别报告。

JSON 重新排版后不得绕过原字节 SHA。样例精确序列化恢复仅在开发夹具中，未进入 Runtime。原始归档与派生报告分开，不伪造远端任务或本地验收。

已有分镜、编辑、Run 或交付不阻止保存候选；首次自动发布，替换/追加须经版本检查和显式切换。在线 workflow 在下载前已经验证持久化操作、项目、风格、请求、清单确认、批准、受理及首个成功 Job；内部接入只确认当前 operation 的成功分镜检查点，再执行 Job/artifact、需求、清单、媒体映射、模板、时长、画幅、引用和连续性门禁。手工接入仍完整验证外部描述资料，且描述文件不接受绕过用的 operation_id。

新派生报告使用 `mantur.drama.clip-compilation/v2` 和 `视频请求体`，旧 v1 保持兼容，首次接入批次原子更新 workflow_state.clip_compile_report/接入身份，仅刷新一次并回读所有剧集快照。--no-write 不创建文件，只证明保存资料内部一致，不声称实时查验 Job。

## 看板兼容

Compiler 仅在受控新报告版本启用 fileId 分支，保留 legacy URL 分支。正文/参数只来自唯一请求行的请求体模板JSON；按 metadata.content 位置及引用表 Token、资产 ID、fileId、mediaRef、SHA 对齐本地媒体，输出已有 media_id。重复素材保留 Token；不按名称排序、不伪造 URL、不联网。缺少当前匹配/有歧义的引用保持未解析，不任取候选。

变体音频映射基础角色。原模板不注入尾帧，pending_previous_tail 等待前序已验收 Run 的真实尾帧；外部 READY_FOR_SUBMIT 不放行视频。只读布局、EPxx/Clip、图片预览、音频互斥、视频及轮询不变。预览 1/6 不等于验收或交付。快照成功按 open-workbench --after-extraction 返回实际链接；尊重仅链接/不启动，不反复弹页，不自行重启服务。

## 按集版本与可选音色

参见 [分镜版本合同](clip-revisions.md)。新增 inspect-clip-compilation-revision、activate-clip-compilation-revision；重新编译必须使用明确 generation_intent，同意图不创建第二个操作。--no-write 不创建操作/版本。

VOICE 仅包含已采用且有效的本地音频。项目允许直出且角色匹配记录明确 status=ai_direct 时，该角色不要求音频，missingVoicePolicy 显式为 ai_direct；否则为 error。已有但无效、冲突或未审核的音色不被忽略。清单允许合法的空 bindings；这不改变图片策略与引用校验。

未匹配角色不能仅凭项目开关通过分镜或视频门禁；先完成匹配并记录角色决策。
