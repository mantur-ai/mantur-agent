#!/usr/bin/env python3
# 本地烧字幕（黑体路，Step 10 / operators.md §7）：
#   PIL 画 STHeiti 华文黑体白字黑描边 → 长句自适应字号防溢出 → ffmpeg overlay 按时间叠加（-c:a copy 不动音频）。
# 时间戳一律锚成片真实语音：传 lines.json（§8 whisper 已聚合）直接用；传 auto 则脚本内跑 faster-whisper 逐字真实时间。
# 用法: burn_subtitle.py <video> <lines.json|auto> <out.mp4>
#   lines.json = [{"text":"第一句","startMs":0,"endMs":2400}, ...]
import json, os, subprocess, sys, tempfile
from PIL import Image, ImageDraw, ImageFont

FONT_PATH = "/System/Library/Fonts/STHeiti Medium.ttc"  # 华文黑体
BASE_FONT = 48          # 起始字号
MIN_FONT = 26           # 缩到此值不再缩（宁可略溢也不糊）
MAX_WIDTH_RATIO = 0.92  # 文本宽超过画面 92% 就缩字号
BOTTOM_MARGIN = 230     # 字底距画面底部像素（720x1280 竖屏底部字幕带）
STROKE = 4              # 黑色描边宽度


def probe_size(video):
    out = subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height", "-of", "csv=p=0:s=x", video,
    ]).decode().strip()
    w, h = out.split("x")
    return int(w), int(h)


def whisper_lines(video):
    # 抽单声道 16k 音轨 → faster-whisper small 逐字时间 → 按句末标点/停顿聚合成行
    from faster_whisper import WhisperModel
    wav = tempfile.mktemp(suffix=".wav")
    subprocess.check_call([
        "ffmpeg", "-y", "-i", video, "-vn", "-ac", "1", "-ar", "16000", wav,
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    model = WhisperModel("small")
    segments, _ = model.transcribe(wav, language="zh", word_timestamps=True)
    lines, buf, start = [], "", None
    for seg in segments:
        for wd in (seg.words or []):
            if start is None:
                start = wd.start
            buf += wd.word
            if wd.word and wd.word[-1] in "。！？；，,.!?;":
                lines.append({"text": buf.strip(), "startMs": int(start * 1000),
                              "endMs": int(wd.end * 1000)})
                buf, start = "", None
        if buf:  # 段末未遇标点也收一行
            lines.append({"text": buf.strip(), "startMs": int(start * 1000),
                          "endMs": int(seg.end * 1000)})
            buf, start = "", None
    os.remove(wav)
    return [ln for ln in lines if ln["text"]]


def fit_font(text, frame_w):
    # 长句自适应：从 BASE_FONT 往下缩，直到文本宽 <= 画面 92%
    size = BASE_FONT
    while size > MIN_FONT:
        font = ImageFont.truetype(FONT_PATH, size)
        w = font.getbbox(text)[2]
        if w <= frame_w * MAX_WIDTH_RATIO:
            break
        size -= 2
    return ImageFont.truetype(FONT_PATH, size)


def render_png(text, frame_w, frame_h, out_png):
    # 整帧透明 PNG，字底部居中，白字黑描边
    img = Image.new("RGBA", (frame_w, frame_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    font = fit_font(text, frame_w)
    l, t, r, b = draw.textbbox((0, 0), text, font=font, stroke_width=STROKE)
    x = (frame_w - (r - l)) // 2 - l
    y = frame_h - BOTTOM_MARGIN - (b - t) - t
    draw.text((x, y), text, font=font, fill="white",
              stroke_width=STROKE, stroke_fill="black")
    img.save(out_png)


def main():
    if len(sys.argv) != 4:
        sys.exit("用法: burn_subtitle.py <video> <lines.json|auto> <out.mp4>")
    video, lines_arg, out = sys.argv[1], sys.argv[2], sys.argv[3]
    frame_w, frame_h = probe_size(video)
    if lines_arg == "auto":
        lines = whisper_lines(video)
    else:
        lines = json.load(open(lines_arg, encoding="utf-8"))
    if not lines:
        sys.exit("没有可烧的字幕行")

    tmp = tempfile.mkdtemp(prefix="subs_")
    inputs, filters, last = ["-i", video], [], "0"
    for i, ln in enumerate(lines):
        png = os.path.join(tmp, f"line{i}.png")
        render_png(ln["text"], frame_w, frame_h, png)
        inputs += ["-i", png]
        s, e = ln["startMs"] / 1000.0, ln["endMs"] / 1000.0
        nxt = f"v{i}"
        filters.append(
            f"[{last}][{i + 1}]overlay=0:0:enable='between(t,{s:.3f},{e:.3f})'[{nxt}]")
        last = nxt
    cmd = ["ffmpeg", "-y", *inputs, "-filter_complex", ";".join(filters),
           "-map", f"[{last}]", "-map", "0:a", "-c:a", "copy", out]
    subprocess.check_call(cmd)
    print("→", out)


if __name__ == "__main__":
    main()
