# 分镜整集版本合同

## 创建与保存

prepare-clip-compilation 描述文件新增 generation_intent（1–128 位字母、数字、下划线或连字符）。已有分镜时必填；同意图恢复同一操作，输入语义变化拒绝复用该意图，新意图重新确认清单、报价和批准。支持 --no-write 只校验候选，不创建文件或联网。

import-clip-compilation 校验原始 JSON/XLSX/Job/清单/剧本血缘后保存独立版本。已有分镜、Run 或交付不阻止保存。首次无分镜时自动采用；以后保存候选不切换活动报告。REVIEW_REQUIRED 可以保存和显式采用以展示问题，不能因此通过视频门禁。

## 查询和确认

统一通过 scripts/studio.mjs --project <绝对项目目录> 执行：

- inspect-clip-compilation-revision：不传参数列出版本和按集采用索引。
- inspect-clip-compilation-revision --revision-id <本地版本ID> [--episodes 1,2]：返回新增、删除、变化 Clip、受影响审核/采用/交付、在途任务和 confirmation_binding。
- activate-clip-compilation-revision --input <项目内确认文件> [--no-write]：按整集切换。确认文件为返回的 confirmation_binding，加 approved:true、user_confirmed:true。不得由测试、默认值或旧确认制造用户批准。

confirmation_binding 包含 schema_version:1、revision_id、episodes 和 expected_state_sha256。省略集数时 inspect 使用该版本完整范围；明确子集只替换所选整集，禁止单 Clip 替换。--no-write 验证输入与计算影响，不创建基线、版本、锁或切换指针。

## 当前与历史

私有 project.json.workflow_state.clip_revisions 保存 schema_version、active、versions 和 activations。原产物在 runtime/clip-compilation-import；工作报告历史在 runtime/clip-revisions/reports，活动报告在 results/clip-active，由现有显式指针供 Compiler 读取。版本文件引用含原字节 SHA，不猜最新文件。组合报告的 episode_contracts 保留各集源协议；旧项目基线仍使用其原有展示和交付解析。

首次版本操作为已有分镜建立基线，归档当前编辑内容与采用关系，不修改历史 Run。新版本 Clip 行及 Run 以 storyboard_revision 关联。跨版本同 ID 不共享审核、采用或尾帧；新候选需重新审核。未受影响集保留有效审核和采用，旧版本可以通过相同检查/确认流程切回。再次采用当前已激活版本为无变更操作；混合范围只替换版本不同的集，保留已激活集的当前编辑、审核与采用。

切换前归档当前工作报告和采用关系，在项目锁中复核摘要，原子提交活动报告、按集索引和 selected_runs。质量问题按集/Clip/引用资产判断；没有身份的质量问题保守作用于原批次。当前统计只包含活动版本的真实 Clip 集合、Run 和交付，删除的 Clip 不再计入分母。历史视频、请求、费用批准和 ZIP 均保留。

目标集存在在途视频或未知提交时，可保存候选但禁止切换；先恢复原任务。其他集不受影响。过期确认返回 CLIP_REVISION_CONFIRMATION_STALE；快照失败保留已切换事实，重复已完成确认只刷新，不再次切换或编译。若之后又切到其他版本，必须重新 inspect 和确认。

## 音色与参数

仅有效已采用音频进入 VOICE；同基础角色变体共享已批准音色。项目 voice_policy.allow_ai_direct、allow_ai_direct 或既有 missing_asset_policy.voices=user_voice_then_explicit_ai_direct 明确允许且角色匹配记录已选择 status=ai_direct 时，才以 missingVoicePolicy=ai_direct 处理该角色；没有匹配记录仍为待匹配。无明确策略返回 CLIP_VOICE_POLICY_REQUIRED，由聊天确认。已指定但缺失、冲突或未审核的音色仍阻断，不能静默改为直出。

Seedance 5–15 秒，4 秒拒绝；本地支持1080p，报价和生成不改值。Schema 本地扩展仅涉及已适配模型的 resolution 枚举，原合同与其他字段继续校验。真实平台是否成功生成1080p另行按费用授权验收。
