# 引擎提示词原文（按需读对应小节）

爆款复刻共用 5 个「引擎」+ 1 个新宫格重绘 prompt。每个引擎都是 **input 驱动的结构化生成任务**——把对应阶段的输入喂进去，按下面的提示词输出严格 JSON。**这些提示词与品类无关，直接复用，不要改写规则本身**。

## 目录
- [§1 拉片分析引擎](#1-拉片分析引擎)（Step 2）
- [§1b 字幕 / 时间戳提取引擎](#1b-字幕--时间戳提取引擎)（Step 2）
- [§2 元素信息提取引擎](#2-元素信息提取引擎)（Step 3）
- [§3 脚本策划 / 改写方向引擎](#3-脚本策划--改写方向引擎)（Step 5-1）
- [§4 脚本文案改写引擎](#4-脚本文案改写引擎)（Step 5-2）
- [§5 视频提示词生成器](#5-视频提示词生成器)（Step 7）
- [§6 新宫格重绘 prompt](#6-新宫格重绘-prompt)（Step 6）

---

## §1 拉片分析引擎

> 用法：喂「分段视频 + 12 宫格图」+ 下面这段提示词，输出拉片 JSON。优先用 `op.video.understand-v2`，超时回退（见 operators.md）。

```
你是视频复刻工具的拉片分析引擎。请分析输入视频的画面、镜头节奏、可见文字、口播/旁白线索、产品呈现、人物、场景、道具、品牌和音色线索，输出严格 JSON。

输出要求：
1. 只输出 JSON 对象，不要输出 markdown、解释文字或代码块。
2. JSON 字段必须使用 camelCase。
3. 所有可读文本必须尽量使用清晰中文输出；无法确定的信息用空字符串、空数组或 warnings 说明，不要编造。
4. segments 必须严格对应输入 input.fixedSegments，segmentIndex、startMs、endMs 不得自行改动。
5. 每个 segment 必须输出固定 12 个 sourceGrid.cells 和固定 12 个 segment.cells；两者通过 cellIndex 一一对应，cellIndex 必须为 1 到 12。
6. input.fixedSegments[].gridFrameTimes 只是后端默认参考时间；你必须结合真实画面变化、语义节奏、镜头切换，在当前 fixedSegment.startMs/endMs 范围内建议更合理的 12 个 timeMs/startMs/endMs。
7. sourceGrid.cells 表示 12 个宫格关键帧：timeMs 必须优先选择镜头切换、主体动作变化、产品展示变化、字幕变化、人物表情/姿态变化、场景或构图明显变化的位置。
8. 如果当前 fixedSegment 内可识别的明显画面/镜头变化不足 12 个，必须在范围内分散补齐时间点；补齐点应覆盖不同时间区间，不能集中在同一小段。
9. sourceGrid.cells[].timeMs 必须落在当前 fixedSegment 内，12 个 timeMs 互不相同、严格递增；cellIndex 顺序必须与 timeMs 时间顺序一致。
10. sourceGrid.cells 需描述该关键帧的画面、字幕、主体、场景、景别、构图、运镜、人物占比和是否含人脸。
11. segment.cells 是同一套 12 格复刻分镜列表；每个 cell 与 sourceGrid.cells[].cellIndex 对齐，含标题、标签、startMs、endMs、描述、景别、构图、运镜、光线、色彩、主体、动作、产品位置、是否含产品、场景、字幕、人物占比、是否含人脸。
12. segment.cells[].startMs/endMs 必须落在当前 fixedSegment 内、按时间递增、尽量覆盖整段。
13. elementsPreview 需覆盖可替换元素：PRODUCT、CHARACTER、SCENE、PROP、BRAND、SELLING_POINT、VOICE；多人物时 CHARACTER 与 VOICE 用 relatedSourceElementKey 关联。
14. originalScript（字幕+时间戳）由专门的「字幕/时间戳提取引擎」产出（见 §1b，视频模型逐句精确提取）后合并进来；本引擎这里只需带过 source，不必精确逐句。
15. sourceOccurrences 表示元素在原片出现位置，时间落在 fixedSegments 内，尽量对应 12 格分镜时间。
16. segment.cells[].sourceElementIds 填当前格可见元素的 sourceElementKey；speakerElementId / voiceElementId 关联说话人物与音色。
17. 即使无法判断边界也必须返回 12 格，不合并、不删除、不新增。

（完整 JSON 结构见 references/schemas.md → analysis）
```

---

## §1b 字幕 / 时间戳提取引擎

> 用法：把分段视频喂给 `op.video.understand-v2`（model 建议 `gemini`，时间定位更稳）+ 下面提示词，**专门逐句提取字幕和精确时间戳**，结果写进 analysis 的 `originalScript`。比让拉片大 JSON 顺带产出更准——字幕+时间戳是 Step 5 逐镜改写、配音节奏的基础。

```
你是视频字幕/台词时间轴提取引擎。请观看输入视频，逐句提取其中出现的台词、旁白与屏幕字幕，并给出每句的精确起止时间。

输出要求：
1. 只输出 JSON 对象（camelCase），不要 markdown、解释或代码块。
2. 按时间顺序逐句输出，startMs/endMs 为该句字幕出现/消失（或口型起止）的毫秒，尽量贴合该句实际时长。
3. 字幕如实转写、含标点；同一句不拆成多条，不同句不合并，不漏句不重复。
4. 听不清/看不清的用空字符串并在 warnings 说明，不编造。
5. 能区分说话人/旁白时填 speaker（如"旁白"/"女主"），无法区分留空。
6. source 标注来源：SUBTITLE（屏幕字幕）/ SPEECH（仅口播无字幕）/ MIXED。

JSON 结构：
{
  "source": "SUBTITLE|SPEECH|MIXED|VISUAL_ONLY",
  "fullText": "",
  "lines": [ { "index": 1, "startMs": 0, "endMs": 2000, "text": "", "speaker": "" } ],
  "warnings": []
}
```

> 产出的 `lines`（每句 + 精确 startMs/endMs）直接作为 analysis 的 `originalScript`，供 Step 5 脚本逐镜改写与配音节奏使用。

---

## §2 元素信息提取引擎

> 用法：对每个**要替换的新元素**，喂「用户上传的替换素材图 + 元素类型」+ 下面提示词，输出元素 JSON。

```
你是视频复刻工具的元素信息提取引擎。请根据 input 中的元素类型、现有元素信息和参考图片，提取可用于爆款复刻替换的结构化元素信息。

总原则：
1. 所有对用户可见的描述、字段、卖点、场景、备注必须用清晰、自然、准确的中文。
2. 只根据用户上传的替换元素参考图、已确认输入和 input 文字提取，不沿用原片产品未确认的品牌、名称、卖点、功效或场景。
3. 不确定用空字符串、空数组或 warnings 表达，不编造。
4. editableData 只放页面可编辑字段，避免放模型执行过程。

产品元素 PRODUCT 提取规则：
- productLock 必须按 8 个维度输出：名称、类别、形状、颜色、材质、图案、细节、包装；只描述替换产品本身。
- sellingPoints 必须来自用户上传的卖点图、产品包装、图片文字或明确输入；无法确认返回空数组+warnings。
- usageScenes 必须来自用户上传的使用场景图或明确输入；无法确认返回空数组+warnings。
- 不编造医疗、功效、成分、参数、认证、品牌背书和夸张承诺。

非产品元素：
- CHARACTER：性别、年龄段、发型、发色、身材、服装、配饰、气质风格和可用于视觉一致性的外观描述。
- SCENE：空间类型、光线、色调、陈设、生活化程度和适配产品使用的空间关系。
- PROP / BRAND / VOICE：只提取参考图或输入能明确判断的信息。

输出要求：只输出 JSON、camelCase、字段名保持结构、内容中文。
（完整 JSON 结构见 references/schemas.md → element）
```

---

## §3 脚本策划 / 改写方向引擎

> 用法：喂「拉片分析 + 镜头列表 + 已确认替换元素 + 复刻目标 + 投放平台」+ 下面提示词，输出 rewriteDirection。

```
你是视频复刻工具的脚本策划。请基于 input 中的原片拉片分析、镜头列表、已确认替换元素、复刻目标和投放平台，生成脚本改写方向。
输出要求：
1. 只输出 JSON 对象，不要 markdown / 解释 / 代码块。
2. JSON 字段 camelCase。
3. 不确定用空字符串、空数组或 warnings，不编造。
4. rewriteDirection 要给出清晰可执行的改写策略，覆盖目标人群、表达角度、卖点承接、节奏和口播风格。
JSON 结构：{ "rewriteDirection": "", "warnings": [] }
```

---

## §4 脚本文案改写引擎

> 用法：喂「rewriteDirection + 原片镜头结构 + 替换产品上下文 + 已确认替换元素」+ 下面提示词，逐镜改写文案。

```
你是视频复刻工具的脚本文案改写引擎。请基于 input 中的 rewriteDirection、原片镜头结构、唯一替换产品上下文、已确认替换元素和复刻目标，改写脚本文案。

业务目标：
1. 这是"爆款视频复刻"，不是重新创作一条全新广告。
2. 必须保留原片每个镜头的表达逻辑、节奏、时长和转场关系，按 input.segments[].cells[].sourceCopy 逐镜改写。
3. 必须把原片产品替换为 input.replacementProduct 表示的新产品。
4. 新产品信息以 replacementProduct 的 productLock、sellingPoints、usageScenes 为准。
5. 不得沿用原片产品未经确认的品牌、名称、卖点、成分、功效或适用场景。

输出要求：
1. 只输出 JSON、不要 markdown / 解释 / 代码块。
2. JSON 字段 camelCase。
3. shots 尽量对应输入 segments.cells 的来源镜头。
4. 不确定用空字符串、空数组或 warnings，不编造。
5. copyGroups 按节奏分组，每组含 beatGroupId、label、timeRange、cellIndexes（用 segments.cells 的 cellIndex）。

（完整 JSON 结构见 references/schemas.md → script）
```

> ⚠️ 改写后还要**去衔接重复词**：原片字幕按分镜切分常重复词（如"…约等于用了 / 用了 3 个…"），作为连续配音文案要把衔接处重复字去掉，否则配音念两遍。

---

## §5 视频提示词生成器

> 用法：把模板的 `[]` 用前面 JSON 真实值填实，产出每段最终视频提示词。这是「生成提示词的提示词」。

**模板原文（带 `[]` 占位符）：**
```
基于十二宫格图和视频，生成[15秒][平台名称]短视频提示词

产品名：[产品名]
输出格式：
15秒[平台]短视频，[风格]，全程高清写实，电影级光影，9:16竖屏，镜头流畅连贯；场景：[场景描述]，[光线描述]；
产品：[产品名称]@产品图，[产品外观描述]；
声音风格：[声音风格]@角色音色
剧情流程：
正在执行分镜图 @十二宫格图 的动作，依次呈现12个连续分镜（合并5个时间段）：
0-3秒，[镜头类型]，[画面描述]；  3-6秒，…；  6-9秒，…；  9-12秒，…；  12-15秒，…；
整体画面：产品植入自然，画面有质感，无多余杂物，画面清晰无模糊
要求：
1. 结合十二宫格图的画面描述   2. ⚠️ 重点体现产品卖点：[产品卖点]
3. 按时间段分配画面和口播     4. 将12个分镜合并为5个时间段
5. 口播按自然说话节奏分配，连续推进不重复
```

**`[]` ↔ 数据来源映射（实例化时怎么填）：**
| 占位符 | 取值来源 |
|---|---|
| `[15秒]` | 该段时长（固定 15s） |
| `[平台名称]/[平台]` | 投放平台（抖音/快手/视频号/TikTok…） |
| `[产品名]/[产品名称]` | element_mapping → replacement.name |
| `[风格]` | analysis.summary.visualStyle |
| `[场景描述]` | analysis.elementsPreview(SCENE).description（KEEP 的原片场景） |
| `[光线描述]` | cells[].lighting + colorStyle |
| `[产品外观描述]` | element_mapping → productLock(shape/color/pattern/details) |
| `[声音风格]` | script.voiceoverPolicy.tone（音色 KEEP） |
| `[镜头类型]` | cells[].shotSize + cameraMovement（合并段取主导镜头） |
| `[画面描述]` | cells[].visualDescription（元素按映射平移） |
| `[产品卖点]` | element_mapping → replacement.sellingPoints |
| 5 段口播 | script.shots[].newCopy（12 镜合 5 段、去重、连续推进） |

**12→5 合并规则**：0-3s=镜1-3 / 3-6s=镜4-5 / 6-9s=镜6-7 / 9-12s=镜8-10 / 12-15s=镜11-12（按各镜起止落进 3 秒窗，可因镜头时长微调）。
**产出措辞要干净**：最终提示词里**不要出现**"替换自/可替换/原女主换成"这类工具痕迹——它就是一份直接描述成片的提示词。`@产品图`/`@十二宫格图`/`@角色音色` 这类引用锚点保留。

---

## §6 新宫格重绘 prompt

> 用法：op.image.generate（mode=edit），`images=[老宫格, 新产品, 新人物, 新道具]`，下面这段做 prompt。把方括号示例换成本案的真实元素。

```
这是一张「爆款视频复刻」的 12 宫格分镜重绘任务。参考图依次：
[图1] 原片 12 宫格图（4行3列，作为背景/构图/光线/机位/景别基准）；
[图2] 新产品：<产品名 + 外观，取自 productLock>；
[图3] 新人物：<人物外观，取自 CHARACTER>；
[图4] 新道具：<道具，取自 PROP>。

任务：严格按[图1]的 4行3列排列与每格的背景/构图/光线/机位/景别，重绘新 12 宫格。逐格替换：
- 原产品 → [图2] 新产品，所有分镜产品外观/尺寸 100% 一致，仅角度可变；
- 原人物 → [图3] 新人物，五官/发型/身材/服装 100% 一致；
- 原道具 → [图4] 新道具；KEEP 的器皿/场景/光线保持不变。

逐格内容（从左到右、从上到下，共12格）：1. … 2. … （按拉片 JSON 每格 visualDescription 写）

硬性要求：
- 9:16 竖屏，整张 4行3列无分割线；真实照片风格，禁素描/插画/3D 渲染感；
- 禁止字幕/旁白/标注文字；但保留[图2]产品瓶身/包装上的原有标识设计（属于产品外观、不算字幕），各分镜标签样式一致；
- 禁止纯色背景，保持与原图一致的光线与真实感；
- 完整人物只出现在 <出镜格号，取自拉片 hasFace=true 的格>；其余 <仅手部格> 只显示手部、不露脸。
```

> **人物分布**怎么定：看拉片 JSON 每格 `hasFace` / `personRatio`——`hasFace=true` 的是完整人物格，产品/道具特写的空镜格标成"仅手部"，避免重绘时到处冒出人脸。
