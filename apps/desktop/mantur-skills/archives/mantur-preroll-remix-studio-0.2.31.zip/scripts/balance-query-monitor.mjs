const messages = Object.freeze({
  CONTRACT_UNSUPPORTED: '余额查询未接入。', LEGACY_PROJECT_READ_ONLY: '历史项目仅供审阅，未查询余额。',
  NOT_STARTED: '余额查询尚未启动。', BALANCE_PENDING: '正在查询余额。', READY: '最近查询余额，非实时账户监控。',
  QUERY_FAILED: '余额查询失败，请检查授权和网络后重试。', INVALID_RESPONSE: '余额查询结果无法核实。',
  BALANCE_TIMEOUT: '余额查询超时，请重试。', CLOSED: '余额查询已关闭。', CLOSE_TIMEOUT: '余额查询清理尚未完成。',
});
const amount = value => typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= Number.MAX_SAFE_INTEGER;

/** One startup read plus explicit refreshes; no identity inference or periodic account polling. */
// CLI cancellation grants 2s for TERM before KILL; cleanup must also await child close.
export function createBalanceQueryMonitor({ queryBalance, unavailableReason, timeoutMs = 10000,
  closeTimeoutMs = 5000, manualCooldownMs = 1000, now = Date.now } = {}) {
  for (const value of [timeoutMs, closeTimeoutMs, manualCooldownMs])
    if (!Number.isSafeInteger(value) || value < 1 || value > 120000) throw new Error('Invalid balance query timing');
  if (typeof now !== 'function' || unavailableReason !== undefined && !['CONTRACT_UNSUPPORTED', 'LEGACY_PROJECT_READ_ONLY'].includes(unavailableReason))
    throw new Error('Invalid balance query configuration');
  const disabled = unavailableReason ?? (typeof queryBalance === 'function' ? undefined : 'CONTRACT_UNSUPPORTED');
  let started = false, closed = false, pending, queued = false, timer, closing, generation = 0, lastStart = -Infinity;
  let state = clear(disabled ?? 'NOT_STARTED');
  function clear(reasonCode, status = 'unavailable') {
    return { mode: 'query', status, totalBalance: null, giftBalance: null, rechargeBalance: null, unit: '馒头',
      checkedAt: null, lastAttemptAt: null, reasonCode, message: messages[reasonCode] };
  }
  const snapshot = () => ({ ...state, queryRevision: generation });
  function pump() {
    clearTimeout(timer);
    if (closed || disabled || !started || pending || !queued) return;
    const delay = lastStart + manualCooldownMs - now();
    if (delay > 0) { timer = setTimeout(pump, delay); timer.unref?.(); return; }
    queued = false;
    const record = { controller: new AbortController(), generation: ++generation };
    pending = record; lastStart = now();
    state = { ...clear('BALANCE_PENDING', 'loading'), lastAttemptAt: new Date(lastStart).toISOString() };
    const current = () => !closed && record.generation === generation && !record.controller.signal.aborted;
    record.timer = setTimeout(() => {
      if (!current()) return;
      generation++; record.controller.abort(); state = clear('BALANCE_TIMEOUT');
    }, timeoutMs); record.timer.unref?.();
    record.promise = Promise.resolve().then(() => {
      if (current()) return queryBalance({ signal: record.controller.signal });
    }).then(value => {
      if (!current()) return;
      if (!amount(value?.totalBalance) || value.unit !== '馒头'
        || ['giftBalance', 'rechargeBalance'].some(key => value[key] !== undefined && !amount(value[key]))) {
        state = clear('INVALID_RESPONSE'); return;
      }
      state = { ...clear('READY', 'ready'), totalBalance: value.totalBalance,
        giftBalance: value.giftBalance ?? null, rechargeBalance: value.rechargeBalance ?? null,
        lastAttemptAt: state.lastAttemptAt, checkedAt: new Date(now()).toISOString() };
    }).catch(error => {
      if (current()) state = clear(error?.code === 'BALANCE_QUERY_INVALID_RESPONSE' ? 'INVALID_RESPONSE' : 'QUERY_FAILED');
    }).finally(() => {
      clearTimeout(record.timer);
      if (pending === record) pending = undefined;
      pump();
    });
  }
  function start() {
    if (!closed && !disabled && !started) { started = true; queued = true; pump(); }
    return snapshot();
  }
  function trigger() {
    if (!closed && !disabled && started) {
      queued = true; generation++;
      if (pending && !pending.controller.signal.aborted) pending.controller.abort();
      state = clear('BALANCE_PENDING', 'loading'); pump();
    }
    return snapshot();
  }
  function close() {
    if (closing) return closing;
    closed = true; queued = false; generation++; clearTimeout(timer);
    state = clear('CLOSED');
    const owned = pending;
    if (owned) { clearTimeout(owned.timer); owned.controller.abort(); }
    closing = (async () => {
      let deadline;
      const cleanupComplete = await Promise.race([
        Promise.resolve(owned?.promise).then(() => true),
        new Promise(resolve => { deadline = setTimeout(() => resolve(false), closeTimeoutMs); }),
      ]);
      clearTimeout(deadline);
      const reasonCode = cleanupComplete ? 'CLOSED' : 'CLOSE_TIMEOUT'; state = clear(reasonCode);
      return { closed: true, cleanupComplete, pendingRequests: pending ? 1 : 0, reasonCode };
    })();
    return closing;
  }
  return { start, trigger, snapshot, close };
}
