import {execFile} from 'node:child_process';
import {promisify} from 'node:util';

/** Ask the OS to open only a verified local viewer. Host permissions still apply. */
export async function openSystemBrowser(value,{platform=process.platform,run=promisify(execFile)}={}){
  let url;
  try{url=new URL(value);}catch{}
  if(typeof value!=='string'||/\s/.test(value)||!/^http:\/\/127\.0\.0\.1:[1-9]\d{0,4}\/?$/.test(value)||!url||Number(url.port)>65535)
    throw Object.assign(Error('工作台地址无效'),{code:'WORKBENCH_URL_INVALID'});
  const commands={darwin:['/usr/bin/open',[url.origin]],win32:['rundll32.exe',['url.dll,FileProtocolHandler',url.origin]],linux:['xdg-open',[url.origin]]};
  const command=commands[platform];
  if(command)try{await run(...command,{timeout:3000,maxBuffer:8192,shell:false,windowsHide:true});return {status:'open_requested'};}catch{}
  return {status:'host_browser_required',reasonCode:'BROWSER_OPEN_UNAVAILABLE'};
}
