import fs from 'node:fs/promises';
import { parentPort, workerData } from 'node:worker_threads';
import mp4box from './mp4box.all.cjs';

mp4box.Log.setLogLevel(mp4box.Log.error);

const MAX_METADATA = 32 * 1024 * 1024, MAX_SAMPLES = 1000000, MAX_BOXES = 20000, MAX_TRACKS = 16;
const fail = (code = 'MEDIA_METADATA_INVALID') => { throw Object.assign(new Error(code), { code }); };
const requireValid = value => { if (!value) fail(); };
const safe = value => Number.isSafeInteger(value) && value >= 0;
const checked = { validation: { container: true, decode: 'not_performed' }, metadataSource: 'container' };
async function readAt(handle, position, size) {
  requireValid(safe(position) && safe(size) && size <= MAX_METADATA);
  const buffer = Buffer.alloc(size);
  let offset = 0;
  while (offset < size) { const { bytesRead } = await handle.read(buffer, offset, size - offset, position + offset); if (!bytesRead) fail(); offset += bytesRead; }
  return buffer;
}
function header(buffer, start, end) {
  requireValid(start + 8 <= end);
  let size = buffer.readUInt32BE(start), bytes = 8;
  const type = buffer.toString('latin1', start + 4, start + 8);
  if (size === 1) { requireValid(start + 16 <= end); const n = buffer.readBigUInt64BE(start + 8); if (n > BigInt(Number.MAX_SAFE_INTEGER)) fail(); size = Number(n); bytes = 16; }
  if (size === 0) size = end - start;
  requireValid(size >= bytes && start + size <= end);
  return { type, size, bytes, start, body: start + bytes, end: start + size };
}
const containers = new Set(['moov','trak','mdia','minf','stbl','edts','dinf','udta','tapt','tref','mvex','moof','traf','mfra','sinf','schi','wave']);
const visualEntries = new Set(['avc1','avc2','avc3','avc4','hvc1','hev1','vp08','vp09','av01','mp4v','jpeg','png ','raw ','encv','apch','apcn','apcs','apco','ap4h','ap4x']);
const audioEntries = new Set(['mp4a','enca','ac-3','ec-3','Opus','fLaC','alac','sowt','twos','lpcm','in24','in32','fl32','fl64']);
// This walk validates bounds and allocation counts before handing metadata to
// mp4box. It is deliberately not a second codec/sample-table parser.
function guardMetadata(buffer, allocation) {
  let boxes = 0, tracks = 0, samples = 0;
  const count = (n, capacity) => { if (!safe(n) || n > MAX_SAMPLES) fail('MEDIA_METADATA_LIMIT'); requireValid(n <= capacity); };
  const full = (box, n) => { requireValid(box.body + n <= box.end); requireValid(buffer[box.body] === 0); };
  function walk(start, end, depth = 0, parent) {
    if (depth > 16) fail('MEDIA_METADATA_LIMIT');
    const table = {};
    while (start < end) {
      const box = header(buffer, start, end);
      if (++boxes > MAX_BOXES) fail('MEDIA_METADATA_LIMIT');
      if (box.type === 'trak' && ++tracks > MAX_TRACKS) fail('MEDIA_METADATA_LIMIT');
      if (box.type === 'cmov') fail('MEDIA_METADATA_UNSUPPORTED');
      if (containers.has(box.type)) walk(box.body, box.end, depth + 1, box.type);
      else if (box.type === 'meta') { requireValid(box.body + 4 <= box.end); walk(box.body + 4, box.end, depth + 1); }
      else if (box.type === 'stsd' || box.type === 'dref') {
        full(box, 8); const n = buffer.readUInt32BE(box.body + 4); count(n, Math.floor((box.end - box.body - 8) / 8));
        let at = box.body + 8;
        for (let i = 0; i < n; i++) {
          const entry = header(buffer, at, box.end);
          if (box.type === 'stsd') {
            if (visualEntries.has(entry.type)) { requireValid(entry.body + 78 <= entry.end); walk(entry.body + 78, entry.end, depth + 1); }
            else if (audioEntries.has(entry.type)) {
              requireValid(entry.body + 28 <= entry.end);
              const version = buffer.readUInt16BE(entry.body + 8), length = version === 0 ? 28 : version === 1 ? 44 : version === 2 ? 64 : null;
              if (length === null) fail('MEDIA_METADATA_UNSUPPORTED');
              requireValid(entry.body + length <= entry.end); walk(entry.body + length, entry.end, depth + 1);
            }
          }
          at = entry.end;
        }
        requireValid(at === box.end);
      } else if (box.type === 'stsz') {
        full(box, 12); const fixed = buffer.readUInt32BE(box.body + 4), n = buffer.readUInt32BE(box.body + 8);
        count(n, fixed ? MAX_SAMPLES : Math.floor((box.end - box.body - 12) / 4)); samples += n;
        allocation.samples += n; if (allocation.samples > MAX_SAMPLES) fail('MEDIA_METADATA_LIMIT');
        if (samples > MAX_SAMPLES) fail('MEDIA_METADATA_LIMIT');
        requireValid(table.sampleCount === undefined); table.sampleCount = n;
        let bytes = fixed * n;
        if (!fixed) for (let i = 0; i < n; i++) { const size = buffer.readUInt32BE(box.body + 12 + i * 4); requireValid(size > 0); bytes += size; }
        allocation.sampleBytes += bytes; requireValid(safe(allocation.sampleBytes) && allocation.sampleBytes <= allocation.payloadBytes);
      } else if (box.type === 'stz2') {
        full(box, 12); const bits = buffer[box.body + 7], n = buffer.readUInt32BE(box.body + 8);
        requireValid([4,8,16].includes(bits)); count(n, Math.floor((box.end - box.body - 12) * 8 / bits)); samples += n;
        allocation.samples += n; if (allocation.samples > MAX_SAMPLES) fail('MEDIA_METADATA_LIMIT');
        if (samples > MAX_SAMPLES) fail('MEDIA_METADATA_LIMIT');
        requireValid(table.sampleCount === undefined); table.sampleCount = n;
        let bytes = 0;
        for (let i = 0; i < n; i++) {
          const at = box.body + 12, size = bits === 16 ? buffer.readUInt16BE(at + i * 2) : bits === 8 ? buffer[at + i] : (buffer[at + Math.floor(i / 2)] >> (i % 2 ? 0 : 4)) & 15;
          requireValid(size > 0); bytes += size;
        }
        allocation.sampleBytes += bytes; requireValid(safe(allocation.sampleBytes) && allocation.sampleBytes <= allocation.payloadBytes);
      } else if (box.type === 'elst') {
        requireValid(box.body+8<=box.end&&buffer[box.body]<=1);
        const n=buffer.readUInt32BE(box.body+4), stride=buffer[box.body]===1?20:12;
        count(n,Math.floor((box.end-box.body-8)/stride));
        if(n!==1)fail('MEDIA_METADATA_UNSUPPORTED');
      } else if (box.type === 'trun') {
        requireValid(box.body + 8 <= box.end && buffer[box.body] <= 1);
        const flags = buffer.readUIntBE(box.body + 1,3), n = buffer.readUInt32BE(box.body + 4);
        requireValid((flags & ~0xf05) === 0);
        const prefix = 8 + (flags & 1 ? 4 : 0) + (flags & 4 ? 4 : 0);
        const stride = [0x100,0x200,0x400,0x800].filter(flag => flags & flag).length * 4;
        requireValid(box.body + prefix <= box.end); count(n,stride ? Math.floor((box.end - box.body - prefix)/stride) : MAX_SAMPLES);
        allocation.samples += n; if (allocation.samples > MAX_SAMPLES) fail('MEDIA_METADATA_LIMIT');
      } else if (['stts','ctts','stsc','stco','co64','stss'].includes(box.type)) {
        requireValid(box.body + 8 <= box.end);
        if (box.type !== 'ctts') requireValid(buffer[box.body] === 0);
        else requireValid(buffer[box.body] <= 1);
        const stride = box.type === 'stsc' ? 12 : ['stts','ctts','co64'].includes(box.type) ? 8 : 4;
        const n = buffer.readUInt32BE(box.body + 4); count(n, Math.floor((box.end - box.body - 8) / stride));
        if (box.type === 'stts' || box.type === 'ctts') {
          let total = 0;
          for (let i = 0; i < n; i++) { const at = box.body + 8 + i * 8; total += buffer.readUInt32BE(at); if (total > MAX_SAMPLES) fail('MEDIA_METADATA_LIMIT'); if (box.type === 'stts') requireValid(buffer.readInt32BE(at + 4) > 0); }
          if (box.type === 'stts') { requireValid(table.timeCount === undefined); table.timeCount = total; }
        }
      }
      start = box.end;
    }
    requireValid(start === end);
    if (parent === 'stbl') requireValid(table.sampleCount !== undefined && table.sampleCount === table.timeCount);
  }
  walk(0, buffer.length);
}
function geometry(entry, matrix, width, height) {
  const sar = entry.pasp;
  if (sar && (!(sar.hSpacing > 0) || sar.hSpacing !== sar.vSpacing)) return { displayGeometryKnown: false };
  if (!matrix || matrix.length !== 9 || matrix[2] !== 0 || matrix[5] !== 0 || matrix[8] !== 1073741824) return { displayGeometryKnown: false };
  const key = [matrix[0],matrix[1],matrix[3],matrix[4]].join(',');
  const rotations = new Map([['65536,0,0,65536',false],['0,65536,-65536,0',true],['-65536,0,0,-65536',false],['0,-65536,65536,0',true]]);
  if (!rotations.has(key)) return { displayGeometryKnown: false };
  const swapped = rotations.get(key);
  return { displayGeometryKnown: true, displayWidth: swapped ? height : width, displayHeight: swapped ? width : height };
}
function playbackTimeline(video, movieScale, fragmented) {
  const table = video.mdia.minf.stbl, samples = video.samples;
  let rawTicks=0, minCTS=Infinity, maxEnd=-Infinity, run=0, remaining=table.stts?.sample_counts?.[0]||0;
  for (const sample of samples) {
    let delta;
    if (fragmented) {
      if(!safe(sample.duration)||sample.duration<=0||sample.dts!==rawTicks)fail('MEDIA_METADATA_UNSUPPORTED');
      delta=sample.duration;
    } else {
      while(remaining===0&&run+1<table.stts.sample_counts.length)remaining=table.stts.sample_counts[++run];
      requireValid(remaining>0);delta=table.stts.sample_deltas[run];remaining--;
    }
    // Use exact stts durations instead of the vendor's last-sample adjustment
    // to mdhd.duration (which can include edit-list/B-frame padding).
    const offset=sample.cts-sample.dts, cts=rawTicks+offset;
    requireValid(Number.isSafeInteger(offset)&&Number.isSafeInteger(cts)&&safe(delta)&&delta>0);
    minCTS=Math.min(minCTS,cts);maxEnd=Math.max(maxEnd,cts+delta);rawTicks+=delta;
  }
  requireValid(safe(rawTicks)&&rawTicks>0&&Number.isSafeInteger(maxEnd));
  const edits=video.edts?.elst?.entries;
  if(!edits)return {ticks:rawTicks,rawTicks};
  if(edits.length!==1)fail('MEDIA_METADATA_UNSUPPORTED');
  const edit=edits[0];
  if(!safe(edit.media_time)||!safe(edit.segment_duration)||edit.segment_duration<=0||edit.media_rate_integer!==1||edit.media_rate_fraction!==0||edit.media_time<minCTS||edit.media_time>=maxEnd)fail('MEDIA_METADATA_UNSUPPORTED');
  const scale=video.mdia.mdhd.timescale;
  requireValid(safe(movieScale)&&movieScale>0&&safe(scale)&&scale>0);
  // Movie timescales often round 121/24 to 5.042. Keep the exact presentation
  // boundary when it is shorter; trimmed single edits use their declared end.
  const segmentTicks=BigInt(edit.segment_duration)*BigInt(scale)/BigInt(movieScale);
  if(segmentTicks>BigInt(Number.MAX_SAFE_INTEGER))fail('MEDIA_METADATA_UNSUPPORTED');
  const ticks=Math.min(maxEnd-edit.media_time,Number(segmentTicks));
  requireValid(safe(ticks)&&ticks>0);
  return {ticks,rawTicks};
}
const codecName = type => ({ avc1:'h264',avc2:'h264',avc3:'h264',avc4:'h264',hvc1:'hevc',hev1:'hevc',vp08:'vp8',vp09:'vp9',av01:'av1',mp4v:'mpeg4','png ':'png',jpeg:'mjpeg',apch:'prores',apcn:'prores',apcs:'prores',apco:'prores',ap4h:'prores',ap4x:'prores' }[type] || type);
async function probeMp4(handle, size) {
  const top = []; let position = 0, total = 0, moovCount = 0;
  while (position < size) {
    if (top.length >= MAX_BOXES) fail('MEDIA_METADATA_LIMIT');
    const head = await readAt(handle, position, Math.min(16, size - position));
    const initial = head.readUInt32BE(0); let bytes = initial === 1 ? 16 : 8;
    requireValid(head.length >= bytes);
    let length = initial === 1 ? Number(head.readBigUInt64BE(8)) : initial === 0 ? size - position : initial;
    requireValid(safe(length) && length >= bytes && position + length <= size);
    const type = head.toString('latin1',4,8);
    if (type === 'cmov') fail('MEDIA_METADATA_UNSUPPORTED');
    if (type === 'moov') moovCount++;
    // Mdat payload is never loaded. Other boxes belong to the bounded metadata
    // budget, including large padding/unknown boxes that the vendor may retain.
    total += type === 'mdat' ? bytes : length;
    if (total > MAX_METADATA) fail('MEDIA_METADATA_LIMIT');
    top.push({ position, length, bytes, type }); position += length;
  }
  requireValid(moovCount === 1 && top.some(box => box.type === 'mdat'));
  const mp4 = mp4box.createFile(false); let parseFailed = false;
  const allocation = { samples:0, sampleBytes:0, payloadBytes:top.filter(box => box.type === 'mdat').reduce((sum,box) => sum + box.length - box.bytes,0) };
  mp4.onError = () => { parseFailed = true; };
  for (const box of top) {
    const buffer = await readAt(handle, box.position, box.type === 'mdat' ? box.bytes : box.length);
    if (box.type === 'moov' || box.type === 'moof') guardMetadata(buffer,allocation);
    const array = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength); array.fileStart = box.position;
    mp4.appendBuffer(array);
    requireValid(!parseFailed);
  }
  const movie = mp4.moov;
  requireValid(movie?.mvhd && movie.traks?.length && movie.traks.length <= MAX_TRACKS);
  const mdats = top.filter(box => box.type === 'mdat').map(box => [box.position + box.bytes, box.position + box.length]);
  let video; const fragmented = Boolean(movie.mvex || top.some(box => box.type === 'moof'));
  for (const track of movie.traks) {
    const table = track.mdia?.minf?.stbl, entries = table?.stsd?.entries;
    requireValid(track.tkhd && track.mdia?.mdhd && track.mdia?.hdlr && entries?.length);
    const sampleCount = track.samples?.length || 0;
    const timeCount = table.stts?.sample_counts?.reduce((sum,n) => sum + n,0);
    requireValid(safe(sampleCount) && sampleCount <= MAX_SAMPLES && (fragmented || timeCount === sampleCount));
    for (const sample of track.samples || []) {
      requireValid(safe(sample.offset) && safe(sample.size) && sample.size > 0 && mdats.some(([start,end]) => sample.offset >= start && sample.offset + sample.size <= end));
      if(sample.description_index!==0||sample.description!==entries[0]||['encv','enca'].includes(sample.description?.type))fail('MEDIA_METADATA_UNSUPPORTED');
    }
    if (!video && track.mdia.hdlr.handler === 'vide') video = track;
  }
  if (!video) fail('VIDEO_MISSING');
  const table = video.mdia.minf.stbl, entry = table.stsd.entries[0];
  if (['encv'].includes(entry.type)) fail('MEDIA_METADATA_UNSUPPORTED');
  const width = entry.getWidth?.(), height = entry.getHeight?.(), timescale = video.mdia.mdhd.timescale;
  requireValid(Number.isInteger(width) && width > 0 && Number.isInteger(height) && height > 0 && safe(timescale) && timescale > 0);
  const {ticks,rawTicks}=playbackTimeline(video,movie.mvhd.timescale,fragmented);
  const frames = video.samples.length;
  requireValid(safe(ticks) && ticks > 0 && frames > 0);
  const duration = ticks / timescale;
  const movieTicks = movie.mvhd.duration, movieScale = movie.mvhd.timescale;
  requireValid(safe(movieTicks) && safe(movieScale) && movieScale > 0 && (movieTicks > 0 || fragmented));
  const containerDuration = movieTicks > 0 ? movieTicks/movieScale : Math.max(...movie.traks.map(track => {
    const samples=track.samples||[], scale=track.mdia.mdhd.timescale;
    if(!samples.length)return 0;
    const end=samples[samples.length-1].dts+samples[samples.length-1].duration;
    requireValid(safe(end)&&end>0&&safe(scale)&&scale>0);return end/scale;
  }));
  return { width,height,...geometry(entry,video.tkhd.matrix,width,height),duration,containerDuration,durationSource:'video-ticks',hasAudio:movie.traks.some(track => track.mdia.hdlr.handler === 'soun'),codec:codecName(entry.type),frames,fps:frames*timescale/rawTicks,...checked };
}
const crcTable = Array.from({ length:256 },(_,n) => { let c=n; for(let i=0;i<8;i++)c=c&1?0xedb88320^(c>>>1):c>>>1; return c>>>0; });
const crcUpdate = (crc,buffer) => { for(const byte of buffer)crc=crcTable[(crc^byte)&255]^(crc>>>8);return crc>>>0; };
async function probePng(handle,size) {
  let position=8, width,height,colour,depth, idat=0, ended=false, count=0, palette=false, dataEnded=false, metadata=8;
  while(position<size) {
    if (++count > MAX_BOXES) fail('MEDIA_METADATA_LIMIT');
    const head=await readAt(handle,position,8), length=head.readUInt32BE(0), type=head.toString('latin1',4,8);
    requireValid(position+12+length<=size && /^[A-Za-z]{4}$/.test(type));
    metadata+=12+(type==='IDAT'?0:length);if(metadata>MAX_METADATA)fail('MEDIA_METADATA_LIMIT');
    if(type==='acTL')fail('MEDIA_METADATA_UNSUPPORTED');
    let crc=crcUpdate(0xffffffff,head.subarray(4));
    for(let at=0;at<length;at+=65536)crc=crcUpdate(crc,await readAt(handle,position+8+at,Math.min(65536,length-at)));
    requireValid(((crc^0xffffffff)>>>0)===(await readAt(handle,position+8+length,4)).readUInt32BE(0));
    if(count===1){
      requireValid(type==='IHDR'&&length===13);const data=await readAt(handle,position+8,13);
      width=data.readUInt32BE(0);height=data.readUInt32BE(4);colour=data[9];depth=data[8];
      const depths={0:[1,2,4,8,16],2:[8,16],3:[1,2,4,8],4:[8,16],6:[8,16]};
      requireValid(width>0&&height>0&&width<=0x7fffffff&&height<=0x7fffffff&&depths[colour]?.includes(data[8])&&data[10]===0&&data[11]===0&&data[12]<=1);
    }else requireValid(type!=='IHDR');
    if(type==='PLTE'){requireValid(!palette&&!idat&&length>0&&length%3===0&&length<=768);palette=true;}
    if(type==='IDAT'){requireValid(!dataEnded&&(colour!==3||palette));idat+=length;}
    else if(idat)dataEnded=true;
    if(type==='IEND'){requireValid(length===0&&idat>0&&position+12===size);ended=true;break;}
    if(type[0]===type[0].toUpperCase()&&!['IHDR','IDAT','IEND','PLTE'].includes(type))fail('MEDIA_METADATA_UNSUPPORTED');
    position+=length+12;
  }
  requireValid(ended);
  return {width,height,displayGeometryKnown:true,displayWidth:width,displayHeight:height,duration:0,containerDuration:0,durationSource:'format',hasAudio:false,codec:'png',frames:1,fps:null,pixelFormat:colour===6?(depth===16?'rgba64be':'rgba'):colour===4?(depth===16?'ya16be':'ya8'):undefined,...checked};
}
async function inspect(file) {
  const handle = await fs.open(file,'r');
  try {
    const stat = await handle.stat(); requireValid(stat.isFile()&&safe(stat.size)&&stat.size>=8);
    const magic = await readAt(handle,0,Math.min(16,stat.size));
    if(magic.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return await probePng(handle,stat.size);
    if(magic.readUInt32BE(0)===0x1a45dfa3){const {probeWebm}=await import('./webm-probe.mjs');return await probeWebm(file);}
    if(['ftyp','wide','free','mdat','moov','skip'].includes(magic.toString('latin1',4,8)))return await probeMp4(handle,stat.size);
    fail('MEDIA_METADATA_UNSUPPORTED');
  } finally { await handle.close(); }
}
try { parentPort.postMessage({ok:true,result:await inspect(workerData.file)}); }
catch(error) { parentPort.postMessage({ok:false,code:error.code||'MEDIA_METADATA_INVALID'}); }
