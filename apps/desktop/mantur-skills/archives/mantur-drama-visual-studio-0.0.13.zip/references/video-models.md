2026-09-28 时长规则：Seedance 2.0 默认 4–15 秒，WAN 3.0 默认 4–30 秒；合法显式范围优先，平台实时 Schema 仍须通过。历史请求不修改。本地时长限制已同步，但不代表 WAN v3 自动接入已完成。

# 视频模型与平台启用门禁

2026-09-22 画面比例增量：正常项目准备应明确选择 `9:16` 或 `16:9`；若选择被绕过，Runtime 在首次封存时持久化 `9:16`。比例与模型一样初始化后固定。Runtime 将项目比例传给 Seedance／WAN 分镜，导入与视频准备复核模板比例，冲突阻断且不自动转换。

新项目在保存 project.json 和打开初始看板前必须确定视频模型。用户尚未明确时，与剧名、比例、分辨率和风格一起只询问一次“Seedance 2.0 / WAN 3.0”；不询问制作范围或交付目标。已明确则直接记录，不可用默认值代替用户选择。项目初始化后不提供模型切换或迁移。

唯一配置来源为 `project.json.video.model`：

| 本地模型 | 分镜算子 | 视频 profile |
|---|---|---|
| seedance-2.0 | op.drama.clip-seedance-compile | seedance-file-video-v1 |
| wan-3.0 | op.drama.clip-wan-compile | wan-file-video-v1 |

视频 provider 始终为 `manturhub:op.video.generate`。Seedance 时长按其独立实时契约与项目约束处理；新wan分镜采用 4–30 秒，调用以 [完整资产表 v3](wan-compilation-v3.md) 为准，不再套用旧的 5–15 秒提交限制。风格、分辨率和比例沿用用户项目选择。

用户于 2026-09-17 指定视频请求模型值为 `wan3.0-video`，替代此前的 `Wan3.0`；本地项目仍记录 `wan-3.0`。2026-09-21 实时视频 Schema 已正式公开该精确枚举，因此注册表保存 providerModel=wan3.0-video、artifactReady=true、platformModelReady=true、videoEnabled=true。同日单次真实付费调用返回同 Job 的 `source=final_video` PNG 尾帧，下载后与视频末帧 SSIM 为 1.0，据此设置 tailReady=true；该标志表示平台尾帧返回合同已验证，不表示跨 Clip 连续链已经验收。新初始化选择收据写入 provider_model=wan3.0-video；此前 provider_model=null 的 WAN 收据继续按原字节兼容，不迁移、不借机修改 project.json 或历史操作。仓库级脱敏验收记录不作为独立 Skill 包的运行依赖。

`open-workbench --on-project-ready` 对新项目检查模型并保存私有固定选择；后续分镜、导入和视频动作检查该记录，模型变化返回 PROJECT_VIDEO_MODEL_IMMUTABLE。该记录是约束凭据，不能用它覆盖 project.json。旧项目无此记录时按旧配置只读兼容；现有操作仍绑定其记录的模型、算子和合同。

同一步骤还保存私有 `runtime/video-ratio-selection.json`；后续项目比例变化返回 `PROJECT_VIDEO_RATIO_IMMUTABLE`。项目缺少 `video.ratio` 时先由 Runtime 在 `project.json` 持久化 `9:16`，再保存收据；已发布项目只读兼容且不借机改写。模型收据与比例收据相互独立，历史 WAN 模型收据不因本次能力更新而迁移。

## 当前平台合同与剩余缺口

2026-09-17 捕获的历史视频 Schema 枚举仍为 seedance、seedance-fast、seedance-mini、grok，未公布 WAN；该历史快照和当时的结论保持原样。2026-09-21 首次只读实时采集确认模型字典改为 seedance、seedance-fast、seedance-mini、wan3.0-video，并公开 WAN 独立条件分支。包内保留该完整输入 Schema 的已知良好指纹。同日后续实时 Schema 将禁止字段从 `not.anyOf.required` 改为 `seed:false`、`generate_audio:false`、`negative_prompt:false` 并更新说明文字；模型枚举、参数边界与输出 Schema 不变，完整输入指纹 `046b9512…` 经差异审核后加入已知良好库。自 2026-09-22 起，未知漂移必须通过包含 Seedance/WAN 模型条件、禁止字段和当前分辨率请求的完整语义检查，不能只按模型字段局部放行，也不会自动开放新增模型或参数。

WAN 本地统一模板仍保留分镜编译产生的 generate_audio、seed 控制及来源，便于历史兼容、模板审计和分镜一致性校验；转换为 `op.video.generate` 请求时不得发送平台 WAN 分支禁止的 `negative_prompt`、`seed`、`generate_audio`、`camera_fixed`。WAN 平台请求允许更宽的画幅枚举，但当前产品只开放项目固化的 `9:16` 与 `16:9`；不因平台上限更宽而静默修改项目参数。图片/音频分别按平台 WAN 上限 10/5 校验；现有引用和真实尾帧规则继续生效。

费用批准、模型和请求一致性、幂等提交及原任务恢复继续校验。后续同场 Clip 必须取得前一 Clip 的实际真实尾帧，缺失或不合规不能继续。枚举、请求合同以及单次真实付费尾帧返回均已验证；跨 Clip 注入、第二段承接、技术完成与导出仍未完成真实端到端验收。平台拒绝请求时返回实际错误，不自动更换模型或重新付费。

缺引用身份时要求平台补齐，不回退 URL，不伪造身份或猜测绑定。包内已包含基于真实样本的 drama-storyboard-wan-v1 / storyboard-status-cn-v1 解析器；未知内部版本、状态或媒体格式拒绝。

真实样本 Job=SUCCEEDED、businessStatus=REVIEW_REQUIRED，包含 6 个 Clip 和 29 个完整媒体引用。接入解析器将 `size` 转为 `metadata.resolution`，将 `metadata.input.media` 按原顺序转为共用 `metadata.content` 文件引用，逐项复核引用表及已确认 Manifest。中文连续性状态映射为本地状态；变体决策、冲突、审核驳回、警告与缺失原因保留。该历史样本的六条 `VARIANT_REVIEW_REQUIRED` 没有对应的 `basis=continuity` 结构化决策，仍作为未知变体问题阻断。只有当 WAN Clip 明确声明 `basis=continuity`、冲突指向同一 Clip 且已选资产与该决策一致时，“组内无前态”降级为不阻断提醒；原始 `REVIEW_REQUIRED` 和证据仍保留。

## 新wan提交与交付

新wan只执行 [完整资产表 v3 调用](wan-compilation-v3.md)。旧三参数请求、v2 差量清单以及旧 Runtime 的wan准备/提交/导入路径不用于新任务。交付原始 JSON/XLSX；页面与视频自动接入未适配前不推进，也不改写历史记录。

以下本地报告、模板转换与视频说明只适用于已由对应旧契约成功接入的历史产物，不代表新 v3 已具备自动接入能力。

## 本地报告 v2

新导入产物使用 `mantur.drama.clip-compilation/v2`，请求表为 `视频请求体`，并保存 `source_operator`、`video_model`、`source_contract_summary`。WAN 摘要包含 normalizer、状态合同版本、编译输入哈希及控制项来源。`请求体模板JSON` 保持 fileId / mediaRef / sha256 受控引用。原始 Job、PRIMARY_JSON、XLSX 和哈希不改写。转换发生在接入时；视频算子调用时只从统一模板构建现有请求结构，按注册表取模型值，并按当前前序 Run 注入真实尾帧。

旧 `mantur.drama.clip-compilation/v1` 和 legacy `Seedance2.0请求体` 通过 `runtime/clip-request-table.mjs` 的 clipRequests/clipRequestTable 读取；不批量迁移旧报告。提示词授权编辑保持原表名与原版本，不能借编辑迁移。两个表同时出现、表与版本不符或表类型错误时拒绝。版本切换创建新的 v2 组合报告，并保留每集原合同及原历史文件。

视频准备检查项目模型、分镜来源和模板模型；报价、批准、提交、恢复共用同一请求与私有 profile。旧 Seedance profile 和操作身份不变，WAN 单独命名。实际尾帧只进入本次请求，不写回基础模板。不增加页面写入口、模型切换、生成按钮或分镜人工确认。

## 验证边界

单元与隔离测试证明本地路由、旧版兼容、身份隔离、WAN 报价与批准提交及实际尾帧门禁。2026-09-21 的独立真实付费调用进一步证明 WAN 能生成视频并返回可物化的真实尾帧，但它绕过了完整 Skill 项目流程。发布前仍须在取得精确费用批准后，用两个同场 WAN Clip 验证一次批次批准、首段真实尾帧注入、第二段承接、技术完成和按集导出；不得为补充 fixture 擅自运行付费任务。
