# 本地锁与图片批量恢复

锁保护同一操作的提交、恢复和状态写入。锁忙不代表生成失败或完成，也不证明远端槽位已释放。页面不提供清锁、恢复或生成按钮。

## 锁诊断与恢复

新锁在完整写入、同步后，以同目录硬链接独占发布；中断可能留下唯一 `.tmp` 暂存文件，但不以半写主锁阻塞后续操作。项目需放在支持硬链接的本地文件系统上；不支持时报告 `PROJECT_LOCK_FILESYSTEM_UNSUPPORTED`，不退回覆盖写或无锁执行。

每次发布只清理本次创建的 `.tmp`，不扫描、回收历史暂存文件或其他调用的文件。清理遇到 `EPERM`／`EACCES`／`EBUSY` 时，最多尝试 3 次、间隔 30 毫秒；`ENOENT` 视为已清理，宿主明确拒绝和其他错误不反复重试。持续失败在 stderr 输出结构化警告 `PROJECT_LOCK_TEMP_CLEANUP_FAILED`，原因只包含 `access_denied`／`host_denied`／`busy`／`io_error`，同一次获取锁调用内同类警告只输出一次，不泄露路径、PID、token 或原始异常。警告不改变 stdout 的业务结果、退出码或原始错误，不表示主锁释放失败、任务失败或可以重提；Agent 先读取本次结果和原操作状态，提示本地清理异常，不能据此重新生成或清锁。权限持续拒绝或进程被强制终止仍可能留下暂存文件，本机制不承诺自动清除所有历史残留。

新主锁和 `.reap` 都保存 PID、随机 token、创建时间和可取得的系统进程启动标识。Windows 使用进程创建时间，Linux 使用 boot ID 与进程启动 tick，macOS 使用系统进程启动时间。启动标识不可取得时保守保留，不能把探测失败当作进程已退出。旧记录仍兼容；PID 不存在可以恢复，有可比的进程出生时间且晚于锁创建时间时可以证明旧 PID 被复用，其他旧活 PID 不仅凭锁的年龄回收。

对原操作再次执行正常恢复动作时，Runtime 自动处理能够证明已失效的主锁和回收记录。

Windows 短暂文件共享冲突仅在进入业务动作前重试获取锁；动作开始后不重放。释放时只重试清理自身锁，持续失败返回明确诊断，不能据此重新生成。

诊断使用只读命令：

```text
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" inspect-project-lock --lock ".pipeline-state/runtime/asset-operations/<operation_id>/operation.lock"
```

返回主锁与 `.reap` 各自的安全状态，不输出 PID、token、锁原文、远端标识或绝对路径。

| 结果／错误 | Agent 下一步 |
|---|---|
| `available` | 锁当前不存在；继续原操作，不新建生成意图 |
| `owner_live`／`PROJECT_BUSY`／`ONLINE_LOCK_UNAVAILABLE` | 可能有另一调用正在执行，按等待策略退避；保留任务与原槽位 |
| `owner_dead` | 原操作恢复会自动回收；不另写批量清锁脚本 |
| `owner_unknown`／`PROJECT_LOCK_OWNER_UNKNOWN` | 无法可靠读取进程身份，停止该项并诊断系统能力与权限 |
| `record_invalid`／`PROJECT_LOCK_INVALID` | 旧锁空白、损坏或无法识别；保留现场，不能循环清理或猜测属主 |
| `access_denied`／`PROJECT_LOCK_ACCESS_DENIED` | 检查项目访问权限及文件占用；不通过删除文件绕过 |
| `PROJECT_LOCK_RELEASE_FAILED` | 动作可能已保存成功，先读原 operation；不因释放锁失败重提付费任务 |
| `io_error` | 检查本地磁盘／读取故障；不能当作文件不存在 |

旧空白／损坏主锁没有可验证的持有者证据，Runtime 不提供强制删除入口。需要人工维护时，先让用户明确安排相关项目全部生产进程停止，复核没有后台调用，保留该锁与原操作状态备份，再由获授权维护者隔离具体文件。不能把“进程表没找到某 PID”“已经等很久”或“先备份了”当作批量删除全部锁的依据；不擅自停止看板服务。修复之后恢复原操作并回读，下载或快照故障不重提付费任务。

## 标准图片队列

平台批量生图和定制音色使用包内单次队列入口，不临时编写按退出码或缺失状态补位的扫描器。先按[素材批量计价](asset-operations.md#图片与定制音色的批量计价)执行 `prepare-asset-batch`，取得完整报价和用户批次批准，再保存项目内描述文件：

```json
{
  "schema_version": 1,
  "items": [
    { "operation_id": "<已有的64位操作ID>", "approval": "input/approved-image-01.json" },
    { "operation_id": "<另一已有操作ID>", "approval": "input/approved-image-02.json" }
  ]
}
```

`items` 保留批准顺序，不重排、不新增生成意图。仅恢复已提交项时可省略其 `approval`；这不授权提交未批准项。描述文件不是批准凭据，各次实际提交仍由原素材操作核验请求、报价、身份和批准。

```text
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" asset-operation-queue-status --input input/image-queue.json
node "<SKILL_DIR>/scripts/studio.mjs" --project "<PROJECT_DIR>" step-asset-operation-queue --input input/image-queue.json
```

status 只读本地，不联网、不写入。step 由 Agent 发起，只运行一轮，到期恢复优先，每项最多调用一次；本轮新提交按配置组共享短时实时报价复核，实际请求与批准仍逐项校验。返回后由 Agent 按每项 `next_at` 分段等待，再调用 step。它不是常驻调度器，不承诺对话结束后继续运行。队列接受 image／voice-design，混合时保守共享 5 个在途槽位；下方图片占用规则同样适用于定制音色，音色试听与审核仍遵守独立合同。

- 每轮扫描当前项目全部图片操作；受理未知、排队、运行和无法识别的状态占用槽位。任意操作记录无法读取时暂停新提交，仍可恢复可读的原任务。已超过 5 个在途时只恢复，不补交。
- 只有已保存的远端明确终态或已验证同步成功产物释放远端占用。本地下载、发布、审核仍单独处理，不能把远端成功当成素材已就绪。
- 重新读取权威 operation 后才决定补位，最多 5 个项目内已知在途图片操作。同一描述文件的 step 串行化；Agent 对同一项目只运行一个批量执行者。不同描述文件、多 Agent／设备仍不保证账号合计，平台最终限流；不建立跨项目共享额度池。
- 私有 `.pipeline-state/runtime/asset-queues/<queue_id>.json` 保存各项错误次数、下次执行时间和暂停状态。恢复仍以原 operation 为事实，队列记录不能修改其状态、幂等键或历史请求。
- 工具异常、`ok=false`、空结果或缺失 polling 都不能当作完成。失败按 30、60、120 秒退避；确定性错误或连续三次失败暂停该项并保留占用，独立项继续。没有进展时汇报诊断，不自动循环重置计数。
- 实际修复阻塞后，可由 Agent 执行一次 `step-asset-operation-queue --input input/image-queue.json --retry-blocked` 重新检查暂停项。该参数仅清除队列退避／暂停，不改变原任务终态、不绕过批准、不授权付费重跑。
- `remote_finished=true` 仅表示所有远端操作已终态。`action=review` 表示 Agent 还须检查候选、择优并调用 `apply-asset-review`，不是默认等待用户；此时 `finished=false`，不反复 resume 代替视觉检查。没有可靠证据时记录具体异常并集中报告，不能宣称完成。
- `finished=true` 表示各项已完成本地审核发布或远端明确失败终态；不代表全部成功或可交付。逐项核对 `review_status`；已记录 pending/rejected 或远端失败会使 `requires_attention=true`，只汇报真实就绪与异常数量。快照待恢复仍为 `finished=false`。检查证据和采用由 Agent 执行，单次 step 不生成视觉结论。

视频继续使用原有批次与场次链入口，不套用图片队列。真实宿主是否终止子进程必须凭现场证据判断；隔离测试不等于所有宿主已经完成验收。
