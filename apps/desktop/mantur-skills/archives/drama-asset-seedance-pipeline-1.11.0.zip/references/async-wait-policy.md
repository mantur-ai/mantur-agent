# 异步等待与轮询合同

资产提取和分镜编译都包含一次完整剧本级模型调用。HTTP提交成功只说明任务已进入队列，不代表模型应在60秒内完成。Agent工具的一次等待窗口与任务总执行时间是两个不同概念，不能把前者当成后者的超时。

## 两站等待策略

`.ai` 与 `.cn` 的业务合同一致，但项目状态必须记录实际站点并始终在同一站轮询。当前没有证据证明两站应使用不同的业务超时，因此两站分别声明、使用相同的保守窗口；以后只能根据线上指标调整，不能由Agent临时猜测。

| 环境 | 阶段 | 常见完成时间 | 长任务提醒阈值 | 最少观察窗口 | 轮询间隔 |
|---|---|---:|---:|---:|---|
| `https://hub.mantur.ai` | `extraction` 资产提取 | 5–15分钟 | 20分钟 | 30分钟 | 前2分钟每15秒；之后每30秒 |
| `https://hub.mantur.ai` | `clips` 分镜编译 | 5–15分钟 | 20分钟 | 30分钟 | 前2分钟每15秒；之后每30秒 |
| `https://hub.mantur.cn` | `extraction` 资产提取 | 5–15分钟 | 20分钟 | 30分钟 | 前2分钟每15秒；之后每30秒 |
| `https://hub.mantur.cn` | `clips` 分镜编译 | 5–15分钟 | 20分钟 | 30分钟 | 前2分钟每15秒；之后每30秒 |

“最少观察窗口”是允许把任务升级为“超过常见窗口”的最早阈值，不是杀死任务或判失败的超时。任务超过30分钟但状态仍为 `created/queued/running/pending/processing/in_progress` 时，保留任务ID，报告“仍在运行/已超常见窗口”，并按用户的完成要求继续监控；不得写成失败。

## 提交与恢复

1. 实时 `describe/quote` 并完成费用确认。
2. 使用稳定幂等键和 `manturhub run <算子> --json-file <参数文件> --no-wait`，只提交一次。
3. 收到 `task_id/poll_url` 后立即写入项目 `.pipeline-state`，再做任何等待。
4. 每次只等待不超过60秒，然后查询一次状态；60秒是Agent保持响应的节奏，不是任务截止时间。
5. 用受控动作保存状态和增量检查点：

```bash
manturhub skill exec drama-asset-seedance-pipeline poll-checkpoint --project "$PROJECT_DIR" -- \
  "$POLL_URL" --stage extraction --state-file .pipeline-state/asset-extract.json \
  --output-dir .pipeline-state/asset-extract-checkpoints

manturhub skill exec drama-asset-seedance-pipeline poll-checkpoint --project "$PROJECT_DIR" -- \
  "$POLL_URL" --stage clips --state-file .pipeline-state/clip-compile.json \
  --output-dir .pipeline-state/clip-checkpoints
```

6. Agent只在状态、checkpoint或阶段发生变化时向用户更新；长时间没有新checkpoint不等于任务失败。
7. 任务终态后保存完整结果、报告和计费回执。恢复会话时使用原 `poll_url` 查询，不能新建幂等键或重新扣费。

## 状态解释

- `created/queued/running/pending/processing/in_progress`：任务仍在运行，`failed=false`。
- `succeeded/success/completed/done`：成功终态。
- `failed/error/cancelled/canceled`：失败或取消终态，才允许报告任务失败。
- 单次 `status` 请求网络超时、5xx或连接中断：本次状态不可用，不代表任务失败。记录读取错误，按退避后的原 `poll_url` 重查；不得重新提交。
- 401/403：当前站点认证错误。报告认证问题并停止查询，不得把任务本身标为失败，也不得拿另一站Key尝试。
- 未知状态：明确返回状态契约错误并停止；不要猜成成功或失败。

## 进度沟通

- 60秒无终态：不发错误，只说明“任务已提交，仍在处理”。
- 15分钟后仍运行：可提示“仍在正常长任务窗口内”。
- 20分钟后仍运行：标记 `long_running=true`，附任务ID和最近状态/checkpoint；不重提。
- 30分钟后仍运行：标记“超过常见窗口但任务未失败”，继续监控或把原任务交回用户稍后查询；不得输出 `PROCESSING_FAILED`。
- 只有平台终态失败时，才汇报真实错误码、失败阶段、retryable和退款状态。
