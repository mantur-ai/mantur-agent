import fs from 'node:fs/promises';
import path from 'node:path';
import {execFile, fork} from 'node:child_process';
import {promisify} from 'node:util';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
import {publicProjectClient,executionContext} from './integration.mjs';
import {loadProject,atomicJson,check,withLock} from './project.mjs';
import {workbenchIdentity} from './workbench-identity.mjs';
import {openSystemBrowser} from './browser-launch.mjs';
import {modeView} from './production-mode.mjs';
import {projectGuidance} from './guidance.mjs';

const exec=promisify(execFile);
// Only non-secret process context is needed for this local review service.
export async function workbenchContext(env=process.env,options={}){
  return executionContext(env,options);
}
async function projectOrNull(dir){try{return await loadProject(dir);}catch(e){if(e.code==='ENOENT')return null;throw e;}}
// Reflect only the existing access-layer declaration; this is not an authenticated host identity.
function hostAttribution(source){
  if(typeof source!=='string'||!source)return {};
  return {hostAttribution:{source,verificationScope:'CALLER_DECLARED',...(source==='unknown'?{warning:{code:'HOST_SOURCE_UNKNOWN',
    message:'当前宿主来源未明确；已知当前宿主时请按公共接入说明补充来源，后续沿用检查返回的绑定参数。'}}:{})}};
}

/** Offline readiness only; checking an account never refreshes or creates a credential. */
export async function doctor(dir,{bindingArgs}={}){
  const nodeReady=Number(process.versions.node.split('.')[0])>=20;
  const p=await projectOrNull(dir);
  let observation;
  try { observation=await publicProjectClient({project:p,projectDir:p?dir:undefined,bindingArgs}).check(); }
  catch(error){observation={code:1,status:error.code||'PACKAGE_OR_CLI_UNAVAILABLE',message:error.message};}
  return {ready:nodeReady&&observation.code===0,readOnly:true,projectReady:!!p,
    checks:[{item:'Node.js',ready:nodeReady,version:process.versions.node},{item:'public-cli',ready:observation.code===0,status:observation.status}],
    ...hostAttribution(observation.source),
    ...Object.fromEntries(['loginInstructions','quickLoginInstructions','bindingArgs','bindingEnv','registrationUrl','accessMode','cliMinimumVersion','cliVersion'].filter(key=>observation[key]!==undefined).map(key=>[key,observation[key]])),
    capabilities:observation.capabilities||{},migrationStatus:'OFFLINE_CANDIDATE',verificationScope:'LOCAL_READINESS_ONLY',
    productionAcceptance:'NOT_CHECKED',hostAcceptance:'NOT_CHECKED'};
}

/** A novice entry returns the next real step instead of requiring hand-written JSON. */
export async function guide(dir){
  const p=await projectOrNull(dir);
  const next=projectGuidance(p);
  return p?{...next,productionMode:modeView(p),recoverableOperations:next.recoverableOperations||[]}:next;
}

/** One-shot CLI action starts a read-only viewer and returns its URL immediately. */
export async function openWorkbench(dir,options={}){
  const deadline=Date.now()+20000;
  for(;;){
    try{return await withLock(dir,()=>startOrReuseWorkbench(dir,options));}
    catch(e){if(e.code!=='PROJECT_LOCKED'||Date.now()>=deadline)throw e;await new Promise(resolve=>setTimeout(resolve,100));}
  }
}
async function startOrReuseWorkbench(dir,{bindingArgs}={}){
  const p=await loadProject(dir),stateFile=path.join(dir,'.preroll/workbench.json');
  const context=await workbenchContext(process.env,{projectDir:dir,bindingArgs});
  // Compare execution identity, not PATH discovery versus a persisted equivalent entry.
  const fingerprint=Object.fromEntries(Object.entries(context).filter(([key])=>!['LANG','MANTURHUB_PROJECT'].includes(key)&&!(key==='PATH'&&context.MANTURHUB_CLI_ENTRY)).sort(([a],[b])=>a.localeCompare(b)));
  const contextHash=crypto.createHash('sha256').update(JSON.stringify(fingerprint)).digest('hex');
  const attribution=hostAttribution(context.MANTURHUB_SOURCE);
  const identity=await workbenchIdentity(dir);let replaced=false,port=0;
  let prior;try{prior=JSON.parse(await fs.readFile(stateFile,'utf8'));}catch(e){if(e.code!=='ENOENT')throw Object.assign(Error('工作台状态无法读取，请先确认并关闭旧看板后重试。'),{code:'WORKBENCH_STATE_INVALID'});}
  if(prior){
    let url;try{url=new URL(prior.url);}catch{check(false,'WORKBENCH_STATE_INVALID','工作台地址记录无效，请核对原项目。');}
    if(url.protocol==='http:'&&url.hostname==='127.0.0.1'&&!url.username&&!url.password&&url.pathname==='/'&&!url.search&&!url.hash&&prior.projectId===p.id){
      if(prior.workbench?.projectKey===identity.projectKey)port=Number(url.port)||80;
      let response;try{response=await fetch(new URL('/api/snapshot',url),{signal:AbortSignal.timeout(1200)});}catch(e){check(e.cause?.code==='ECONNREFUSED','WORKBENCH_UNREACHABLE','旧看板状态尚不能确认，请检查旧看板后重试，避免重复启动。');}
      if(response){
        let snapshot;try{snapshot=await response.json();}catch{check(false,'WORKBENCH_PORT_IN_USE','原工作台端口已被其他服务占用，请核对后重试。');}
        check(response.ok&&snapshot.id===p.id,'WORKBENCH_PORT_IN_USE','原工作台端口已被其他服务占用，请核对后重试。');
        const copied=prior.workbench?.projectKey&&prior.workbench.projectKey!==identity.projectKey;
        if(copied){port=0;}else{
          check(!snapshot.workbench?.projectKey||snapshot.workbench.projectKey===identity.projectKey,'WORKBENCH_PORT_IN_USE','原工作台端口已被其他项目占用，请核对后重试。');
          if(prior.contextHash===contextHash&&snapshot.workbench?.buildId===identity.buildId&&snapshot.workbench?.projectKey===identity.projectKey&&snapshot.workbench?.version===identity.version)return {url:url.origin,readOnly:true,reused:true,workbench:identity,...attribution};
          await stopVerifiedWorkbench(prior,url,dir);port=Number(url.port)||80;
          let closed=false;for(let i=0;i<30;i++){try{await fetch(new URL('/api/snapshot',url),{signal:AbortSignal.timeout(500)});}catch(e){if(e.cause?.code==='ECONNREFUSED'){closed=true;break;}}await new Promise(resolve=>setTimeout(resolve,100));}
          check(closed,'WORKBENCH_RESTART_REQUIRED','旧看板可能正在同步状态或下载成片，尚未退出，请稍后重试。');replaced=true;
        }
      }
    }
  }
  const entry=fileURLToPath(new URL('./workbench.mjs',import.meta.url));
  const childEnv=Object.fromEntries(['PATH','HOME','USERPROFILE','LANG','SystemRoot','TEMP','TMP','APPDATA','LOCALAPPDATA'].filter(key=>typeof context[key]==='string').map(key=>[key,context[key]]));
  const child=fork(entry,[path.resolve(dir)],{detached:true,windowsHide:true,execArgv:[],stdio:['ignore','ignore','ignore','ipc'],env:childEnv});
  const control={token:crypto.randomBytes(32).toString('hex'),instanceId:crypto.randomUUID()};
  try{
    const started=await receiveChild(child,{type:'start',control,context,port});
    check(started?.ok&&started.url,started?.code==='WORKBENCH_PORT_IN_USE'?'WORKBENCH_PORT_IN_USE':'WORKBENCH_START_FAILED',started?.code==='WORKBENCH_PORT_IN_USE'?'原工作台端口已被其他服务占用，请核对后重试。':'工作台启动失败');
    check(started.workbench?.buildId===identity.buildId&&started.workbench?.projectKey===identity.projectKey,'WORKBENCH_VERSION_CHANGED','安装内容已变化，请重新打开工作台');
    await atomicJson(stateFile,{url:started.url,pid:child.pid,projectId:p.id,workbench:identity,control,contextHash});
    const committed=await receiveChild(child,{type:'commit'});
    check(committed?.ok&&committed.type==='committed','WORKBENCH_START_FAILED');
    child.disconnect();child.unref();
    return {url:started.url,readOnly:true,reused:false,workbench:identity,...attribution,...(replaced?{message:'已恢复本项目工作台，请在现有页面刷新。'}:{})};
  }catch(e){child.kill();throw e;}
}

function receiveChild(child,message){
  return new Promise((resolve,reject)=>{
    const finish=(error,data)=>{clearTimeout(timer);child.off('message',received);child.off('error',failed);child.off('exit',exited);error?reject(error):resolve(data);};
    const received=data=>finish(null,data),failed=()=>finish(Object.assign(Error('工作台启动失败'),{code:'WORKBENCH_START_FAILED'}));
    const exited=()=>failed(),timer=setTimeout(()=>finish(Object.assign(Error('工作台启动超时'),{code:'WORKBENCH_START_TIMEOUT'})),10000);
    child.once('message',received);child.once('error',failed);child.once('exit',exited);
    child.send(message,error=>{if(error)failed();});
  });
}

/** Called only after the cached endpoint identifies this project. Never trust a PID alone. */
export async function stopVerifiedWorkbench(prior,url,dir){
  const project=await loadProject(dir);
  const snapshot=await(await fetch(new URL('/api/snapshot',url),{signal:AbortSignal.timeout(1200)})).json();
  check(prior.projectId===project.id&&snapshot.id===project.id,'WORKBENCH_INSTANCE_UNVERIFIED');
  if(prior.control?.token&&prior.control?.instanceId){
    const stop=await fetch(new URL('/api/workbench/shutdown',url),{method:'POST',headers:{'X-Workbench-Control':prior.control.token,'X-Workbench-Instance':prior.control.instanceId},signal:AbortSignal.timeout(2000)});
    check(stop.ok,'WORKBENCH_RESTART_REQUIRED','旧看板身份校验未通过，请先关闭旧服务后重试。');return;
  }
  const message='旧看板无法安全自动关闭，请先关闭旧版看板服务，再运行 open-workbench；不会另启结果看板。';
  check(['darwin','linux'].includes(process.platform)&&Number.isInteger(prior.pid)&&prior.pid>0,'WORKBENCH_RESTART_REQUIRED',message);
  let command;try{command=(await exec('ps',['-p',String(prior.pid),'-o','command='],{timeout:2000,maxBuffer:8192})).stdout.trim();}catch{check(false,'WORKBENCH_RESTART_REQUIRED',message);}
  const entry=fileURLToPath(new URL('./workbench.mjs',import.meta.url));
  const canonical=await fs.realpath(dir);
  const candidates=new Set([`${process.execPath} ${entry} ${canonical}`,`${process.execPath} ${entry} ${path.resolve(dir)}`]);
  check(candidates.has(command),'WORKBENCH_RESTART_REQUIRED',message);
  process.kill(prior.pid,'SIGTERM');
}

/** Import is already committed before starting the optional viewer. */
export async function presentImportedProject(dir,result,{headless=false,open=openWorkbench,launch=openSystemBrowser,browser='host',reveal='new',bindingArgs}={}){
  const projectDir=await fs.realpath(dir);
  if(headless)return {...result,projectDir,headless:true};
  let workbench;
  try{workbench=await open(projectDir,{bindingArgs});}
  catch(error){if(error.code==='PROJECT_BUSINESS_CONFLICT'||/CLI_BINDING_CONFLICT|Connector /.test(error.message))throw error;return {...result,projectDir,warning:{code:'WORKBENCH_START_FAILED',reasonCode:['PROJECT_LOCKED','WORKBENCH_START_FAILED','WORKBENCH_START_TIMEOUT','WORKBENCH_STATE_INVALID','WORKBENCH_UNREACHABLE','WORKBENCH_INSTANCE_UNVERIFIED','WORKBENCH_RESTART_REQUIRED','WORKBENCH_VERSION_CHANGED','WORKBENCH_PORT_IN_USE'].includes(error.code)?error.code:'WORKBENCH_START_FAILED',message:'项目记录已保留，但工作台启动未完成；请按宿主权限机制处理后运行 open-workbench 重试。'},nextAction:'open-workbench'};}
  const requested=reveal==='always'||!workbench.reused;
  // One presentation owner: ordinary updates never ask a second browser to open.
  let presentation={owner:'host',action:requested?'open_browser':'refresh_browser',url:workbench.url,
    status:requested?'host_browser_required':'existing_page_update',visibility:'unverified',beforeNextAction:requested,
    message:requested?'先查找本项目已有页面并复用；地址变化时导航原页面，仅在没有页面时用宿主内置浏览器打开。宿主不支持时展示链接，不自动打开外部浏览器。':'在本项目已有页面内刷新；本次不请求新开页面。若用户反馈页面已关闭，再执行 open-workbench。'};
  if(browser==='auto'){
    presentation={owner:'system',action:requested?'open_browser':'refresh_browser',url:workbench.url,
      status:requested?'link_available':'existing_page_update',visibility:'unverified',beforeNextAction:false,
      message:requested?'已选择系统浏览器；不再请求宿主打开第二个页面。未出现页面时可使用此链接。':'沿用系统浏览器中的本项目页面，不另开宿主页面。'};
    if(requested)try{const opened=await launch(workbench.url);presentation.status=opened.status==='open_requested'?'open_requested':'link_available';if(opened.reasonCode)presentation.reasonCode=opened.reasonCode;}catch{presentation.reasonCode='BROWSER_OPEN_UNAVAILABLE';}
  }
  return {...result,projectDir,workbench,presentation,...(workbench.hostAttribution?{hostAttribution:workbench.hostAttribution}:{})};
}
