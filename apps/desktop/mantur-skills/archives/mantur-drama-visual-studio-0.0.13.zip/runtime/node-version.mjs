export const MINIMUM_NODE_VERSION = '18.20.8';

export function assertNodeVersion() {
  const version = process.versions.node;
  const parts = /^(\d+)\.(\d+)\.(\d+)$/.exec(version);
  const minimum = MINIMUM_NODE_VERSION.split('.').map(Number);
  const actual = parts ? parts.slice(1).map(Number) : [];
  const firstDifference = actual.findIndex((value, index) => value !== minimum[index]);
  if (!parts || (firstDifference >= 0 && actual[firstDifference] < minimum[firstDifference])) {
    const error = new Error(`Node.js >=${MINIMUM_NODE_VERSION} is required. Use a supported Node.js release and retry the same command.`);
    error.code = 'NODE_VERSION_UNSUPPORTED';
    throw error;
  }
}
