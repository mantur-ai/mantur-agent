import { createHash } from 'node:crypto';
import { existsSync, readFileSync, statSync } from 'node:fs';
import { relative, resolve } from 'node:path';
import { assertProjectWritePath, projectRoot, readJson, writeJson } from './common.mjs';
import { withProjectLock } from './project-lock.mjs';
import {refreshUiSnapshot} from './studio.mjs';

export function deliveryRecord(type, episode, clipIds, zip, status='ready', revisionOverride) {
  const root=projectRoot();
  const project=readJson(resolve(root,'.pipeline-state/project.json'),{object:true}),index=project.workflow_state?.clip_revisions,active=index?.active?.[String(episode)],storyboard_revision=revisionOverride??(index?.versions?.[active]?.baseline?'':active||'');
  const artifact=zip ? assertProjectWritePath(zip) : null;
  return {schema_version:1,delivery_id:`${type}-EP${String(episode).padStart(2,'0')}${storyboard_revision?'-'+storyboard_revision:''}`,storyboard_revision,type,episode_id:`EP${String(episode).padStart(2,'0')}`,
    expected_clip_ids:clipIds,included_clip_ids:status==='ready'?clipIds:[],status,updated_at:new Date().toISOString(),
    ...(artifact?{artifact_path:relative(root,artifact).replaceAll('\\','/'),artifact_sha256:createHash('sha256').update(readFileSync(artifact)).digest('hex'),artifact_bytes:statSync(artifact).size}:{}),
    validation:{status:status==='ready'?'passed':'pending',checks:status==='ready'?[{code:'EXPORT_VERIFIED',passed:true,message:'目标 Clip、媒体完整性和导出结构通过。'}]:[]}};
}

export async function saveDelivery(record, {refresh=true} = {}) {
  await withProjectLock(assertProjectWritePath(resolve(projectRoot(),'.pipeline-state/runtime/deliveries.lock')),async()=>{
    const root=projectRoot();
    const project=readJson(resolve(root,'.pipeline-state/project.json'),{object:true});
    const manifestPath=resolve(root,'.pipeline-state/manifest.json');
    const manifest=existsSync(manifestPath)?readJson(manifestPath,{object:true}):{};
    const target=assertProjectWritePath(resolve(root,project.workflow_state?.deliveries||manifest.authoritative_files?.deliveries?.path||'.pipeline-state/deliveries.json'));
    const data=existsSync(target)?readJson(target,{object:true}):{schema_version:1,items:[]};
    if(!Array.isArray(data.items)) throw new Error('Invalid delivery index');
    const items=data.items.filter(row=>row.delivery_id!==record.delivery_id);
    writeJson(target,{...data,items:[...items,record]});
  });
  if (!refresh) return {snapshot_refresh:{ok:true,deferred:true}};
  // Expose building/ready/failed transitions; a display failure must not undo an export.
  try {return {snapshot_refresh:{ok:true,...refreshUiSnapshot([])}};}
  catch(error){return {snapshot_refresh:{ok:false,code:error.code||'SNAPSHOT_REFRESH_FAILED',production_result_preserved:true}};}
}

export function expectedClips(episode) {
  const root=projectRoot();
  const project=readJson(resolve(root,'.pipeline-state/project.json'),{object:true});
  const manifestPath=resolve(root,'.pipeline-state/manifest.json');
  const manifest=existsSync(manifestPath)?readJson(manifestPath,{object:true}):{};
  const path=project.clip_compile?.enriched_report||project.clip_compile?.legacy_compile_report||project.workflow_state?.clip_compile_report||manifest.authoritative_files?.clip_compile_report?.path||'.pipeline-state/results/clip-compile-report.json';
  const report=readJson(assertProjectWritePath(resolve(root,path)),{object:true});
  const rows=(report['Clip总表']||[]).filter(row=>Number(row['集数'])===episode).sort((a,b)=>Number(a['集内序号'])-Number(b['集内序号']));
  const ids=rows.map(row=>row['Clip ID']);
  if(!ids.length||new Set(ids).size!==ids.length) throw new Error('Expected episode Clip set is missing or duplicated');
  return ids;
}
