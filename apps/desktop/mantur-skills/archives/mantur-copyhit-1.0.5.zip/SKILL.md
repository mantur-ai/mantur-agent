---
name: mantur-copyhit
title: 爆款视频复刻
description: 把一条现成的爆款带货/口播视频，换成用户自己的产品、人物、道具，复刻出一条画面、节奏、卖点都对齐的同款短视频（保留原片音色配音）。只要用户想"复刻 / 对标 / 仿写 / 翻拍 / 套版 / 借鉴某条爆款视频做一条自己的"，或说"把这条视频换成我的产品再做一条""照着这个爆款做个同款""帮我仿一条这种带货视频""这条视频很火，用我的货也来一条"，就用本 skill——即使用户没明说"复刻"二字。覆盖任意品类（食品饮料 / 美妆 / 3C / 服饰 / 日用 / 保健）与任意平台（抖音 / 快手 / 视频号 / 小红书 / TikTok）。不适用于：从零原创脚本视频、纯剪辑拼接已有素材、只擦字幕、只做配音、只生成单张图。
category: 视频制作
version: 1.0.5
triggers:
  - 爆款复刻
  - 爆款视频复刻
  - 复刻视频
  - 对标视频
  - 同款视频
  - 视频套版
  - 爆款翻拍
  - 仿写爆款
  - 换成我的产品再做一条
  - 照着这个爆款做
uses_operators:
  - op.video.understand-v2
  - op.video.grid
  - op.video.compose
  - op.image.generate
  - op.video.generate
  - op.audio.extract
---

## 平台接入（ManturHub 自动注入）

### 认证
首次使用先运行 `manturhub login` 完成浏览器授权；CLI 会保存并复用登录凭证。
自动化环境也可设置 `MANTURHUB_KEY`。REST 请求统一使用 `x-api-key: <YOUR_KEY>`，API Key 可在当前 ManturHub 站点的 `/dashboard/api-keys` 创建。

### 算子调用
优先使用 `manturhub run <算子ID> --json '{...}'`；异步任务由 CLI 自动轮询并返回最终结果。
直接调用 REST 时，以 `manturhub describe <算子ID>` 返回的实时 schema 和轮询说明为准。
任务失败由平台自动退费，无需在 Skill 中实现重复扣费或退款逻辑。

### 文件上传
本地文件必须先换成公网 URL 再传给算子：
- CLI：`manturhub upload <本地文件>` → 返回可直接传给算子的公网 URL
- REST：`POST /api/v1/uploads/presign` → 拿 `put_url` PUT 上传 → 用 `access_url`

### 执行前自检
1. 先运行 `manturhub describe <算子ID>` 获取实时参数 schema，不要凭 Skill 内的历史示例猜参数。
2. 调用前运行 `manturhub quote <算子ID>` 查实时价格。
3. 调用所需的本地素材先运行 `manturhub upload <本地文件>`，不要把本地路径直接传给算子。

### 算子引用门禁

- 只使用 `manturhub ls` 当前返回且状态为 `online` 的正式算子 ID；调用前必须运行 `manturhub describe <算子ID>`。
- 禁止历史别名、离线/受限算子和 Skill 内未出现在实时目录中的 ID；如果依赖不可用，直接报告不可用，不自行拼接替代算子链。

### 本 Skill 依赖算子
- `op.video.understand-v2`（视频/图像理解算子）：`manturhub quote op.video.understand-v2`
- `op.video.grid`（视频宫格图生成）：`manturhub quote op.video.grid`
- `op.video.compose`（视频合成拼接）：`manturhub quote op.video.compose`
- `op.image.generate`（AI 图片生成）：`manturhub quote op.image.generate`
- `op.video.generate`（AI 视频生成）：`manturhub quote op.video.generate`
- `op.audio.extract`（视频音色提取）：`manturhub quote op.audio.extract`

---

# 爆款视频复刻（mantur-copyhit）

把一条别人的爆款带货/口播视频，**换成用户自己的产品/人物/道具**，复刻出一条**画面构图、镜头节奏、卖点结构都对齐**的同款短视频，并保留原片音色配音。

**输入**：① 一条爆款原视频；② 用户要替换的素材——新产品图（多角度更好）、新人物图、新道具图（按需）。
**输出**：一条复刻成片（默认竖屏 9:16、带配音），过程中沉淀一整套可复用的 JSON / 提示词 / 中间图。

这套流程**与品类无关**——橙汁、口红、耳机、卫衣都同样适用。下面以"原片产品 → 用户新产品"的通用视角描述；遇到具体品类，把对应元素代进去即可。

---

## 核心原则（先理解，再照做）

- **复刻 ≠ 原创**：目标是"换产品的同款"，不是新广告。**保留原片每个镜头的节奏、时长、转场、口播结构**，只把元素（产品/人物/道具/品牌/卖点）平移成用户的。理解这一点，后面每步才不会跑偏成"自由发挥"。
- **数据贯穿全程**：每个阶段的 JSON / 图 / 视频产出，**就是下一阶段的入参**。所以每步都要落盘、命名清晰，断了某一环后面就接不上。
- **逐阶段和用户确认**：每个关键产出（拉片 JSON、新宫格图、视频提示词、每段成片）**先给用户看、确认无误再进下一步**。这是"出品确定"的 skill，不是一把梭——中间错一步，后面全废、还白烧馒头。
- **正文是地图，references 是分册**：主流程在这里，**细节按需翻 reference**，别把长提示词/规范背在脑子里：
  - 五个引擎的**提示词原文** + 新宫格重绘 prompt → 读 `references/engines.md`
  - 各阶段 **JSON 结构** → 读 `references/schemas.md`
  - **算子调用要点 + 踩坑**（出片参数、URL 过期、切分、拼接等）→ 读 `references/operators.md`
  - **能力全部走算子中台**（已无本地依赖）：切分/拼接 `op.video.compose`、宫格 `op.video.grid`、拉片 `op.video.understand-v2`、抽音色 `op.audio.extract`、新宫格 `op.image.generate`、出片 `op.video.generate`；`scripts/` 里的本地脚本**仅作中台不可用时的回退**

> 平台接入（认证、算子异步 invoke+poll、自动退费、估价、上传 presign）由平台注入，**不在本文范围**。本文只写业务流程。

---

## 总流程 · 10 个阶段

| # | 阶段 | 用什么 | 产出 |
|---|------|--------|------|
| 0 | 素材准备 & 分段切分 | `op.video.compose`(切分) + 上传 | 分段视频、替换素材 URL |
| 1 | 宫格图生成（拆解原片） | `op.video.grid` | 每段 4×3 = 12 宫格图 |
| 2 | 拉片分析 | `op.video.understand-v2`（超时回退本地/外部）+ 引擎①提示词 | `analysis_*.json` |
| 3 | 元素信息提取 | 引擎②提示词 | `element_*.json` |
| 4 | 元素替换映射 | 规则 + `op.audio.extract`(抽音色) | `element_mapping.json` + 音色样本 |
| 5 | 脚本文案改写 | 引擎③+④提示词 | `script_*.json` |
| 6 | 新宫格图生成 | `op.image.generate`（mode=edit） | `new_grid_*.png` |
| 7 | 视频提示词生成 | 引擎⑤模板 | `video_prompt_*.md` |
| 8 | 视频出片 | `op.video.generate` | 每段 15s 带声视频 |
| 9 | 拼接成片 | `op.video.compose` | 完整复刻成片 |

> **分段约定**：原片按 **15 秒一段**切分（多数口播爆款 15s 是一个完整卖点节拍）。30s 原片 = 2 段、45s = 3 段，逐段跑 1→9，最后阶段 9 拼起来。

---

## Step 0 · 素材准备 & 分段切分

1. 让用户给齐：**原视频** + **要替换的素材**（产品图，人物图、道具图按需——没有的元素就保留原片）。
2. 把原视频按 15 秒切段。**默认用算子 `op.video.compose`**：每段一个 `trim`（如取 0-15s、15-30s）输出成一段。先上传原视频拿 URL 再调；用法见 `references/operators.md`。（中台不可用时回退 `scripts/split_video.sh`，走 ffmpeg 重编码、不能 `-c copy`，否则切点跳关键帧、对不齐。）
3. 把所有本地文件上传换成公网 URL（算子只吃 URL）。
4. ⚠️ **URL 有"上游时效"**：上传后几小时，上游算子可能就拉不动了（见 operators.md 的"图 URL 过期"坑）。所以**临到出片（阶段 8）前再统一上传一次**，别在 Step 0 就上传完等着。

**产出**：`partN/原视频_partN.mp4` 各段 + 替换素材文件（建议放 `replace_assets/`）。

---

## Step 1 · 宫格图生成（拆解原片）

把每段抽成 **4 行 3 列 = 12 格**的关键帧拼图。这张宫格图是后面所有阶段共用的**构图/机位/景别/动作基准**——它定义了"复刻要还原成什么样"。

- 算子 `op.video.grid`，参数 `grid="4x3"`（4 行 3 列）、`storyboards:[{start,end}]` 按段各出一张。
- **入参来源**：Step 0 的分段视频 URL。
- 详细参数见 `references/operators.md`。

**产出**：每段一张 12 宫格图。

---

## Step 2 · 拉片分析

逐格拆解原片，输出严格 JSON：固定 **12 个 sourceGrid.cells（关键帧）+ 12 个 segment.cells（分镜）**，记录景别、构图、运镜、光线、主体、动作、字幕、人物占比、卖点、音色线索。

- **优先用算子中台 `op.video.understand-v2`**：喂入「分段视频 URL + 引擎①提示词」做拉片理解。所有能力都优先走中台算子（统一计费、统一接入、自动退费）。
  - **回退策略**：拉片提示词很长、输出很大，understand-v2 喂超长 prompt 可能网关超时（502/504）。**确实超时再回退**——用外部长上下文多模态模型（如 Gemini 3.5 Flash），或本地视觉（ffmpeg 抽帧拼成宫格 + 看图逐格写 JSON）。无论用哪条，**输出的 JSON 结构必须一致**。回退判断与做法见 `references/operators.md`。
- **字幕 + 时间戳单独精确提取**：用 `op.video.understand-v2`（model 建议 `gemini`）+ **字幕/时间戳提取引擎**（engines.md §1b）逐句提取台词/旁白/字幕 + 精确 `startMs/endMs`，写进 `originalScript`。**别让拉片大 JSON 顺带产字幕时间戳**——单独提才准，它是 Step 5 逐镜改写、配音节奏的基础。
- **引擎①提示词原文**：读 `references/engines.md` → §1。
- **输出 JSON 结构**：读 `references/schemas.md` → analysis。
- **入参来源**：宫格图（S1）+ 分段视频（S0）+ 固定分段(segmentIndex/start/end)。

**产出**：`analysis_partN.json`。**给用户确认**逐格描述是否准确，再继续。

---

## Step 3 · 元素信息提取

把每个**要替换的新元素**结构化，为"换成什么"打底。核心是产品的 **productLock 8 维**（名称/类别/形状/颜色/材质/图案/细节/包装）+ 卖点 + 使用场景 + 负向词。

- **只用用户上传的替换素材**提取，**不沿用原片产品未确认的品牌/卖点/功效**——否则会把别人的卖点安到用户产品上，既不准又有合规风险。
- **引擎②提示词原文**：`references/engines.md` → §2。**JSON 结构**：`schemas.md` → element。
- **入参来源**：拉片 `elementsPreview`（S2）+ 用户替换素材图（S0）。

**产出**：`element_partN.json`。

---

## Step 4 · 元素替换映射

建一张映射表，逐元素标 **REPLACE / KEEP**：人物→新人物、产品→新产品、道具→新道具、品牌随产品换；**没有替换素材的元素（场景、器皿等）一律 KEEP**，保留原片。

- **音色默认 KEEP 不替换**，但要**按人物说话时间戳抽原声样本**存档（出片靠它驱动口型/保持原音色）。用算子 **`op.audio.extract`**：传 `src`(原视频 URL) + `start` + `duration`，**音色样本至少 5 秒**（平台要求 5-10s）；它**默认自动 AI 分离人声、去 BGM** 得纯净样本（`channels:1`、按需 `denoise`）。用法见 `references/operators.md`。（中台不可用时回退 `scripts/extract_voice.sh`。）
- **入参来源**：元素提取 JSON（S3）+ 替换素材（S0）+ 原片音轨（S0）。**结构**：`schemas.md` → mapping。

**产出**：`element_mapping.json` + `voice_sample/voice_3s.wav`。

---

## Step 5 · 脚本文案改写（两步）

1. **引擎③ 出改写方向** `rewriteDirection`（目标人群/表达角度/卖点承接/节奏/口播风格）。
2. **引擎④ 逐镜改写**：严格对位原片每个 cell，**只把产品/元素平移**（如 原品类词→新品类词、原品牌→新品牌），**保留每镜节奏/时长/转场，不重新创作、不加戏**。

- ⚠️ **去掉字幕重叠词**：原片字幕常在分镜切分处重复词（如"…用了 / 用了 3 个…"）。作为**连续配音文案**要把衔接处的重复字去掉，否则配音会念两遍。
- **引擎③④提示词原文**：`references/engines.md` → §3、§4。**入参**：拉片 cells + originalScript（S2）+ 替换产品 productLock/卖点（S3/S4）+ 投放平台。

**产出**：`rewrite_direction.json` + `script_partN.json`（含逐镜 `shots[].newCopy`）。

---

## Step 6 · 新宫格图生成

图生图**重绘**一张新 12 宫格：导入 **老宫格（构图/光线/机位基准）+ 新产品 + 新人物 + 新道具**，严格按老宫格每格的机位/景别**逐格替换元素**，其余（场景、器皿、夜景光线等 KEEP 的）保持不变。

- 算子 `op.image.generate`，`mode=edit`，`images=[老宫格, 新产品, 新人物, 新道具]`，prompt 里用 `[图1]…[图4]` 点名。
- **⚠️ op.image.generate 返回 base64（不是 URL）**——用 `scripts/save_image_b64.py` 解码存盘。
- **重绘 prompt 模板** + 人物分布写法：`references/engines.md` → §6。**入参**：老宫格（S1）+ 新素材（S0/S4）+ 拉片逐格画面描述（S2）。

**产出**：`new_grid_partN.png`。**给用户确认**：人物一致性、产品标签清晰、该露脸/该只露手的格子对不对，再继续。

---

## Step 7 · 视频提示词生成

用**引擎⑤模板**，把模板里的 `[]` 占位符**全部用前面 JSON 的真实值填实**，产出每段可直接驱动视频生成的**最终提示词**：平台/风格/场景/光线/产品外观/声音风格 +（把 12 镜**合并成 5 个 3 秒时间段**的画面与口播）。

- **模板 + `[]`↔来源映射表**：`references/engines.md` → §5。**入参**：新宫格（S6）+ 拉片场景/光线/镜头（S2）+ 产品名/外观/卖点（S3/S4）+ 逐镜口播 newCopy（S5）。
- **12→5 合并**：0-3s=镜1-3 / 3-6s=镜4-5 / 6-9s=镜6-7 / 9-12s=镜8-10 / 12-15s=镜11-12（按各镜起止落进对应 3 秒窗，可微调）。

**产出**：`video_prompt_partN.md`（每段一份最终提示词，措辞干净、无"替换/可换"等工具痕迹）。

---

## Step 8 · 视频出片

用 `op.video.generate` 的 **multimodal 模式**，一次喂入「提示词 + 4 张参考图 + 音色音频」生成 15s 带声视频。**这是最容易踩坑的一步，出片前务必读 `references/operators.md` → 出片参数**。三个关键点：

- `model:"seedance"`，`images=[宫格,产品,人物,道具]`（prompt 里 `@Image1~4` 点名，`image_roles` 全 `reference_image`）。
- **`images` 上限 9 张（算子硬限制）**：⚠️ 某类参考图过多时别全塞——**产品图超过 4 张（多角度）就先用 `op.image.generate` 合成一张「产品多角度拼图」**，作为单张产品图（`@Image2`）传入；这样既不超 9 张、也避免产品被拆成 @Image2~6 点名混乱。人物/道具同理，多张先合一张。合成用法见 `references/operators.md` → §3。
- `ref_audios=[音色样本]` 驱动口型；**`generate_audio:true` 必须传**——不传成片**没有声音**（默认 false，且文档没列这个字段，是隐藏开关）。
- **出片前重新上传所有素材换全新 URL**（旧 URL 上游拉不动 → `resource download failed`，见踩坑）。
- **分辨率**默认 720p（最省可行档，已验证 480p 在 multimodal 下常被拒）；要高清用 1080p。

**入参来源**：视频提示词（S7）+ 新宫格（S6）+ 产品/人物/道具图（S0/S4）+ 音色（S4）。
**产出**：`video_partN.mp4`（15s · 9:16 · 带声）。**给用户看每段**，台词/音色/口型有问题就回 S5/S7 调。

---

## Step 9 · 拼接成片

把各段 15s 视频按顺序拼成完整成片。**默认用算子 `op.video.compose`**：同一 track 里依次排各段、用 `target_time` 接续（0-15s、15-30s…）输出统一规格的成片；用法见 `references/operators.md`。（中台不可用时回退 `scripts/concat_videos.sh`，ffmpeg 先把各段 scale 到同一分辨率+帧率再 concat，否则错位/失败。）

**入参来源**：各段 15s 视频（S8）。**产出**：`video_full.mp4` —— 最终复刻成片，交付用户。

---

## 收尾

- 复盘：把这次的引擎提示词、JSON、参数沉淀好，便于复用与二次迭代。
- 如需进一步处理，先用 `manturhub ls` 确认目标算子当前为 online，再单独执行；本 Skill 不预置额外算子链。
- 遇到任何"上游失败 / 没声音 / 人物不一致 / 分辨率不匹配"，**先翻 `references/operators.md` 的踩坑速查**，多数问题那里有定论，别盲目改 prompt。
